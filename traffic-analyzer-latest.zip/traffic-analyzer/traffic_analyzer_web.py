#!/usr/bin/env python3
"""Interface web do Traffic Analyzer v1.71.3 para MeshMonitor."""

import base64
import csv
import hashlib
import hmac
import io
import ipaddress
import json
import os
import re
import secrets
import sqlite3
import statistics
import subprocess
import sys
import threading
import time
import tempfile
import zipfile
from datetime import datetime
import urllib.error
import urllib.parse
import urllib.request

import mesh_commands as meshcmd
import automation_manager as automgr
import firmware_announcer as firmware_notices
from mesh_command_dispatch import MeshCommandDispatcher
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

APP_VERSION = "1.71.3"
try:
    _version_path = Path(__file__).with_name("VERSION")
    if _version_path.exists():
        APP_VERSION = _version_path.read_text(encoding="utf-8").strip() or APP_VERSION
except Exception:
    pass

BIND = os.getenv("MAP_BIND", "0.0.0.0")
PORT = int(os.getenv("MAP_PORT", "8788"))
TITLE = os.getenv("MAP_TITLE", "Traffic Analyzer - MeshMonitor - por Alex, PT2VHF")
def _display_title(title: str) -> str:
    if title.startswith("Traffic Analyzer"):
        return title.replace("Traffic Analyzer", f"Traffic Analyzer v{APP_VERSION}", 1)
    return f"{title} - v{APP_VERSION}"
DISPLAY_TITLE = _display_title(TITLE)
TOPOLOGY_FILE = Path(os.getenv(
    "TOPOLOGY_FILE",
    "/var/lib/traffic-analyzer/topology.json",
))
TOPOLOGY_HISTORY_QUEUE_DIR = Path(os.getenv(
    "TA_TOPOLOGY_HISTORY_QUEUE_DIR",
    str(TOPOLOGY_FILE.parent / "topology-history-queue"),
))
MM_BASE_URL = os.getenv("MM_BASE_URL", "http://127.0.0.1:3001").rstrip("/")
MM_API_TOKEN = os.getenv("MM_API_TOKEN", "").strip()
MM_SOURCE = os.getenv("MM_SOURCE", "default").strip() or "default"
NODE_QUERY_BACKEND = os.getenv("TA_NODE_QUERY_BACKEND", "auto").strip().lower() or "auto"
if NODE_QUERY_BACKEND not in {"auto", "virtual", "meshmonitor"}:
    NODE_QUERY_BACKEND = "auto"
VIRTUAL_NODE_HOST = os.getenv("TA_VIRTUAL_NODE_HOST", "127.0.0.1").strip() or "127.0.0.1"
try:
    VIRTUAL_NODE_PORT = int(os.getenv("TA_VIRTUAL_NODE_PORT", "4404"))
except (TypeError, ValueError):
    VIRTUAL_NODE_PORT = 4404
VIRTUAL_NODE_PYTHON = os.getenv(
    "TA_VIRTUAL_NODE_PYTHON",
    str(Path(__file__).with_name(".venv") / "bin" / "python"),
).strip()
VIRTUAL_NODE_HELPER = Path(os.getenv(
    "TA_VIRTUAL_NODE_HELPER",
    str(Path(__file__).with_name("meshtastic_query.py")),
))
VIRTUAL_NODE_CONNECT_TIMEOUT = max(2, min(int(os.getenv("TA_VIRTUAL_NODE_CONNECT_TIMEOUT", "10")), 30))
VIRTUAL_NODE_QUERY_TIMEOUT = max(10, min(int(os.getenv("TA_VIRTUAL_NODE_QUERY_TIMEOUT", "30")), 120))
TRAFFIC_ARCHIVE_DB = Path(os.getenv(
    "TRAFFIC_ARCHIVE_DB",
    "/var/lib/traffic-analyzer/traffic.db",
))
VIRTUAL_QUERY_STATE_DIR = Path(os.getenv(
    "TA_VIRTUAL_QUERY_STATE_DIR",
    str(TRAFFIC_ARCHIVE_DB.parent / "query-jobs"),
))
ACCESS_LOG_FILE = Path(os.getenv(
    "TA_ACCESS_LOG_FILE",
    str(TRAFFIC_ARCHIVE_DB.parent / "access.log"),
))
ACCESS_LOG_MAX_BYTES = max(1_000_000, int(os.getenv("TA_ACCESS_LOG_MAX_BYTES", str(20 * 1024 * 1024))))
ACCESS_RETENTION_DAYS = max(0, int(os.getenv("TA_ACCESS_RETENTION_DAYS", "365")))
ACCESS_GEOIP_URL = str(os.getenv("TA_ACCESS_GEOIP_URL", "")).strip()
_access_log_lock = threading.Lock()
_access_geo_lock = threading.Lock()
_access_geo_cache = {}
ARCHIVE_POLL_SECONDS = max(1.0, float(os.getenv("ARCHIVE_POLL_SECONDS", "2")))
ARCHIVE_PAGE_SIZE = max(100, min(int(os.getenv("ARCHIVE_PAGE_SIZE", "500")), 1000))
ARCHIVE_OVERLAP_MS = max(1000, int(os.getenv("ARCHIVE_OVERLAP_MS", "10000")))
TRACEROUTE_HISTORY_PAGE_SIZE = max(100, min(int(os.getenv("TA_TRACEROUTE_HISTORY_PAGE_SIZE", "2000")), 2000))
TRACEROUTE_HISTORY_FALLBACK_LIMIT = max(5000, min(int(os.getenv("TA_TRACEROUTE_HISTORY_FALLBACK_LIMIT", "50000")), 250000))
TRACEROUTE_HISTORY_MAX_RECORDS = max(0, int(os.getenv("TA_TRACEROUTE_HISTORY_MAX_RECORDS", "0")))
TRACEROUTE_HISTORY_INITIAL_LIMIT = max(1000, min(int(os.getenv("TA_TRACEROUTE_HISTORY_INITIAL_LIMIT", "5000")), 50000))
TRACEROUTE_HISTORY_MAX_LIMIT = max(
    TRACEROUTE_HISTORY_INITIAL_LIMIT,
    min(int(os.getenv("TA_TRACEROUTE_HISTORY_MAX_LIMIT", "250000")), 1000000),
)
TRACEROUTE_PAIR_HISTORY_LIMIT = max(10, min(int(os.getenv("TA_TRACEROUTE_PAIR_HISTORY_LIMIT", "1000")), 1000))
TRACEROUTE_PAIR_RECONCILE_MAX_PAIRS = max(0, int(os.getenv("TA_TRACEROUTE_PAIR_RECONCILE_MAX_PAIRS", "0")))
ARCHIVE_RETENTION_ALLOWED_DAYS = {0, 1, 7, 30}
try:
    _archive_retention_env = int(os.getenv("ARCHIVE_RETENTION_DAYS", "0"))
except (TypeError, ValueError):
    _archive_retention_env = 0
ARCHIVE_RETENTION_DEFAULT_DAYS = _archive_retention_env if _archive_retention_env in ARCHIVE_RETENTION_ALLOWED_DAYS else 0
ARCHIVE_SETTINGS_FILE = Path(os.getenv("TA_ARCHIVE_SETTINGS_FILE", str(TRAFFIC_ARCHIVE_DB.parent / "archive-settings.json")))
_archive_stop = threading.Event()
_archive_status_lock = threading.Lock()
_archive_status = {"running": False, "last_sync_ms": None, "last_error": None, "inserted_last_sync": 0}
_topology_refresh_lock = threading.Lock()
_version_status_lock = threading.Lock()
_version_status_cache = {"checked_at": 0.0, "data": None}
VERSION_CHECK_DEFAULT_MINUTES = 15
VERSION_CHECK_MIN_MINUTES = 5
VERSION_CHECK_MAX_MINUTES = 1440
GITHUB_RELEASES_LATEST_URL = "https://api.github.com/repos/alexpmr/traffic-analyzer/releases/latest"
UPDATE_SETTINGS_FILE = Path(os.getenv("UPDATE_SETTINGS_FILE", "/var/lib/traffic-analyzer/update-settings.json"))
UPDATE_REQUEST_FILE = Path(os.getenv("UPDATE_REQUEST_FILE", "/var/lib/traffic-analyzer/update-request.json"))
UPDATE_STATUS_FILE = Path(os.getenv("UPDATE_STATUS_FILE", "/var/lib/traffic-analyzer/update-status.json"))
LAST_INSTALL_FILE = Path(os.getenv("LAST_INSTALL_FILE", "/var/lib/traffic-analyzer/last-install.json"))
UI_DEFAULTS_FILE = Path(os.getenv("UI_DEFAULTS_FILE", "/var/lib/traffic-analyzer/ui-defaults.json"))
RAINBOW_API_TOKEN = str(os.getenv("TA_RAINBOW_API_TOKEN", "")).strip()
LIGHTNING_API_KEY = str(os.getenv("TA_LIGHTNING_API_KEY", "")).strip()
INMET_ALERTS_URL = str(os.getenv("TA_INMET_ALERTS_URL", "https://apiprevmet3.inmet.gov.br/avisos/ativos")).strip()
NOTICE_SETTINGS_FILE = Path(os.getenv("TA_NOTICE_SETTINGS_FILE", str(TRAFFIC_ARCHIVE_DB.parent / "automatic-notices-settings.json")))
NOTICE_STATE_FILE = Path(os.getenv("TA_NOTICE_STATE_FILE", str(TRAFFIC_ARCHIVE_DB.parent / "automatic-notices-state.json")))
NOTICE_POLL_SECONDS = max(300, min(int(os.getenv("TA_NOTICE_POLL_SECONDS", "600")), 86400))
MESHTASTIC_RELEASES_URL = str(os.getenv("TA_MESHTASTIC_RELEASES_URL", "https://api.github.com/repos/meshtastic/firmware/releases?per_page=20")).strip()
AUTOMATION_SETTINGS_FILE = Path(os.getenv("TA_AUTOMATION_SETTINGS_FILE", str(TRAFFIC_ARCHIVE_DB.parent / "automations.json")))
_automation_test_lock = threading.Lock()
_automation_last_test_at = 0.0
_nodeinfo_trace_lock = threading.Lock()
_nodeinfo_last_trace_global = 0.0
_nodeinfo_last_trace_destinations = {}
MESH_COMMANDS_ENABLED = str(os.getenv("TA_MESH_COMMANDS_ENABLED", "true")).strip().lower() in {"1","true","yes","on"}
MESH_COMMAND_POLL_SECONDS = max(1.0, min(float(os.getenv("TA_MESH_COMMAND_POLL_SECONDS", "3")), 60.0))
PING_COOLDOWN_SECONDS = max(0, min(int(os.getenv("TA_PING_COOLDOWN_SECONDS", "30")), 86400))
CLIMA_COOLDOWN_SECONDS = max(0, min(int(os.getenv("TA_CLIMA_COOLDOWN_SECONDS", "300")), 86400))
CLIMA_API_URL = str(os.getenv("TA_CLIMA_API_URL", "http://127.0.0.1:8765/clima")).strip()
CLIMA_REPLY_GAP_SECONDS = max(0.0, min(float(os.getenv("TA_CLIMA_REPLY_GAP_SECONDS", "8")), 60.0))
# Home Assistant: descargas próximas (bloco Raios) e previsão do tempo (bloco Previsão) do CLIMA.
# Valores salvos em Automações → CLIMA têm precedência sobre o .env.
HOME_ASSISTANT_SETTINGS_FILE = Path(os.getenv("TA_HA_SETTINGS_FILE", str(TRAFFIC_ARCHIVE_DB.parent / "home-assistant.json")))
CLIMA_HOME_ASSISTANT_ENV = {
    "url": str(os.getenv("TA_HA_URL", "http://127.0.0.1:8123")).strip(),
    "token": str(os.getenv("TA_HA_TOKEN", "")).strip(),
    "lightningEntity": str(os.getenv("TA_HA_LIGHTNING_ENTITY", "binary_sensor.alex_rodrigues_alexpmr_gmail_com_binary_sensors_is_lightning")).strip(),
    "forecastEntity": str(os.getenv("TA_HA_FORECAST_ENTITY", "weather.forecast_alex_rodrigues_alexpmr_gmail_com")).strip(),
}
MESH_COMMAND_NODE_LABEL = str(os.getenv("TA_MESH_COMMAND_NODE_LABEL", "VHF3")).strip() or "VHF3"
PING_ROUTE_TIMEOUT_SECONDS = max(5, min(int(os.getenv("TA_PING_ROUTE_TIMEOUT_SECONDS", "20")), 90))
_notice_stop = threading.Event()
_mesh_command_stop = threading.Event()
_mesh_dispatcher_lock = threading.RLock()
_mesh_dispatcher_active = None
_mesh_last_listener_error = None
_notice_wakeup = threading.Event()
_update_watch_stop = threading.Event()
_notice_lock = threading.Lock()
ELEVATION_TILE_BASE_URL = str(os.getenv("TA_ELEVATION_TILE_BASE_URL", "https://s3.amazonaws.com/elevation-tiles-prod/terrarium")).strip().rstrip("/")
AUTO_UPDATE_RETRY_BACKOFF_SECONDS = 6 * 3600
# Solicitação sem progresso do updater (path unit não disparou ou execução interrompida)
# não pode bloquear para sempre a atualização automática ao abrir a página.
AUTO_UPDATE_PENDING_STALE_SECONDS = 10 * 60
AUTO_UPDATE_RUNNING_STALE_SECONDS = 30 * 60

AUTH_ENABLED = str(os.getenv("TA_AUTH_ENABLED", "false")).strip().lower() in {"1", "true", "yes", "on"}
AUTH_USER = str(os.getenv("TA_AUTH_USER", "admin")).strip() or "admin"
AUTH_PASSWORD_HASH = str(os.getenv("TA_AUTH_PASSWORD_HASH", "")).strip()
AUTH_SESSION_HOURS = max(1, min(168, int(os.getenv("TA_AUTH_SESSION_HOURS", "12") or 12)))
AUTH_SESSION_SECONDS = AUTH_SESSION_HOURS * 3600
AUTH_SECURE_COOKIE = str(os.getenv("TA_AUTH_SECURE_COOKIE", "auto")).strip().lower()
AUTH_COOKIE_NAME = "ta_session"
_auth_sessions = {}
_auth_sessions_lock = threading.Lock()
_auth_login_attempts = {}
_auth_login_lock = threading.Lock()
AUTH_LOGIN_WINDOW_SECONDS = 600
AUTH_LOGIN_MAX_FAILURES = 5
AUTH_LOGIN_BLOCK_SECONDS = 300


def _auth_b64decode(value: str) -> bytes:
    raw = str(value or "").strip()
    raw += "=" * ((4 - len(raw) % 4) % 4)
    return base64.urlsafe_b64decode(raw.encode("ascii"))


def _auth_verify_password(password: str) -> bool:
    try:
        scheme, iterations_raw, salt_raw, digest_raw = AUTH_PASSWORD_HASH.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        iterations = int(iterations_raw)
        if iterations < 100_000 or iterations > 5_000_000:
            return False
        salt = _auth_b64decode(salt_raw)
        expected = _auth_b64decode(digest_raw)
        actual = hashlib.pbkdf2_hmac("sha256", str(password or "").encode("utf-8"), salt, iterations)
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def _auth_client_ip(handler) -> str:
    try:
        return str(handler.client_address[0])
    except Exception:
        return "unknown"


def _auth_login_remaining(ip: str) -> int:
    now = time.time()
    with _auth_login_lock:
        state = _auth_login_attempts.get(ip)
        if not state:
            return 0
        blocked_until = float(state.get("blocked_until") or 0)
        if blocked_until > now:
            return max(1, int(blocked_until - now))
        failures = [float(v) for v in state.get("failures", []) if now - float(v) < AUTH_LOGIN_WINDOW_SECONDS]
        if failures:
            state["failures"] = failures
            state["blocked_until"] = 0
        else:
            _auth_login_attempts.pop(ip, None)
        return 0


def _auth_register_failure(ip: str):
    now = time.time()
    with _auth_login_lock:
        state = _auth_login_attempts.setdefault(ip, {"failures": [], "blocked_until": 0})
        failures = [float(v) for v in state.get("failures", []) if now - float(v) < AUTH_LOGIN_WINDOW_SECONDS]
        failures.append(now)
        state["failures"] = failures
        if len(failures) >= AUTH_LOGIN_MAX_FAILURES:
            state["blocked_until"] = now + AUTH_LOGIN_BLOCK_SECONDS


def _auth_clear_failures(ip: str):
    with _auth_login_lock:
        _auth_login_attempts.pop(ip, None)


def _auth_cookie_value(handler) -> str:
    raw = str(handler.headers.get("Cookie") or "")
    if not raw:
        return ""
    try:
        cookie = SimpleCookie()
        cookie.load(raw)
        item = cookie.get(AUTH_COOKIE_NAME)
        return str(item.value if item else "")
    except Exception:
        return ""


def _auth_session(handler):
    if not AUTH_ENABLED:
        return {"user": AUTH_USER, "csrf": "", "expires": time.time() + AUTH_SESSION_SECONDS, "auth_disabled": True}
    sid = _auth_cookie_value(handler)
    if not sid:
        return None
    now = time.time()
    with _auth_sessions_lock:
        session = _auth_sessions.get(sid)
        if not session:
            return None
        if float(session.get("expires") or 0) <= now:
            _auth_sessions.pop(sid, None)
            return None
        return dict(session)


def _auth_cookie_secure(handler) -> bool:
    if AUTH_SECURE_COOKIE in {"1", "true", "yes", "on"}:
        return True
    if AUTH_SECURE_COOKIE in {"0", "false", "no", "off"}:
        return False
    proto = str(handler.headers.get("X-Forwarded-Proto") or "").split(",", 1)[0].strip().lower()
    return proto == "https"


def _auth_set_cookie_header(handler, sid: str, max_age: int) -> str:
    parts = [
        f"{AUTH_COOKIE_NAME}={sid}",
        "Path=/",
        "HttpOnly",
        "SameSite=Strict",
        f"Max-Age={max(0, int(max_age))}",
    ]
    if _auth_cookie_secure(handler):
        parts.append("Secure")
    return "; ".join(parts)


def _auth_new_session():
    sid = secrets.token_urlsafe(36)
    csrf = secrets.token_urlsafe(28)
    expires = time.time() + AUTH_SESSION_SECONDS
    with _auth_sessions_lock:
        _auth_sessions[sid] = {"user": AUTH_USER, "csrf": csrf, "expires": expires}
        if len(_auth_sessions) > 512:
            now = time.time()
            for key, value in list(_auth_sessions.items()):
                if float(value.get("expires") or 0) <= now:
                    _auth_sessions.pop(key, None)
    return sid, csrf, expires


def _auth_drop_session(handler):
    sid = _auth_cookie_value(handler)
    if sid:
        with _auth_sessions_lock:
            _auth_sessions.pop(sid, None)


def _auth_status(handler) -> dict:
    session = _auth_session(handler)
    authenticated = bool(session)
    return {
        "success": True,
        "enabled": AUTH_ENABLED,
        "configured": bool(AUTH_PASSWORD_HASH),
        "authenticated": authenticated,
        "user": session.get("user") if session else None,
        "csrfToken": session.get("csrf") if session and AUTH_ENABLED else "",
        "expiresAtMs": int(float(session.get("expires") or 0) * 1000) if session and AUTH_ENABLED else None,
        "sessionHours": AUTH_SESSION_HOURS,
    }


def _auth_require_write(handler) -> bool:
    if not AUTH_ENABLED:
        return True
    session = _auth_session(handler)
    if not session:
        body = json.dumps({
            "success": False,
            "error": "authentication_required",
            "message": "Faça login como administrador para executar esta ação.",
        }, ensure_ascii=False).encode("utf-8")
        handler._send(401, "application/json; charset=utf-8", body)
        return False
    supplied = str(handler.headers.get("X-CSRF-Token") or "")
    expected = str(session.get("csrf") or "")
    if not supplied or not hmac.compare_digest(supplied, expected):
        body = json.dumps({
            "success": False,
            "error": "csrf_failed",
            "message": "Sessão inválida ou proteção CSRF ausente. Faça login novamente.",
        }, ensure_ascii=False).encode("utf-8")
        handler._send(403, "application/json; charset=utf-8", body)
        return False
    return True


HTML = r'''<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__DISPLAY_TITLE__</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
 integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
<style>
  html,body{height:100%;margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#0e1621;color:#e8edf2}
  #app{height:100%;display:flex;flex-direction:column;min-height:0}
  header{padding:10px 14px;background:#17212b;border-bottom:1px solid #293744;display:flex;gap:14px;align-items:center;flex-wrap:wrap}
  header h1{font-size:17px;margin:0;font-weight:700}.downloadBtn{background:#234d63;border-color:#4c7e96;font-weight:700}
  #summary{display:flex;gap:8px;flex-wrap:wrap;padding:8px 12px;background:#111c27;border-bottom:1px solid #293744}
  #playback{display:flex;gap:5px;align-items:center;flex-wrap:nowrap;white-space:nowrap;overflow-x:auto;overflow-y:hidden;scrollbar-width:thin;overscroll-behavior-x:contain;min-width:0;flex:0 0 auto;padding:6px 8px;background:#14202b;border-bottom:1px solid #293744}
  #playStatus{font-size:12px;color:#cbd6df;min-width:54px;max-width:110px;flex:0 1 84px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .liveBadge{color:#ff6b6b;font-weight:700}
  .metric{background:#1d2b38;border:1px solid #304353;border-radius:7px;padding:5px 9px;font-size:12px}
  .metric b{font-size:15px;margin-right:4px}
  #nav{display:flex;gap:5px;align-items:center}
  .navbtn{font-weight:700;padding:6px 10px}.navbtn.active{background:#e4b800;color:#101820;border-color:#ffe34d}
  .view{display:none;flex:1;min-height:0;min-width:0}.view.active{display:flex;flex-direction:column}
  #viewMap{position:relative;overflow:hidden}#viewMap #map{flex:1;min-height:0}
  .basemapLightTile{filter:grayscale(.10) brightness(1.12) contrast(.92) saturate(.82)}
  .basemapDarkTile{filter:grayscale(.18) invert(.88) hue-rotate(180deg) brightness(.58) contrast(1.18) saturate(.72)}
  #trafficToolbar{display:flex;gap:9px;align-items:center;flex-wrap:wrap;padding:9px 12px;background:#111c27;border-bottom:1px solid #293744}
  #trafficStats{display:flex;gap:8px;flex-wrap:wrap;padding:8px 12px;background:#14202b;border-bottom:1px solid #293744}
  #trafficBody{display:grid;grid-template-columns:max-content minmax(360px,1fr);flex:1;min-height:0;min-width:0}
  #trafficTableWrap{overflow:auto;min-height:0;min-width:0;max-width:100vw}.trafficTable{width:auto;border-collapse:collapse;font-size:12px;table-layout:fixed}.trafficTable th{position:sticky;top:0;background:#17212b;color:#cbd6df;text-align:left;padding:8px;border-bottom:1px solid #405668;z-index:2}.trafficTable td{padding:7px 8px;border-bottom:1px solid #22313f;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.trafficTable tr{cursor:pointer}.trafficTable tbody tr:hover{background:#1d2b38}.trafficTable tbody tr.selected{background:#263b4d}
  .trafficTable th:nth-child(1),.trafficTable td:nth-child(1){width:72px}.trafficTable th:nth-child(2),.trafficTable td:nth-child(2){width:48px}.trafficTable th:nth-child(3),.trafficTable td:nth-child(3){width:185px;max-width:185px}.trafficTable th:nth-child(4),.trafficTable td:nth-child(4){width:185px;max-width:185px}.trafficTable th:nth-child(5),.trafficTable td:nth-child(5){width:118px;max-width:118px}.trafficTable th:nth-child(6),.trafficTable td:nth-child(6){width:58px}.trafficTable th:nth-child(7),.trafficTable td:nth-child(7){width:58px}.trafficTable th:nth-child(8),.trafficTable td:nth-child(8){width:48px}
  .badge{display:inline-block;padding:2px 6px;border-radius:10px;font-size:10px;font-weight:800}.rx{background:#174f37;color:#7af0ad}.tx{background:#164a64;color:#7ddcff}.typeBadge{background:#374657;color:#e8edf2}.type-text{background:#5d3b7c}.type-position{background:#365f3a}.type-nodeinfo{background:#795628}.type-telemetry{background:#1f5d69}.type-traceroute{background:#5a487d}.type-routing{background:#754044}.type-neighbor{background:#4d5b25}
  #packetDetail{overflow:auto;border-left:1px solid #293744;background:#111a24;padding:14px}.detailTitle{font-size:16px;font-weight:800;margin-bottom:8px}.detailGrid{display:grid;grid-template-columns:120px minmax(0,1fr);gap:7px;font-size:12px}.detailGrid b{color:#9fb0bf}.emptyDetail{color:#8194a5;font-size:13px;padding-top:8px}.payloadBox{background:#172532;border:1px solid #304353;border-radius:7px;padding:9px;line-height:1.45;overflow-wrap:anywhere}.payloadRows{display:grid;grid-template-columns:minmax(110px,38%) minmax(0,1fr);gap:4px 9px}.payloadRows .k{color:#9fb0bf;font-weight:700}.payloadRows .v{overflow-wrap:anywhere}.techDetails{margin-top:8px}.techDetails summary{cursor:pointer;color:#9fc6e4;font-weight:700}.techDetails .payloadBox{margin-top:7px}.rawJson{margin-top:9px;border-top:1px solid #304353;padding-top:7px}.rawJson summary{font-size:11px;color:#8194a5;font-weight:600}.techDetails pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#0d1620;border:1px solid #2e4050;border-radius:6px;padding:8px;font-size:10px;max-height:320px;overflow:auto}.broadcastTag{display:inline-block;background:#345d39;color:#a8f0b0;border-radius:9px;padding:2px 6px;font-size:10px;font-weight:800;margin-left:6px}
  #viewSettings{overflow:auto}.settingsCard{max-width:900px;margin:24px auto;background:#17212b;border:1px solid #304353;border-radius:10px;padding:20px;width:calc(100% - 48px);box-sizing:border-box}.settingsCard h2{margin-top:0}.settingsCard h3{margin:20px 0 4px;color:#e9d46d}.settingRow{padding:12px 0;border-bottom:1px solid #293744}.settingRow:last-child{border-bottom:0}.settingDesc{color:#99aaba;font-size:12px;margin-top:5px}.soundTest{margin-left:8px}.settingsGrid{display:grid;grid-template-columns:repeat(2,minmax(260px,1fr));gap:10px 22px}.settingsGrid .settingRow{min-width:0}.mapActions{margin-left:auto;display:flex;gap:5px;align-items:center;flex-wrap:nowrap;white-space:nowrap;flex:0 0 auto}
  .mapSearchBox{position:relative;display:flex;align-items:center;flex-wrap:nowrap;flex:0 0 auto;gap:4px;min-width:0;z-index:5400}
  .mapSearchBox input{width:clamp(145px,15vw,195px);min-width:120px;flex:0 0 auto}
  .mapSearchBox button{white-space:nowrap}
  .mapSearchMatches{position:fixed;left:0;top:0;width:min(385px,calc(100vw - 14px));max-height:min(300px,calc(100vh - 75px));overflow:auto;background:#172736;border:1px solid #526b7c;border-radius:7px;box-shadow:0 8px 20px #0008;z-index:5500}
  .mapSearchMatches[hidden]{display:none!important}
  .mapSearchMatches button{display:flex;flex-direction:column;gap:3px;text-align:left;width:100%;border:0;border-bottom:1px solid #344757;border-radius:0;white-space:normal;padding:9px}
  .mapSearchMatches button:hover,.mapSearchMatches button:focus-visible{background:#31506b}
  .mapSearchMatches small{color:#b7cbda}
  .mapSearchInfo{font-size:11px;color:#b9cddd;white-space:nowrap}
  .mapSearchPulse{animation:mapSearchPulse 1s ease-in-out 7;pointer-events:none}
  @keyframes mapSearchPulse{0%,100%{stroke-width:3;stroke-opacity:.95;fill-opacity:.04}50%{stroke-width:8;stroke-opacity:.4;fill-opacity:.22}}
  @media(max-width:680px){.mapSearchBox input{width:145px;min-width:110px}.mapSearchInfo{max-width:70px;overflow:hidden;text-overflow:ellipsis}}@media(max-width:760px){.settingsGrid{grid-template-columns:1fr}.mapActions{margin-left:auto}}
  @media(max-width:1150px){#trafficBody{grid-template-columns:minmax(0,1fr)}#packetDetail{display:none}header{align-items:flex-start}.trafficTable{min-width:760px}}
  select,input,button{background:#233443;color:#edf3f8;border:1px solid #405668;border-radius:6px;padding:5px 7px}
  label{font-size:12px;color:#cbd6df}
  #map{height:100%;width:100%;min-height:0;min-width:0}
  .mapActions{display:flex;align-items:center;gap:5px;flex-wrap:nowrap}.mapActions label{display:flex;align-items:center;gap:4px;flex:0 0 auto}.mapActions select{min-width:105px;max-width:140px}.mapLayersMenu{position:relative;flex:0 0 auto}.mapLayersMenu>summary{list-style:none;cursor:pointer;background:#233443;color:#edf3f8;border:1px solid #405668;border-radius:6px;padding:5px 9px;font-size:12px}.mapLayersMenu>summary::-webkit-details-marker{display:none}.mapLayersPanel{position:fixed;left:0;top:0;z-index:5500;min-width:210px;background:#17212b;border:1px solid #405668;border-radius:8px;padding:9px 10px;box-shadow:0 10px 28px rgba(0,0,0,.4)}.mapLayersPanel label{display:flex;align-items:center;gap:7px;white-space:nowrap}.mapLayersPanel .layerSubControl{margin:4px 0 7px 22px;gap:6px;font-size:10px;color:#9fb0be}.mapLayersPanel .layerSubControl input[type=range]{width:105px;padding:0}.layerStatus{font-size:10px;color:#91a4b3;margin-top:5px}.leaflet-weather-radar-pane,.leaflet-clouds-pane,.leaflet-hillshade-pane,.leaflet-elevation-pane{pointer-events:none}.rfCoverageHit{cursor:pointer}.weatherAlertPopup{max-width:360px}.elevationThresholdControl{display:none;position:absolute;right:12px;top:50%;transform:translateY(-50%);z-index:1150;background:rgba(23,33,43,.95);border:1px solid #52697a;border-radius:9px;padding:8px 7px;color:#edf3f8;box-shadow:0 8px 22px rgba(0,0,0,.35);text-align:center;min-width:72px}.elevationThresholdControl.active{display:block}.elevationThresholdTitle{font-size:10px;font-weight:800;color:#e9d46d;margin-bottom:3px}.elevationThresholdValue{font-size:12px;font-weight:800;margin-bottom:4px}.elevationVerticalRange{display:block;writing-mode:vertical-lr;direction:rtl;-webkit-appearance:slider-vertical;width:28px;height:390px;margin:2px auto;padding:0;accent-color:#e4b800}.elevationThresholdNumber{width:64px!important;padding:3px 4px!important;font-size:11px!important;text-align:center}.elevationThresholdUnit{font-size:9px;color:#9fb0be;margin-top:2px}.elevationScaleLabel{font-size:8px;color:#8194a5;line-height:1}.elevationControlRow{display:flex;align-items:center;justify-content:center;gap:3px}@media(max-height:700px){.elevationVerticalRange{height:255px}}
  .legend{background:rgba(23,33,43,.94);padding:8px 10px;border-radius:7px;color:#edf3f8;font-size:12px;line-height:1.55;border:1px solid #405668;min-width:190px}
  .legendSection{margin-top:7px;padding-top:6px;border-top:1px solid rgba(128,148,165,.35)}.legendLine{display:inline-block;width:34px;height:0;margin:0 7px 2px 0;vertical-align:middle;border-top-style:solid}.legendLine.mqtt{border-top-style:dashed}.legendNote{font-size:10px;color:#9fb0be;line-height:1.3;margin-top:4px;max-width:230px}
  .dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px}
  .identified{background:#39a96b}.stub{background:#e0a13a}.routeonly{background:#d85b5b}
  .trafficFresh{background:#2ecc71}.trafficWarm{background:#f39c12}.trafficOld{background:#e74c3c}.trafficUnknown{background:#7f8c8d}
  .leaflet-popup-pane{z-index:1200}.leaflet-popup-content-wrapper,.leaflet-popup-tip{background:#17212b;color:#e8edf2}.leaflet-popup.nodePopupFloating{z-index:1300}.leaflet-popup.nodePopupDragging{z-index:1400}.leaflet-popup.nodePopupDetached .leaflet-popup-tip-container{display:none}.leaflet-popup a.leaflet-popup-close-button{z-index:30}
  .nodePopupDragHandle{position:sticky;top:0;z-index:8;display:flex;align-items:center;gap:9px;margin:0 0 7px;padding:3px 0 7px 0;background:#17212b;border-bottom:1px solid rgba(64,86,104,.75);cursor:grab;touch-action:none;user-select:none}.nodePopupDragHandle:active{cursor:grabbing}.nodePopupDragGlyph{flex:0 0 auto;color:#7fd0ff;font-size:16px;font-weight:900;line-height:1}.nodePopupDragText{min-width:0;flex:1}.nodePopupDragHint{flex:0 0 auto;color:#8194a5;font-size:9px;text-transform:uppercase;letter-spacing:.04em}.nodePopupHeaderActions{display:flex;align-items:center;gap:5px;flex:0 0 auto}.nodePopupHeaderActions button{font-size:10px;padding:4px 8px;cursor:pointer}.nodePopupCloseVisible{background:#462a2e;border-color:#87515a;color:#ffd5da;font-weight:800}.nodePopupReset{background:#213744}.nodePopupStaticHandle{margin-bottom:7px}
  .nodePopup{width:min(1120px,calc(100vw - 90px));max-width:calc(100vw - 28px);min-width:min(560px,calc(100vw - 28px));min-height:260px;max-height:calc(100vh - 70px);overflow:auto;resize:both;overscroll-behavior:contain;scrollbar-gutter:stable;padding-right:7px;box-sizing:border-box;font-size:12px;line-height:1.35}.nodePopupTitle{font-size:15px;font-weight:800;margin-bottom:2px}.nodePopupId{color:#9fb0be;margin-bottom:8px}.nodePopupSection{border-top:1px solid #304353;margin-top:9px;padding-top:8px}.nodePopupSectionTitle{font-weight:800;color:#e9d46d;margin-bottom:6px}.nodeMetaGrid{display:grid;grid-template-columns:minmax(115px,.72fr) minmax(135px,1fr) minmax(115px,.72fr) minmax(135px,1fr);gap:4px 10px}.nodeMetaLabel{color:#aebbc7}.nodeMetaValue{overflow-wrap:anywhere;min-width:0}.nodeMetaPresent{color:#8de4ad}.nodeMetaMissing{color:#ffcc66}.nodeMetaNA{color:#8194a5}.nodeQueryButtons{display:flex;gap:5px;flex-wrap:wrap;margin:6px 0 8px}.nodeQueryButtons button{font-size:11px;padding:4px 7px}.nodeQueryButtons button.primary{background:#234d63;border-color:#4c7e96;font-weight:800}.nodeQueryList{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:3px 12px}.nodeQueryRow{display:grid;grid-template-columns:18px minmax(105px,.8fr) minmax(0,1.2fr);gap:5px;align-items:start;padding:3px 0;border-bottom:1px solid rgba(64,86,104,.28)}.nodeQueryRow:last-child{border-bottom:0}.nodeQueryMark{font-weight:900}.nodeQueryState{color:#9fb0be;overflow-wrap:anywhere}.nodeQueryOk .nodeQueryMark,.nodeQueryOk .nodeQueryState{color:#8de4ad}.nodeQueryWait .nodeQueryMark{color:#6fc7ff}.nodeQueryError .nodeQueryMark,.nodeQueryError .nodeQueryState{color:#ff8b8b}.nodeQueryTimeout .nodeQueryMark,.nodeQueryTimeout .nodeQueryState{color:#ffcc66}.nodeQueryProgress{height:4px;margin-top:4px;border-radius:999px;overflow:hidden;background:#263846}.nodeQueryProgressBar{height:100%;width:0;background:#6fc7ff;transition:width .25s linear}.nodeQueryOk .nodeQueryProgressBar{background:#58d68d}.nodeQueryTimeout .nodeQueryProgressBar{background:#f2c94c}.nodeQueryError .nodeQueryProgressBar{background:#ff6b6b}.leaflet-popup.nodePopupMaximized{left:8px!important;top:8px!important;transform:none!important;margin:0!important;width:calc(100% - 16px)!important;height:calc(100% - 16px)!important;max-width:none!important}.leaflet-popup.nodePopupMaximized .leaflet-popup-content-wrapper{width:100%;height:100%;box-sizing:border-box}.leaflet-popup.nodePopupMaximized .leaflet-popup-content{width:100%!important;height:100%;margin:0;padding:10px;box-sizing:border-box}.leaflet-popup.nodePopupMaximized .nodePopup{width:100%;height:100%;max-width:none;max-height:none;min-width:0;min-height:0;resize:none}.leaflet-popup.nodePopupMaximized .leaflet-popup-tip-container{display:none}.nodeTelemetryRows{max-height:160px;overflow:auto;margin-top:5px;padding-right:3px;columns:2;column-gap:18px}.nodeTelemetryRows>div{break-inside:avoid;margin-bottom:3px}.nodeSmall{font-size:10px;color:#8194a5}.nodePopupActionsNote{font-size:10px;color:#8194a5;margin-top:5px}
  @media(max-width:900px){.nodePopup{width:min(720px,calc(100vw - 50px));min-width:0;max-height:calc(100vh - 60px);resize:vertical}.nodeMetaGrid{grid-template-columns:minmax(125px,42%) minmax(0,1fr)}.nodeQueryList{grid-template-columns:1fr}.nodeTelemetryRows{columns:1}}
  @media(max-width:600px){.nodePopup{width:calc(100vw - 44px);min-width:0;max-width:calc(100vw - 44px);min-height:220px;max-height:calc(100vh - 54px);resize:vertical;padding-right:4px}.nodeMetaGrid{grid-template-columns:1fr}.nodeMetaValue{margin-bottom:3px}.nodeQueryRow{grid-template-columns:18px minmax(90px,1fr)}.nodeQueryState{grid-column:2}}
  .nodeWindow{position:absolute;z-index:1600;display:none;flex-direction:column;background:#17212b;border:1px solid #52697a;border-radius:10px;box-shadow:0 18px 48px rgba(0,0,0,.52);overflow:hidden;min-width:360px;min-height:240px;max-width:calc(100% - 16px);max-height:calc(100% - 16px)}
  .nodeWindow.open{display:flex}.nodeWindow.dragging,.nodeWindow.resizing{user-select:none}.nodeWindow.maximized{position:fixed!important;left:8px!important;top:8px!important;width:calc(100vw - 16px)!important;height:calc(100vh - 16px)!important;max-width:none!important;max-height:none!important;border-radius:6px;z-index:5000}
  .nodeWindowHeader{display:flex;align-items:center;gap:9px;flex:0 0 auto;padding:8px 10px;background:#1b2a36;border-bottom:1px solid #405668;cursor:move;touch-action:none;user-select:none}
  .nodeWindowGrip{font-size:17px;color:#7fd0ff;font-weight:900;line-height:1}.nodeWindowTitleWrap{min-width:0;flex:1}.nodeWindowTitle{font-size:14px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nodeWindowId{font-size:10px;color:#9fb0be;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .nodeWindowActions{display:flex;gap:5px;align-items:center;flex:0 0 auto}.nodeWindowActions button{font-size:10px;padding:4px 8px}.nodeWindowClose{background:#462a2e;border-color:#87515a;color:#ffd5da;font-weight:800}
  .nodeWindowBody{flex:1;min-height:0;overflow:auto;padding:10px;box-sizing:border-box;overscroll-behavior:contain;scrollbar-gutter:stable}
  .nodeWindowBody .nodePopup{width:100%;max-width:none;min-width:0;min-height:0;max-height:none;overflow:visible;resize:none;padding:0}.nodeWindowBody .nodePopupStaticHandle{display:none}.nodeWindowBody .nodeTelemetryRows{max-height:none;overflow:visible}
  .nodeWindowResizeHandle{position:absolute;right:0;bottom:0;width:22px;height:22px;cursor:nwse-resize;z-index:4;touch-action:none}.nodeWindowResizeHandle:after{content:'';position:absolute;right:4px;bottom:4px;width:10px;height:10px;border-right:2px solid #86a7bc;border-bottom:2px solid #86a7bc}
  @media(max-width:700px){.nodeWindow{min-width:280px;min-height:220px}.nodeWindowHeader{gap:5px;padding:6px}.nodeWindowActions button{padding:4px 6px}.nodeWindowBody{padding:7px}}
  .warn{color:#ffcc66}
  .short-label{background:rgba(14,22,33,.88);border:1px solid #405668;color:#fff;border-radius:4px;padding:1px 4px;font-weight:700;box-shadow:none}
  .short-label:before{display:none}
  #flowToast{position:fixed;right:16px;top:16px;z-index:2000;max-width:440px;background:rgba(23,33,43,.97);border:1px solid #6e5aa8;border-left:5px solid #a970ff;border-radius:8px;padding:10px 12px;box-shadow:0 8px 24px rgba(0,0,0,.35);font-size:12px;line-height:1.4;display:none;cursor:pointer}
  #flowToast b{color:#d8c8ff}.flowNote{color:#aebbc7;margin-top:3px}.flowUnknown{border-left-color:#ffb347!important}.flowKnown{border-left-color:#a970ff!important}
  .activityLeafletIcon{background:transparent!important;border:0!important}.activityPulse{position:relative;width:46px;height:46px;display:flex;align-items:center;justify-content:center;transform:translate(-1px,-1px);pointer-events:none}.activityPulse .activityCore{position:relative;z-index:3;width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;border:2px solid #fff;box-shadow:0 0 12px rgba(255,255,255,.75);animation:activityBounce var(--taDur,1s) ease-out both}.activityPulse:before,.activityPulse:after{content:'';position:absolute;inset:7px;border-radius:50%;border:3px solid currentColor;opacity:.9;animation:activityRing var(--taDur,1s) ease-out both}.activityPulse:after{animation-delay:.16s}.activityPulse.origin{color:#38d6ff}.activityPulse.origin .activityCore{background:#0c6b82}.activityPulse.relay{color:#ffcf4a}.activityPulse.relay .activityCore{background:#8a6810}.activityPulse.response{color:#a970ff}.activityPulse.response .activityCore{background:#5a3482}@keyframes activityRing{0%{transform:scale(.45);opacity:.95}100%{transform:scale(1.65);opacity:0}}@keyframes activityBounce{0%{transform:scale(.7)}35%{transform:scale(1.25)}100%{transform:scale(1)}}
  .traceHud{background:rgba(14,22,33,.90);border:1px solid #405668;border-radius:8px;color:#e8edf2;padding:7px 9px;min-width:260px;max-width:410px;max-height:34vh;overflow:auto;box-shadow:0 6px 18px rgba(0,0,0,.28);pointer-events:none}.traceHud:empty{display:none}.traceHudItem{padding:5px 0;border-bottom:1px solid rgba(64,86,104,.55)}.traceHudItem:last-child{border-bottom:0}.traceHudHead{font-size:11px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.traceHudTotal{color:#ffd166;font-weight:700;margin-left:5px}.traceHudLeg{font-size:10px;color:#b9c7d2;margin-top:2px}.traceHudLeg.active{color:#fff;font-weight:800}.traceHudLeg .forward{color:#54e8ff}.traceHudLeg .return{color:#ff83e7}.traceHudDim{color:#8093a3}

  /* Estatísticas consolidadas */
  #viewStatistics{overflow:hidden;background:#0e1621}
  .statsShell{width:100%;box-sizing:border-box;min-height:0;height:100%;display:flex;flex-direction:column}
  .statsTopbar{position:relative;z-index:20;flex:0 0 auto;background:#101b26;border-bottom:1px solid #304353;padding:10px 14px;box-shadow:0 5px 14px rgba(0,0,0,.18)}
  .statsContent{flex:1;min-height:0;overflow:auto;background:#0e1621;overscroll-behavior:contain}
  .statsHeader{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:9px}.statsHeader h2{margin:0 auto 0 0;font-size:18px}
  .statsAccessControls{display:none;align-items:center;gap:7px;flex-wrap:wrap;padding-left:9px;border-left:1px solid #405668}.statsAccessControls.open{display:flex}.statsContextLabel{font-weight:800;color:#e9d46d}
  .statsTabs{display:flex;gap:5px;flex-wrap:wrap}.statsTab{font-weight:700;font-size:12px;padding:6px 9px}.statsTab.active{background:#e4b800;color:#101820;border-color:#ffe34d}
  .clickableStatRow{cursor:pointer}.clickableStatRow:hover,.clickableStatRow:focus{outline:none;background:rgba(228,184,0,.12)}
  .statsPanel{display:none}.statsPanel.active{display:block}
  .statsOverviewText{background:#17212b;border:1px solid #304353;border-left:4px solid #e4b800;border-radius:8px;padding:12px 14px;line-height:1.55;margin:10px 0 12px}
  .statsSplit{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.statsCompactTable{min-width:560px}
  @media(max-width:900px){.statsSplit{grid-template-columns:1fr}}
  /* v1.15 - Saúde da Rede e Anomalias */
  #viewHealth,#viewAnomalies,#viewAccess{overflow:visible;background:#0e1621}
  .dashboardWrap{width:100%;box-sizing:border-box;padding:14px;max-width:1500px;margin:0 auto}
  .dashboardToolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px}
  .dashboardToolbar h2{margin:0 auto 0 0;font-size:18px}
  .dashGrid{display:grid;grid-template-columns:repeat(4,minmax(170px,1fr));gap:10px;margin-bottom:12px}
  .dashCard{background:#17212b;border:1px solid #304353;border-radius:9px;padding:12px;min-width:0}
  .dashCard .value{font-size:27px;font-weight:800;line-height:1.05;margin:4px 0}.dashCard .label{font-size:12px;color:#aebbc7}.dashCard .sub{font-size:11px;color:#8194a5;margin-top:5px}
  .dashSection{background:#111a24;border:1px solid #293744;border-radius:9px;margin:10px 0;overflow:hidden}.dashSection h3{font-size:14px;margin:0;padding:10px 12px;background:#17212b;border-bottom:1px solid #293744}.dashSectionBody{padding:10px 12px;overflow:auto}
  .dashTable{width:100%;border-collapse:collapse;font-size:12px;min-width:720px}.dashTable th{position:sticky;top:0;background:#17212b;color:#cbd6df;text-align:left;padding:8px;border-bottom:1px solid #405668}.dashTable td{padding:8px;border-bottom:1px solid #22313f}.dashTable tr:last-child td{border-bottom:0}
  .statsFitBody{overflow-x:hidden}.dashTable.statsFitTable,#statsPanelRouting .dashTable{min-width:0;table-layout:fixed}.dashTable.statsFitTable th,.dashTable.statsFitTable td,#statsPanelRouting .dashTable th,#statsPanelRouting .dashTable td{white-space:normal;overflow-wrap:anywhere;word-break:normal}.statsFitTable th,.statsFitTable td{padding-left:6px;padding-right:6px}#statsPanelRouting .dashSectionBody{overflow-x:hidden}
  @media(max-width:700px){.dashTable.statsFitTable,#statsPanelRouting .dashTable{font-size:11px}.dashTable.statsFitTable th,.dashTable.statsFitTable td,#statsPanelRouting .dashTable th,#statsPanelRouting .dashTable td{padding:6px 4px}}
  #viewNodes{overflow:auto;background:#0e1621}.nodesWrap{width:100%;box-sizing:border-box;padding:12px;max-width:1800px;margin:0 auto}.nodesToolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:9px}.nodesToolbar h2{margin:0 auto 0 0;font-size:18px}.nodesColumnsMenu{position:relative}.nodesColumnsPanel{position:absolute;right:0;top:calc(100% + 5px);z-index:1200;display:none;min-width:235px;background:#17212b;border:1px solid #405668;border-radius:8px;padding:8px;box-shadow:0 10px 28px rgba(0,0,0,.38)}.nodesColumnsPanel.open{display:grid;gap:5px}.nodesColumnsPanel label{display:flex;gap:7px;align-items:center}.nodesTableWrap{overflow:auto;border:1px solid #293744;border-radius:9px;max-height:calc(100vh - 150px)}.nodesTable{width:100%;border-collapse:collapse;font-size:12px;min-width:1150px}.nodesTable th{position:sticky;top:0;z-index:3;background:#17212b;color:#cbd6df;text-align:left;padding:8px 9px;border-bottom:1px solid #405668;white-space:nowrap;cursor:pointer;user-select:none}.nodesTable th:hover{background:#20303d}.nodesTable td{padding:7px 9px;border-bottom:1px solid #22313f;white-space:nowrap}.nodesTable tbody tr{cursor:pointer}.nodesTable tbody tr:hover{background:#1b2b38}.nodesTable .nodeNameCell{font-weight:800}.nodesFilter{display:flex;align-items:center;gap:4px}.nodesFilter input{width:220px;max-width:36vw}.nodesFilterClear{padding:4px 8px}.batteryGood{color:#78e7a6;font-weight:800}.batteryWarn{color:#ffd36b;font-weight:800}.batteryBad{color:#ff8d83;font-weight:800}.nodesSort{font-size:10px;color:#7fd0ff;margin-left:4px}.nodeAge{display:inline-flex;align-items:center;gap:6px;font-weight:800}.nodeAgeDot{width:8px;height:8px;border-radius:50%;display:inline-block}.nodeAgeFresh{color:#78e7a6}.nodeAgeFresh .nodeAgeDot{background:#2ecc71}.nodeAgeWarm{color:#ffd36b}.nodeAgeWarm .nodeAgeDot{background:#f1c40f}.nodeAgeOld{color:#ff8d83}.nodeAgeOld .nodeAgeDot{background:#e74c3c}.nodeAgeUnknown{color:#8da0af}.nodeAgeUnknown .nodeAgeDot{background:#7f8c8d}.nodeOptional{display:none}.nodesShow-rssi .col-rssi,.nodesShow-channelUtilization .col-channelUtilization,.nodesShow-airUtilTx .col-airUtilTx,.nodesShow-nodeId .col-nodeId,.nodesShow-pkc .col-pkc,.nodesShow-state .col-state{display:table-cell}.nodeSelectCol{width:56px}.nodesTable th.nodeSelectCol{cursor:default}.nodesTable td.nodeSelectCol{white-space:nowrap}.nodeSelectCol input{cursor:pointer;margin:0 6px 0 0;vertical-align:middle}.nodeOpenBtn{padding:1px 6px;font-size:12px;line-height:1.2}.nodesTable tbody tr.nodeSelected{background:#173a52}.nodesTable tbody tr.nodeSelected:hover{background:#1d4562}.nodesTable tbody tr:focus{outline:2px solid #4fa3d9;outline-offset:-2px}.nodesBulkBar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:0 0 9px;padding:8px 10px;background:#15283a;border:1px solid #3c6a8c;border-radius:8px}.nodesBulkBar[hidden]{display:none}.nodesBulkBar b{margin-right:6px}.nodesBulkBar button{padding:5px 9px}.nodesBulkBar .nodesBulkDanger{background:#4b2026;border-color:#8a3a44}.nodeDetailsModal{width:min(1180px,96vw);max-height:92vh;overflow:auto}.nodeDetailsModal .nodePopup{width:100%;max-width:none;max-height:none;overflow:visible;padding-right:0}
  @media(max-width:800px){.nodesWrap{padding:8px}.nodesTableWrap{max-height:calc(100vh - 135px)}}
  .miniBars{display:flex;align-items:flex-end;gap:7px;height:130px;padding:8px 4px 22px}.miniBarWrap{flex:1;min-width:42px;text-align:center;position:relative;height:100%}.miniBar{position:absolute;bottom:19px;left:12%;right:12%;background:#3a8fbd;border-radius:4px 4px 0 0;min-height:2px}.miniBarLabel{position:absolute;bottom:0;left:0;right:0;font-size:10px;color:#91a4b3}.miniBarValue{position:absolute;bottom:calc(var(--h) + 23px);left:0;right:0;font-size:10px;color:#dbe6ee}
  .severity{display:inline-block;padding:2px 7px;border-radius:10px;font-size:10px;font-weight:800}.sev-critical{background:#6e2020;color:#ffb2b2}.sev-warning{background:#6a4a13;color:#ffd98a}.sev-info{background:#174f64;color:#9ce8ff}.sev-ok{background:#174f37;color:#9df2bc}
  .anomalyRow{display:grid;grid-template-columns:92px minmax(150px,240px) minmax(300px,1fr) 160px;gap:8px;align-items:start;padding:10px 12px;border-bottom:1px solid #22313f;font-size:12px}.anomalyRow:last-child{border-bottom:0}.anomalyTitle{font-weight:800}.anomalyEvidence{color:#9fb0bf;margin-top:3px}.anomalyTime{color:#8194a5;text-align:right}
  .emptyPanel{padding:22px;color:#8194a5;text-align:center}.methodNote{font-size:11px;color:#8194a5;line-height:1.45}
  @media(max-width:1000px){.dashGrid{grid-template-columns:repeat(2,minmax(160px,1fr))}.anomalyRow{grid-template-columns:90px 1fr}.anomalyRow .anomalyMsg,.anomalyRow .anomalyTime{grid-column:2}.anomalyTime{text-align:left}}
  @media(max-width:620px){.dashGrid{grid-template-columns:1fr}.dashboardWrap{padding:9px}}


  /* v1.16 - Mensagens do canal primário */
  #viewMessages{background:#0b141a;min-height:0;position:relative;--message-font-size:13px}
  #messageHeader{padding:7px 12px;background:#17212b;border-bottom:1px solid #293744;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
  #messageHeader .msgTitle{font-weight:800}.msgHint{font-size:11px;color:#91a4b3}.msgSpacer{flex:1}
  #messageList{flex:1;overflow:auto;padding:12px 14px;box-sizing:border-box;background:linear-gradient(rgba(11,20,26,.96),rgba(11,20,26,.96));scroll-behavior:smooth}
  .msgDay{text-align:center;margin:12px 0}.msgDay span{background:#182229;color:#b8c7d1;padding:5px 10px;border-radius:8px;font-size:11px;box-shadow:0 1px 2px rgba(0,0,0,.25)}
  .msgRow{display:flex;margin:4px 0}.msgRow.mine{justify-content:flex-end}.msgBubble{max-width:min(92%,1200px);min-width:120px;border-radius:9px;padding:6px 8px 5px;box-shadow:0 1px 2px rgba(0,0,0,.28);overflow-wrap:anywhere;position:relative}.msgRow.theirs .msgBubble{background:#202c33;border-top-left-radius:2px}.msgRow.mine .msgBubble{background:#005c4b;border-top-right-radius:2px}
  .msgSender{font-size:calc(var(--message-font-size,13px) - 2px);color:#70cfff;font-weight:800;margin-bottom:2px}.msgSenderNode{appearance:none;border:0;background:transparent;padding:0;color:inherit;font:inherit;font-weight:800;cursor:pointer;text-align:left}.msgSenderNode:hover{text-decoration:underline}.msgText{white-space:pre-wrap;font-size:var(--message-font-size,13px);line-height:1.35;padding-right:58px}.msgMeta{font-size:calc(var(--message-font-size,13px) - 3px);color:#b8c4ca;text-align:right;margin-top:-1px;white-space:nowrap}.msgStatus{font-size:12px;margin-left:4px;letter-spacing:-2px}.msgStatus.confirmed{color:#53bdeb}.msgStatus.failed{color:#ff8f8f}.msgTransport{font-size:9px;color:#8194a5;margin-left:5px}
  .traceBlocks{display:grid;gap:7px;white-space:normal}.traceBlock{background:rgba(0,0,0,.17);border:1px solid #40505a;border-radius:7px;padding:7px 8px}.traceBlock.return{border-color:#52606c}.traceBlockTitle{font-size:11px;font-weight:900;color:#70cfff;margin-bottom:4px;text-transform:uppercase;letter-spacing:.02em}.traceHop{display:block;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.35}.traceHop+.traceHop{margin-top:2px}.traceArrow{color:#91a4b3;font-weight:800;margin-right:5px}
  .msgNewMark{display:inline-block;background:#1f6f8b;color:white;border-radius:8px;padding:1px 5px;font-size:9px;margin-left:5px}
  #messageComposer{display:flex;gap:8px;align-items:flex-end;padding:8px 12px;background:#202c33;border-top:1px solid #293744;box-sizing:border-box}#messageInput{flex:1;min-height:38px;max-height:120px;resize:none;border-radius:18px;padding:9px 12px;font-family:inherit;font-size:var(--message-font-size,13px);line-height:1.25;background:#2a3942;color:#fff;caret-color:#fff}#messageInput::placeholder{color:#9fb0bf;opacity:1}#messageSend{width:42px;height:42px;border-radius:50%;font-size:20px;background:#00a884;border-color:#00a884;color:#fff;padding:0;display:flex;align-items:center;justify-content:center}.msgCounter{font-size:10px;color:#91a4b3;min-width:52px;text-align:right;padding-bottom:11px}.msgCounter.over{color:#ff8f8f;font-weight:800}
  #messagesNav.unread{animation:messagesUnread 1.15s ease-in-out infinite;border-color:#53bdeb;box-shadow:0 0 0 1px rgba(83,189,235,.25)}@keyframes messagesUnread{0%,100%{background:#233443;color:#edf3f8}50%{background:#0b6f81;color:#fff}}
  .unreadCount{display:none;background:#25d366;color:#07140c;border-radius:10px;min-width:18px;padding:1px 5px;margin-left:4px;font-size:10px;font-weight:900}.unread .unreadCount{display:inline-block}
  .msgActions{display:flex;gap:4px;justify-content:flex-end;margin-top:3px;opacity:.72}.msgActions button{padding:1px 6px;min-height:22px;border-radius:10px;font-size:11px;background:#26343d;border-color:#42515a;color:#d7e2e8}.msgRow:hover .msgActions{opacity:1}
  .msgReplyQuote{border-left:3px solid #53bdeb;background:rgba(0,0,0,.16);border-radius:5px;padding:5px 7px;margin:0 0 5px;font-size:11px;line-height:1.3}.msgReplyQuote b{display:block;color:#70cfff}.msgReplyQuote span{display:block;color:#c0ccd2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:680px}
  .msgReactions{display:flex;gap:5px;flex-wrap:wrap;margin-top:5px}.reactionChip{display:inline-flex;gap:5px;align-items:center;background:#182229;border:1px solid #40505a;border-radius:15px;padding:3px 8px;font-size:21px;line-height:1.1}.reactionChip b{font-size:11px;line-height:1}.reactionChip.mine{border-color:#53bdeb}
  .reactionPickerInline{display:none;gap:6px;flex-wrap:wrap;justify-content:flex-end;margin-top:5px}.reactionPickerInline.open{display:flex}.reactionPickerInline button{font-size:27px;line-height:1;padding:6px 8px;min-width:42px;min-height:40px;border-radius:10px;background:#26343d;border-color:#465762}
  #messageComposer{flex-wrap:wrap}.replyComposerBar{display:none;flex:0 0 100%;align-items:center;gap:8px;background:#182229;border-left:3px solid #53bdeb;border-radius:6px;padding:6px 8px;box-sizing:border-box}.replyComposerBar.open{display:flex}.replyComposerText{min-width:0;flex:1;font-size:11px;color:#c0ccd2}.replyComposerText b{display:block;color:#70cfff}.replyComposerText span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.replyComposerClose{padding:2px 7px;border-radius:50%;font-size:14px}
  .emojiToolBtn{width:42px;height:42px;border-radius:50%;font-size:27px;padding:0}.emojiPicker{display:none;position:absolute;left:12px;bottom:62px;width:min(390px,calc(100% - 80px));background:#17212b;border:1px solid #405668;border-radius:9px;box-shadow:0 10px 28px rgba(0,0,0,.42);padding:9px;z-index:1600;grid-template-columns:repeat(7,1fr);gap:6px}.emojiPicker.open{display:grid}.emojiPicker button{font-size:29px;line-height:1;padding:7px 3px;min-height:44px;background:#202c33;border-color:#40505a;border-radius:9px}
  .messageNewBelow{display:none;position:absolute;right:22px;bottom:78px;z-index:1550;align-items:center;gap:5px;border-radius:18px;padding:7px 12px;background:#0b6f81;border:1px solid #53bdeb;color:#fff;font-weight:800;box-shadow:0 4px 16px rgba(0,0,0,.35)}.messageNewBelow.open{display:flex}
  body[data-theme="light"] .msgReplyQuote,body[data-theme="light"] .replyComposerBar,body[data-theme="light"] .reactionChip{background:#f4f7f9;border-color:#cbd5dd}body[data-theme="light"] .emojiPicker{background:#fff;border-color:#b9c6cf}body[data-theme="light"] .emojiPicker button,body[data-theme="light"] .reactionPickerInline button,body[data-theme="light"] .msgActions button{background:#f4f7f9;color:#18232d;border-color:#c2ced6}body[data-theme="light"] .messageNewBelow{background:#087c9d;border-color:#0aa6c9;color:#fff}
  @media(max-width:650px){.msgBubble{max-width:88%}.msgText{padding-right:46px}#messageList{padding:10px 8px}#messageComposer{padding:8px}.msgCounter,.mentionHelp{display:none}.emojiPicker{left:8px;width:calc(100% - 70px)}}

  /* v1.20 - versão disponível e tema claro */
  .versionBadge{font-size:11px;font-weight:800;padding:5px 8px;border-radius:999px;white-space:nowrap;cursor:pointer}
  .versionBadge.checking{background:#263744;border-color:#405668;color:#cbd6df}.versionBadge.current{background:#174f37;border-color:#2f8b5e;color:#a9f5c5}.versionBadge.update{background:#6a4a13;border-color:#b98220;color:#ffe099}.versionBadge.error{background:#4c3940;border-color:#76535d;color:#f2bdca}
  .versionModalBackdrop{position:fixed;inset:0;z-index:5000;background:rgba(0,0,0,.58);display:none;align-items:center;justify-content:center;padding:18px;box-sizing:border-box}.versionModalBackdrop.open{display:flex}.versionModal{width:min(720px,96vw);max-height:min(78vh,760px);overflow:auto;background:#17212b;border:1px solid #405668;border-radius:12px;box-shadow:0 18px 55px rgba(0,0,0,.48);padding:18px;box-sizing:border-box}.versionModalHead{display:flex;align-items:center;gap:10px}.versionModalHead h2{margin:0;flex:1;font-size:18px}.versionClose{font-size:20px;line-height:1}.versionNotes{white-space:pre-wrap;background:#101820;border:1px solid #304353;border-radius:8px;padding:12px;font-size:12px;line-height:1.45;max-height:360px;overflow:auto}.versionActions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:12px}.versionActions a{display:inline-block;background:#234d63;color:#fff;border:1px solid #4c7e96;border-radius:6px;padding:6px 9px;text-decoration:none;font-weight:700}.updateCmd{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;background:#101820;border:1px solid #304353;border-radius:6px;padding:6px 8px;font-size:12px}

  body[data-theme="light"]{background:#f2f5f7;color:#18232d}
  body[data-theme="light"] header{background:#ffffff;border-bottom-color:#cbd5dd}
  body[data-theme="light"] #summary,body[data-theme="light"] #trafficToolbar{background:#f5f7f9;border-color:#cbd5dd}
  body[data-theme="light"] #playback,body[data-theme="light"] #trafficStats{background:#edf2f5;border-color:#cbd5dd}
  body[data-theme="light"] .metric,body[data-theme="light"] .settingsCard,body[data-theme="light"] .dashCard,body[data-theme="light"] .dashSection,body[data-theme="light"] #packetDetail{background:#ffffff;border-color:#cbd5dd;color:#18232d}
  body[data-theme="light"] .dashSection h3,body[data-theme="light"] .trafficTable th,body[data-theme="light"] .dashTable th{background:#e9eef2;color:#263746;border-color:#cbd5dd}
  body[data-theme="light"] .trafficTable td,body[data-theme="light"] .dashTable td,body[data-theme="light"] .settingRow,body[data-theme="light"] .anomalyRow{border-color:#dce3e8}
  body[data-theme="light"] .trafficTable tbody tr:hover{background:#edf4f8}body[data-theme="light"] .trafficTable tbody tr.selected{background:#dcebf4}
  body[data-theme="light"] select,body[data-theme="light"] input,body[data-theme="light"] button,body[data-theme="light"] textarea{background:#ffffff;color:#17212b;border-color:#aebbc5}
  body[data-theme="light"] .navbtn.active{background:#e4b800;color:#101820;border-color:#b99700}
  body[data-theme="light"] label,body[data-theme="light"] #playStatus{color:#344654}
  body[data-theme="light"] .settingDesc,body[data-theme="light"] .methodNote,body[data-theme="light"] .emptyDetail,body[data-theme="light"] .emptyPanel{color:#627582}
  body[data-theme="light"] #viewHealth,body[data-theme="light"] #viewAnomalies{background:#f2f5f7}
  body[data-theme="light"] #viewMessages{background:#efeae2}
  body[data-theme="light"] #messageHeader{background:#ffffff;border-color:#cbd5dd;color:#18232d}
  body[data-theme="light"] #messageList{background:#efeae2}
  body[data-theme="light"] .msgRow.theirs .msgBubble{background:#ffffff;color:#17212b}.msgRow.mine .msgBubble{color:#ffffff}
  body[data-theme="light"] .msgRow.mine .msgBubble{background:#d9fdd3;color:#17212b}
  body[data-theme="light"] .msgMeta{color:#5f6f78}body[data-theme="light"] .msgSender{color:#087c9d}
  body[data-theme="light"] #messageComposer{background:#f0f2f5;border-color:#cbd5dd}body[data-theme="light"] #messageInput{background:#ffffff;color:#17212b;caret-color:#17212b}body[data-theme="light"] #messageInput::placeholder{color:#778894}
  body[data-theme="light"] .legend,body[data-theme="light"] .traceHud{background:rgba(255,255,255,.96);color:#17212b;border-color:#aebbc5}
  body[data-theme="light"] .short-label{background:rgba(255,255,255,.93);color:#17212b;border-color:#8ca0ae}
  body[data-theme="light"] .leaflet-popup-content-wrapper,body[data-theme="light"] .leaflet-popup-tip{background:#ffffff;color:#17212b}
  body[data-theme="light"] .versionModal{background:#ffffff;color:#17212b;border-color:#aebbc5}body[data-theme="light"] .versionNotes,body[data-theme="light"] .updateCmd{background:#f5f7f9;color:#17212b;border-color:#cbd5dd}

  /* v1.21 - menções */
  #messageComposer{position:relative}.mentionSuggestions{position:absolute;left:12px;bottom:58px;width:min(560px,calc(100% - 88px));max-height:260px;overflow:auto;background:#17212b;border:1px solid #405668;border-radius:9px;box-shadow:0 10px 28px rgba(0,0,0,.42);z-index:1500;display:none}.mentionSuggestions.open{display:block}.mentionItem{display:grid;grid-template-columns:minmax(70px,100px) minmax(0,1fr);gap:8px;padding:8px 10px;cursor:pointer;border-bottom:1px solid #293744}.mentionItem:last-child{border-bottom:0}.mentionItem:hover,.mentionItem.active{background:#263b4d}.mentionShort{font-weight:900;color:#e9d46d}.mentionLong{font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mentionId{font-size:10px;color:#8194a5}.chatMention{color:#70cfff;font-weight:800}.mentionHelp{font-size:10px;color:#91a4b3;margin-left:6px}
body[data-theme="light"] .mentionSuggestions{background:#ffffff;border-color:#aebbc5;color:#17212b}body[data-theme="light"] .mentionItem{border-color:#dce3e8}body[data-theme="light"] .mentionItem:hover,body[data-theme="light"] .mentionItem.active{background:#e7f1f7}body[data-theme="light"] .mentionShort{color:#8a6b00}body[data-theme="light"] .mentionId{color:#6f808c}body[data-theme="light"] .chatMention{color:#087c9d}

  /* v1.22 - internacionalização e ajuda */
  .languageControl{position:relative;display:flex;align-items:center;white-space:nowrap}.languageButton{display:flex;align-items:center;gap:7px;min-width:118px;padding:5px 9px;border-radius:8px;border:1px solid #2f83b7;background:#12283a;color:#f2f7fb;font-size:11px;font-weight:800;cursor:pointer;line-height:1.15}.languageButton:hover,.languageButton:focus-visible{background:#19364d;border-color:#49a6dd;outline:none}.languageFlag{display:inline-flex;align-items:center;justify-content:center;width:21px;height:15px;flex:0 0 21px;line-height:1;overflow:hidden;border-radius:2px;box-shadow:0 0 0 1px rgba(255,255,255,.18)}.languageFlagSvg{display:block;width:21px;height:15px}.languageName{flex:1;text-align:left}.languageCaret{font-size:9px;color:#a9bed0;margin-left:2px}.languageMenu{position:absolute;top:calc(100% + 5px);left:0;z-index:5200;display:none;min-width:148px;padding:5px;background:#111a24;border:1px solid #304353;border-radius:8px;box-shadow:0 12px 28px rgba(0,0,0,.48)}.languageMenu.open{display:grid;gap:2px}.languageOption{display:flex;align-items:center;gap:8px;width:100%;padding:7px 8px;border:0;border-radius:6px;background:transparent;color:#dbe6ee;font-size:11px;font-weight:700;text-align:left;cursor:pointer}.languageOption:hover,.languageOption:focus-visible{background:#263b4d;outline:none}.languageOption.selected{background:#20384c;color:#fff}.languageOption .languageCheck{margin-left:auto;opacity:0;font-size:10px}.languageOption.selected .languageCheck{opacity:1}.languageSr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
  #viewHelp{overflow:auto}.helpCard{max-width:1100px;margin:18px auto;background:#17212b;border:1px solid #304353;border-radius:10px;padding:22px;width:calc(100% - 36px);box-sizing:border-box;line-height:1.5}.helpCard h2{margin:0 0 8px}.helpCard h3{margin:22px 0 7px;color:#e9d46d}.helpCard h4{margin:15px 0 5px;color:#9fc6e4}.helpCard p,.helpCard li{font-size:13px}.helpCard ul{padding-left:22px}.helpCard code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;background:#101820;border:1px solid #304353;border-radius:4px;padding:1px 4px}.helpCode{white-space:pre-wrap;font-family:ui-monospace,SFMono-Regular,Consolas,monospace;background:#101820;border:1px solid #304353;border-radius:7px;padding:10px 12px;font-size:12px;overflow:auto}.helpCallout{background:#132a38;border-left:4px solid #3a8fbd;border-radius:6px;padding:10px 12px;margin:10px 0;font-size:12px}.helpWarn{background:#382d13;border-left-color:#d6a700}.helpGrid{display:grid;grid-template-columns:repeat(2,minmax(260px,1fr));gap:10px 18px}.helpMini{background:#111a24;border:1px solid #293744;border-radius:8px;padding:11px}.helpMini b{display:block;margin-bottom:4px}.i18nNoTranslate{unicode-bidi:plaintext}
  body[data-theme="light"] .languageButton{background:#fff;color:#17212b;border-color:#8fb6cf}body[data-theme="light"] .languageButton:hover,body[data-theme="light"] .languageButton:focus-visible{background:#edf6fb;border-color:#4a9dcc}body[data-theme="light"] .languageMenu{background:#fff;border-color:#aebbc5;box-shadow:0 12px 28px rgba(30,50,65,.22)}body[data-theme="light"] .languageOption{color:#263746}body[data-theme="light"] .languageOption:hover,body[data-theme="light"] .languageOption:focus-visible{background:#e7f1f7}body[data-theme="light"] .languageOption.selected{background:#dbeaf4;color:#17212b}body[data-theme="light"] .helpCard{background:#fff;border-color:#cbd5dd;color:#18232d}body[data-theme="light"] .helpCard h3{color:#7a6500}body[data-theme="light"] .helpCard h4{color:#245f7c}body[data-theme="light"] .helpMini{background:#f5f7f9;border-color:#dce3e8}body[data-theme="light"] .helpCode,body[data-theme="light"] .helpCard code{background:#f5f7f9;border-color:#cbd5dd;color:#17212b}body[data-theme="light"] .helpCallout{background:#e8f3f8}body[data-theme="light"] .helpWarn{background:#fff6d9}
  @media(max-width:780px){.helpGrid{grid-template-columns:1fr}.helpCard{width:calc(100% - 20px);margin:10px auto;padding:15px}}

  /* v1.23 - conforto visual, filtros e atualização automática */
  #viewMessages{--message-font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;--message-font-weight:400;--message-font-style:normal;--message-text-decoration:none;--message-line-height:1.35;--message-row-gap:4px}
  .msgRow{margin-top:var(--message-row-gap,4px)!important;margin-bottom:var(--message-row-gap,4px)!important}
  .msgText{font-family:var(--message-font-family)!important;font-weight:var(--message-font-weight)!important;font-style:var(--message-font-style)!important;text-decoration:var(--message-text-decoration)!important;line-height:var(--message-line-height)!important}
  #messageInput{font-family:var(--message-font-family)!important;font-weight:var(--message-font-weight)!important;font-style:var(--message-font-style)!important;text-decoration:var(--message-text-decoration)!important;line-height:var(--message-line-height)!important}
  .styleChecks{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-top:7px}.styleChecks label{font-size:12px}
  .anomalyFilter{display:flex;gap:5px;align-items:center}
  .updateStatusBox{background:#111a24;border:1px solid #293744;border-radius:8px;padding:10px 12px;font-size:12px;line-height:1.5;min-height:48px}.updateStatusBox b{color:#dbe6ee}
  .updateState-running,.updateState-pending{color:#ffd166;font-weight:800}.updateState-success,.updateState-no_change{color:#7af0ad;font-weight:800}.updateState-failed,.updateState-rolled_back{color:#ff9c9c;font-weight:800}
  body[data-theme="light"] .updateStatusBox{background:#f5f7f9;border-color:#dce3e8;color:#263746}body[data-theme="light"] .updateStatusBox b{color:#18232d}
  .whatsNewList{white-space:pre-wrap;line-height:1.55}.whatsNewList .wnItem{margin:0 0 7px}
  .authControls{display:flex;align-items:center;gap:6px;margin-left:auto}.authBadge{font-size:11px;font-weight:800;padding:5px 8px;border-radius:12px;background:#5a4213;color:#ffe49a;border:1px solid #7d6222}.authBadge.admin{background:#174f37;color:#9df0bd;border-color:#2a7553}.authBadge.disabled{background:#344555;color:#c9d5de;border-color:#526779}.authAction{font-weight:800;padding:5px 9px}
  .authModalForm{display:grid;gap:10px;margin-top:12px}.authModalForm label{display:grid;gap:5px;font-size:12px}.authModalForm input{font-size:14px;padding:9px}.authError{min-height:18px;color:#ff9c9c;font-size:12px}.authHint{background:#111a24;border:1px solid #304353;border-radius:7px;padding:9px;font-size:12px;color:#aebbc7;line-height:1.45}
  .readOnlyBanner{display:none;margin:8px 0 14px;padding:9px 11px;border-radius:7px;background:#5a4213;border:1px solid #7d6222;color:#ffe49a;font-size:12px;font-weight:700}.readOnlyBanner.open{display:block}
  .messageReadOnly{display:none;padding:4px 8px;border-radius:10px;background:#5a4213;color:#ffe49a;border:1px solid #7d6222;font-size:10px;font-weight:800}.messageReadOnly.open{display:inline-block}
  #viewSettings.authLocked .settingsCard input:disabled,#viewSettings.authLocked .settingsCard select:disabled,#viewSettings.authLocked .settingsCard button:disabled{opacity:.58;cursor:not-allowed}
  .localPrefsToolbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:8px 0 14px;padding:10px 11px;border:1px solid #304353;border-radius:7px;background:#111a24}.localPrefsToolbar .settingDesc{margin:0;flex:1;min-width:240px}.adminOnlyBadge{display:inline-block;margin-left:7px;padding:2px 7px;border-radius:999px;background:#4f3d13;border:1px solid #806620;color:#ffe49a;font-size:10px;vertical-align:middle}.adminOnlySection.locked{opacity:.78}.adminOnlySection.locked .settingDesc{color:#81909d}
  #messageComposer.readOnly{opacity:.68}.authLockIcon{font-weight:900;margin-right:4px}
  body[data-theme="light"] .authHint{background:#f5f7f9;border-color:#cbd5dd;color:#425566}body[data-theme="light"] .readOnlyBanner,body[data-theme="light"] .messageReadOnly{background:#fff5d2;color:#6f5310;border-color:#d9bb56}

.mesh-role-marker{background:transparent;border:0}
.mesh-role-marker svg{display:block;filter:drop-shadow(0 1px 2px #0008)}
.mesh-role-marker:focus-visible{outline:2px solid #fff;outline-offset:2px;border-radius:50%}
.roleLegend{margin-top:8px;border-top:1px solid #8ea6b544;padding-top:5px}
.roleLegend summary{cursor:pointer;font-weight:600}
.roleLegendGrid{display:grid;grid-template-columns:1fr 1fr;gap:5px 10px;max-height:185px;overflow:auto;margin-top:6px}
.roleLegendItem{display:flex;align-items:center;gap:4px;white-space:nowrap;font-size:11px}
.roleLegendItem svg{width:24px;height:24px;flex-shrink:0}
</style>
</head>
<body>
<div id="flowToast" title="Clique para abrir o mapa"></div>
<div id="versionModalBackdrop" class="versionModalBackdrop" role="dialog" aria-modal="true" aria-labelledby="versionModalTitle">
  <div class="versionModal">
    <div class="versionModalHead"><h2 id="versionModalTitle">Versão do Traffic Analyzer</h2><button id="versionModalClose" class="versionClose" type="button" title="Fechar">×</button></div>
    <p id="versionModalSummary" class="settingDesc">Consultando a versão publicada…</p>
    <div id="versionNotes" class="versionNotes">Sem informações carregadas.</div>
    <div class="versionActions"><a id="versionReleaseLink" href="https://github.com/alexpmr/traffic-analyzer/releases/latest" target="_blank" rel="noopener noreferrer">Ver Release no GitHub</a><button id="versionCloseAction" type="button">Fechar</button><button id="versionContinue" type="button">Continuar</button></div>
  </div>
</div>
<div id="whatsNewBackdrop" class="versionModalBackdrop" role="dialog" aria-modal="true" aria-labelledby="whatsNewTitle">
  <div class="versionModal">
    <div class="versionModalHead"><h2 id="whatsNewTitle">Traffic Analyzer atualizado</h2><button id="whatsNewClose" class="versionClose" type="button" title="Fechar">×</button></div>
    <p id="whatsNewSummary" class="settingDesc"></p>
    <div id="whatsNewNotes" class="versionNotes whatsNewList"></div>
    <div class="versionActions"><a id="whatsNewReleaseLink" href="https://github.com/alexpmr/traffic-analyzer/releases/latest" target="_blank" rel="noopener noreferrer">Ver Release no GitHub</a><button id="whatsNewOk" type="button">Fechar</button></div>
  </div>
</div>
<div id="authModalBackdrop" class="versionModalBackdrop" role="dialog" aria-modal="true" aria-labelledby="authModalTitle">
  <div class="versionModal authModal">
    <div class="versionModalHead"><h2 id="authModalTitle">Entrar como administrador</h2><button id="authModalClose" class="versionClose" type="button" title="Fechar">×</button></div>
    <div id="authModalHint" class="authHint">O acesso sem login permanece em modo somente leitura.</div>
    <div class="authModalForm">
      <label>Usuário <input id="authUsername" type="text" autocomplete="username" maxlength="64" value="admin"></label>
      <label>Senha <input id="authPassword" type="password" autocomplete="current-password"></label>
      <div id="authError" class="authError"></div>
      <button id="authLoginSubmit" type="button">Entrar</button>
    </div>
  </div>
</div>
<div id="app">
<header>
  <h1>__DISPLAY_TITLE__</h1>
  <div class="languageControl i18nNoTranslate" id="languageControl">
    <span class="languageSr">Idioma da interface</span>
    <button id="uiLanguageButton" class="languageButton" type="button" aria-haspopup="listbox" aria-expanded="false" aria-label="Idioma da interface" title="Idioma da interface">
      <span id="uiLanguageFlag" class="languageFlag" aria-hidden="true"><svg class="languageFlagSvg" viewBox="0 0 28 20" focusable="false" aria-hidden="true"><rect width="28" height="20" rx="1.5" fill="#009c3b"/><polygon points="14,2 26,10 14,18 2,10" fill="#ffdf00"/><circle cx="14" cy="10" r="4.3" fill="#002776"/><path d="M9.9 9.4c2.8-1 5.8-.7 8.4.8" fill="none" stroke="#fff" stroke-width=".85"/></svg></span>
      <span id="uiLanguageName" class="languageName">Português</span>
      <span class="languageCaret" aria-hidden="true">▾</span>
    </button>
    <div id="uiLanguageMenu" class="languageMenu" role="listbox" aria-label="Idioma da interface">
      <button class="languageOption selected" type="button" role="option" aria-selected="true" data-language="pt-BR"><span class="languageFlag" aria-hidden="true"><svg class="languageFlagSvg" viewBox="0 0 28 20" focusable="false" aria-hidden="true"><rect width="28" height="20" rx="1.5" fill="#009c3b"/><polygon points="14,2 26,10 14,18 2,10" fill="#ffdf00"/><circle cx="14" cy="10" r="4.3" fill="#002776"/><path d="M9.9 9.4c2.8-1 5.8-.7 8.4.8" fill="none" stroke="#fff" stroke-width=".85"/></svg></span><span>Português</span><span class="languageCheck" aria-hidden="true">✓</span></button>
      <button class="languageOption" type="button" role="option" aria-selected="false" data-language="en"><span class="languageFlag" aria-hidden="true"><svg class="languageFlagSvg" viewBox="0 0 28 20" focusable="false" aria-hidden="true"><rect width="28" height="20" rx="1.5" fill="#fff"/><g fill="#b22234"><rect width="28" height="1.54"/><rect y="3.08" width="28" height="1.54"/><rect y="6.16" width="28" height="1.54"/><rect y="9.24" width="28" height="1.54"/><rect y="12.32" width="28" height="1.54"/><rect y="15.40" width="28" height="1.54"/><rect y="18.46" width="28" height="1.54"/></g><rect width="12.2" height="10.78" fill="#3c3b6e"/><g fill="#fff"><circle cx="2" cy="2" r=".55"/><circle cx="5" cy="2" r=".55"/><circle cx="8" cy="2" r=".55"/><circle cx="11" cy="2" r=".55"/><circle cx="3.5" cy="4.5" r=".55"/><circle cx="6.5" cy="4.5" r=".55"/><circle cx="9.5" cy="4.5" r=".55"/><circle cx="2" cy="7" r=".55"/><circle cx="5" cy="7" r=".55"/><circle cx="8" cy="7" r=".55"/><circle cx="11" cy="7" r=".55"/><circle cx="3.5" cy="9.4" r=".55"/><circle cx="6.5" cy="9.4" r=".55"/><circle cx="9.5" cy="9.4" r=".55"/></g></svg></span><span>English</span><span class="languageCheck" aria-hidden="true">✓</span></button>
    </div>
  </div>
  <button id="versionBadge" class="versionBadge checking" type="button" title="Verificar versão">v__APP_VERSION__ · verificando…</button>
  <div class="authControls"><span id="authStateBadge" class="authBadge">Verificando acesso…</span><button id="authAction" class="authAction" type="button">Entrar</button></div>
  <div id="nav">
    <button class="navbtn active" data-view="map">Mapa</button>
    <button class="navbtn" data-view="nodes">Nós</button>
    <button class="navbtn" data-view="traffic">Tráfego</button>
    <button class="navbtn" id="messagesNav" data-view="messages">Mensagens <span id="messagesUnreadCount" class="unreadCount">0</span></button>
    <button class="navbtn" data-view="statistics">Estatísticas</button>
    <button class="navbtn" data-view="automations">Automações</button>
    <button class="navbtn" data-view="settings">Configurações</button>
    <button class="navbtn" data-view="help">Ajuda</button>
  </div>
</header>
<section id="viewMap" class="view active">
<div id="summary"></div>
<div id="playback">
  <label>Reprodução:
    <select id="playMode">
      <option value="history">Histórico</option>
      <option value="live" selected>Ao vivo</option>
    </select>
  </label>
  <button id="prevTrace" title="Traceroute anterior">⏮</button>
  <button id="playTrace" title="Pausar animações ao vivo">⏸</button>
  <button id="nextTrace" title="Próximo traceroute">⏭</button>
  <label>Velocidade:
    <select id="animSpeed">
      <option value="80">0,5x</option>
      <option value="150" selected>1x</option>
      <option value="280">2x</option>
      <option value="500">4x</option>
    </select>
  </label>
  <span id="playStatus">Histórico pronto.</span>
  <div class="mapActions">
    <div id="mapSearchPanel" class="mapSearchBox">
      <label for="mapSearchInput" class="mapSearchLabel" title="Pesquisar estações por nome ou Node ID">⌕</label>
      <input id="mapSearchInput" type="search" placeholder="Pesquisar nó..." aria-label="Pesquisar nós no mapa por nome curto, longo, histórico ou Node ID" autocomplete="off" maxlength="120">
      <button id="mapSearchClear" type="button" title="Limpar pesquisa e restaurar mapa" aria-label="Limpar pesquisa">×</button>
      <span id="mapSearchCount" class="mapSearchInfo" role="status"></span>
      <div id="mapSearchMatches" class="mapSearchMatches" hidden></div>
    </div>
    <label>Mapa:
      <select id="mapToolbarType" title="Escolher mapa-base">
        <option value="osm">OSM / Ruas</option>
        <option value="topo">Topográfico</option>
        <option value="light">Claro</option>
        <option value="dark">Escuro</option>
        <option value="satellite">Satélite</option>
      </select>
    </label>
    <details id="mapLayersMenu" class="mapLayersMenu">
      <summary>Camadas</summary>
      <div class="mapLayersPanel">
        <label><input id="weatherRadarEnabled" type="checkbox" checked> Radar meteorológico</label>
        <div id="weatherRadarStatus" class="layerStatus">Ligado</div>
        <label><input id="rfCoverageEnabled" type="checkbox"> Cobertura RF</label>
        <div id="rfCoverageStatus" class="layerStatus">Desligado</div>
        <label><input id="hillshadeEnabled" type="checkbox"> Relevo sombreado</label>
        <div id="hillshadeStatus" class="layerStatus">Desligado</div>
        <label><input id="elevationEnabled" type="checkbox"> Relevo com corte</label>
        <div id="elevationStatus" class="layerStatus">Desligado</div>
        <label class="layerSubControl">Opacidade <input id="elevationOpacity" type="range" min="10" max="100" step="5" value="55"> <span id="elevationOpacityValue">55%</span></label>
        <label><input id="lightningEnabled" type="checkbox"> Raios</label>
        <div id="lightningStatus" class="layerStatus">Desligado</div>
        <label><input id="alertsEnabled" type="checkbox"> Alertas meteorológicos</label>
        <div id="alertsStatus" class="layerStatus">Desligado</div>
        <label><input id="cloudsEnabled" type="checkbox"> Nuvens</label>
        <div id="cloudsStatus" class="layerStatus">Desligado</div>
      </div>
    </details>
    <button id="clearLinkIsolation" type="button" style="display:none">Mostrar todos os nós e enlaces</button><button id="fit">Enquadrar</button><button id="reload">Atualizar</button>
  </div>
</div>
<div id="map"></div>
<div id="nodeWindow" class="nodeWindow" role="dialog" aria-label="Informações do nó">
  <div id="nodeWindowHeader" class="nodeWindowHeader">
    <span class="nodeWindowGrip" aria-hidden="true">⠿</span>
    <div class="nodeWindowTitleWrap"><div id="nodeWindowTitle" class="nodeWindowTitle">Nó</div><div id="nodeWindowId" class="nodeWindowId"></div></div>
    <div class="nodeWindowActions">
      <button id="nodeWindowReset" type="button">↺ Reposicionar</button>
      <button id="nodeWindowExpand" type="button">⛶ Expandir</button>
      <button id="nodeWindowClose" class="nodeWindowClose" type="button">Fechar</button>
    </div>
  </div>
  <div id="nodeWindowBody" class="nodeWindowBody"></div>
  <div id="nodeWindowResizeHandle" class="nodeWindowResizeHandle" title="Arraste para redimensionar"></div>
</div>
</section>
<section id="viewNodes" class="view">
  <div class="nodesWrap">
    <div class="nodesToolbar">
      <h2>Nós</h2>
      <span id="nodesSummary" class="settingDesc">Carregando...</span>
      <div class="nodesFilter"><label>Filtrar: <input id="nodesFilter" type="search" placeholder="nome, ID, hardware..." autocomplete="off"></label><button id="nodesFilterClear" class="nodesFilterClear" type="button" title="Limpar filtro">×</button></div>
      <div class="nodesColumnsMenu">
        <button id="nodesColumnsButton" type="button">Colunas</button>
        <div id="nodesColumnsPanel" class="nodesColumnsPanel">
          <label><input type="checkbox" data-node-column="rssi"> RSSI</label>
          <label><input type="checkbox" data-node-column="channelUtilization"> Utilização do canal</label>
          <label><input type="checkbox" data-node-column="airUtilTx"> Air Util TX</label>
          <label><input type="checkbox" data-node-column="nodeId"> Node ID</label>
          <label><input type="checkbox" data-node-column="pkc"> PKC</label>
          <label><input type="checkbox" data-node-column="state"> Estado</label>
        </div>
      </div>
      <button id="nodesReload" type="button">Atualizar</button>
    </div>
    <div id="nodesBulkBar" class="nodesBulkBar" hidden>
      <b id="nodesBulkCount">0 nós selecionados</b>
      <button type="button" data-node-bulk="favorite">☆ Favoritar</button>
      <button type="button" data-node-bulk="unfavorite">★ Desfavoritar</button>
      <button type="button" data-node-bulk="hide">Ocultar no mapa</button>
      <button type="button" data-node-bulk="show">Mostrar no mapa</button>
      <button type="button" data-node-bulk="nodeinfo">ℹ Node Info</button>
      <button type="button" data-node-bulk="traceroute">⇢ Traceroute</button>
      <button type="button" data-node-bulk="copy">Copiar IDs</button>
      <button type="button" data-node-bulk="csv">Exportar CSV</button>
      <button type="button" data-node-bulk="deleteLocal" class="nodesBulkDanger">🗑 Excluir do banco local</button>
      <button type="button" data-node-bulk="deleteEverywhere" class="nodesBulkDanger">🗑 Excluir da base e do dispositivo</button>
      <button type="button" data-node-bulk="clear">Limpar seleção</button>
    </div>
    <div id="nodesTableWrap" class="nodesTableWrap">
      <table id="nodesTable" class="nodesTable">
        <thead><tr>
          <th class="nodeSelectCol"><input id="nodesSelectAll" type="checkbox" title="Selecionar todos os nós filtrados" aria-label="Selecionar todos os nós filtrados"></th>
          <th data-node-sort="longName">Nome longo</th>
          <th data-node-sort="shortName">Nome curto</th>
          <th data-node-sort="role">Role</th>
          <th data-node-sort="hardware">Hardware</th>
          <th data-node-sort="hops">Saltos</th>
          <th data-node-sort="battery">Bateria</th>
          <th data-node-sort="voltage">Tensão</th>
          <th data-node-sort="distance">Distância</th>
          <th data-node-sort="snr">SNR</th>
          <th data-node-sort="lastInteraction">Última interação</th>
          <th data-node-sort="lastPosition">Última posição</th>
          <th class="nodeOptional col-rssi" data-node-sort="rssi">RSSI</th>
          <th class="nodeOptional col-channelUtilization" data-node-sort="channelUtilization">Utilização do canal</th>
          <th class="nodeOptional col-airUtilTx" data-node-sort="airUtilTx">Air Util TX</th>
          <th class="nodeOptional col-nodeId" data-node-sort="nodeId">Node ID</th>
          <th class="nodeOptional col-pkc" data-node-sort="pkc">PKC</th>
          <th class="nodeOptional col-state" data-node-sort="state">Estado</th>
        </tr></thead>
        <tbody id="nodesRows"><tr><td colspan="18">Carregando nós...</td></tr></tbody>
      </table>
    </div>
  </div>
</section>
<div id="nodeDetailsBackdrop" class="versionModalBackdrop" role="dialog" aria-modal="true" aria-label="Detalhes do nó">
  <div class="versionModal nodeDetailsModal">
    <div class="versionModalHead"><h2>Detalhes do nó</h2><button id="nodeDetailsClose" class="versionClose" type="button" title="Fechar">×</button></div>
    <div id="nodeDetailsModalBody"></div>
  </div>
</div>
<section id="viewTraffic" class="view">

  <div id="trafficToolbar">
    <b>Tráfego ao vivo</b>
    <span id="trafficLive" class="liveBadge">● AO VIVO</span>
    <label>Direção: <select id="trafficDirection"><option value="all">Todos</option><option value="rx">RX</option><option value="tx">TX</option></select></label>
    <label>Tipo: <select id="trafficType"><option value="all">Todos</option><option value="TEXT_MESSAGE_APP">Mensagem</option><option value="POSITION_APP">Position</option><option value="NODEINFO_APP">NodeInfo</option><option value="TELEMETRY_APP">Telemetry</option><option value="TRACEROUTE_APP">Traceroute</option><option value="ROUTING_APP">Routing</option><option value="NEIGHBORINFO_APP">NeighborInfo</option><option value="ADMIN_APP">Admin</option></select></label>
    <label>Buscar: <input id="trafficSearch" type="search" placeholder="nó, ID, tipo..." style="width:180px"></label>
    <button id="trafficPause">Pausar</button>
    <button id="trafficReload">Atualizar</button>
    <button id="trafficDump" class="downloadBtn" title="Baixa todo o histórico persistente em traffic.json dentro de um ZIP">Baixar dump JSON (.zip)</button>
  </div>
  <div id="trafficStats"></div>
  <div id="trafficBody">
    <div id="trafficTableWrap">
      <table class="trafficTable">
        <thead><tr><th>Hora</th><th>DIR</th><th>Origem</th><th>Destino</th><th>Tipo</th><th>SNR</th><th>RSSI</th><th>Hops</th></tr></thead>
        <tbody id="trafficRows"><tr><td colspan="8">Carregando pacotes...</td></tr></tbody>
      </table>
    </div>
    <aside id="packetDetail"><div class="emptyDetail">Clique em um pacote para ver os detalhes.</div></aside>
  </div>
</section>


<section id="viewMessages" class="view">
  <div id="messageHeader">
    <span class="msgTitle">Canal primário</span><span class="msgHint">Canal 0 - mensagens de broadcast</span><span id="messageReadOnly" class="messageReadOnly">🔒 Somente leitura — faça login para enviar ou reagir</span>
    <span class="msgSpacer"></span><span id="messageStatus" class="msgHint">Carregando...</span><button id="messageLoadOlder" title="Carregar mais mensagens antigas">Carregar anteriores</button><button id="messageReload" title="Consultar novas mensagens agora">Atualizar</button>
  </div>
  <div id="messageList"><div class="emptyPanel">Carregando mensagens...</div></div>
  <button id="messageNewBelow" class="messageNewBelow" type="button">↓ Novas mensagens</button>
  <div id="messageComposer">
    <div id="replyComposerBar" class="replyComposerBar"><div id="replyComposerText" class="replyComposerText"></div><button id="replyComposerClose" class="replyComposerClose" type="button" title="Cancelar resposta">×</button></div>
    <div id="mentionSuggestions" class="mentionSuggestions"></div>
    <div id="emojiPicker" class="emojiPicker"></div>
    <button id="messageEmojiBtn" class="emojiToolBtn" type="button" title="Inserir emoji">☺</button>
    <textarea id="messageInput" rows="1" placeholder="Digite uma mensagem"></textarea><span id="messageCounter" class="msgCounter">0 B</span><span class="mentionHelp">Use @ para localizar um nó; o @ é removido antes da transmissão.</span><button id="messageSend" title="Enviar">➤</button>
  </div>
</section>
<section id="viewStatistics" class="view">
  <div class="statsShell">
    <div class="statsTopbar">
      <div class="statsHeader">
        <h2>Estatísticas</h2>
        <label>Período: <select id="statsPeriod"><option value="1">1 h</option><option value="6">6 h</option><option value="24">24 h</option><option value="168">7 dias</option><option value="720">30 dias</option><option value="all" selected>Todo</option></select></label>
        <label>Nó: <select id="statsNodeFilter"><option value="">Todos</option></select></label>
        <button id="statsReload" type="button">Atualizar tudo</button><span id="statsUpdated" class="settingDesc"></span>
        <button id="statsReport" type="button" title="Abre um relatório estruturado pronto para imprimir ou salvar como PDF">Relatório / PDF</button>
        <button id="statsExportCsv" type="button" title="Exporta o tráfego do período/filtro atual em CSV">Exportar CSV</button>
        <span id="statsAccessControls" class="statsAccessControls">
          <span class="statsContextLabel">Acessos</span><span id="accessUpdated" class="settingDesc"></span>
          <label>Período: <select id="accessDays"><option value="7">7 dias</option><option value="30" selected>30 dias</option><option value="90">90 dias</option><option value="365">1 ano</option></select></label>
          <button id="accessReload">Atualizar</button><button id="accessDownload">Baixar log</button>
        </span>
      </div>
      <div class="statsTabs">
        <button class="statsTab active" data-stats-tab="overview">Visão Geral</button><button class="statsTab" data-stats-tab="network">Rede</button><button class="statsTab" data-stats-tab="rf">RF</button><button class="statsTab" data-stats-tab="ranking">Ranking</button><button class="statsTab" data-stats-tab="routing">Routing</button><button class="statsTab" data-stats-tab="traffic">Tráfego</button><button class="statsTab" data-stats-tab="queries">Consultas</button><button class="statsTab" data-stats-tab="chat">Chat</button><button class="statsTab" data-stats-tab="energy">Energia</button><button class="statsTab" data-stats-tab="anomalies">Pontos de atenção</button><button class="statsTab" data-stats-tab="access">Acessos</button>
      </div>
    </div>
    <div id="statsContent" class="statsContent">
    <div id="statsPanelOverview" class="statsPanel active dashboardWrap"><div id="statsOverviewCards" class="dashGrid"><div class="dashCard"><div class="label">Carregando...</div></div></div><div id="statsOverviewText" class="statsOverviewText">Calculando resumo da rede...</div><div class="statsSplit"><div class="dashSection"><h3>Tipos de tráfego</h3><div id="statsOverviewTypes" class="dashSectionBody"></div></div><div class="dashSection"><h3>Nós mais ativos</h3><div id="statsOverviewNodes" class="dashSectionBody"></div></div></div></div>
    <div id="statsPanelNetwork" class="statsPanel"><div id="viewHealth"><div class="dashboardWrap"><div class="dashboardToolbar"><h2>Saúde da Rede</h2><span id="healthUpdated" class="settingDesc"></span><button id="healthReload">Atualizar</button></div><div id="healthCards" class="dashGrid"></div><div class="dashSection"><h3>Atividade dos últimos 7 dias</h3><div class="dashSectionBody"><div id="healthDaily" class="miniBars"></div></div></div><div class="dashSection"><h3>Traceroutes e roteamento</h3><div id="healthRoutes" class="dashSectionBody"></div></div><div class="dashSection"><h3>Interações por chat no canal primário</h3><div class="dashSectionBody"><table class="dashTable"><thead><tr><th>Nó</th><th>Interações</th></tr></thead><tbody id="healthChatRows"></tbody></table></div></div><div class="dashSection"><h3>Nós que merecem atenção</h3><div class="dashSectionBody"><table class="dashTable"><thead><tr><th>Nó</th><th>Último tráfego</th><th>Tempo sem ouvir</th><th>Pacotes 7d</th><th>SNR médio 7d</th></tr></thead><tbody id="healthSilentRows"></tbody></table></div></div></div></div></div>
    <div id="statsPanelRf" class="statsPanel dashboardWrap"><div id="statsRfCards" class="dashGrid"></div><div class="dashSection"><h3>Enlaces observados com maior atividade</h3><div class="dashSectionBody statsFitBody"><table class="dashTable statsCompactTable statsFitTable"><thead><tr><th>Origem</th><th>Destino</th><th>Pacotes</th><th>SNR médio</th><th>RSSI médio</th><th>Última observação</th></tr></thead><tbody id="statsRfRows"></tbody></table></div></div><div class="methodNote">Pares origem-destino observados não significam, isoladamente, enlace RF físico permanente.</div></div>
    <div id="statsPanelRanking" class="statsPanel dashboardWrap"><div class="dashSection"><h3>10 enlaces RF diretos mais longos</h3><div class="dashSectionBody statsFitBody"><table class="dashTable statsCompactTable statsFitTable"><thead><tr><th>#</th><th>Nó A</th><th>Nó B</th><th>Distância</th><th>Obs. RF</th><th>SNR médio</th><th>Última RF</th></tr></thead><tbody id="statsRfLongestRows"></tbody></table></div></div><div class="methodNote">Usa a mesma classificação RF confirmada do mapa: cada aresta A↔B representa um hop observado e entra quando há SNR válido nesse hop e posição conhecida nos dois extremos. Traceroutes revalidados pela API continuam sendo mostrados como evidência adicional, mas não são requisito; assim, enlaces históricos não somem do ranking quando o traceroute original caduca no MeshMonitor.</div><div class="dashSection"><h3>Diagnóstico de elegibilidade</h3><div class="dashSectionBody statsFitBody"><table class="dashTable statsCompactTable statsFitTable"><thead><tr><th>Nó A</th><th>Nó B</th><th>Distância</th><th>RF</th><th>Diretas</th><th>Motivo</th></tr></thead><tbody id="statsRankingAuditRows"></tbody></table></div></div></div>
    <div id="statsPanelRouting" class="statsPanel dashboardWrap"><div id="statsRoutingCards" class="dashGrid"></div><div class="statsSplit"><div class="dashSection"><h3>Distribuição por hops</h3><div id="statsHopDistribution" class="dashSectionBody statsFitBody"></div></div><div class="dashSection"><h3>Nós intermediários observados</h3><div id="statsRelayRows" class="dashSectionBody statsFitBody"></div></div></div></div>
    <div id="statsPanelTraffic" class="statsPanel dashboardWrap"><div id="statsTrafficCards" class="dashGrid"></div><div class="dashSection"><h3>Volume por tipo</h3><div class="dashSectionBody"><table class="dashTable statsCompactTable"><thead><tr><th>Tipo</th><th>Pacotes</th><th>Participação</th></tr></thead><tbody id="statsTrafficTypeRows"></tbody></table></div></div></div>
    <div id="statsPanelQueries" class="statsPanel dashboardWrap"><div id="statsQueryCards" class="dashGrid"></div><div class="dashSection"><h3>Atividade de consultas observada</h3><div class="dashSectionBody"><table class="dashTable statsCompactTable"><thead><tr><th>Tipo</th><th>TX</th><th>RX</th><th>Total observado</th></tr></thead><tbody id="statsQueryRows"></tbody></table></div></div><div class="methodNote">ACK, resposta efetiva, timeout e indisponibilidade continuam sendo estados distintos no popup do nó.</div></div>
    <div id="statsPanelChat" class="statsPanel dashboardWrap"><div id="statsChatCards" class="dashGrid"></div><div class="dashSection"><h3>Nós com mais interações no canal primário</h3><div class="dashSectionBody"><table class="dashTable"><thead><tr><th>Nó</th><th>Interações acumuladas</th></tr></thead><tbody id="statsChatRows"></tbody></table></div></div></div>
    <div id="statsPanelEnergy" class="statsPanel dashboardWrap"><div id="statsEnergyCards" class="dashGrid"></div><div class="dashSection"><h3>Bateria e energia dos nós</h3><div class="dashSectionBody"><table class="dashTable"><thead><tr><th>Nó</th><th>Bateria</th><th>Tensão</th><th>Última interação</th></tr></thead><tbody id="statsEnergyRows"></tbody></table></div></div></div>
    <div id="statsPanelAnomalies" class="statsPanel"><div id="viewAnomalies"><div class="dashboardWrap"><div class="dashboardToolbar"><h2>Pontos de atenção</h2><span id="anomalyUpdated" class="settingDesc"></span><label>Severidade: <select id="anomalySeverity"><option value="all" selected>Todas</option><option value="critical">Crítica</option><option value="warning">Atenção</option><option value="info">Informativa</option></select></label><button id="anomalyReload">Reanalisar</button></div><div id="anomalyCards" class="dashGrid"></div><div class="dashSection"><h3>Pontos identificados</h3><div id="anomalyList"></div></div><div class="dashSection"><h3>Como interpretar</h3><div class="dashSectionBody methodNote">Os pontos de atenção são gerados por heurísticas e servem para priorizar investigação; não constituem prova isolada de falha.</div></div></div></div></div>
    <div id="statsPanelAccess" class="statsPanel"><div id="viewAccess"><div class="dashboardWrap"><div id="accessLocked" class="readOnlyBanner" style="display:none">🔒 Faça login como administrador para visualizar os registros de acesso.</div><div id="accessContent"><div id="accessCards" class="dashGrid"></div><div class="dashSection"><h3>Acessos por dia</h3><div class="dashSectionBody"><div id="accessDaily" class="miniBars"></div></div></div><div class="dashSection"><h3>Países</h3><div class="dashSectionBody"><table class="dashTable"><thead><tr><th>País</th><th>Acessos</th><th>IPs únicos</th></tr></thead><tbody id="accessCountryRows"></tbody></table></div></div><div class="dashSection"><h3>Cidades</h3><div class="dashSectionBody"><table class="dashTable"><thead><tr><th>Cidade</th><th>País</th><th>Acessos</th><th>IPs únicos</th></tr></thead><tbody id="accessCityRows"></tbody></table></div></div><div class="dashSection"><h3>IPs</h3><div class="dashSectionBody"><table class="dashTable"><thead><tr><th>IP</th><th>Cidade / País</th><th>Acessos</th><th>Primeiro acesso</th><th>Último acesso</th><th>Navegador</th></tr></thead><tbody id="accessIpRows"></tbody></table></div></div><div class="dashSection"><h3>Navegadores e sistemas</h3><div id="accessClients" class="dashSectionBody"></div></div><div id="accessNote" class="methodNote"></div></div></div></div></div>
    </div>
  </div>
</section>

<section id="viewSettings" class="view">
  <div class="settingsCard">
    <h2>Configurações do Traffic Analyzer</h2>
    <div id="settingsReadOnly" class="readOnlyBanner">🔒 Visitante: a personalização visual abaixo fica somente neste navegador. Recursos administrativos continuam bloqueados.</div>
    <div class="localPrefsToolbar">
      <button id="restoreAdminDefaults" type="button">Restaurar padrão do administrador</button>
      <div class="settingDesc">Mapa, aparência, animações, sons e leitura podem ser personalizados localmente sem alterar o servidor ou a experiência de outros visitantes.</div>
    </div>

    <h3>Aparência</h3>
    <div class="settingsGrid">
      <div class="settingRow">
        <label>Tema da interface: <select id="uiTheme"><option value="dark" selected>Escuro (padrão)</option><option value="light">Claro</option></select></label>
        <div class="settingDesc">Altera a interface inteira. O mapa-base continua sendo configurado separadamente.</div>
      </div>
    </div>

    <h3>Mapa e topologia</h3>
    <div class="settingsGrid">
      <div class="settingRow">
        <label>Janela: <select id="ageHours"><option value="all" selected>Todos</option><option value="1">1 h</option><option value="6">6 h</option><option value="12">12 h</option><option value="24">24 h</option><option value="168">7 dias</option><option value="720">30 dias</option></select></label>
        <div class="settingDesc">Filtra enlaces e traceroutes pela idade da observação.</div>
      </div>
      <div class="settingRow">
        <label>Mínimo de observações: <input id="minObs" type="number" min="1" value="1" style="width:70px"></label>
        <div class="settingDesc">Oculta enlaces com menos observações que o valor escolhido.</div>
      </div>
      <div class="settingRow">
        <label>Mapa base: <select id="mapType"><option value="osm" selected>Ruas (OSM)</option><option value="topo">Topográfico</option><option value="light">Claro</option><option value="dark">Escuro</option><option value="satellite">Satélite</option></select></label>
        <div class="settingDesc">Também pode ser alterado diretamente na barra do mapa. A camada de radar é controlada pelo menu Camadas e fica ligada por padrão.</div>
      </div>
      <div class="settingRow">
        <label>Brilho: <input id="mapBrightness" type="range" min="30" max="150" step="5" value="100" style="width:150px;vertical-align:middle"> <span id="mapBrightnessValue">100%</span></label>
      </div>
      <div class="settingRow">
        <label>Máximo do slider de corte do relevo: <input id="elevationSliderMax" type="number" min="100" max="9000" step="100" value="3000" style="width:86px"> m</label>
        <div class="settingDesc">Define o topo da escala do slider vertical da camada Relevo com corte. Padrão: 3.000 m.</div>
      </div>
      <div class="settingRow">
        <b>Enlaces RF confirmados</b><br>
        <label>Cor: <input id="rfLineColor" type="color" value="#ffff00" style="width:48px;height:30px;padding:2px;vertical-align:middle"></label><br>
        <label>Espessura: <input id="rfLineWidth" type="range" min="1" max="8" step="1" value="3" style="width:150px;vertical-align:middle"> <span id="rfLineWidthValue">3 px</span></label>
        <div class="settingDesc">Linha contínua somente quando existir evidência física RF no hop, atualmente SNR válido. Se houver observações RF e MQTT/não-RF no período, a linha permanece contínua e o popup mostra a composição.</div>
      </div>
      <div class="settingRow">
        <b>Enlaces MQTT / não-RF</b><br>
        <label>Cor: <input id="mqttLineColor" type="color" value="#ff8c42" style="width:48px;height:30px;padding:2px;vertical-align:middle"></label><br>
        <label>Espessura: <input id="mqttLineWidth" type="range" min="1" max="8" step="1" value="3" style="width:150px;vertical-align:middle"> <span id="mqttLineWidthValue">3 px</span></label>
        <div class="settingDesc">Linha tracejada quando não houver evidência física RF no hop. Sem SNR válido, a observação é tratada como MQTT/não-RF, mesmo que o registro de traceroute tenha chegado ao MeshMonitor por RF.</div>
        <button id="lineStyleReset" type="button" style="margin-top:7px">Restaurar cores e espessuras</button>
      </div>
      <div class="settingRow">
        <label><input id="showLines" type="checkbox" checked> Mostrar linhas</label><br>
        <label><input id="showNodes" type="checkbox" checked> Mostrar nós</label><br>
        <label><input id="showHeatmap" type="checkbox"> Mapa de calor</label>
      </div>
      <div class="settingRow">
        <label><input id="showShortNames" type="checkbox"> Mostrar nomes curtos</label><br>
        <label><input id="onlyIdentified" type="checkbox"> Mostrar somente identificados</label>
      </div>
      <div class="settingRow">
        <label><input id="autoZoomTraceroute" type="checkbox"> Auto Zoom durante traceroutes</label>
        <div class="settingDesc">Enquadra automaticamente todos os nós envolvidos nas animações de traceroute. Se houver animações simultâneas, usa a área combinada. Cinco segundos após a última terminar, retorna ao enquadramento anterior.</div>
      </div>
    </div>

    <h3>Temas sonoros</h3>
    <div class="settingsGrid">
      <div class="settingRow">
        <label><input id="soundEnabled" type="checkbox"> Ativar sonificação da malha</label>
        <div class="settingDesc">Os sons acompanham eventos realmente observados. O Traffic Analyzer não inventa retransmissões para produzir efeitos.</div>
      </div>
      <div class="settingRow">
        <label>Tema: <select id="soundTheme"><option value="pinball70">Fliperama anos 70</option><option value="formal" selected>Formal</option><option value="radio">Rádio / Telecom</option><option value="silent">Silencioso</option></select></label>
        <button id="soundTest" class="soundTest" type="button">Testar tema</button>
        <div class="settingDesc">Os efeitos são sintetizados localmente pelo navegador; nenhum arquivo de áudio é baixado.</div>
      </div>
      <div class="settingRow">
        <label>Volume: <input id="soundVolume" type="range" min="0" max="100" step="5" value="35" style="width:180px;vertical-align:middle"> <span id="soundVolumeValue">35%</span></label><br>
        <label>Densidade sonora: <select id="soundDensity"><option value="low">Baixa</option><option value="normal" selected>Normal</option><option value="high">Alta</option></select></label>
        <div class="settingDesc">Em densidade baixa, parte dos ricochetes é suprimida em malhas muito movimentadas. Normal e Alta preservam mais eventos observados.</div>
      </div>
      <div class="settingRow">
        <label>Intervalo mínimo: <input id="soundMinInterval" type="range" min="40" max="800" step="20" value="120" style="width:150px;vertical-align:middle"> <span id="soundMinIntervalValue">120 ms</span></label><br>
        <label>Máximo simultâneo: <input id="soundMaxVoices" type="number" min="1" max="8" step="1" value="3" style="width:60px"> sons</label>
        <div class="settingDesc">Limita sobreposição e evita uma sequência de efeitos excessivamente densa.</div>
      </div>
      <div class="settingRow">
        <label><input id="soundRoutingEnabled" type="checkbox" checked> Sons de roteamento e traceroute</label><br>
        <label><input id="soundMessagesEnabled" type="checkbox" checked> Sons de mensagens</label><br>
        <label><input id="soundAlertsEnabled" type="checkbox" checked> Sons de alertas e falhas</label>
      </div>
      <div class="settingRow">
        <label><input id="soundStereoEnabled" type="checkbox"> Estéreo espacial</label>
        <div class="settingDesc">Quando ativado, eventos visíveis no mapa recebem leve deslocamento esquerda/direita conforme a posição. Desligado por padrão.</div>
      </div>
      <div class="settingRow">
        <b>Fliperama anos 70</b>
        <div class="settingDesc">Origem do pacote: lançador mecânico. Retransmissor observado: ricochete metálico. Destino/ACK: alvo e pontuação. Falha: efeito de bola perdida.</div>
      </div>
    </div>

    <h3>Atividade em tempo real no mapa</h3>
    <div class="settingsGrid">
      <div class="settingRow">
        <label><input id="activityAnimationEnabled" type="checkbox" checked> Animar atividade dos nós</label><br>
        <label><input id="activityOriginEnabled" type="checkbox" checked> Realçar origem/resposta</label><br>
        <label><input id="activityRelayEnabled" type="checkbox" checked> Realçar retransmissor observado</label>
        <div class="settingDesc">Cada atividade observada recebe um pulso visual no mapa. Só são destacados nós que podem ser identificados com segurança.</div>
      </div>
      <div class="settingRow">
        <label>Duração do realce: <select id="activityDuration"><option value="650">0,65 s</option><option value="1000" selected>1,0 s</option><option value="1500">1,5 s</option><option value="2000">2,0 s</option></select></label>
        <div class="settingDesc">Origem/resposta usa pulso azul/roxo; relay observado usa pulso amarelo. O Traffic Analyzer não inventa relays intermediários.</div>
      </div>
    </div>

    <h3>Mensagens</h3>
    <div class="settingsGrid">
      <div class="settingRow">
        <label>Tamanho da fonte:
          <input id="messageFontSize" type="range" min="10" max="20" step="1" value="13">
          <span id="messageFontSizeValue">13 px</span>
        </label>
        <div class="settingDesc">Ajusta o tamanho do texto do chat, do remetente, do horário e do campo de composição. A preferência fica salva neste navegador.</div>
      </div>
      <div class="settingRow">
        <label>Fonte: <select id="messageFontFamily"><option value="system" selected>Sistema</option><option value="arial">Arial / Helvetica</option><option value="verdana">Verdana</option><option value="tahoma">Tahoma</option><option value="georgia">Georgia</option><option value="mono">Monoespaçada</option></select></label>
        <div class="styleChecks"><label><input id="messageBold" type="checkbox"> <b>Negrito</b></label><label><input id="messageItalic" type="checkbox"> <i>Itálico</i></label><label><input id="messageUnderline" type="checkbox"> <u>Sublinhado</u></label></div>
        <div class="settingDesc">Formatação somente visual. Nenhum marcador de estilo é enviado pela malha.</div>
      </div>
      <div class="settingRow">
        <label>Altura da linha: <input id="messageLineHeight" type="range" min="1.10" max="2.00" step="0.05" value="1.35" style="width:150px;vertical-align:middle"> <span id="messageLineHeightValue">1,35</span></label><br>
        <label>Espaço entre mensagens: <input id="messageRowGap" type="range" min="1" max="14" step="1" value="4" style="width:150px;vertical-align:middle"> <span id="messageRowGapValue">4 px</span></label>
      </div>
      <div class="settingRow">
        <b>Uso da tela</b>
        <div class="settingDesc">A tela de Mensagens usa praticamente toda a largura e altura disponíveis, preservando apenas margens mínimas para leitura.</div>
      </div>
    </div>

    <div class="adminOnlySection">
      <h3>Banco de tráfego <span class="adminOnlyBadge">Administrador</span></h3>
      <div class="settingsGrid">
        <div class="settingRow">
          <label>Retenção do tráfego bruto:
            <select id="archiveRetentionDays" data-admin-only>
              <option value="0" selected>Nunca apagar (padrão)</option>
              <option value="1">1 dia</option>
              <option value="7">1 semana</option>
              <option value="30">1 mês</option>
            </select>
          </label>
          <div class="settingDesc">Define por quanto tempo pacotes e posições brutas ficam no traffic.db. Nós e enlaces já observados permanecem na memória histórica até o banco ser apagado/resetado.</div>
        </div>
        <div class="settingRow">
          <div id="archiveRetentionStatus" class="settingDesc">Carregando estado do banco...</div>
        </div>
      </div>
    </div>

    <div id="adminDefaultsSection" class="adminOnlySection">
      <h3>Apresentação padrão para visitantes <span class="adminOnlyBadge">Administrador</span></h3>
      <div class="settingsGrid">
        <div class="settingRow">
          <button id="saveVisitorDefaults" type="button" data-admin-only>Usar minha configuração visual atual como padrão dos visitantes</button>
          <div class="settingDesc">Grava no servidor o visual atual como ponto de partida para novos navegadores. Preferências locais já salvas por cada visitante continuam prevalecendo.</div>
        </div>
        <div class="settingRow">
          <div id="visitorDefaultsStatus" class="settingDesc">Carregando padrão global...</div>
        </div>
      </div>
    </div>

    <div class="adminOnlySection">
    <h3>Avisos automáticos no canal primário <span class="adminOnlyBadge">Administrador</span></h3>
    <div class="settingsGrid">
      <div class="settingRow">
        <label><input id="autoNoticeInmet" type="checkbox" checked data-admin-only> Alertas do INMET para Brasília/DF</label>
        <div class="settingDesc">Envia no canal primário apenas alertas novos ou atualizados que atinjam Brasília/DF. Alertas já existentes na primeira inicialização são apenas registrados para evitar flood.</div>
      </div>
      <div class="settingRow">
        <label><input id="autoNoticeMeshtasticStable" type="checkbox" checked data-admin-only> Nova versão estável do Meshtastic</label><br>
        <label><input id="autoNoticeMeshtasticUnstable" type="checkbox" checked data-admin-only> Nova versão instável do Meshtastic</label><br>
        <label><input id="autoNoticeMeshtasticNightly" type="checkbox" checked data-admin-only> Nova versão nightly do Meshtastic</label>
        <div class="settingDesc">Monitora releases oficiais e nightly. Configure intervalo, modelo e categorias também em Automações → Meshtastic.</div>
      </div>
      <div class="settingRow">
        <button id="autoNoticeCheckNow" type="button" data-admin-only>Verificar agora</button>
        <div id="autoNoticeStatus" class="settingDesc">Carregando estado dos avisos automáticos...</div>
      </div>
    </div>
    </div>

    <div class="adminOnlySection">
    <h3>Atualizações <span class="adminOnlyBadge">Administrador</span></h3>
    <div class="settingsGrid">
      <div class="settingRow">
        <label><input id="autoUpdateEnabled" type="checkbox" checked disabled> Atualização automática de versões estáveis: sempre ativa</label>
        <div class="settingDesc">Ao detectar uma Latest Release estável mais nova, o Traffic Analyzer cria automaticamente a solicitação. Um serviço systemd dedicado executa o update como root, preservando health check e rollback.</div>
      </div>
      <div class="settingRow">
        <label><input id="rollbackEnabled" type="checkbox" checked data-admin-only> Rollback automático se a nova versão não ficar saudável</label>
        <div class="settingDesc">Em caso de falha, restaura a aplicação e os units do systemd preservados antes da atualização.</div>
      </div>
      <div class="settingRow">
        <label>Verificar novas versões a cada: <input id="versionCheckInterval" type="number" min="5" max="1440" step="5" value="15" style="width:76px" data-admin-only> minutos</label>
        <div class="settingDesc">Padrão: 15 minutos. A alteração é persistida no servidor e aplicada imediatamente, sem reiniciar o Traffic Analyzer.</div>
      </div>
      <div class="settingRow">
        <button id="updateNow" type="button" data-admin-only>Atualizar agora</button>
        <div class="settingDesc">Instala somente a Latest Release estável publicada no repositório oficial.</div>
      </div>
      <div class="settingRow">
        <div id="updateStatusBox" class="updateStatusBox">Carregando status de atualização...</div>
      </div>
    </div>
    </div>

    <h3>Fluxos e privacidade</h3>
    <div class="settingRow">
      <label><input id="nodeInfoFlowEnabled" type="checkbox" checked> Mostrar fluxo de NodeInfo no mapa</label>
      <div class="settingDesc">Somente os saltos observados em traceroute são desenhados. Sem rota, destaca-se origem/destino sem linha reta. O traceroute não comprova necessariamente o caminho original do NodeInfo.</div>
    </div>
    <div class="settingRow">
      <label><input id="nodeInfoToastEnabled" type="checkbox" checked> Exibir avisos flutuantes de NodeInfo</label>
      <div class="settingDesc">Controla apenas os avisos; não desativa a visualização no mapa.</div>
    </div>
    <div class="settingRow">
      <label><input id="nodeInfoAutoTraceEnabled" type="checkbox"> Consultar traceroute automaticamente para NodeInfo enviado pela estação local</label>
      <div class="settingDesc">Padrão desligado. Somente pacotes TX confirmados no histórico, com destino específico: máximo 1 consulta a cada 5 minutos e 30 minutos por destino. Não mede rotas entre terceiros. Gera tráfego adicional RF.</div>
      <button id="nodeInfoTraceNow" type="button" data-admin-only disabled>Descobrir rota agora</button>
      <div id="nodeInfoRouteStatus" class="settingDesc" role="status">Nenhum NodeInfo selecionado. Consultas RF não são iniciadas automaticamente.</div>
    </div>
    <div class="settingRow">
      <b>Conteúdo dos pacotes</b>
      <div class="settingDesc">Mensagens TEXT_MESSAGE em broadcast mostram o payload no detalhe. Mensagens diretas continuam ocultas por padrão. Payloads e dados técnicos são apresentados com rótulos amigáveis; o JSON bruto fica disponível apenas como diagnóstico secundário.</div>
    </div>
    <div class="settingRow">
      <b>Segurança</b>
      <div class="settingDesc">O token mm_v1 permanece no processo servidor e não é enviado ao navegador.</div>
    </div>
  </div>
</section>
<section id="viewHelp" class="view">
  <div id="helpContent" class="helpCard"></div>
</section>
</div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
 integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script src="https://unpkg.com/leaflet.heat/dist/leaflet-heat.js"></script>
<script>
const LANGUAGE_KEY='trafficAnalyzerLanguageV122';
const FLAG_SVG_BR="<svg class=\"languageFlagSvg\" viewBox=\"0 0 28 20\" focusable=\"false\" aria-hidden=\"true\"><rect width=\"28\" height=\"20\" rx=\"1.5\" fill=\"#009c3b\"/><polygon points=\"14,2 26,10 14,18 2,10\" fill=\"#ffdf00\"/><circle cx=\"14\" cy=\"10\" r=\"4.3\" fill=\"#002776\"/><path d=\"M9.9 9.4c2.8-1 5.8-.7 8.4.8\" fill=\"none\" stroke=\"#fff\" stroke-width=\".85\"/></svg>";
const FLAG_SVG_US="<svg class=\"languageFlagSvg\" viewBox=\"0 0 28 20\" focusable=\"false\" aria-hidden=\"true\"><rect width=\"28\" height=\"20\" rx=\"1.5\" fill=\"#fff\"/><g fill=\"#b22234\"><rect width=\"28\" height=\"1.54\"/><rect y=\"3.08\" width=\"28\" height=\"1.54\"/><rect y=\"6.16\" width=\"28\" height=\"1.54\"/><rect y=\"9.24\" width=\"28\" height=\"1.54\"/><rect y=\"12.32\" width=\"28\" height=\"1.54\"/><rect y=\"15.40\" width=\"28\" height=\"1.54\"/><rect y=\"18.46\" width=\"28\" height=\"1.54\"/></g><rect width=\"12.2\" height=\"10.78\" fill=\"#3c3b6e\"/><g fill=\"#fff\"><circle cx=\"2\" cy=\"2\" r=\".55\"/><circle cx=\"5\" cy=\"2\" r=\".55\"/><circle cx=\"8\" cy=\"2\" r=\".55\"/><circle cx=\"11\" cy=\"2\" r=\".55\"/><circle cx=\"3.5\" cy=\"4.5\" r=\".55\"/><circle cx=\"6.5\" cy=\"4.5\" r=\".55\"/><circle cx=\"9.5\" cy=\"4.5\" r=\".55\"/><circle cx=\"2\" cy=\"7\" r=\".55\"/><circle cx=\"5\" cy=\"7\" r=\".55\"/><circle cx=\"8\" cy=\"7\" r=\".55\"/><circle cx=\"11\" cy=\"7\" r=\".55\"/><circle cx=\"3.5\" cy=\"9.4\" r=\".55\"/><circle cx=\"6.5\" cy=\"9.4\" r=\".55\"/><circle cx=\"9.5\" cy=\"9.4\" r=\".55\"/></g></svg>";
const SUPPORTED_LANGUAGES={
  'pt-BR':{flagSvg:FLAG_SVG_BR,name:'Português',locale:'pt-BR'},
  'en':{flagSvg:FLAG_SVG_US,name:'English',locale:'en-US'}
};
let currentLang=SUPPORTED_LANGUAGES[localStorage.getItem(LANGUAGE_KEY)]?localStorage.getItem(LANGUAGE_KEY):'pt-BR';
function uiLocale(){return SUPPORTED_LANGUAGES[currentLang]?.locale||'pt-BR';}
function closeLanguageMenu(){
  const menu=document.getElementById('uiLanguageMenu'),btn=document.getElementById('uiLanguageButton');
  menu?.classList.remove('open');btn?.setAttribute('aria-expanded','false');
}
function updateLanguageMenu(){
  const meta=SUPPORTED_LANGUAGES[currentLang]||SUPPORTED_LANGUAGES['pt-BR'];
  const flag=document.getElementById('uiLanguageFlag'),name=document.getElementById('uiLanguageName');
  if(flag)flag.innerHTML=meta.flagSvg;if(name)name.textContent=meta.name;
  document.querySelectorAll('.languageOption[data-language]').forEach(opt=>{
    const selected=opt.dataset.language===currentLang;
    opt.classList.toggle('selected',selected);opt.setAttribute('aria-selected',selected?'true':'false');
  });
  const btn=document.getElementById('uiLanguageButton');
  if(btn){
    const label=currentLang==='en'?'Interface language':'Idioma da interface';
    btn.setAttribute('aria-label',label);btn.setAttribute('title',label);
  }
  const menu=document.getElementById('uiLanguageMenu');
  if(menu)menu.setAttribute('aria-label',currentLang==='en'?'Interface language':'Idioma da interface');
}

const I18N_PAIRS=[
  ['Resumo','Summary'],['Informações do nó','Node info'],['Consultas ao nó','Node queries'],['Últimos metadados recebidos','Latest metadata received'],['Posição','Position'],['Dispositivo','Device'],['Ambiente','Environment'],['Qualidade do ar','Air quality'],['Energia','Power'],['Vizinhos','Neighbors'],['Expandir','Expand'],['Restaurar','Restore'],['Reposicionar','Reset position'],['As consultas ativas usam o Virtual Node do MeshMonitor quando disponível. As respostas confirmadas atualizam este popup.','Active queries use the MeshMonitor Virtual Node when available. Confirmed responses update this popup.'],['não consultado','not queried'],['enviando…','sending…'],['aguardando resposta','waiting for response'],['respondido','answered'],['sem resposta / timeout','no response / timeout'],['sem resposta inicial','no initial response'],['aguardando possível retry do MM','waiting for a possible MM retry'],['retry 1 do MM observado','MM retry 1 observed'],['aguardando segunda tentativa do MM','waiting for MM second attempt'],['retry 2 do MM observado','MM retry 2 observed'],['sem retry observado','no retry observed'],['janela do MM','MM window'],['sem resposta após 90 s','no response after 90 s'],['sem resposta correlacionada','no correlated response'],['aguardando resposta correlacionada','waiting for a correlated response'],['aguardando vez no Virtual Node','waiting for the Virtual Node'],['conectando ao Virtual Node','connecting to the Virtual Node'],['TX observado','TX observed'],['TX observados','TX observed'],['resposta tardia','late response'],['destino respondeu','destination replied'],['o nó recebeu a solicitação, mas não forneceu esse dado','the node received the request but did not provide this data'],['não foi encontrada rota até o nó','no route to the node was found'],['canal não disponível para a solicitação','channel unavailable for the request'],['solicitação não autorizada nesse canal','request not authorized on this channel'],['erro','error'],['não suportado / não aplicável','unsupported / not applicable'],['somente nó local ou 0-hop','local or 0-hop nodes only'],['sem informação','no information'],['Métricas do dispositivo','Device metrics'],['Métricas ambientais','Environmental metrics'],['Métricas de energia','Power metrics'],['Informações de vizinhos','Neighbor info'],
  ['Filtrar:','Filter:'],['Limpar filtro','Clear filter'],['nome, ID, hardware...','name, ID, hardware...'],['VHF3 sem posição','VHF3 has no position'],['Nó sem posição conhecida; não é possível focalizá-lo no mapa.','Node has no known position; it cannot be focused on the map.'],
  ['Período:','Period:'],['7 dias','7 days'],['30 dias','30 days'],['90 dias','90 days'],['1 ano','1 year'],['Baixar log','Download log'],['Relatório / PDF','Report / PDF'],['Exportar CSV','Export CSV'],['Abre um relatório estruturado pronto para imprimir ou salvar como PDF','Opens a structured report ready to print or save as PDF'],['Exporta o tráfego do período/filtro atual em CSV','Exports traffic for the current period/filter as CSV'],['Acessos por dia','Access by day'],['Países','Countries'],['País','Country'],['Cidades','Cities'],['Cidade','City'],['IPs únicos','Unique IPs'],['Primeiro acesso','First access'],['Último acesso','Last access'],['Navegador','Browser'],['Navegadores e sistemas','Browsers and systems'],['Acessos hoje','Access today'],['Acessos - 7 dias','Access - 7 days'],['Acessos - 30 dias','Access - 30 days'],['IPs únicos - 30 dias','Unique IPs - 30 days'],['Logins com sucesso - 30 dias','Successful logins - 30 days'],['Falhas de login - 30 dias','Login failures - 30 days'],['Faça login como administrador para visualizar os registros de acesso.','Sign in as administrator to view access records.'],['Não informado','Not provided'],['Rede local','Local network'],['Local','Local'],
  ['Mapa','Map'],['Nós','Nodes'],['Tráfego','Traffic'],['Mensagens','Messages'],['Saúde da Rede','Network Health'],['Anomalias','Anomalies'],['Acessos','Access'],['Configurações','Settings'],['Ajuda','Help'],
  ['Colunas','Columns'],['Nome longo','Long name'],['Nome curto','Short name'],['Saltos','Hops'],['Distância','Distance'],['Última interação','Last interaction'],['Última posição','Last position'],['Detalhes do nó','Node details'],['Estado','State'],['Arraste para mover','Drag to move'],['arraste','drag'],
  ['Idioma:','Language:'],['Idioma da interface','Interface language'],['Português','Portuguese'],
  ['Reprodução:','Playback:'],['Histórico','History'],['Ao vivo','Live'],['Velocidade:','Speed:'],['Enquadrar','Fit'],['Atualizar','Refresh'],
  ['Traceroute anterior','Previous traceroute'],['Próximo traceroute','Next traceroute'],['Pausar animações ao vivo','Pause live animations'],['Retomar animações ao vivo','Resume live animations'],['Reproduzir/retomar histórico','Play/resume history'],['Pausar histórico','Pause history'],
  ['Tráfego ao vivo','Live traffic'],['Direção:','Direction:'],['Todos','All'],['Tipo:','Type:'],['Mensagem','Message'],['Buscar:','Search:'],['Pausar','Pause'],['Retomar','Resume'],['Baixar dump JSON (.zip)','Download JSON dump (.zip)'],
  ['Baixa todo o histórico persistente em traffic.json dentro de um ZIP','Downloads the entire persistent history as traffic.json inside a ZIP'],['Hora','Time'],['DIR','DIR'],['Origem','Source'],['Destino','Destination'],['Tipo','Type'],['Hops','Hops'],
  ['Clique em um pacote para ver os detalhes.','Click a packet to view details.'],['Clique para ver o payload formatado','Click to view the formatted payload'],['Nenhum pacote corresponde ao filtro.','No packet matches the filter.'],
  ['Canal primário','Primary channel'],['Canal 0 - mensagens de broadcast','Channel 0 - broadcast messages'],['Carregando...','Loading...'],['Carregar anteriores','Load older'],['Carregar mais mensagens antigas','Load older messages'],['Consultar novas mensagens agora','Check for new messages now'],['Digite uma mensagem','Type a message'],['Digite @ para mencionar um nó','Type @ to mention a node'],['Enviar','Send'],['nova','new'],['Sem mensagens não lidas','No unread messages'],['Nenhuma mensagem encontrada no canal primário.','No messages found on the primary channel.'],
  ['Saúde da Rede','Network Health'],['Atividade dos últimos 7 dias','Activity over the last 7 days'],['Traceroutes e roteamento','Traceroutes and routing'],['Interações por chat no canal primário','Chat interactions on the primary channel'],['Nós que merecem atenção','Nodes that need attention'],['Último tráfego','Last traffic'],['Tempo sem ouvir','Time since heard'],['Pacotes 7d','Packets 7d'],['SNR médio 7d','Average SNR 7d'],['Reanalisar','Reanalyze'],
  ['Os indicadores usam o histórico persistente do Traffic Analyzer e a topologia observada pelo MeshMonitor. O ranking de chat conta interações acumuladas registradas no canal primário. Ausência de tráfego não prova falha física; pode representar um nó silencioso, desligado ou fora do alcance da fonte.','Indicators use the Traffic Analyzer persistent history and the topology observed by MeshMonitor. The chat ranking counts accumulated interactions recorded on the primary channel. Lack of traffic does not prove a physical failure; it may represent a silent node, a powered-off node, or a node outside the source range.'],
  ['Pontos de atenção','Points of attention'],['Pontos identificados','Identified points'],['Como interpretar','How to interpret'],['Os pontos de atenção são gerados por heurísticas e servem para priorizar investigação; não constituem prova isolada de falha.','Points of attention are generated by heuristics and help prioritize investigation; they are not standalone proof of failure.'],['As anomalias são heurísticas: silêncio prolongado, degradação de SNR, mudança relevante na quantidade de hops e traceroute assimétrico. Elas servem para priorizar investigação e não constituem prova isolada de defeito, indisponibilidade ou causalidade.','Anomalies are heuristics: prolonged silence, SNR degradation, significant hop-count changes, and asymmetric traceroutes. They help prioritize investigation and are not standalone proof of failure, outage, or causality.'],
  ['Configurações do Traffic Analyzer','Traffic Analyzer Settings'],['Aparência','Appearance'],['Tema da interface:','Interface theme:'],['Escuro (padrão)','Dark (default)'],['Escuro','Dark'],['Claro','Light'],['Altera a interface inteira. O mapa-base continua sendo configurado separadamente.','Changes the entire interface. The base map remains configured separately.'],
  ['Mapa e topologia','Map and topology'],['Janela:','Window:'],['Filtra enlaces e traceroutes pela idade da observação.','Filters links and traceroutes by observation age.'],['Mínimo de observações:','Minimum observations:'],['Oculta enlaces com menos observações que o valor escolhido.','Hides links with fewer observations than the selected value.'],['Mapa base:','Base map:'],['Ruas (OSM)','Streets (OSM)'],['Topográfico','Topographic'],['Satélite','Satellite'],['Brilho:','Brightness:'],['Cor das linhas:','Line color:'],['Mostrar linhas','Show lines'],['Mostrar nós','Show nodes'],['Mapa de calor','Heat map'],['Mostrar nomes curtos','Show short names'],['Mostrar somente identificados','Show identified only'],['Auto Zoom durante traceroutes','Auto Zoom during traceroutes'],['Enquadra automaticamente todos os nós envolvidos nas animações de traceroute. Se houver animações simultâneas, usa a área combinada. Cinco segundos após a última terminar, retorna ao enquadramento anterior.','Automatically fits all nodes involved in traceroute animations. If animations overlap, it uses the combined area. Five seconds after the last one finishes, it returns to the previous framing.'],
  ['Notificações sonoras','Sound notifications'],['Som no início de uma nova viagem de pacote','Sound at the start of a new packet journey'],['O som toca uma única vez quando uma nova viagem de pacote é observada. Cópias/retransmissões do mesmo packet_id não geram novos sons.','The sound plays once when a new packet journey is observed. Copies/retransmissions of the same packet_id do not generate new sounds.'],['Som:','Sound:'],['Plim','Chime'],['Campainha','Bell'],['Duplo','Double'],['Suave','Soft'],['Testar som','Test sound'],['Todos os sons são sintetizados localmente; nenhum arquivo de áudio é baixado.','All sounds are synthesized locally; no audio file is downloaded.'],['Volume:','Volume:'],['A preferência fica salva neste navegador. O primeiro clique libera o Web Audio quando exigido pelo navegador.','The preference is saved in this browser. The first click enables Web Audio when required by the browser.'],
  ['Atividade em tempo real no mapa','Real-time map activity'],['Animar atividade dos nós','Animate node activity'],['Realçar origem/resposta','Highlight source/response'],['Realçar retransmissor observado','Highlight observed relay'],['Cada atividade observada recebe um pulso visual no mapa. Só são destacados nós que podem ser identificados com segurança.','Each observed activity gets a visual pulse on the map. Only nodes that can be identified safely are highlighted.'],['Duração do realce:','Highlight duration:'],['Origem/resposta usa pulso azul/roxo; relay observado usa pulso amarelo. O Traffic Analyzer não inventa relays intermediários.','Source/response uses a blue/purple pulse; the observed relay uses a yellow pulse. Traffic Analyzer does not invent intermediate relays.'],
  ['Tamanho da fonte:','Font size:'],['Ajusta o tamanho do texto do chat, do remetente, do horário e do campo de composição. A preferência fica salva neste navegador.','Adjusts chat text, sender, timestamp, and composer font sizes. The preference is saved in this browser.'],['Uso da tela','Screen usage'],['A tela de Mensagens usa praticamente toda a largura e altura disponíveis, preservando apenas margens mínimas para leitura.','The Messages screen uses nearly all available width and height while preserving minimal reading margins.'],
  ['Fluxos e privacidade','Flows and privacy'],['Mostrar fluxo de NodeInfo no mapa','Show NodeInfo flow on the map'],['O mapa liga origem e destino. A animação por hops só usa rota observada quando existe traceroute completo compatível; sem evidência suficiente, nenhum hop é inventado.','The map connects source and destination. Hop-by-hop animation only uses an observed route when a compatible complete traceroute exists; without sufficient evidence, no hop is invented.'],['Conteúdo dos pacotes','Packet content'],['Mensagens TEXT_MESSAGE em broadcast mostram o payload no detalhe. Mensagens diretas continuam ocultas por padrão. Payloads e dados técnicos são apresentados com rótulos amigáveis; o JSON bruto fica disponível apenas como diagnóstico secundário.','Broadcast TEXT_MESSAGE packets show their payload in details. Direct messages remain hidden by default. Payloads and technical data are shown with friendly labels; raw JSON remains available only as secondary diagnostics.'],['Segurança','Security'],['O token mm_v1 permanece no processo servidor e não é enviado ao navegador.','The mm_v1 token remains in the server process and is never sent to the browser.'],
  ['Banco de tráfego','Traffic database'],['Retenção do tráfego bruto:','Raw traffic retention:'],['Nunca apagar (padrão)','Never delete (default)'],['1 dia','1 day'],['1 semana','1 week'],['1 mês','1 month'],['Define por quanto tempo pacotes e posições brutas ficam no traffic.db. Nós e enlaces já observados permanecem na memória histórica até o banco ser apagado/resetado.','Defines how long raw packets and positions stay in traffic.db. Previously observed nodes and links remain in historical memory until the database is deleted/reset.'],['Carregando estado do banco...','Loading database status...'],['pacotes','packets'],['nós históricos','historical nodes'],['enlaces históricos','historical links'],['registro mais antigo','oldest record'],['tamanho do banco','database size'],
  ['Verificar novas versões a cada:','Check for new versions every:'],['minutos','minutes'],['Padrão: 15 minutos. A alteração é persistida no servidor e aplicada imediatamente, sem reiniciar o Traffic Analyzer.','Default: 15 minutes. The change is persisted on the server and applied immediately without restarting Traffic Analyzer.'],
  ['Versão do Traffic Analyzer','Traffic Analyzer Version'],['Consultando a versão publicada…','Checking the published version…'],['verificando…','checking…'],['Sem informações carregadas.','No information loaded.'],['Ver Release no GitHub','View Release on GitHub'],['Continuar','Continue'],['Fechar','Close'],['Verificar versão','Check version'],['Esta é a versão mais recente publicada','This is the latest published version'],['Nova versão disponível - clique para ver as novidades','New version available - click to see what is new'],['Não foi possível verificar a versão mais recente','Could not check the latest version'],['Não há notas de versão disponíveis.','No release notes are available.'],
  ['Último tráfego','Last traffic'],['até 2 h','up to 2 h'],['2 a 24 h','2 to 24 h'],['mais de 24 h','more than 24 h'],['sem registro','no record'],['Sem tráfego registrado','No traffic recorded'],['Tráfego nas últimas 2 h','Traffic in the last 2 h'],['Tráfego entre 2 e 24 h','Traffic between 2 and 24 h'],['Tráfego há mais de 24 h','Traffic more than 24 h ago'],
  ['enlaces no filtro','links in filter'],['nós no mapa','nodes on map'],['identificados','identified'],['traceroutes no histórico','traceroutes in history'],['ícones visíveis','visible circles'],['Calor = atividade de roteamento observada','Heat = observed routing activity'],['armazenados no MM','stored in MM'],['carregados','loaded'],['último minuto','last minute'],['no filtro','in filter'],
  ['Observações:','Observations:'],['Ida:','Outbound:'],['Volta:','Return:'],['SNR médio:','Average SNR:'],['Faixa SNR:','SNR range:'],['Última observação:','Last observation:'],['canal:','channel:'],['Estado:','State:'],['Posição:','Position:'],['Último tráfego:','Last traffic:'],['Situação:','Status:'],['Public key:','Public key:'],['Short name:','Short name:'],['sim','yes'],['não','no'],
  ['Dados técnicos','Technical data'],['Nenhum dado técnico adicional disponível.','No additional technical data available.'],['Ver JSON bruto','View raw JSON'],['Mostrar fluxo','Show flow'],['Criptografado','Encrypted'],['Canal','Channel'],['Nome','Name'],['Nome curto','Short name'],['Chave pública','Public key'],['Licenciado','Licensed'],['Nó','Node'],['Última recepção','Last reception'],['Vizinhos','Neighbors'],['Rota','Route'],['Rota de volta','Return route'],['Erro de roteamento','Routing error'],['Motivo','Reason'],['ID da solicitação','Request ID'],['ID da resposta','Reply ID'],['ID do pacote','Packet ID'],['Tipo de telemetria','Telemetry type'],['Solicita resposta','Requests response'],['Solicita ACK','Requests ACK'],['Tipo de pacote','Packet type'],['Transporte','Transport'],['Recebido em','Received at'],['Prioridade','Priority'],['Métricas do dispositivo','Device metrics'],['Métricas ambientais','Environmental metrics'],['Estatísticas locais','Local statistics'],['Métricas de energia','Power metrics'],['Qualidade do ar','Air quality'],['Bateria','Battery'],['Tensão','Voltage'],['Utilização do canal','Channel utilization'],['Horário','Time'],['Temperatura','Temperature'],['Umidade','Humidity'],['Pressão','Pressure'],['Resistência do gás','Gas resistance'],['Corrente','Current'],['Luminosidade','Illuminance'],
  ['Calculando indicadores','Calculating indicators'],['Nós ativos - 2 h','Active nodes - 2 h'],['nós conhecidos','known nodes'],['Nós ativos - 24 h','Active nodes - 24 h'],['sem tráfego > 24 h','no traffic > 24 h'],['Pacotes - 24 h','Packets - 24 h'],['Enlaces observados','Observed links'],['vistos nas últimas 24 h','seen in the last 24 h'],['histórico carregado','loaded history'],['Com ida e volta','With outbound and return'],['completos nos 2 sentidos','complete in both directions'],['Mediana de hops','Median hops'],['por perna observada','per observed leg'],['Sem registro','No record'],['nós sem timestamp confiável','nodes without a reliable timestamp'],['Idas observadas','Observed outbound legs'],['Voltas observadas','Observed return legs'],['Traceroutes incompletos','Incomplete traceroutes'],['Média de hops','Average hops'],['Nenhuma interação de chat registrada no canal primário.','No chat interaction recorded on the primary channel.'],['Nenhum nó requer atenção pelo critério atual.','No node requires attention under the current criterion.'],['Não foi possível calcular','Could not calculate'],
  ['Crítica','Critical'],['Críticas','Critical anomalies'],['Atenção','Warning'],['Informativa','Informational'],['Informativas','Informational anomalies'],['Nenhuma anomalia foi detectada pelos critérios atuais.','No anomaly was detected by the current criteria.'],['Erro ao analisar:','Analysis error:'],['Nó silencioso há mais de 24 h','Node silent for more than 24 h'],['Nó silencioso há mais de 7 dias','Node silent for more than 7 days'],['Não há tráfego recente deste nó no histórico disponível.','There is no recent traffic from this node in the available history.'],['O nó ultrapassou a janela de 24 horas sem tráfego observado.','The node exceeded the 24-hour window without observed traffic.'],['Queda de SNR no enlace','SNR drop on link'],['Mudança relevante de hops','Significant hop-count change'],['Traceroute assimétrico','Asymmetric traceroute'],['A observação mais recente contém apenas um dos sentidos do traceroute.','The latest observation contains only one direction of the traceroute.'],
  ['AO VIVO','LIVE'],['● PAUSADO','● PAUSED'],['ANIMAÇÃO PAUSADA','ANIMATION PAUSED'],['conectando…','connecting…'],['IDA','OUTBOUND'],['VOLTA','RETURN'],['Total ida + volta:','Total outbound + return:'],['sem percurso completo','no complete path'],['Histórico pausado.','History paused.'],['Histórico: nenhum traceroute completamente mapeável no filtro atual.','History: no fully mappable traceroute in the current filter.'],['A atualização excedeu 90 segundos.','The update exceeded 90 seconds.'],['Atualizando...','Updating...'],['Atualizado ✓','Updated ✓'],['Erro','Error'],
  ['● AO VIVO','● LIVE'],['Carregando mensagens...','Loading messages...'],['Carregando pacotes...','Loading packets...'],['Histórico pronto.','History ready.'],['Interações','Interactions'],['Clique para abrir o mapa','Click to open the map'],['nó, ID, tipo...','node, ID, type...'],['data não informada','date not provided'],
  ['Mensagem muito longa. Reduza o texto para até aproximadamente 600 bytes.','Message too long. Reduce the text to approximately 600 bytes or less.'],['Enviando...','Sending...'],['Mensagem enviada ao MeshMonitor','Message sent to MeshMonitor'],['Limite de 1.500 mensagens já carregado.','The 1,500-message limit is already loaded.'],['Nenhuma mensagem anterior adicional disponível.','No additional older messages are available.'],['Nó desconhecido','Unknown node'],['pedido provável','probable request'],
  ['Linha lógica exibida; procurando um traceroute próximo no tempo para não inventar hops.','Logical line displayed; looking for a nearby traceroute in time so no hops are invented.'],['Sem coordenadas suficientes para desenhar o fluxo no mapa.','Not enough coordinates to draw the flow on the map.'],['O pacote comum não carrega a cadeia completa de relays. A linha tracejada é apenas origem/destino; nenhum hop foi inventado.','A regular packet does not carry the complete relay chain. The dashed line is only source/destination; no hop was invented.'],['caminho intermediário ainda não observado','intermediate path not observed yet'],
  ['Nenhuma mobilidade observada neste período.','No mobility observed in this period.'],['Hoje','Today'],['Ontem','Yesterday'],['há poucos segundos','a few seconds ago'],['[conteúdo oculto]','[content hidden]'],
  ['Severidade:','Severity:'],['Todas','All'],['Sistema','System'],['Monoespaçada','Monospace'],['Fonte:','Font:'],['Negrito','Bold'],['Itálico','Italic'],['Sublinhado','Underline'],
  ['Altura da linha:','Line height:'],['Espaço entre mensagens:','Space between messages:'],['Formatação somente visual. Nenhum marcador de estilo é enviado pela malha.','Visual formatting only. No style marker is transmitted over the mesh.'],
  ['Espessura das linhas:','Line thickness:'],['Ajusta apenas a visualização dos enlaces; não altera a topologia nem os cálculos.','Only changes link rendering; it does not change topology or calculations.'],['Restaurar padrão','Restore default'],
  ['Atualizações','Updates'],['Atualização automática de versões estáveis: sempre ativa','Automatic stable-version updates: always enabled'],['Ao detectar uma Latest Release estável mais nova, o Traffic Analyzer cria automaticamente a solicitação. Um serviço systemd dedicado executa o update como root, preservando health check e rollback.','When a newer stable Latest Release is detected, Traffic Analyzer automatically creates the update request. A dedicated systemd service performs the update as root while preserving health checks and rollback.'],
  ['Rollback automático se a nova versão não ficar saudável','Automatic rollback if the new version does not become healthy'],['Em caso de falha, restaura a aplicação e os units do systemd preservados antes da atualização.','On failure, restores the application and systemd units saved before the update.'],['Atualizar agora','Update now'],['Instala somente a Latest Release estável publicada no repositório oficial.','Installs only the stable Latest Release published in the official repository.'],['Carregando status de atualização...','Loading update status...'],
  ['Traffic Analyzer atualizado','Traffic Analyzer updated'],['Versão anterior:','Previous version:'],['Versão atual:','Current version:'],['Última atualização:','Last update:'],['Destino','Target'],
  ['Pendente','Pending'],['Atualizando','Updating'],['Concluída','Completed'],['Falhou','Failed'],['Rollback executado','Rollback completed'],['Nunca','Never'],['Status:','Status:'],
  ['Solicitação de atualização enviada.','Update request sent.'],['Nenhuma atualização disponível.','No update is available.'],
  ['Responder','Reply'],['Reagir','React'],['Resposta','Reply'],['Respondendo a','Replying to'],['Mensagem original não carregada','Original message not loaded'],['Cancelar resposta','Cancel reply'],['Inserir emoji','Insert emoji'],['Novas mensagens','New messages'],
  ['Entrar','Sign in'],['Sair','Sign out'],['Entrar como administrador','Administrator sign in'],['Usuário','Username'],['Senha','Password'],['Verificando acesso…','Checking access…'],['Somente leitura','Read only'],['Administrador','Administrator'],['Autenticação desativada','Authentication disabled'],['Senha administrativa não configurada','Administrator password not configured'],
  ['O acesso sem login permanece em modo somente leitura.','Access without sign-in remains read only.'],['Modo somente leitura — faça login para alterar estas configurações.','Read-only mode — sign in to change these settings.'],['Somente leitura — faça login para enviar ou reagir','Read only — sign in to send or react'],['Usuário ou senha inválidos.','Invalid username or password.'],['Sessão expirada. Faça login novamente.','Session expired. Sign in again.'],
  ['Não foi possível identificar o pacote original para responder.','Could not identify the original packet to reply to.'],['Não foi possível identificar o pacote original para reagir.','Could not identify the original packet to react to.'],
  ['Reação enviada ao MeshMonitor','Reaction sent to MeshMonitor'],['Reação enviada em modo compatível','Reaction sent in compatibility mode'],['Falha no envio','Send failed'],
  ['Temas sonoros','Sound themes'],['Ativar sonificação da malha','Enable mesh sonification'],['Os sons acompanham eventos realmente observados. O Traffic Analyzer não inventa retransmissões para produzir efeitos.','Sounds follow events that were actually observed. Traffic Analyzer does not invent relays to produce effects.'],
  ['Tema:','Theme:'],['Fliperama anos 70','1970s Pinball'],['Formal','Formal'],['Rádio / Telecom','Radio / Telecom'],['Silencioso','Silent'],['Testar tema','Test theme'],
  ['Os efeitos são sintetizados localmente pelo navegador; nenhum arquivo de áudio é baixado.','Effects are synthesized locally by the browser; no audio file is downloaded.'],['Densidade sonora:','Sound density:'],['Baixa','Low'],['Normal','Normal'],['Alta','High'],
  ['Em densidade baixa, parte dos ricochetes é suprimida em malhas muito movimentadas. Normal e Alta preservam mais eventos observados.','At low density, some ricochets are suppressed on very busy meshes. Normal and High preserve more observed events.'],
  ['Intervalo mínimo:','Minimum interval:'],['Máximo simultâneo:','Maximum simultaneous:'],['sons','sounds'],['Limita sobreposição e evita uma sequência de efeitos excessivamente densa.','Limits overlap and prevents an excessively dense sequence of effects.'],
  ['Sons de roteamento e traceroute','Routing and traceroute sounds'],['Sons de mensagens','Message sounds'],['Sons de alertas e falhas','Alert and failure sounds'],['Estéreo espacial','Spatial stereo'],
  ['Quando ativado, eventos visíveis no mapa recebem leve deslocamento esquerda/direita conforme a posição. Desligado por padrão.','When enabled, visible map events receive slight left/right panning based on position. Off by default.'],
  ['Origem do pacote: lançador mecânico. Retransmissor observado: ricochete metálico. Destino/ACK: alvo e pontuação. Falha: efeito de bola perdida.','Packet source: mechanical plunger. Observed relay: metallic ricochet. Destination/ACK: target and scoring. Failure: lost-ball effect.'],
  ['Use @ para localizar um nó; o @ é removido antes da transmissão.','Use @ to find a node; @ is removed before transmission.'],
  ['Adiciona bandeiras do Brasil e dos Estados Unidos ao seletor de idioma.','Adds Brazil and United States flags to the language selector.'],
  ['Remove o caractere @ das menções antes de transmitir a mensagem, preservando apenas o nome do nó.','Removes the @ character from mentions before transmitting the message, preserving only the node name.'],
  ['Ícones por papel do nó','Node role icons'],
  ['Papel não informado','Role not reported'],
  ['Adiciona controles visuais de fonte, negrito, itálico, sublinhado, altura de linha e espaçamento entre mensagens.','Adds visual controls for font, bold, italic, underline, line height, and message spacing.'],
  ['Adiciona filtro de severidade na aba Anomalias: Todas, Críticas, Atenção e Informativas.','Adds a severity filter to the Anomalies tab: All, Critical, Warning, and Informational.'],
  ['Adiciona ajuste de espessura das linhas do mapa e restauração de cor/espessura ao padrão.','Adds map line thickness control and reset of color/thickness to defaults.'],
  ['Adiciona auto-update opcional por Latest Release estável, executado por serviço systemd dedicado.','Adds optional auto-update from the stable Latest Release, executed by a dedicated systemd service.'],
  ['Adiciona verificação de saúde, lock contra atualizações simultâneas e rollback automático em caso de falha.','Adds health verification, a lock against concurrent updates, and automatic rollback on failure.'],
  ['Adiciona status de atualização, botão Atualizar agora e persistência das preferências de auto-update no servidor.','Adds update status, an Update now button, and server-side persistence of auto-update preferences.'],
  ['Adiciona popup de novidades exibido uma única vez ao iniciar após uma atualização.','Adds a what\'s-new popup shown once when the application starts after an update.'],
  ['O atualizador manual traffic-analyzer-update passa a usar a mesma cadeia segura de Latest Release estável do auto-update.','The manual traffic-analyzer-update command now uses the same secure stable Latest Release chain as auto-update.'],
  ['O atualizador manual `traffic-analyzer-update` passa a usar a mesma cadeia segura de Latest Release estável do auto-update.','The manual `traffic-analyzer-update` command now uses the same secure stable Latest Release chain as auto-update.'],
  ['Restaurar padrão do administrador','Restore administrator default'],['Visitante: a personalização visual abaixo fica somente neste navegador. Recursos administrativos continuam bloqueados.','Visitor: the visual customization below stays only in this browser. Administrative features remain locked.'],
  ['Mapa, aparência, animações, sons e leitura podem ser personalizados localmente sem alterar o servidor ou a experiência de outros visitantes.','Map, appearance, animations, sounds, and reading preferences can be customized locally without changing the server or other visitors experience.'],
  ['Apresentação padrão para visitantes','Default presentation for visitors'],['Usar minha configuração visual atual como padrão dos visitantes','Use my current visual settings as the visitor default'],
  ['Grava no servidor o visual atual como ponto de partida para novos navegadores. Preferências locais já salvas por cada visitante continuam prevalecendo.','Stores the current visual setup on the server as the starting point for new browsers. Existing local visitor preferences continue to take precedence.'],
  ['Carregando padrão global...','Loading global default...'],['Padrão global salvo.','Global default saved.'],['Padrão global ainda não definido; usando os padrões de fábrica.','No global default has been defined yet; factory defaults are being used.'],['Padrão global carregado.','Global default loaded.'],
  ['10 enlaces RF diretos mais longos','10 longest direct RF links'],['Distância','Distance'],['Obs. RF','RF obs.'],['Última RF','Last RF'],['Somente adjacências confiáveis da API de traceroutes do MeshMonitor, com SNR válido e posição conhecida nos dois extremos. O período Todo inclui o histórico revalidado, inclusive nós offline; evidências permanecem no traffic.db até reset explícito.','Only trusted adjacencies from the MeshMonitor traceroute API, with valid SNR and known positions at both endpoints. The All period includes history revalidated through the authenticated v1 API, including offline nodes; evidence remains in traffic.db until an explicit reset.'],['Sem enlaces RF diretos com posição válida no período.','No direct RF links with valid positions in the selected period.'],['Clique para mostrar somente este enlace no mapa','Click to show only this link on the map'],['Mostrar todos os nós e enlaces','Show all nodes and links'],['Este enlace não está disponível na topologia atual.','This link is not available in the current topology.'],['Este enlace não pode ser enquadrado porque um dos nós não possui posição válida.','This link cannot be framed because one endpoint has no valid position.'],
  ['Enlaces RF confirmados','Confirmed RF links'],['Enlaces MQTT / não-RF','MQTT / non-RF links'],['Cor:','Color:'],['Espessura:','Thickness:'],
  ['Linha contínua somente quando existir evidência física RF no hop, atualmente SNR válido. Se houver observações RF e MQTT/não-RF no período, a linha permanece contínua e o popup mostra a composição.','Solid line only when the hop has physical RF evidence, currently a valid SNR. Mixed RF and MQTT/non-RF observations remain solid and the popup shows the composition.'],
  ['Linha tracejada quando não houver evidência física RF no hop. Sem SNR válido, a observação é tratada como MQTT/não-RF, mesmo que o registro de traceroute tenha chegado ao MeshMonitor por RF.','Dashed line when there is no physical RF evidence for the hop. Without a valid SNR, the observation is treated as MQTT/non-RF even if the traceroute record reached MeshMonitor over RF.'],
  ['Restaurar cores e espessuras','Restore colors and thicknesses'],['Tipo de enlace','Link type'],['RF confirmado','Confirmed RF'],['MQTT / não-RF','MQTT / non-RF'],
  ['Enlace misto permanece contínuo quando houver ao menos uma observação RF no período.','A mixed link stays solid when there is at least one RF observation in the selected period.'],
  ['Classificação:','Classification:'],['Misto RF + MQTT/não-RF (há evidência RF)','Mixed RF + MQTT/non-RF (RF evidence present)'],['Distância indisponível','Distance unavailable'],['Critério RF: SNR válido observado no hop','RF criterion: valid SNR observed on the hop'],
  ['Mapa:','Map:'],['Camadas','Layers'],['Radar meteorológico','Weather radar'],['Máximo do slider de corte do relevo:','Relief cutoff slider maximum:'],['Define o topo da escala do slider vertical da camada Relevo com corte. Padrão: 3.000 m.','Sets the top of the vertical slider scale for the Relief cutoff layer. Default: 3,000 m.'],['máx. do slider (m)','slider max (m)'],['Cobertura RF','RF coverage'],['Relevo sombreado','Hillshade'],['Relevo com corte','Relief cutoff'],['Corte do relevo','Relief cutoff'],['Opacidade','Opacity'],['Cota mínima','Minimum elevation'],['Altitude mínima','Minimum altitude'],['Altitude mínima exibida','Minimum displayed altitude'],['Altitude mínima em metros','Minimum altitude in meters'],['metros ou mais','meters or higher'],['Terreno ≥','Terrain ≥'],['Dados de elevação','Elevation data'],['Raios','Lightning'],['Alertas meteorológicos','Weather alerts'],['Nuvens','Clouds'],['Ligado','On'],['Desligado','Off'],['Atualizando radar…','Updating radar…'],['Carregando cobertura…','Loading coverage…'],['Atualizando raios…','Updating lightning…'],['Atualizando alertas…','Updating alerts…'],['Atualizando nuvens…','Updating clouds…'],['Ligado · radar atualizado','On · radar updated'],
  ['SNR médio RF conhecido:','Known RF average SNR:'],['MQTT inferido/explícito:','Inferred/explicit MQTT:'],['outros não-RF:','other non-RF:'],
];
const I18N_PT_EN=new Map(I18N_PAIRS);
const I18N_EN_PT=new Map(I18N_PAIRS.map(([pt,en])=>[en,pt]));
function translateDynamic(text,target){
  let s=String(text??'');
  if(target==='en'){
    s=s.replace(/^Ligado · ≥ (.+)$/,'On · ≥ $1');
    s=s.replace(/^Histórico pausado · posição (\d+)\/(\d+)$/,'History paused · position $1/$2');
    s=s.replace(/^Histórico: (\d+) traceroutes animáveis · posição (\d+)\/(\d+)$/,'History: $1 animatable traceroutes · position $2/$3');
    s=s.replace(/^Histórico concluído · (\d+) traceroutes reproduzidos$/,'History complete · $1 traceroutes played');
    s=s.replace(/^Histórico (\d+)\/(\d+)$/,'History $1/$2');
    s=s.replace(/^· ANIMAÇÃO PAUSADA · (\d+) traceroute\(s\) represado\(s\) · (\d+) pulso\(s\) represado\(s\) · (\d+) congelado\(s\)( · (\d+) descartado\(s\) por limite)?$/,(m,a,b,c,d,e)=>`· ANIMATION PAUSED · ${a} queued traceroute(s) · ${b} queued pulse(s) · ${c} frozen${e?` · ${e} dropped by limit`:''}`);
    s=s.replace(/^· conectando…$/,'· connecting…');
    s=s.replace(/^· direta (.+) · percurso (.+)$/,'· direct $1 · path $2');
    s=s.replace(/^Total ida \+ volta: (.+)$/,'Total outbound + return: $1');
    s=s.replace(/^Ida: (.+) \| Volta: (.+)$/,'Outbound: $1 | Return: $2');
    s=s.replace(/^· (\d+) traceroutes simultâneos$/,'· $1 simultaneous traceroutes');
    s=s.replace(/^· 1 traceroute em animação$/,'· 1 traceroute animating');
    s=s.replace(/^· erro: (.+)$/,'· error: $1');
    s=s.replace(/^(\d+) mensagens · atualizado (.+)$/,'$1 messages · updated $2');
    s=s.replace(/^(\d+) mensagens · histórico ampliado$/,'$1 messages · history expanded');
    s=s.replace(/^(\d+) mensagem\(ns\) não lida\(s\)$/,'$1 unread message(s)');
    s=s.replace(/^Carregando histórico anterior \(até (\d+)\)\.\.\.$/,'Loading older history (up to $1)...');
    s=s.replace(/^Falha no envio: (.+)$/,'Send failed: $1');
    s=s.replace(/^Não foi possível enviar: (.+)$/,'Could not send: $1');
    s=s.replace(/^Erro: (.+)$/,'Error: $1').replace(/^erro: (.+)$/,'error: $1').replace(/^erro (.+)$/,'error $1');
    s=s.replace(/^Falha ao atualizar: (.+)$/,'Update failed: $1');
    s=s.replace(/^Atualizando v([^ ]+) para v([^ ]+)\.$/,'Updating v$1 to v$2.');
    s=s.replace(/^Atualização concluída: v([^ ]+) → v([^ ]+)\.$/,'Update complete: v$1 → v$2.');
    s=s.replace(/^Erro ao carregar topologia: (.+)$/,'Error loading topology: $1');
    s=s.replace(/^(\d+) nó\(s\) · (\d+) pontos · (.+) acumulados$/,'$1 node(s) · $2 points · $3 accumulated');
    s=s.replace(/^Instalada: v([^ ]+) · disponível: v([^ ]+) · publicada em (.+)\.$/,'Installed: v$1 · available: v$2 · published $3.');
    s=s.replace(/^Instalada: v([^ ]+)\. Esta é a versão mais recente publicada\.$/,'Installed: v$1. This is the latest published version.');
    s=s.replace(/^Instalada: v([^ ]+)\. Não foi possível consultar o GitHub agora\.$/,'Installed: v$1. GitHub could not be checked right now.');
    s=s.replace(/^v([^ ]+) → v([^ ]+) disponível$/,'v$1 → v$2 available');
    s=s.replace(/^v([^ ]+) · não verificado$/,'v$1 · not checked');
    s=s.replace(/^v([^ ]+) · ATUALIZADO$/,'v$1 · UP TO DATE');
    s=s.replace(/^analisado (.+)$/,'analyzed $1').replace(/^atualizado (.+)$/,'updated $1');
    s=s.replace(/^há (\d+) segundos$/,'$1 seconds ago').replace(/^há (\d+) minuto$/,'$1 minute ago').replace(/^há (\d+) minutos$/,'$1 minutes ago');
    s=s.replace(/^há (\d+) hora$/,'$1 hour ago').replace(/^há (\d+) horas$/,'$1 hours ago');
    s=s.replace(/^há (\d+) dia$/,'$1 day ago').replace(/^há (\d+) dias$/,'$1 days ago');
    s=s.replace(/^há (\d+) hora e (\d+) minuto$/,'$1 hour and $2 minute ago').replace(/^há (\d+) hora e (\d+) minutos$/,'$1 hour and $2 minutes ago').replace(/^há (\d+) horas e (\d+) minuto$/,'$1 hours and $2 minute ago').replace(/^há (\d+) horas e (\d+) minutos$/,'$1 hours and $2 minutes ago');
    s=s.replace(/^há (\d+) dia e (\d+) hora$/,'$1 day and $2 hour ago').replace(/^há (\d+) dia e (\d+) horas$/,'$1 day and $2 hours ago').replace(/^há (\d+) dias e (\d+) hora$/,'$1 days and $2 hour ago').replace(/^há (\d+) dias e (\d+) horas$/,'$1 days and $2 hours ago');
    s=s.replace(/^Estado: (.+)$/,'State: $1').replace(/^Posição: (.+)$/,'Position: $1').replace(/^Último tráfego: (.+)$/,'Last traffic: $1').replace(/^Situação: (.+)$/,'Status: $1');
    s=s.replace(/^Observações: (.+)$/,'Observations: $1').replace(/^Ida: (.+)$/,'Outbound: $1').replace(/^Volta: (.+)$/,'Return: $1').replace(/^SNR médio: (.+)$/,'Average SNR: $1').replace(/^Faixa SNR: (.+)$/,'SNR range: $1').replace(/^Última observação: (.+)$/,'Last observation: $1').replace(/ \| canal: /,' | channel: ');
    s=s.replace(/^NodeInfo (.+) · caminho intermediário ainda não observado$/,'NodeInfo $1 · intermediate path not observed yet');
    s=s.replace(/^Rota observada por traceroute próximo \((\d+)s\) · não prova que o NodeInfo usou exatamente os mesmos relays$/,'Route observed by a nearby traceroute ($1s) · this does not prove NodeInfo used exactly the same relays');
    s=s.replace(/^por Alex, PT2VHF$/,'by Alex, PT2VHF').replace(/ - por Alex, PT2VHF$/,' - by Alex, PT2VHF');
  }else{
    s=s.replace(/^On · ≥ (.+)$/,'Ligado · ≥ $1');
    s=s.replace(/^History paused · position (\d+)\/(\d+)$/,'Histórico pausado · posição $1/$2');
    s=s.replace(/^History: (\d+) animatable traceroutes · position (\d+)\/(\d+)$/,'Histórico: $1 traceroutes animáveis · posição $2/$3');
    s=s.replace(/^History complete · (\d+) traceroutes played$/,'Histórico concluído · $1 traceroutes reproduzidos');
    s=s.replace(/^History (\d+)\/(\d+)$/,'Histórico $1/$2');
    s=s.replace(/^· ANIMATION PAUSED · (\d+) queued traceroute\(s\) · (\d+) queued pulse\(s\) · (\d+) frozen( · (\d+) dropped by limit)?$/,(m,a,b,c,d,e)=>`· ANIMAÇÃO PAUSADA · ${a} traceroute(s) represado(s) · ${b} pulso(s) represado(s) · ${c} congelado(s)${e?` · ${e} descartado(s) por limite`:''}`);
    s=s.replace(/^· connecting…$/,'· conectando…');
    s=s.replace(/^· direct (.+) · path (.+)$/,'· direta $1 · percurso $2');
    s=s.replace(/^Total outbound \+ return: (.+)$/,'Total ida + volta: $1');
    s=s.replace(/^Outbound: (.+) \| Return: (.+)$/,'Ida: $1 | Volta: $2');
    s=s.replace(/^· (\d+) simultaneous traceroutes$/,'· $1 traceroutes simultâneos').replace(/^· 1 traceroute animating$/,'· 1 traceroute em animação').replace(/^· error: (.+)$/,'· erro: $1');
    s=s.replace(/^(\d+) messages · updated (.+)$/,'$1 mensagens · atualizado $2').replace(/^(\d+) messages · history expanded$/,'$1 mensagens · histórico ampliado').replace(/^(\d+) unread message\(s\)$/,'$1 mensagem(ns) não lida(s)');
    s=s.replace(/^Loading older history \(up to (\d+)\)\.\.\.$/,'Carregando histórico anterior (até $1)...').replace(/^Send failed: (.+)$/,'Falha no envio: $1').replace(/^Could not send: (.+)$/,'Não foi possível enviar: $1');
    s=s.replace(/^Error: (.+)$/,'Erro: $1').replace(/^error: (.+)$/,'erro: $1').replace(/^error (.+)$/,'erro $1').replace(/^Update failed: (.+)$/,'Falha ao atualizar: $1').replace(/^Error loading topology: (.+)$/,'Erro ao carregar topologia: $1');
    s=s.replace(/^Updating v([^ ]+) to v([^ ]+)\.$/,'Atualizando v$1 para v$2.');
    s=s.replace(/^Update complete: v([^ ]+) → v([^ ]+)\.$/,'Atualização concluída: v$1 → v$2.');
    s=s.replace(/^(\d+) node\(s\) · (\d+) points · (.+) accumulated$/,'$1 nó(s) · $2 pontos · $3 acumulados');
    s=s.replace(/^Installed: v([^ ]+) · available: v([^ ]+) · published (.+)\.$/,'Instalada: v$1 · disponível: v$2 · publicada em $3.').replace(/^Installed: v([^ ]+)\. This is the latest published version\.$/,'Instalada: v$1. Esta é a versão mais recente publicada.').replace(/^Installed: v([^ ]+)\. GitHub could not be checked right now\.$/,'Instalada: v$1. Não foi possível consultar o GitHub agora.');
    s=s.replace(/^v([^ ]+) → v([^ ]+) available$/,'v$1 → v$2 disponível').replace(/^v([^ ]+) · not checked$/,'v$1 · não verificado').replace(/^v([^ ]+) · UP TO DATE$/,'v$1 · ATUALIZADO');
    s=s.replace(/^analyzed (.+)$/,'analisado $1').replace(/^updated (.+)$/,'atualizado $1');
    s=s.replace(/^(\d+) seconds ago$/,'há $1 segundos').replace(/^(\d+) minute ago$/,'há $1 minuto').replace(/^(\d+) minutes ago$/,'há $1 minutos').replace(/^(\d+) hour ago$/,'há $1 hora').replace(/^(\d+) hours ago$/,'há $1 horas').replace(/^(\d+) day ago$/,'há $1 dia').replace(/^(\d+) days ago$/,'há $1 dias');
    s=s.replace(/^State: (.+)$/,'Estado: $1').replace(/^Position: (.+)$/,'Posição: $1').replace(/^Last traffic: (.+)$/,'Último tráfego: $1').replace(/^Status: (.+)$/,'Situação: $1');
    s=s.replace(/^Observations: (.+)$/,'Observações: $1').replace(/^Outbound: (.+)$/,'Ida: $1').replace(/^Return: (.+)$/,'Volta: $1').replace(/^Average SNR: (.+)$/,'SNR médio: $1').replace(/^SNR range: (.+)$/,'Faixa SNR: $1').replace(/^Last observation: (.+)$/,'Última observação: $1').replace(/ \| channel: /,' | canal: ');
    s=s.replace(/^NodeInfo (.+) · intermediate path not observed yet$/,'NodeInfo $1 · caminho intermediário ainda não observado');
    s=s.replace(/^Route observed by a nearby traceroute \((\d+)s\) · this does not prove NodeInfo used exactly the same relays$/,'Rota observada por traceroute próximo ($1s) · não prova que o NodeInfo usou exatamente os mesmos relays');
    s=s.replace(/^by Alex, PT2VHF$/,'por Alex, PT2VHF').replace(/ - by Alex, PT2VHF$/,' - por Alex, PT2VHF');
  }
  return s;
}
function translateUiString(value,target=currentLang){
  const raw=String(value??'');
  const lead=(raw.match(/^\s*/)||[''])[0],trail=(raw.match(/\s*$/)||[''])[0];
  const core=raw.slice(lead.length,raw.length-trail.length);
  if(!core)return raw;
  const map=target==='en'?I18N_PT_EN:I18N_EN_PT;
  const exact=map.get(core);
  const out=exact!==undefined?exact:translateDynamic(core,target);
  return lead+out+trail;
}
function tr(value){return translateUiString(value,currentLang);}
function skipI18nElement(el){return !!el?.closest?.('script,style,.msgText,.msgSender,.mentionLong,.mentionShort,.mentionId,.versionNotes,.rawJson,pre,.updateCmd,.i18nNoTranslate');}
function translateUiElement(el){
  if(!el||el.nodeType!==1||skipI18nElement(el))return;
  for(const attr of ['title','placeholder','aria-label']){
    if(el.hasAttribute?.(attr)){const old=el.getAttribute(attr),neu=translateUiString(old,currentLang);if(neu!==old)el.setAttribute(attr,neu);}
  }
}
function translateUiTree(root){
  if(!root)return;
  if(root.nodeType===3){const p=root.parentElement;if(!skipI18nElement(p)){const neu=translateUiString(root.data,currentLang);if(neu!==root.data)root.data=neu;}return;}
  if(root.nodeType!==1 && root.nodeType!==9)return;
  if(root.nodeType===1)translateUiElement(root);
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT);
  let n; while((n=walker.nextNode())){if(n.nodeType===3){if(!skipI18nElement(n.parentElement)){const neu=translateUiString(n.data,currentLang);if(neu!==n.data)n.data=neu;}}else translateUiElement(n);}
}
let i18nBusy=false,i18nObserver=null;
function initI18nObserver(){
  if(i18nObserver)return;
  i18nObserver=new MutationObserver(ms=>{
    if(i18nBusy)return;i18nBusy=true;
    try{for(const m of ms){if(m.type==='characterData')translateUiTree(m.target);else if(m.type==='attributes')translateUiElement(m.target);else for(const n of m.addedNodes)translateUiTree(n);}}finally{i18nBusy=false;}
  });
  i18nObserver.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['title','placeholder','aria-label']});
}
function renderHelp(){
  const el=document.getElementById('helpContent');if(!el)return;
  if(currentLang==='en'){
    el.innerHTML=`<h2>Traffic Analyzer Help</h2>
      <p>Traffic Analyzer is a companion web application for MeshMonitor. It analyzes Meshtastic traffic, observed RF topology, traceroutes, messages, node activity, network health, and anomalies without taking over the radio connection used by MeshMonitor.</p>
      <div class="helpCallout"><b>Important:</b> the application only shows what its configured MeshMonitor source has observed. A missing link, route, position, or packet is not proof that it never existed on the mesh.</div>
      <h3>1. Map</h3><p>The Map tab shows nodes with known coordinates and observed routing relationships. Starting with v1.47.0, every observed node and link is kept in Traffic Analyzer's own historical memory until traffic.db is explicitly deleted/reset; MeshMonitor retention no longer makes an already-known link disappear. Time windows only filter the view. Node popups can be dragged by their header to avoid covering legends or map controls, while their internal content remains scrollable. Node color indicates the age of the last observed traffic. Link style also carries transport evidence: a solid line means at least one RF-confirmed observation exists in the selected period; a dashed line means only MQTT/non-RF evidence was seen. Mixed links stay solid and the popup shows the RF versus MQTT/non-RF observation counts. The RF Coverage layer composes archived receptions into a heatmap: overlapping receptions accumulate visually and each point is weighted by SNR, with RSSI as fallback. Use <b>Fit</b> to tightly frame visible nodes and <b>Refresh</b> to force topology regeneration.</p>
      <ul><li><b>History:</b> replays traceroutes on their observed timeline and allows several packets to move simultaneously. Long windows are proportionally time-compressed.</li><li><b>Live:</b> each new complete traceroute starts independently without waiting for earlier animations to finish.</li><li><b>No artificial limit:</b> there is no functional cap on packets in transit; all observed events are kept.</li><li><b>Pause:</b> freezes every visual animation. Collection and processing continue, and waiting events are released on resume.</li><li><b>Speed:</b> also affects packets already moving and the History timeline.</li><li><b>Auto Zoom:</b> can follow all nodes involved in simultaneous traceroute animations.</li></ul>
      <h3>2. Nodes</h3><p>The Nodes tab inventories every node known to the configured MeshMonitor source. The filter narrows the list character by character. Click any column heading to sort ascending or descending. Last interaction is color-coded: green up to 1 hour, yellow from more than 1 hour through 12 hours, and red above 12 hours. Battery percentage is green at 50% or above, yellow from 20% to 49.9%, and red below 20%. Distance is calculated specifically from VHF3 when both nodes have a known position. The Columns menu can reveal RSSI, channel utilization, Air Util TX, Node ID, PKC and state. A single click selects a row (Shift+click selects a range; the header checkbox selects every filtered node) and the selection bar applies bulk actions: favorite, hide on the map, Node Info/Traceroute over RF (up to 10 nodes, spaced out), copy IDs, CSV export, and deletion with a per-node result. Right-click on a selected row opens the same bulk actions. Double-click a row, press Enter, or use the ▤ button to open the expanded <b>Node details</b> view, reusing the same data and query logic as the map popup. The panel shows identification, position, telemetry, RF, routing, traceroute, firmware, and power information when available.</p>
      <h3>3. Traffic</h3><p>The Traffic tab displays RX/TX packets observed by MeshMonitor. Filters can narrow direction, packet type, and text search. Click a row to inspect the formatted payload and technical fields. Direct text-message contents remain hidden by the server privacy policy.</p>
      <h3>4. Messages</h3><p>The Messages tab works with the primary channel (channel 0). Enter sends a message; Shift+Enter inserts a line break. Delivery symbols represent protocol state/ACK and do <b>not</b> mean that a human read the message.</p>
      <h4>Reply</h4><p>Use <b>Reply</b> or double-click a message. Traffic Analyzer uses the native Meshtastic/MeshMonitor <code>replyId</code> and shows a reference to the original message in the reply bubble.</p>
      <h4>Emoji and reactions</h4><p>The emoji button inserts emoji into normal message text. On received messages, <b>React</b> offers larger 👍 👎 ❤️ 😂 😮 😢 controls. Traffic Analyzer first attempts the native Meshtastic tapback (<code>emoji=1</code> + <code>replyId</code>). If MeshMonitor denies only that endpoint with HTTP 403, it automatically sends an emoji reply with <code>replyId</code> as a compatibility fallback.</p><h4>Scrolling</h4><p>When you scroll up to read older messages, automatic refresh preserves your position. New messages do not pull the view to the bottom; a <b>↓ New messages</b> button appears. Clicking it - or manually returning to the bottom - restores auto-scroll. <b>Load older</b> also preserves the reading position.</p>
      <h4>Node mentions</h4><p>Type <code>@</code> and start entering a short name, full name, or node ID. Use the arrow keys and Enter/Tab, or click a suggestion. The <code>@</code> character is only the autocomplete trigger; selecting a result inserts the full node name without <code>@</code>.</p>
      <h3>5. Network Health</h3><p>This tab summarizes recent node activity, packet volume, observed links, traceroute completeness, hop counts, chat interactions, and nodes that deserve attention. These indicators prioritize investigation; they are not proof of a hardware or RF fault.</p><p>Under <b>Statistics → Ranking</b>, the <b>10 longest direct RF links</b> ranking uses only trusted traceroute API adjacencies with valid SNR and known positions at both endpoints. The All period also includes revalidated historical links from nodes that are currently offline. A route A→B→C contributes A↔B and B↔C only; it never invents A↔C.</p>
      <h3>6. Points of attention</h3><p>Points of attention use heuristics such as prolonged silence, SNR degradation, relevant hop-count changes, and asymmetric traceroutes. Always interpret each indication together with RF conditions, node role, power state, and the observation point.</p>
      <h3>7. Access</h3><p>The Access tab is restricted to the administrator when authentication is enabled. It summarizes page views by day, countries, cities, unique IP addresses, browsers, operating systems, and login success/failure counts. Raw access events are also written as JSON Lines to <code>access.log</code> next to <code>traffic.db</code>. Public IP geolocation is not sent to any external service by default: country/city come from trusted reverse-proxy/CDN headers, local/private addresses, or an explicitly configured server-side GeoIP endpoint.</p>
      <h3>8. Settings</h3><div class="helpGrid"><div class="helpMini"><b>Appearance</b>Choose Dark or Light interface theme. The base-map style is independent.</div><div class="helpMini"><b>Map and topology</b>Control time window, minimum observations, map style, line visibility, node labels, heat map, Auto Zoom, and independent color/thickness for confirmed RF versus MQTT/non-RF links.</div><div class="helpMini"><b>Traffic database</b>The administrator can retain raw packets/positions for 1 day, 1 week, 1 month, or never delete them. The default is Never delete. This cleanup never removes the permanent node/link memory.</div><div class="helpMini"><b>Sound</b>Choose 1970s Pinball, Formal, Radio / Telecom, or Silent and tune density, volume, and event types.</div><div class="helpMini"><b>Real-time activity</b>Configure source/response and observed-relay pulses.</div><div class="helpMini"><b>Messages</b>Adjust size, font family, bold, italic, underline, line height, and spacing - interface only.</div><div class="helpMini"><b>Privacy</b>NodeInfo flow uses observed evidence and never invents intermediate hops.</div></div>
      <h3>9. Authentication and Internet exposure</h3><p>When authentication is enabled, visitors may freely change visual and reading preferences in Settings; these changes stay only in that browser. Administrative actions remain locked: sending/replying/reacting to messages, forcing topology refresh, changing update settings, triggering updates, and changing the server-side visitor default all require an authenticated administrator session.</p><p>The administrator can save the current visual setup as the global default for new visitors. A visitor can still override it locally and can use <b>Restore administrator default</b> at any time. Every server write API remains protected by an authenticated session and CSRF token.</p><p>Configure the administrator password on the server with <code>sudo traffic-analyzer-set-password</code>. Passwords are stored only as PBKDF2-SHA256 hashes. Sessions use HttpOnly/SameSite cookies and expire automatically. For Internet exposure, place Traffic Analyzer behind an HTTPS reverse proxy such as Caddy, Nginx or Cloudflare Tunnel; the application itself does not terminate TLS.</p>
      <h3>10. Language</h3><p>Use the pull-down language menu at the top of the application. Portuguese is the default. Flags are rendered as embedded SVG, so they do not depend on Windows or browser emoji support. Switching to English translates navigation, settings, help, status messages, labels, tooltips, map interface text, and analytical panels. Node names, user messages, IDs, raw protocol values, and release notes are preserved as source data.</p>
      <h3>11. Version and updates</h3><p>The badge at the top compares the installed version with the latest published GitHub Release. Automatic checks run every 15 minutes by default; an administrator can change the interval from 5 to 1,440 minutes under Settings → Updates. Starting with v1.48.0, every newer stable official Release is installed automatically by the dedicated systemd updater, even when no browser or administrator session is active. Backup, health check, lock and rollback remain enabled. After a successful update, each browser/profile sees the release-notes popup once for that installed version.</p>
      <div class="helpCode i18nNoTranslate">cat /opt/traffic-analyzer/VERSION</div>
      <p>After an update that changes JavaScript or CSS, use <b>Ctrl+F5</b> if the browser is still showing cached interface files.</p>
      <h3>12. Interpretation limits</h3><div class="helpCallout helpWarn">Traffic Analyzer describes observed data. RF meshes are dynamic: absence of traffic does not by itself prove an outage; a traceroute is evidence of a route observed at a point in time; a relay byte does not always identify a complete path.</div>`;
  }else{
    el.innerHTML=`<h2>Ajuda do Traffic Analyzer</h2>
      <p>O Traffic Analyzer é uma aplicação web complementar ao MeshMonitor. Ele analisa tráfego Meshtastic, topologia RF observada, traceroutes, mensagens, atividade dos nós, saúde da rede e anomalias sem assumir a conexão com o rádio utilizada pelo MeshMonitor.</p>
      <div class="helpCallout"><b>Importante:</b> a aplicação mostra somente aquilo que a fonte MeshMonitor configurada conseguiu observar. A ausência de enlace, rota, posição ou pacote não prova que o evento nunca existiu na malha.</div>
      <h3>1. Mapa</h3><p>A aba Mapa mostra nós com coordenadas conhecidas e relações de roteamento observadas. A partir da v1.47.0, cada nó e enlace observado fica na memória histórica própria do Traffic Analyzer até o traffic.db ser explicitamente apagado/resetado; a retenção do MeshMonitor não faz mais um enlace já conhecido desaparecer. As janelas de tempo apenas filtram a visualização. O popup de cada nó pode ser arrastado pelo cabeçalho para não encobrir a legenda ou outros controles, mantendo a rolagem interna do conteúdo. A cor do nó indica a idade do último tráfego observado. O estilo do enlace também representa evidência de transporte: linha contínua significa que existe ao menos uma observação RF confirmada no período; linha tracejada significa que foram observadas apenas evidências MQTT/não-RF. Enlaces mistos permanecem contínuos e o popup informa a quantidade de observações RF e MQTT/não-RF. A camada Cobertura RF compõe as recepções arquivadas em um mapa de calor: recepções sobrepostas se acumulam visualmente e cada ponto é ponderado por SNR, com RSSI como fallback. Use <b>Enquadrar</b> para ocupar a tela com os nós visíveis e <b>Atualizar</b> para forçar a regeneração da topologia.</p>
      <ul><li><b>Histórico:</b> reproduz traceroutes em ordem temporal e permite vários pacotes simultaneamente. Janelas longas têm a escala de tempo comprimida proporcionalmente.</li><li><b>Ao vivo:</b> novos traceroutes completos iniciam sua própria animação sem esperar os anteriores terminarem.</li><li><b>Sem limite artificial:</b> não há teto funcional de pacotes em trânsito; a interface acompanha todos os eventos observados.</li><li><b>Pausa:</b> congela todas as animações visuais. Coleta e processamento continuam, e o que ficou aguardando é liberado ao retomar.</li><li><b>Velocidade:</b> afeta também os pacotes que já estão se movendo e a linha do tempo do Histórico.</li><li><b>Auto Zoom:</b> opcionalmente acompanha em conjunto os nós envolvidos nas animações simultâneas.</li></ul>
      <h3>2. Nós</h3><p>A aba Nós lista todos os nós conhecidos pela fonte MeshMonitor configurada. O filtro reduz a lista caractere por caractere enquanto você digita. Clique em qualquer título de coluna para alternar entre ordem crescente e decrescente. A última interação usa cores: verde até 1 hora, amarelo acima de 1 hora até 12 horas e vermelho acima de 12 horas. O percentual da bateria fica verde a partir de 50%, amarelo de 20% a 49,9% e vermelho abaixo de 20%. A distância é calculada especificamente em relação ao VHF3 quando os dois nós possuem posição conhecida. O menu Colunas permite exibir RSSI, utilização do canal, Air Util TX, Node ID, PKC e estado. Um clique seleciona a linha (Shift+clique seleciona um intervalo; a caixa do cabeçalho seleciona todos os nós filtrados) e a barra de seleção aplica ações em lote: favoritar, ocultar no mapa, Node Info/Traceroute por RF (até 10 nós, espaçados), copiar IDs, exportar CSV e excluir com resultado por nó. O clique direito numa linha selecionada abre as mesmas ações. Duplo clique, Enter ou o botão ▤ abrem a visualização ampliada de <b>Detalhes do nó</b>, reutilizando os mesmos dados e consultas do popup do mapa. O painel mostra identificação, posição, telemetria, RF, routing, traceroute, firmware e energia conforme disponíveis.</p>
      <h3>3. Tráfego</h3><p>A aba Tráfego mostra pacotes RX/TX observados pelo MeshMonitor. Os filtros permitem restringir direção, tipo de pacote e busca textual. Clique em uma linha para examinar payload formatado e campos técnicos. O conteúdo de mensagens diretas permanece oculto pela política de privacidade do servidor.</p>
      <h3>4. Mensagens</h3><p>A aba Mensagens trabalha com o canal primário (canal 0). Enter envia; Shift+Enter cria uma nova linha. Os símbolos de entrega representam estado de protocolo/ACK e <b>não</b> significam que uma pessoa leu a mensagem.</p>
      <h4>Responder</h4><p>Use <b>Responder</b> ou dê duplo clique em uma mensagem. O Traffic Analyzer usa o <code>replyId</code> nativo do Meshtastic/MeshMonitor e mostra no novo balão uma referência à mensagem original.</p>
      <h4>Emojis e reações</h4><p>O botão de emoji insere emojis normalmente no texto. Em mensagens recebidas, <b>Reagir</b> oferece 👍 👎 ❤️ 😂 😮 😢 em tamanho ampliado. O Traffic Analyzer tenta primeiro o tapback Meshtastic nativo (<code>emoji=1</code> + <code>replyId</code>). Se o MeshMonitor negar somente esse endpoint com HTTP 403, usa automaticamente uma resposta emoji compatível com <code>replyId</code>, sem perder a ação.</p><h4>Rolagem</h4><p>Ao subir para ler mensagens antigas, as consultas automáticas preservam a posição. Mensagens novas não puxam a tela para o fim; aparece o botão <b>↓ Novas mensagens</b>. Ao clicar nele - ou ao rolar manualmente até o final - o auto-scroll é reativado. <b>Carregar anteriores</b> também preserva o ponto de leitura.</p>
      <h4>Menções de nós</h4><p>Digite <code>@</code> e comece a escrever o short name, nome completo ou node ID. Use as setas e Enter/Tab ou clique em uma sugestão. O <code>@</code> funciona somente como gatilho da busca; ao selecionar, o campo recebe o nome completo do nó sem o caractere <code>@</code>.</p>
      <h3>5. Saúde da Rede</h3><p>Resume atividade recente dos nós, volume de pacotes, enlaces observados, completude dos traceroutes, quantidade de hops, interações por chat e nós que merecem atenção. Os indicadores priorizam investigação; não são prova de defeito de hardware ou RF.</p><p>Em <b>Estatísticas → Ranking</b>, o ranking <b>10 enlaces RF diretos mais longos</b> usa somente adjacências confiáveis da API de traceroutes, com SNR válido e posição conhecida nos dois extremos. O período Todo também inclui enlaces históricos revalidados de nós atualmente offline. Uma rota A→B→C contribui apenas com A↔B e B↔C; o sistema nunca inventa A↔C.</p>
      <h3>6. Pontos de atenção</h3><p>Os pontos de atenção usam heurísticas como silêncio prolongado, degradação de SNR, mudanças relevantes de hops e traceroutes assimétricos. Interprete cada indicação junto das condições de RF, role, alimentação do nó e ponto de observação.</p>
      <h3>7. Acessos</h3><p>A aba Acessos fica restrita ao administrador quando a autenticação estiver ativada. Ela resume acessos por dia, países, cidades, IPs únicos, navegadores, sistemas operacionais e sucessos/falhas de login. Os eventos brutos também são gravados em formato JSON Lines no arquivo <code>access.log</code>, ao lado do <code>traffic.db</code>. Por padrão, IPs públicos não são enviados a nenhum serviço externo de geolocalização: país/cidade vêm de cabeçalhos confiáveis do proxy/CDN, de endereços locais/privados ou de um endpoint GeoIP configurado explicitamente no servidor.</p>
      <h3>8. Configurações</h3><div class="helpGrid"><div class="helpMini"><b>Aparência</b>Escolha tema Escuro ou Claro. O mapa-base é independente.</div><div class="helpMini"><b>Mapa e topologia</b>Controle janela temporal, mínimo de observações, mapa-base, linhas, nomes, mapa de calor, Auto Zoom e cor/espessura independentes para enlaces RF confirmados e MQTT/não-RF.</div><div class="helpMini"><b>Banco de tráfego</b>O administrador pode reter pacotes/posições brutas por 1 dia, 1 semana, 1 mês ou Nunca apagar. O padrão é Nunca apagar. Essa limpeza nunca remove a memória permanente de nós/enlaces.</div><div class="helpMini"><b>Som</b>Escolha Fliperama anos 70, Formal, Rádio / Telecom ou Silencioso e ajuste densidade, volume e tipos de evento.</div><div class="helpMini"><b>Atividade ao vivo</b>Configure pulsos de origem/resposta e relay observado.</div><div class="helpMini"><b>Mensagens</b>Ajuste tamanho, família da fonte, negrito, itálico, sublinhado, altura de linha e espaçamento - somente na interface.</div><div class="helpMini"><b>Privacidade</b>O fluxo NodeInfo usa evidência observada e não inventa hops intermediários.</div></div>
      <h3>9. Autenticação e exposição na internet</h3><p>Com a autenticação ativada, visitantes podem alterar livremente preferências visuais e de leitura em Configurações; essas alterações ficam somente naquele navegador. Ações administrativas continuam bloqueadas: enviar/responder/reagir a mensagens, forçar atualização da topologia, alterar o auto-update, disparar atualização e mudar o padrão global dos visitantes exigem sessão administrativa autenticada.</p><p>O administrador pode salvar a configuração visual atual como padrão global para novos visitantes. Cada visitante ainda pode sobrescrevê-la localmente e usar <b>Restaurar padrão do administrador</b> quando quiser. Todas as APIs de escrita no servidor permanecem protegidas por sessão autenticada e token CSRF.</p><p>Configure a senha administrativa no servidor com <code>sudo traffic-analyzer-set-password</code>. A senha é armazenada apenas como hash PBKDF2-SHA256. As sessões usam cookie HttpOnly/SameSite e expiram automaticamente. Para exposição na internet, use um reverse proxy HTTPS como Caddy, Nginx ou Cloudflare Tunnel; o Traffic Analyzer não termina TLS diretamente.</p>
      <h3>10. Idioma</h3><p>Use o menu pull-down de idioma no topo. Português é o padrão. As bandeiras são desenhadas por SVG embutido, sem depender do suporte de emojis do Windows ou do navegador. Ao selecionar English, navegação, configurações, ajuda, estados, rótulos, tooltips, textos da interface do mapa e painéis analíticos passam para inglês. Nomes dos nós, mensagens dos usuários, IDs, valores brutos de protocolo e notas das Releases permanecem como dados de origem.</p>
      <h3>11. Versão e atualização</h3><p>O indicador no topo compara a versão instalada com a Latest Release publicada no GitHub. A verificação automática ocorre a cada 15 minutos por padrão; o administrador pode definir de 5 a 1.440 minutos em Configurações → Atualizações. A partir da v1.48.0, toda nova Release estável oficial é instalada automaticamente pelo atualizador systemd dedicado, mesmo sem navegador aberto ou sessão administrativa. Backup, health check, lock e rollback permanecem ativos. Após uma atualização bem-sucedida, cada navegador/perfil exibe uma única vez o popup com as novidades da versão instalada.</p>
      <div class="helpCode i18nNoTranslate">sudo traffic-analyzer-update
cat /opt/traffic-analyzer/VERSION</div>
      <p>Depois de uma atualização que altere JavaScript ou CSS, use <b>Ctrl+F5</b> caso o navegador ainda esteja exibindo arquivos antigos em cache.</p>
      <h3>12. Limites de interpretação</h3><div class="helpCallout helpWarn">O Traffic Analyzer descreve dados observados. Malhas RF são dinâmicas: ausência de tráfego não prova, isoladamente, indisponibilidade; um traceroute é evidência de uma rota observada naquele momento; o byte de relay não identifica necessariamente todo o caminho.</div>`;
  }
}
function applyLanguage(lang,persist=true){
  currentLang=SUPPORTED_LANGUAGES[lang]?lang:'pt-BR';
  if(persist)localStorage.setItem(LANGUAGE_KEY,currentLang);
  document.documentElement.lang=currentLang==='en'?'en':'pt-BR';
  updateLanguageMenu();
  renderHelp();
  i18nBusy=true;try{translateUiTree(document.body);document.title=translateUiString(document.title,currentLang);}finally{i18nBusy=false;}
  if(typeof updatePlaybackStatusIdle==='function')updatePlaybackStatusIdle();
}

document.getElementById('uiLanguageButton').addEventListener('click',e=>{
  e.stopPropagation();
  const menu=document.getElementById('uiLanguageMenu'),btn=document.getElementById('uiLanguageButton');
  const opening=!menu.classList.contains('open');
  menu.classList.toggle('open',opening);btn.setAttribute('aria-expanded',opening?'true':'false');
  if(opening)setTimeout(()=>menu.querySelector('.languageOption.selected')?.focus(),0);
});
document.querySelectorAll('.languageOption[data-language]').forEach(opt=>opt.addEventListener('click',e=>{
  e.stopPropagation();applyLanguage(opt.dataset.language,true);closeLanguageMenu();document.getElementById('uiLanguageButton')?.focus();
}));
document.getElementById('uiLanguageMenu').addEventListener('keydown',e=>{
  const opts=[...document.querySelectorAll('.languageOption[data-language]')],idx=opts.indexOf(document.activeElement);
  if(e.key==='ArrowDown'||e.key==='ArrowUp'){
    e.preventDefault();const delta=e.key==='ArrowDown'?1:-1;opts[(idx+delta+opts.length)%opts.length]?.focus();
  }else if(e.key==='Escape'){e.preventDefault();closeLanguageMenu();document.getElementById('uiLanguageButton')?.focus();}
});
document.addEventListener('click',e=>{if(!document.getElementById('languageControl')?.contains(e.target))closeLanguageMenu();});

const MAP_ZOOM_SNAP=0.05;
const MAP_ZOOM_DELTA=0.20;
const MAP_WHEEL_PX_PER_ZOOM_LEVEL=120;
const MAP_WHEEL_DEBOUNCE_MS=30;
const map = L.map('map', {
  preferCanvas:true,
  zoomSnap:MAP_ZOOM_SNAP,
  zoomDelta:MAP_ZOOM_DELTA,
  wheelPxPerZoomLevel:MAP_WHEEL_PX_PER_ZOOM_LEVEL,
  wheelDebounceTime:MAP_WHEEL_DEBOUNCE_MS,
  scrollWheelZoom:true
}).setView([-15.8,-47.9], 9);

const baseMaps = {
  osm: {
    label:'Ruas (OSM)',
    providers:[
      {
        name:'OpenStreetMap',
        url:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        options:{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}
      },
      {
        name:'OpenTopoMap',
        url:'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
        options:{maxZoom:17,attribution:'Map data &copy; OpenStreetMap contributors, SRTM | Map style &copy; OpenTopoMap'}
      }
    ]
  },
  topo: {
    label:'Topográfico',
    providers:[
      {
        name:'OpenTopoMap',
        url:'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
        options:{maxZoom:17,attribution:'Map data &copy; OpenStreetMap contributors, SRTM | Map style &copy; OpenTopoMap'}
      },
      {
        name:'OpenStreetMap',
        url:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        options:{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}
      }
    ]
  },
  light: {
    label:'Claro',
    providers:[
      {
        name:'OpenStreetMap · tema claro local',
        url:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        options:{maxZoom:19,className:'basemapLightTile',attribution:'&copy; OpenStreetMap contributors'}
      },
      {
        name:'OpenTopoMap · tema claro local',
        url:'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
        options:{maxZoom:17,className:'basemapLightTile',attribution:'Map data &copy; OpenStreetMap contributors, SRTM | Map style &copy; OpenTopoMap'}
      }
    ]
  },
  dark: {
    label:'Escuro',
    providers:[
      {
        name:'OpenStreetMap · tema escuro local',
        url:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        options:{maxZoom:19,className:'basemapDarkTile',attribution:'&copy; OpenStreetMap contributors'}
      },
      {
        name:'OpenTopoMap · tema escuro local',
        url:'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
        options:{maxZoom:17,className:'basemapDarkTile',attribution:'Map data &copy; OpenStreetMap contributors, SRTM | Map style &copy; OpenTopoMap'}
      }
    ]
  },
  satellite: {
    label:'Satélite',
    providers:[
      {
        name:'Esri World Imagery',
        url:'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        options:{maxZoom:19,attribution:'Tiles &copy; Esri'}
      },
      {
        name:'OpenStreetMap',
        url:'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        options:{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}
      }
    ]
  }
};

let baseLayer = null;
let baseMapTileErrors = 0;
let baseMapFallbackActive = false;
let baseMapProviderIndex = 0;
let baseMapCurrentType = 'osm';
let baseMapSwitchGeneration = 0;
let weatherRadarLayer = null;
let weatherRadarRefreshTimer = null;
let weatherRadarLastFrame = null;
let rfCoverageLayer = L.layerGroup();
let hillshadeLayer = null;
let elevationLayer = null;
let elevationControl = null;
let elevationRedrawRaf = null;
let elevationThresholdMeters = 1000;
let elevationSliderMaxMeters = 3000;
let elevationOpacity = 0.55;
let lightningLayer = L.layerGroup();
let weatherAlertsLayer = L.layerGroup();
let cloudsLayer = null;
let lightningRefreshTimer = null;
let alertsRefreshTimer = null;
let cloudsRefreshTimer = null;
const WEATHER_RADAR_REFRESH_MS = 300000;
const WEATHER_LAYER_REFRESH_MS = 600000;
for(const [paneName,z,cls] of [['weatherRadarPane',250,'leaflet-weather-radar-pane'],['hillshadePane',210,'leaflet-hillshade-pane'],['elevationPane',220,'leaflet-elevation-pane'],['cloudsPane',230,'leaflet-clouds-pane']]){
  if(!map.getPane(paneName)){
    const pane=map.createPane(paneName); pane.classList.add(cls); pane.style.zIndex=String(z);
  }
}
const lineLayer = L.layerGroup().addTo(map);
const nodeLayer = L.layerGroup().addTo(map);
const animationLayer = L.layerGroup().addTo(map);
const flowLayer = L.layerGroup().addTo(map);
const activityLayer = L.layerGroup().addTo(map);
const activityMarkers = new Map();
let heatLayer = null;
let topology = null;
const nodeTrafficLastSeen = new Map();
const nodeMarkers = new Map();
const mapSearchHighlightLayer = L.layerGroup().addTo(map);
let mapSearchText='';
let mapSearchHintTimer=null;
let openNodeNum = null;
let suppressNodePopupClose = false;
let openNodePopupScrollTop = 0;
let nodePopupDragState={nodeNum:null,x:0,y:0,left:null,top:null};
let nodePopupExpandedNode=null;
let nodeWindowState={nodeNum:null,left:null,top:null,width:null,height:null,maximized:false,restore:null};
let nodesSortKey = 'lastInteraction';
let nodesSortDir = 'desc';
let nodesFilterText = '';
const NODES_COLUMNS_KEY='trafficAnalyzerNodesColumnsV132';
let nodesOptionalColumns=new Set();
let lastBounds = null;
let isolatedEdgeId = null;
let isolatedEdgeNodes = new Set();
let historyIndex = 0;
let playbackRunning = false;
let historyAnimationPaused = false;
let animationGeneration = 0;
let historyAnimationSeq = 0;
let historySchedulerRaf = null;
let historySchedulerState = null;
const activeHistoryAnimations = new Map();
let livePollTimer = null;
let liveInitialized = false;
let liveSeen = new Set();
let liveQueue = [];
let pausedActivityQueue = [];
let liveProcessing = false;
let liveAnimationSeq = 0;
let liveAnimationPaused = false;
const activeLiveAnimations = new Map();
let autoZoomSavedCenter = null;
let autoZoomSavedZoom = null;
let autoZoomRestoreTimer = null;
let autoZoomEngaged = false;
const autoZoomActive = new Map();
const traceHudEntries = new Map();
let traceHudContainer = null;

const PREF_KEY = 'trafficAnalyzerPrefsV15';
let serverUiDefaults={};
let serverUiDefaultsUpdatedAtMs=null;

function loadPrefs(){
  try {
    const current=localStorage.getItem(PREF_KEY);
    if(current) return JSON.parse(current);
    const legacy=localStorage.getItem('mmRouteMapPrefsV12');
    if(legacy){ const parsed=JSON.parse(legacy); localStorage.setItem(PREF_KEY,JSON.stringify(parsed)); return parsed; }
    return {};
  } catch { return {}; }
}
function collectPrefs(){
  return {
    defaultsVersion: 420,
    ageHours: document.getElementById('ageHours').value,
    minObs: Number(document.getElementById('minObs').value || 1),
    onlyIdentified: document.getElementById('onlyIdentified').checked,
    mapType: document.getElementById('mapType').value,
    weatherRadarEnabled: document.getElementById('weatherRadarEnabled')?.checked !== false,
    rfCoverageEnabled: Boolean(document.getElementById('rfCoverageEnabled')?.checked),
    hillshadeEnabled: Boolean(document.getElementById('hillshadeEnabled')?.checked),
    elevationEnabled: Boolean(document.getElementById('elevationEnabled')?.checked),
    elevationThreshold: Math.round(Number(elevationThresholdMeters || 1000)),
    elevationSliderMax: Math.round(Number(elevationSliderMaxMeters || 3000)),
    elevationOpacity: Math.round(Number(elevationOpacity || .55) * 100),
    lightningEnabled: Boolean(document.getElementById('lightningEnabled')?.checked),
    alertsEnabled: Boolean(document.getElementById('alertsEnabled')?.checked),
    cloudsEnabled: Boolean(document.getElementById('cloudsEnabled')?.checked),
    brightness: Number(document.getElementById('mapBrightness').value || 100),
    rfLineColor: document.getElementById('rfLineColor').value || '#ffff00',
    rfLineWidth: Number(document.getElementById('rfLineWidth').value || 3),
    mqttLineColor: document.getElementById('mqttLineColor').value || '#ff8c42',
    mqttLineWidth: Number(document.getElementById('mqttLineWidth').value || 3),
    showShortNames: document.getElementById('showShortNames').checked,
    showLines: document.getElementById('showLines').checked,
    showNodes: document.getElementById('showNodes').checked,
    showHeatmap: document.getElementById('showHeatmap').checked,
    animSpeed: Number(document.getElementById('animSpeed').value || 150),
    soundEnabled: document.getElementById('soundEnabled').checked,
    soundVolume: Number(document.getElementById('soundVolume').value || 35),
    soundTheme: document.getElementById('soundTheme').value || 'formal',
    soundDensity: document.getElementById('soundDensity').value || 'normal',
    soundMinInterval: Number(document.getElementById('soundMinInterval').value || 120),
    soundMaxVoices: Number(document.getElementById('soundMaxVoices').value || 3),
    soundRoutingEnabled: document.getElementById('soundRoutingEnabled').checked,
    soundMessagesEnabled: document.getElementById('soundMessagesEnabled').checked,
    soundAlertsEnabled: document.getElementById('soundAlertsEnabled').checked,
    soundStereoEnabled: document.getElementById('soundStereoEnabled').checked,
    activityAnimationEnabled: document.getElementById('activityAnimationEnabled').checked,
    activityOriginEnabled: document.getElementById('activityOriginEnabled').checked,
    activityRelayEnabled: document.getElementById('activityRelayEnabled').checked,
    activityDuration: Number(document.getElementById('activityDuration').value || 1000),
    autoZoomTraceroute: document.getElementById('autoZoomTraceroute').checked,
    nodeInfoFlowEnabled: document.getElementById('nodeInfoFlowEnabled').checked,
    nodeInfoToastEnabled: document.getElementById('nodeInfoToastEnabled').checked,
    nodeInfoAutoTraceEnabled: document.getElementById('nodeInfoAutoTraceEnabled').checked,
    messageFontSize: Number(document.getElementById('messageFontSize').value || 13),
    messageFontFamily: document.getElementById('messageFontFamily').value || 'system',
    messageBold: document.getElementById('messageBold').checked,
    messageItalic: document.getElementById('messageItalic').checked,
    messageUnderline: document.getElementById('messageUnderline').checked,
    messageLineHeight: Number(document.getElementById('messageLineHeight').value || 1.35),
    messageRowGap: Number(document.getElementById('messageRowGap').value || 4),
    uiTheme: document.getElementById('uiTheme').value || 'dark'
  };
}
function savePrefs(){ localStorage.setItem(PREF_KEY, JSON.stringify(collectPrefs())); }

async function loadUiDefaults(){
  try{
    const r=await fetch('/api/ui-defaults',{cache:'no-store'});
    const b=await r.json();
    if(!r.ok||!b.success)throw new Error(b.message||('HTTP '+r.status));
    serverUiDefaults=(b.defaults&&typeof b.defaults==='object')?b.defaults:{};
    serverUiDefaultsUpdatedAtMs=b.updatedAtMs||null;
    const status=document.getElementById('visitorDefaultsStatus');
    if(status)status.textContent=Object.keys(serverUiDefaults).length?tr('Padrão global carregado.'):tr('Padrão global ainda não definido; usando os padrões de fábrica.');
    return b;
  }catch(e){
    serverUiDefaults={};serverUiDefaultsUpdatedAtMs=null;
    const status=document.getElementById('visitorDefaultsStatus');if(status)status.textContent=tr('Erro')+': '+e;
    return null;
  }
}
async function saveVisitorDefaults(){
  if(!authCanWrite()){openAuthModal();return;}
  const btn=document.getElementById('saveVisitorDefaults');
  const status=document.getElementById('visitorDefaultsStatus');
  btn.disabled=true;
  try{
    const r=await authFetch('/api/ui-defaults',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prefs:collectPrefs()})});
    const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||('HTTP '+r.status));
    serverUiDefaults=b.defaults||{};serverUiDefaultsUpdatedAtMs=b.updatedAtMs||null;
    status.textContent=tr('Padrão global salvo.');
  }catch(e){status.textContent=tr('Erro')+': '+e;}
  finally{btn.disabled=!authCanWrite();}
}
function restoreAdminDefaults(){
  localStorage.removeItem(PREF_KEY);
  location.reload();
}
function setBaseMap(type,{providerIndex=0,announceFallback=true}={}){
  const cfg=baseMaps[type]||baseMaps.osm;
  const normalized=baseMaps[type]?type:'osm';
  const providers=Array.isArray(cfg.providers)&&cfg.providers.length?cfg.providers:baseMaps.osm.providers;
  const safeIndex=Math.max(0,Math.min(Number(providerIndex)||0,providers.length-1));
  const provider=providers[safeIndex];
  const settingsSelect=document.getElementById('mapType');
  const toolbarSelect=document.getElementById('mapToolbarType');
  if(settingsSelect)settingsSelect.value=normalized;
  if(toolbarSelect)toolbarSelect.value=normalized;

  const generation=++baseMapSwitchGeneration;
  if(baseLayer){try{map.removeLayer(baseLayer);}catch{}}
  baseMapTileErrors=0;
  baseMapProviderIndex=safeIndex;
  baseMapCurrentType=normalized;
  baseMapFallbackActive=safeIndex>0;

  baseLayer=L.tileLayer(provider.url,{...provider.options,crossOrigin:false}).addTo(map);
  baseLayer.on('tileload',()=>{
    if(generation!==baseMapSwitchGeneration)return;
    baseMapTileErrors=Math.max(0,baseMapTileErrors-1);
  });
  baseLayer.on('tileerror',ev=>{
    if(generation!==baseMapSwitchGeneration)return;
    baseMapTileErrors++;
    if(baseMapTileErrors===1){
      console.warn('[Traffic Analyzer] Falha ao carregar tile do mapa-base',{
        mapType:normalized,provider:provider.name,url:ev?.tile?.src||provider.url
      });
    }
    if(baseMapTileErrors<4)return;
    const nextIndex=safeIndex+1;
    if(nextIndex<providers.length){
      const nextProvider=providers[nextIndex];
      console.warn('[Traffic Analyzer] Mapa-base indisponível; ativando fallback',{
        mapType:normalized,from:provider.name,to:nextProvider.name
      });
      if(announceFallback){
        flowToast('<b>Mapa-base indisponível</b><div class="flowNote">'+esc(provider.name)+' não respondeu. Usando temporariamente '+esc(nextProvider.name)+'. Nenhuma chave de API é necessária.</div>',true);
      }
      setBaseMap(normalized,{providerIndex:nextIndex,announceFallback:false});
      return;
    }
    console.error('[Traffic Analyzer] Todos os provedores do mapa-base falharam',{
      mapType:normalized,provider:provider.name
    });
    if(announceFallback){
      flowToast('<b>Falha no mapa-base</b><div class="flowNote">Não foi possível carregar os provedores sem chave disponíveis. Nós e enlaces continuam preservados.</div>',true);
    }
  });
  baseLayer.bringToBack();
  applyBrightness();
  renderLegend();
}
function weatherRadarStatus(text,error=false){
  const el=document.getElementById('weatherRadarStatus');if(!el)return;
  el.textContent=text;el.style.color=error?'#ff9b91':'';
}
function removeWeatherRadarLayer(){
  if(weatherRadarLayer){try{map.removeLayer(weatherRadarLayer);}catch{} weatherRadarLayer=null;}
}
async function refreshWeatherRadar(){
  const enabled=document.getElementById('weatherRadarEnabled')?.checked !== false;
  if(!enabled){removeWeatherRadarLayer();weatherRadarStatus('Desligado');return;}
  weatherRadarStatus('Atualizando radar…');
  try{
    const r=await fetch('https://api.rainviewer.com/public/weather-maps.json',{cache:'no-store'});
    if(!r.ok)throw new Error('HTTP '+r.status);
    const data=await r.json();
    const frames=Array.isArray(data?.radar?.past)?data.radar.past:[];
    const frame=frames.length?frames[frames.length-1]:null;
    if(!frame?.path)throw new Error('sem quadro de radar');
    const host=String(data?.host||'https://tilecache.rainviewer.com').replace(/\/$/,'');
    const key=host+frame.path;
    if(key!==weatherRadarLastFrame||!weatherRadarLayer){
      removeWeatherRadarLayer();
      weatherRadarLayer=L.tileLayer(host+frame.path+'/256/{z}/{x}/{y}/2/1_1.png',{
        pane:'weatherRadarPane',opacity:.58,maxZoom:19,maxNativeZoom:7,
        attribution:'Radar © RainViewer'
      }).addTo(map);
      weatherRadarLastFrame=key;
    }
    weatherRadarStatus('Ligado · radar atualizado');
  }catch(e){
    removeWeatherRadarLayer();
    weatherRadarStatus('Radar indisponível: '+String(e?.message||e),true);
  }
}
function setWeatherRadarEnabled(enabled,{persist=true}={}){
  const cb=document.getElementById('weatherRadarEnabled');
  if(cb)cb.checked=Boolean(enabled);
  if(weatherRadarRefreshTimer){clearInterval(weatherRadarRefreshTimer);weatherRadarRefreshTimer=null;}
  if(enabled){
    refreshWeatherRadar();
    weatherRadarRefreshTimer=setInterval(refreshWeatherRadar,WEATHER_RADAR_REFRESH_MS);
  }else{
    removeWeatherRadarLayer();
    weatherRadarStatus('Desligado');
  }
  if(persist)savePrefs();
}
function setLayerStatus(id,text,error=false){
  const el=document.getElementById(id); if(!el)return;
  el.textContent=text; el.style.color=error?'#ff9b91':'';
}
function selectedCoverageHours(){
  const v=String(document.getElementById('ageHours')?.value||'24');
  if(v==='all')return 720;
  const n=Number(v); return Number.isFinite(n)?Math.max(1,Math.min(720,n)):24;
}
function rfCoverageStyle(snrValue,rssiValue){
  const s=Number(snrValue),r=Number(rssiValue);
  if(Number.isFinite(s)) return s>=8?'#32cd32':s>=2?'#d7d33f':s>=-5?'#ff9e2f':'#e34a33';
  if(Number.isFinite(r)) return r>=-80?'#32cd32':r>=-100?'#d7d33f':r>=-115?'#ff9e2f':'#e34a33';
  return '#7f8c8d';
}
function rfCoverageIntensity(snrValue,rssiValue){
  const s=Number(snrValue),r=Number(rssiValue);
  if(Number.isFinite(s)) return Math.max(.18,Math.min(1,(s+20)/32));
  if(Number.isFinite(r)) return Math.max(.18,Math.min(1,(r+130)/70));
  return .18;
}
async function refreshRfCoverage(){
  if(!document.getElementById('rfCoverageEnabled')?.checked){rfCoverageLayer.clearLayers();setLayerStatus('rfCoverageStatus','Desligado');return;}
  setLayerStatus('rfCoverageStatus','Carregando cobertura…');
  try{
    const r=await fetch('/api/layers/rf-coverage?hours='+encodeURIComponent(selectedCoverageHours()),{cache:'no-store'});
    const b=await r.json(); if(!r.ok||!b.success)throw new Error(b.message||('HTTP '+r.status));
    const points=(b.points||[]).filter(p=>Number.isFinite(Number(p.lat))&&Number.isFinite(Number(p.lon)));
    rfCoverageLayer.clearLayers();
    if(points.length){
      if(typeof L.heatLayer!=='function')throw new Error('Leaflet.heat indisponível');
      const heatPoints=points.map(p=>[Number(p.lat),Number(p.lon),rfCoverageIntensity(p.snr,p.rssi)]);
      const heat=L.heatLayer(heatPoints,{
        radius:28,blur:21,maxZoom:18,minOpacity:.20,
        gradient:{0.18:'#313695',0.35:'#2c7bb6',0.52:'#abd9e9',0.68:'#ffffbf',0.82:'#fdae61',1:'#d73027'}
      });
      rfCoverageLayer.addLayer(heat);
      for(const p of points){
        const hit=L.circleMarker([Number(p.lat),Number(p.lon)],{radius:9,weight:0,opacity:0,fillOpacity:0,className:'rfCoverageHit'});
        hit.bindPopup('<b>'+esc(p.name||p.nodeId||'Nó')+'</b><br>Recepção RF registrada<br>SNR: '+snr(p.snr)+'<br>RSSI: '+(p.rssi==null?'—':esc(p.rssi)+' dBm')+'<br>'+dt(p.timestampMs));
        rfCoverageLayer.addLayer(hit);
      }
    }
    if(!map.hasLayer(rfCoverageLayer))rfCoverageLayer.addTo(map);
    setLayerStatus('rfCoverageStatus',`Ligado · ${points.length} recepções RF no mapa de calor`);
  }catch(e){rfCoverageLayer.clearLayers();setLayerStatus('rfCoverageStatus','Cobertura indisponível: '+String(e?.message||e),true);}
}
function setRfCoverageEnabled(enabled,{persist=true}={}){
  const cb=document.getElementById('rfCoverageEnabled');if(cb)cb.checked=Boolean(enabled);
  if(enabled)refreshRfCoverage();else{rfCoverageLayer.clearLayers();if(map.hasLayer(rfCoverageLayer))map.removeLayer(rfCoverageLayer);setLayerStatus('rfCoverageStatus','Desligado');}
  if(persist)savePrefs();
}
function setHillshadeEnabled(enabled,{persist=true}={}){
  const cb=document.getElementById('hillshadeEnabled');if(cb)cb.checked=Boolean(enabled);
  if(enabled){
    if(!hillshadeLayer)hillshadeLayer=L.tileLayer('https://services.arcgisonline.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer/tile/{z}/{y}/{x}',{pane:'hillshadePane',opacity:.42,maxZoom:16,attribution:'Hillshade © Esri'});
    hillshadeLayer.addTo(map);setLayerStatus('hillshadeStatus','Ligado');
  }else{if(hillshadeLayer&&map.hasLayer(hillshadeLayer))map.removeLayer(hillshadeLayer);setLayerStatus('hillshadeStatus','Desligado');}
  if(persist)savePrefs();
}
function elevationMetersText(value){
  return Math.round(Number(value)||0).toLocaleString(uiLocale())+' m';
}
function elevationStatusText(){
  return 'Ligado · ≥ '+elevationMetersText(elevationThresholdMeters);
}
function renderElevationTile(canvas){
  const raw=canvas?._taElevationRaw;if(!raw)return;
  const ctx=canvas.getContext('2d'),out=ctx.createImageData(256,256),dst=out.data;
  const threshold=Number(elevationThresholdMeters)||0;
  const alpha=Math.max(0,Math.min(255,Math.round(elevationOpacity*255)));
  for(let i=0;i<raw.length;i+=4){
    const h=(raw[i]*256+raw[i+1]+raw[i+2]/256)-32768;
    if(h>=threshold){
      const rise=Math.max(0,Math.min(1,(h-threshold)/2500));
      dst[i]=Math.round(224+22*rise);
      dst[i+1]=Math.round(172-55*rise);
      dst[i+2]=Math.round(62-25*rise);
      dst[i+3]=alpha;
    }
  }
  ctx.putImageData(out,0,0);
}
function redrawElevationTiles(){
  if(elevationRedrawRaf)cancelAnimationFrame(elevationRedrawRaf);
  elevationRedrawRaf=requestAnimationFrame(()=>{
    elevationRedrawRaf=null;
    if(!elevationLayer)return;
    const tiles=elevationLayer._tiles||{};
    for(const entry of Object.values(tiles)){const canvas=entry?.el;if(canvas?._taElevationRaw)renderElevationTile(canvas);}
    setLayerStatus('elevationStatus',elevationStatusText());
  });
}
function syncElevationControls(){
  const slider=document.getElementById('elevationThresholdSlider');
  const number=document.getElementById('elevationThresholdNumber');
  const value=document.getElementById('elevationThresholdValue');
  const maxLabel=document.getElementById('elevationScaleMax');
  const maxSetting=document.getElementById('elevationSliderMax');
  const opacity=document.getElementById('elevationOpacity');
  const opacityValue=document.getElementById('elevationOpacityValue');
  if(slider){slider.max=String(Math.round(elevationSliderMaxMeters));slider.value=String(Math.round(elevationThresholdMeters));}
  if(number){number.min='100';number.max='9000';number.value=String(Math.round(elevationSliderMaxMeters));}
  if(value)value.textContent=elevationMetersText(elevationThresholdMeters);
  if(maxLabel)maxLabel.textContent=elevationMetersText(elevationSliderMaxMeters);
  if(maxSetting)maxSetting.value=String(Math.round(elevationSliderMaxMeters));
  if(opacity)opacity.value=String(Math.round(elevationOpacity*100));
  if(opacityValue)opacityValue.textContent=Math.round(elevationOpacity*100)+'%';
}
function setElevationThreshold(value,{persist=false}={}){
  const n=Number(value);if(!Number.isFinite(n))return;
  elevationThresholdMeters=Math.max(0,Math.min(elevationSliderMaxMeters,Math.round(n)));
  syncElevationControls();redrawElevationTiles();
  if(persist)savePrefs();
}
function setElevationSliderMax(value,{persist=false}={}){
  const n=Number(value);if(!Number.isFinite(n))return;
  elevationSliderMaxMeters=Math.max(100,Math.min(9000,Math.round(n)));
  if(elevationThresholdMeters>elevationSliderMaxMeters)elevationThresholdMeters=elevationSliderMaxMeters;
  syncElevationControls();redrawElevationTiles();
  if(persist)savePrefs();
}
function setElevationOpacity(value,{persist=false}={}){
  const n=Number(value);if(!Number.isFinite(n))return;
  elevationOpacity=Math.max(.10,Math.min(1,n>1?n/100:n));
  syncElevationControls();redrawElevationTiles();
  if(persist)savePrefs();
}
function decodeElevationBlob(blob){
  if(typeof createImageBitmap==='function')return createImageBitmap(blob);
  return new Promise((resolve,reject)=>{
    const url=URL.createObjectURL(blob),img=new Image();
    img.onload=()=>{URL.revokeObjectURL(url);resolve(img);};
    img.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('imagem DEM inválida'));};
    img.src=url;
  });
}
const ElevationGridLayer=L.GridLayer.extend({
  createTile(coords,done){
    const canvas=L.DomUtil.create('canvas','leaflet-tile');
    canvas.width=256;canvas.height=256;canvas.setAttribute('aria-hidden','true');
    fetch('/api/layers/elevation/tile/'+coords.z+'/'+coords.x+'/'+coords.y,{cache:'force-cache'})
      .then(r=>{if(!r.ok)throw new Error('HTTP '+r.status);return r.blob();})
      .then(blob=>decodeElevationBlob(blob))
      .then(bitmap=>{
        const ctx=canvas.getContext('2d',{willReadFrequently:true});
        ctx.clearRect(0,0,256,256);ctx.drawImage(bitmap,0,0,256,256);
        if(bitmap?.close)bitmap.close();
        const src=ctx.getImageData(0,0,256,256);
        canvas._taElevationRaw=new Uint8ClampedArray(src.data);
        renderElevationTile(canvas);done(null,canvas);
      })
      .catch(err=>{canvas._taElevationError=String(err?.message||err);done(null,canvas);});
    return canvas;
  }
});
function ensureElevationLayer(){
  if(!elevationLayer)elevationLayer=new ElevationGridLayer({
    pane:'elevationPane',tileSize:256,minZoom:0,maxZoom:19,maxNativeZoom:15,
    attribution:'Elevation © Mapzen / AWS Open Data'
  });
  return elevationLayer;
}
function initElevationControl(){
  if(elevationControl)return;
  const box=L.DomUtil.create('div','elevationThresholdControl',map.getContainer());
  box.id='elevationThresholdControl';
  box.innerHTML='<div class="elevationThresholdTitle">Corte do relevo</div><div id="elevationThresholdValue" class="elevationThresholdValue">1.000 m</div><div id="elevationScaleMax" class="elevationScaleLabel">3.000 m</div><input id="elevationThresholdSlider" class="elevationVerticalRange" type="range" min="0" max="3000" step="50" value="1000" aria-label="Altitude mínima exibida"><div class="elevationScaleLabel">0 m</div><div class="elevationControlRow"><input id="elevationThresholdNumber" class="elevationThresholdNumber" type="number" min="100" max="9000" step="100" value="3000" aria-label="Limite máximo do slider em metros"></div><div class="elevationThresholdUnit">máx. do slider (m)</div>';
  L.DomEvent.disableClickPropagation(box);L.DomEvent.disableScrollPropagation(box);
  const slider=box.querySelector('#elevationThresholdSlider'),number=box.querySelector('#elevationThresholdNumber');
  slider.addEventListener('input',()=>setElevationThreshold(slider.value));
  slider.addEventListener('change',()=>setElevationThreshold(slider.value,{persist:true}));
  number.addEventListener('input',()=>{if(number.value!=='')setElevationSliderMax(number.value);});
  number.addEventListener('change',()=>setElevationSliderMax(number.value,{persist:true}));
  elevationControl=box;
  syncElevationControls();
}
function setElevationEnabled(enabled,{persist=true}={}){
  const cb=document.getElementById('elevationEnabled');if(cb)cb.checked=Boolean(enabled);
  initElevationControl();
  document.getElementById('elevationThresholdControl')?.classList.toggle('active',Boolean(enabled));
  const opacity=document.getElementById('elevationOpacity');if(opacity)opacity.disabled=!enabled;
  if(enabled){
    const layer=ensureElevationLayer();if(!map.hasLayer(layer))layer.addTo(map);
    setLayerStatus('elevationStatus',elevationStatusText());
  }else{
    if(elevationLayer&&map.hasLayer(elevationLayer))map.removeLayer(elevationLayer);
    setLayerStatus('elevationStatus','Desligado');
  }
  if(persist)savePrefs();
}
async function refreshLightning(){
  if(!document.getElementById('lightningEnabled')?.checked){lightningLayer.clearLayers();setLayerStatus('lightningStatus','Desligado');return;}
  const bnd=map.getBounds();setLayerStatus('lightningStatus','Atualizando raios…');
  try{
    const q=new URLSearchParams({south:bnd.getSouth(),west:bnd.getWest(),north:bnd.getNorth(),east:bnd.getEast(),minutes:'60'});
    const r=await fetch('/api/layers/lightning?'+q.toString(),{cache:'no-store'});const b=await r.json();
    if(!r.ok||!b.success)throw new Error(b.message||('HTTP '+r.status));
    lightningLayer.clearLayers();
    for(const x of (b.flashes||[])){
      if(!Number.isFinite(Number(x.lat))||!Number.isFinite(Number(x.lon)))continue;
      const age=Math.max(0,Number(x.ageMinutes||0));
      const radius=age<=15?6:age<=30?5:4;
      L.circleMarker([Number(x.lat),Number(x.lon)],{radius,weight:1,color:'#ffea00',fillColor:'#ffea00',fillOpacity:age<=15?.9:.55,opacity:.9})
        .bindTooltip(`Raio · há ${Math.round(age)} min`).addTo(lightningLayer);
    }
    if(!map.hasLayer(lightningLayer))lightningLayer.addTo(map);
    setLayerStatus('lightningStatus',`Ligado · ${(b.flashes||[]).length} raios / 60 min`);
  }catch(e){lightningLayer.clearLayers();setLayerStatus('lightningStatus','Raios indisponíveis: '+String(e?.message||e),true);}
}
function setLightningEnabled(enabled,{persist=true}={}){
  const cb=document.getElementById('lightningEnabled');if(cb)cb.checked=Boolean(enabled);
  if(lightningRefreshTimer){clearInterval(lightningRefreshTimer);lightningRefreshTimer=null;}
  if(enabled){refreshLightning();lightningRefreshTimer=setInterval(refreshLightning,120000);}else{lightningLayer.clearLayers();if(map.hasLayer(lightningLayer))map.removeLayer(lightningLayer);setLayerStatus('lightningStatus','Desligado');}
  if(persist)savePrefs();
}
async function refreshWeatherAlerts(){
  if(!document.getElementById('alertsEnabled')?.checked){weatherAlertsLayer.clearLayers();setLayerStatus('alertsStatus','Desligado');return;}
  setLayerStatus('alertsStatus','Atualizando alertas…');
  try{
    const r=await fetch('/api/layers/weather-alerts',{cache:'no-store'});const b=await r.json();
    if(!r.ok||!b.success)throw new Error(b.message||('HTTP '+r.status));
    weatherAlertsLayer.clearLayers();
    const sevColor={Extreme:'#b00020',Severe:'#e85d04',Moderate:'#f6bd00',Minor:'#4d9de0'};
    for(const a of (b.alerts||[])){
      const color=sevColor[a.severity]||'#f6bd00';
      for(const poly of (a.polygons||[])){
        if(!Array.isArray(poly)||poly.length<3)continue;
        const layer=L.polygon(poly.map(p=>[Number(p[0]),Number(p[1])]),{color,weight:2,fillColor:color,fillOpacity:.18});
        layer.bindPopup('<div class="weatherAlertPopup"><b>'+esc(a.event||'Alerta meteorológico')+'</b><br>'+esc(a.severity||'')+(a.headline?'<br>'+esc(a.headline):'')+(a.expires?'<br>Até: '+esc(a.expires):'')+(a.description?'<br><br>'+esc(a.description):'')+'<br><small>Fonte: INMET</small></div>');
        weatherAlertsLayer.addLayer(layer);
      }
    }
    if(!map.hasLayer(weatherAlertsLayer))weatherAlertsLayer.addTo(map);
    setLayerStatus('alertsStatus',`Ligado · ${(b.alerts||[]).length} alertas INMET`);
  }catch(e){weatherAlertsLayer.clearLayers();setLayerStatus('alertsStatus','Alertas indisponíveis: '+String(e?.message||e),true);}
}
function setAlertsEnabled(enabled,{persist=true}={}){
  const cb=document.getElementById('alertsEnabled');if(cb)cb.checked=Boolean(enabled);
  if(alertsRefreshTimer){clearInterval(alertsRefreshTimer);alertsRefreshTimer=null;}
  if(enabled){refreshWeatherAlerts();alertsRefreshTimer=setInterval(refreshWeatherAlerts,WEATHER_LAYER_REFRESH_MS);}else{weatherAlertsLayer.clearLayers();if(map.hasLayer(weatherAlertsLayer))map.removeLayer(weatherAlertsLayer);setLayerStatus('alertsStatus','Desligado');}
  if(persist)savePrefs();
}
async function refreshClouds(){
  if(!document.getElementById('cloudsEnabled')?.checked){if(cloudsLayer&&map.hasLayer(cloudsLayer))map.removeLayer(cloudsLayer);setLayerStatus('cloudsStatus','Desligado');return;}
  setLayerStatus('cloudsStatus','Atualizando nuvens…');
  try{
    const r=await fetch('/api/layers/clouds/meta',{cache:'no-store'});const b=await r.json();
    if(!r.ok||!b.success)throw new Error(b.message||('HTTP '+r.status));
    if(cloudsLayer&&map.hasLayer(cloudsLayer))map.removeLayer(cloudsLayer);
    cloudsLayer=L.tileLayer('/api/layers/clouds/tile/'+encodeURIComponent(b.snapshot)+'/{z}/{x}/{y}',{pane:'cloudsPane',opacity:.48,minZoom:0,maxZoom:12,maxNativeZoom:7,attribution:'Clouds © Rainbow Weather'});
    cloudsLayer.addTo(map);setLayerStatus('cloudsStatus','Ligado · nuvens atuais');
  }catch(e){if(cloudsLayer&&map.hasLayer(cloudsLayer))map.removeLayer(cloudsLayer);setLayerStatus('cloudsStatus','Nuvens indisponíveis: '+String(e?.message||e),true);}
}
function setCloudsEnabled(enabled,{persist=true}={}){
  const cb=document.getElementById('cloudsEnabled');if(cb)cb.checked=Boolean(enabled);
  if(cloudsRefreshTimer){clearInterval(cloudsRefreshTimer);cloudsRefreshTimer=null;}
  if(enabled){refreshClouds();cloudsRefreshTimer=setInterval(refreshClouds,WEATHER_LAYER_REFRESH_MS);}else{if(cloudsLayer&&map.hasLayer(cloudsLayer))map.removeLayer(cloudsLayer);setLayerStatus('cloudsStatus','Desligado');}
  if(persist)savePrefs();
}
function applyBrightness(){
  const value = Math.max(30, Math.min(150, Number(document.getElementById('mapBrightness').value || 100)));
  document.getElementById('mapBrightnessValue').textContent = `${value}%`;
  const pane = map.getPane('tilePane');
  if(pane) pane.style.filter = `brightness(${value}%)`;
}
function applyTheme(){
  const value=document.getElementById('uiTheme')?.value==='light'?'light':'dark';
  document.body.dataset.theme=value;
}
const MESSAGE_FONT_STACKS={
  system:'system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif',
  arial:'Arial,Helvetica,sans-serif',
  verdana:'Verdana,Geneva,sans-serif',
  tahoma:'Tahoma,Verdana,sans-serif',
  georgia:'Georgia,Times New Roman,serif',
  mono:'ui-monospace,SFMono-Regular,Consolas,Liberation Mono,monospace'
};
function applyMessageAppearance(){
  const view=document.getElementById('viewMessages');if(!view)return;
  const size=Math.max(10,Math.min(20,Number(document.getElementById('messageFontSize')?.value||13)));
  const familyKey=document.getElementById('messageFontFamily')?.value||'system';
  const lineHeight=Math.max(1.10,Math.min(2.00,Number(document.getElementById('messageLineHeight')?.value||1.35)));
  const rowGap=Math.max(1,Math.min(14,Number(document.getElementById('messageRowGap')?.value||4)));
  view.style.setProperty('--message-font-size',`${size}px`);
  view.style.setProperty('--message-font-family',MESSAGE_FONT_STACKS[familyKey]||MESSAGE_FONT_STACKS.system);
  view.style.setProperty('--message-font-weight',document.getElementById('messageBold')?.checked?'700':'400');
  view.style.setProperty('--message-font-style',document.getElementById('messageItalic')?.checked?'italic':'normal');
  view.style.setProperty('--message-text-decoration',document.getElementById('messageUnderline')?.checked?'underline':'none');
  view.style.setProperty('--message-line-height',String(lineHeight));
  view.style.setProperty('--message-row-gap',`${rowGap}px`);
  const sizeLabel=document.getElementById('messageFontSizeValue');if(sizeLabel)sizeLabel.textContent=`${size} px`;
  const lhLabel=document.getElementById('messageLineHeightValue');if(lhLabel)lhLabel.textContent=lineHeight.toLocaleString(uiLocale(),{minimumFractionDigits:2,maximumFractionDigits:2});
  const gapLabel=document.getElementById('messageRowGapValue');if(gapLabel)gapLabel.textContent=`${rowGap} px`;
}
function applyMessageFontSize(){applyMessageAppearance();}
function initVisualPrefs(){
  const localPrefs = loadPrefs();

  // Migra somente preferências locais antigas. Navegadores novos não gravam
  // automaticamente o padrão global no localStorage, permitindo que mudanças
  // futuras do administrador cheguem a quem ainda não criou um override local.
  if(Object.keys(localPrefs).length && Number(localPrefs.defaultsVersion || 0) < 420){
    if(Number(localPrefs.defaultsVersion || 0) < 140) localPrefs.mapType = 'osm';
    const legacyColor=/^#[0-9a-fA-F]{6}$/.test(localPrefs.lineColor||'') ? localPrefs.lineColor : '#ffff00';
    const legacyWidth=Number.isFinite(Number(localPrefs.lineWidth)) ? Math.max(1,Math.min(8,Number(localPrefs.lineWidth))) : 3;
    if(!localPrefs.rfLineColor) localPrefs.rfLineColor=(String(legacyColor).toLowerCase()==='#ff0000')?'#ffff00':legacyColor;
    if(!localPrefs.rfLineWidth) localPrefs.rfLineWidth=legacyWidth;
    if(!localPrefs.mqttLineColor) localPrefs.mqttLineColor='#ff8c42';
    if(!localPrefs.mqttLineWidth) localPrefs.mqttLineWidth=3;
    delete localPrefs.lineColor; delete localPrefs.lineWidth;
    localPrefs.defaultsVersion = 420;
    localStorage.setItem(PREF_KEY, JSON.stringify(localPrefs));
  }
  const prefs = {...serverUiDefaults,...localPrefs};

  if(['all','1','6','12','24','168','720'].includes(String(prefs.ageHours))) document.getElementById('ageHours').value = String(prefs.ageHours);
  if(Number.isFinite(Number(prefs.minObs)) && Number(prefs.minObs)>=1) document.getElementById('minObs').value = String(Math.floor(Number(prefs.minObs)));
  document.getElementById('onlyIdentified').checked = Boolean(prefs.onlyIdentified);
  if(baseMaps[prefs.mapType]) document.getElementById('mapType').value = prefs.mapType;
  const toolbarMap=document.getElementById('mapToolbarType');
  if(toolbarMap)toolbarMap.value=document.getElementById('mapType').value;
  const layerDefaults={weatherRadarEnabled:true,rfCoverageEnabled:false,hillshadeEnabled:false,elevationEnabled:false,lightningEnabled:false,alertsEnabled:false,cloudsEnabled:false};
  for(const [id,def] of Object.entries(layerDefaults)){
    const el=document.getElementById(id); if(el)el.checked=(typeof prefs[id]==='boolean')?prefs[id]:def;
  }
  if(Number.isFinite(Number(prefs.brightness))) document.getElementById('mapBrightness').value = String(prefs.brightness);
  elevationSliderMaxMeters=Number.isFinite(Number(prefs.elevationSliderMax))?Math.max(100,Math.min(9000,Math.round(Number(prefs.elevationSliderMax)))):3000;
  elevationThresholdMeters=Number.isFinite(Number(prefs.elevationThreshold))?Math.max(0,Math.min(elevationSliderMaxMeters,Math.round(Number(prefs.elevationThreshold)))):1000;
  document.getElementById('elevationSliderMax').value=String(elevationSliderMaxMeters);
  elevationOpacity=Number.isFinite(Number(prefs.elevationOpacity))?Math.max(.10,Math.min(1,Number(prefs.elevationOpacity)/100)):.55;
  const rfColor=prefs.rfLineColor || prefs.lineColor;
  const rfWidth=prefs.rfLineWidth ?? prefs.lineWidth;
  if(/^#[0-9a-fA-F]{6}$/.test(rfColor || '')) document.getElementById('rfLineColor').value = rfColor;
  if(Number.isFinite(Number(rfWidth))) document.getElementById('rfLineWidth').value = String(Math.max(1,Math.min(8,Number(rfWidth))));
  if(/^#[0-9a-fA-F]{6}$/.test(prefs.mqttLineColor || '')) document.getElementById('mqttLineColor').value = prefs.mqttLineColor;
  if(Number.isFinite(Number(prefs.mqttLineWidth))) document.getElementById('mqttLineWidth').value = String(Math.max(1,Math.min(8,Number(prefs.mqttLineWidth))));
  if(typeof prefs.showShortNames === 'boolean') document.getElementById('showShortNames').checked = prefs.showShortNames;
  document.getElementById('showLines').checked = (typeof prefs.showLines === 'boolean') ? prefs.showLines : true;
  document.getElementById('showNodes').checked = (typeof prefs.showNodes === 'boolean') ? prefs.showNodes : true;
  document.getElementById('showHeatmap').checked = (typeof prefs.showHeatmap === 'boolean') ? prefs.showHeatmap : false;
  if([80,150,280,500].includes(Number(prefs.animSpeed))) document.getElementById('animSpeed').value = String(prefs.animSpeed);
  document.getElementById('soundEnabled').checked = Boolean(prefs.soundEnabled);
  if(Number.isFinite(Number(prefs.soundVolume))) document.getElementById('soundVolume').value = String(Math.max(0,Math.min(100,Number(prefs.soundVolume))));
  if(['pinball70','formal','radio','silent'].includes(prefs.soundTheme)) document.getElementById('soundTheme').value=prefs.soundTheme;
  else if(prefs.soundTone) document.getElementById('soundTheme').value='formal';
  if(['low','normal','high'].includes(prefs.soundDensity)) document.getElementById('soundDensity').value=prefs.soundDensity;
  if(Number.isFinite(Number(prefs.soundMinInterval))) document.getElementById('soundMinInterval').value=String(Math.max(40,Math.min(800,Number(prefs.soundMinInterval))));
  if(Number.isFinite(Number(prefs.soundMaxVoices))) document.getElementById('soundMaxVoices').value=String(Math.max(1,Math.min(8,Number(prefs.soundMaxVoices))));
  document.getElementById('soundRoutingEnabled').checked=(typeof prefs.soundRoutingEnabled==='boolean')?prefs.soundRoutingEnabled:true;
  document.getElementById('soundMessagesEnabled').checked=(typeof prefs.soundMessagesEnabled==='boolean')?prefs.soundMessagesEnabled:true;
  document.getElementById('soundAlertsEnabled').checked=(typeof prefs.soundAlertsEnabled==='boolean')?prefs.soundAlertsEnabled:true;
  document.getElementById('soundStereoEnabled').checked=Boolean(prefs.soundStereoEnabled);
  document.getElementById('activityAnimationEnabled').checked = (typeof prefs.activityAnimationEnabled === 'boolean') ? prefs.activityAnimationEnabled : true;
  document.getElementById('activityOriginEnabled').checked = (typeof prefs.activityOriginEnabled === 'boolean') ? prefs.activityOriginEnabled : true;
  document.getElementById('activityRelayEnabled').checked = (typeof prefs.activityRelayEnabled === 'boolean') ? prefs.activityRelayEnabled : true;
  if([650,1000,1500,2000].includes(Number(prefs.activityDuration))) document.getElementById('activityDuration').value = String(prefs.activityDuration);
  document.getElementById('autoZoomTraceroute').checked = (typeof prefs.autoZoomTraceroute === 'boolean') ? prefs.autoZoomTraceroute : false;
  document.getElementById('nodeInfoFlowEnabled').checked = (typeof prefs.nodeInfoFlowEnabled === 'boolean') ? prefs.nodeInfoFlowEnabled : true;
  document.getElementById('nodeInfoToastEnabled').checked = (typeof prefs.nodeInfoToastEnabled === 'boolean') ? prefs.nodeInfoToastEnabled : true;
  document.getElementById('nodeInfoAutoTraceEnabled').checked = (typeof prefs.nodeInfoAutoTraceEnabled === 'boolean') ? prefs.nodeInfoAutoTraceEnabled : false;
  if(Number.isFinite(Number(prefs.messageFontSize))) document.getElementById('messageFontSize').value = String(Math.max(10,Math.min(20,Number(prefs.messageFontSize))));
  if(MESSAGE_FONT_STACKS[prefs.messageFontFamily]) document.getElementById('messageFontFamily').value=prefs.messageFontFamily;
  document.getElementById('messageBold').checked=Boolean(prefs.messageBold);
  document.getElementById('messageItalic').checked=Boolean(prefs.messageItalic);
  document.getElementById('messageUnderline').checked=Boolean(prefs.messageUnderline);
  if(Number.isFinite(Number(prefs.messageLineHeight))) document.getElementById('messageLineHeight').value=String(Math.max(1.10,Math.min(2.00,Number(prefs.messageLineHeight))));
  if(Number.isFinite(Number(prefs.messageRowGap))) document.getElementById('messageRowGap').value=String(Math.max(1,Math.min(14,Number(prefs.messageRowGap))));
  document.getElementById('uiTheme').value = prefs.uiTheme === 'light' ? 'light' : 'dark';
  applyTheme();
  applyMessageAppearance();
  document.getElementById('rfLineWidthValue').textContent=`${document.getElementById('rfLineWidth').value} px`;
  document.getElementById('mqttLineWidthValue').textContent=`${document.getElementById('mqttLineWidth').value} px`;
  document.getElementById('soundVolumeValue').textContent = `${document.getElementById('soundVolume').value}%`;
  document.getElementById('soundMinIntervalValue').textContent = `${document.getElementById('soundMinInterval').value} ms`;
  setBaseMap(document.getElementById('mapType').value);
  applyBrightness();
  setWeatherRadarEnabled(document.getElementById('weatherRadarEnabled')?.checked !== false,{persist:false});
  setRfCoverageEnabled(Boolean(document.getElementById('rfCoverageEnabled')?.checked),{persist:false});
  setHillshadeEnabled(Boolean(document.getElementById('hillshadeEnabled')?.checked),{persist:false});
  initElevationControl();
  syncElevationControls();
  setElevationEnabled(Boolean(document.getElementById('elevationEnabled')?.checked),{persist:false});
  setLightningEnabled(Boolean(document.getElementById('lightningEnabled')?.checked),{persist:false});
  setAlertsEnabled(Boolean(document.getElementById('alertsEnabled')?.checked),{persist:false});
  setCloudsEnabled(Boolean(document.getElementById('cloudsEnabled')?.checked),{persist:false});
}

const esc = (x) => String(x ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dt = (ms) => ms ? new Date(ms).toLocaleString(uiLocale()) : '—';
const snr = (v) => (v === null || v === undefined) ? '—' : `${Number(v).toFixed(1)} dB`;
const HARDWARE_MODELS={
0:'UNSET',1:'TLORA_V2',2:'TLORA_V1',3:'TLORA_V2_1_1P6',4:'TBEAM',5:'HELTEC_V2_0',6:'TBEAM_V0P7',7:'T_ECHO',8:'TLORA_V1_1P3',9:'RAK4631',10:'HELTEC_V2_1',11:'HELTEC_V1',12:'LILYGO_TBEAM_S3_CORE',13:'RAK11200',14:'NANO_G1',15:'TLORA_V2_1_1P8',16:'TLORA_T3_S3',17:'NANO_G1_EXPLORER',18:'NANO_G2_ULTRA',19:'LORA_TYPE',20:'WIPHONE',21:'WIO_WM1110',22:'RAK2560',23:'HELTEC_HRU_3601',24:'HELTEC_WIRELESS_BRIDGE',25:'STATION_G1',26:'RAK11310',27:'SENSELORA_RP2040',28:'SENSELORA_S3',29:'CANARYONE',30:'RP2040_LORA',31:'STATION_G2',32:'LORA_RELAY_V1',33:'T_ECHO_PLUS',34:'PPR',35:'GENIEBLOCKS',36:'NRF52_UNKNOWN',37:'PORTDUINO',38:'ANDROID_SIM',39:'DIY_V1',40:'NRF52840_PCA10059',41:'DR_DEV',42:'M5STACK',43:'HELTEC_V3',44:'HELTEC_WSL_V3',45:'BETAFPV_2400_TX',46:'BETAFPV_900_NANO_TX',47:'RPI_PICO',48:'HELTEC_WIRELESS_TRACKER',49:'HELTEC_WIRELESS_PAPER',50:'T_DECK',51:'T_WATCH_S3',52:'PICOMPUTER_S3',53:'HELTEC_HT62',54:'EBYTE_ESP32_S3',55:'ESP32_S3_PICO',56:'CHATTER_2',57:'HELTEC_WIRELESS_PAPER_V1_0',58:'HELTEC_WIRELESS_TRACKER_V1_0',59:'UNPHONE',60:'TD_LORAC',61:'CDEBYTE_EORA_S3',62:'TWC_MESH_V4',63:'NRF52_PROMICRO_DIY',64:'RADIOMASTER_900_BANDIT_NANO',65:'HELTEC_CAPSULE_SENSOR_V3',66:'HELTEC_VISION_MASTER_T190',67:'HELTEC_VISION_MASTER_E213',68:'HELTEC_VISION_MASTER_E290',69:'HELTEC_MESH_NODE_T114',70:'SENSECAP_INDICATOR',71:'TRACKER_T1000_E',72:'RAK3172',73:'WIO_E5',74:'RADIOMASTER_900_BANDIT',75:'ME25LS01_4Y10TD',76:'RP2040_FEATHER_RFM95',77:'M5STACK_COREBASIC',78:'M5STACK_CORE2',79:'RPI_PICO2',80:'M5STACK_CORES3',81:'SEEED_XIAO_S3',82:'MS24SF1',83:'TLORA_C6',84:'WISMESH_TAP',85:'ROUTASTIC',86:'MESH_TAB',87:'MESHLINK',88:'XIAO_NRF52_KIT',89:'THINKNODE_M1',90:'THINKNODE_M2',91:'T_ETH_ELITE',92:'HELTEC_SENSOR_HUB',93:'MUZI_BASE',94:'HELTEC_MESH_POCKET',95:'SEEED_SOLAR_NODE',96:'NOMADSTAR_METEOR_PRO',97:'CROWPANEL',98:'LINK_32',99:'SEEED_WIO_TRACKER_L1',100:'SEEED_WIO_TRACKER_L1_EINK',101:'MUZI_R1_NEO',102:'T_DECK_PRO',103:'T_LORA_PAGER',104:'M5STACK_RESERVED',105:'WISMESH_TAG',106:'RAK3312',107:'THINKNODE_M5',108:'HELTEC_MESH_SOLAR',109:'T_ECHO_LITE',110:'HELTEC_V4',111:'M5STACK_C6L',112:'M5STACK_CARDPUTER_ADV',113:'HELTEC_WIRELESS_TRACKER_V2',114:'T_WATCH_ULTRA',115:'THINKNODE_M3',116:'WISMESH_TAP_V2',117:'RAK3401',118:'RAK6421',119:'THINKNODE_M4',120:'THINKNODE_M6',121:'MESHSTICK_1262',122:'TBEAM_1_WATT',123:'T5_S3_EPAPER_PRO',124:'TBEAM_BPF',125:'MINI_EPAPER_S3',126:'TDISPLAY_S3_PRO',127:'HELTEC_MESH_NODE_T096',128:'MESH_TRACKER_X1',129:'THINKNODE_M7',130:'THINKNODE_M8',131:'THINKNODE_M9',132:'HELTEC_V4_R8',133:'HELTEC_MESH_NODE_T1',134:'STATION_G3',135:'T_IMPULSE_PLUS',136:'T_ECHO_CARD',137:'SEEED_WIO_TRACKER_L2',138:'CROWPANEL_P4',139:'HELTEC_MESH_TOWER_V2',140:'MESHNOLOGY_W10',141:'HELTEC_RC32',142:'HELTEC_RC52',143:'HELTEC_RCC6',255:'PRIVATE_HW'
};
const DEVICE_ROLES={0:'Client',1:'Client (Mute)',2:'Router',3:'Router Client',4:'Repeater',5:'Tracker',6:'Sensor',7:'TAK',8:'Client (Hidden)',9:'Lost and Found',10:'TAK Tracker',11:'Router (Late)',12:'Client (Base)'};
function hardwareFriendly(v){
  if(v===null||v===undefined||v==='')return null;
  const n=Number(v),raw=HARDWARE_MODELS[n];
  if(!raw)return `Unknown (${v})`;
  const exact={UNSET:'Unset',TBEAM:'T-Beam',T_ECHO:'T-Echo',T_ECHO_PLUS:'T-Echo Plus',T_ECHO_LITE:'T-Echo Lite',T_ECHO_CARD:'T-Echo Card',T_DECK:'T-Deck',T_DECK_PRO:'T-Deck Pro',LILYGO_TBEAM_S3_CORE:'LilyGo T-Beam S3 Core',HELTEC_V2_0:'Heltec V2.0',HELTEC_V2_1:'Heltec V2.1',HELTEC_V1:'Heltec V1',HELTEC_V3:'Heltec V3',HELTEC_V4:'Heltec V4',HELTEC_V4_R8:'Heltec V4 R8',STATION_G1:'Station G1',STATION_G2:'Station G2',STATION_G3:'Station G3'};
  if(exact[raw])return exact[raw];
  return raw.split('_').map(w=>{
    if(/^RAK\d+$/i.test(w))return w.toUpperCase();
    if(/^(GPS|NRF|ESP|RP|RPI|DIY|M5STACK|WIO|TWC|TAK|HT|RC|TX|S3|C6|E5)$/i.test(w))return w.toUpperCase();
    if(/^V\d/.test(w))return w.replaceAll('P','.');
    return w.charAt(0).toUpperCase()+w.slice(1).toLowerCase();
  }).join(' ');
}
// Custom inline SVG glyphs: no external icon/font service is required.
const NODE_ROLE_META=[
 ['CLIENT','Client','<rect x="8" y="6" width="9" height="15" rx="2"/><path d="M10 6V2m1 8h3m-3 4h3m-3 4h1"/>'],
 ['CLIENT_MUTE','Client Mute','<rect x="4" y="6" width="9" height="15" rx="2"/><path d="M6 6V2m1 8h3m6 2 5 6m0-6-5 6"/>'],
 ['ROUTER','Router','<path d="m6 21 6-15 6 15M8 17h8M10 12h4M12 3v3M7 3c-3 2-3 5 0 7m10-7c3 2 3 5 0 7"/>'],
 ['ROUTER_CLIENT','Router Client','<path d="m3 20 5-13 5 13M5 16h6M8 4v3M4 4c-2 1-2 4 0 5m8-5c2 1 2 4 0 5"/><rect x="15" y="10" width="6" height="11" rx="1"/><path d="M17 10V6m0 8h2"/>'],
 ['REPEATER','Repeater','<path d="M3 8h17l-4-4m4 12H3l4 4M4 8l4-4m12 12-4 4M7 12h10"/>'],
 ['TRACKER','Tracker','<path d="M19 9c0 5-7 12-7 12S5 14 5 9a7 7 0 1 1 14 0Z"/><circle cx="12" cy="9" r="2.5"/>'],
 ['SENSOR','Sensor','<path d="M9 14V5a3 3 0 0 1 6 0v9a5 5 0 1 1-6 0Zm3-8v11m6-11h3m-3 4h2"/><circle cx="12" cy="18" r="1"/>'],
 ['TAK','TAK','<path d="m12 3 3 6 6 3-6 3-3 6-3-6-6-3 6-3Z"/><path d="M12 8v8m-4-4h8"/>'],
 ['CLIENT_HIDDEN','Client Hidden','<path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6-10-6-10-6Zm2 9L20 3"/><circle cx="12" cy="12" r="3"/>'],
 ['LOST_AND_FOUND','Lost & Found','<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6M10 6v5m0 2v1"/>'],
 ['TAK_TRACKER','TAK Tracker','<path d="M19 9c0 5-7 12-7 12S5 14 5 9a7 7 0 1 1 14 0Z"/><path d="m12 5 1 3 3 1-3 1-1 3-1-3-3-1 3-1Z"/>'],
 ['ROUTER_LATE','Router Late','<path d="m3 20 5-13 5 13M5 16h6M8 3v4M4 4c-2 1-2 4 0 5m8-5c2 1 2 4 0 5"/><circle cx="18" cy="16" r="5"/><path d="M18 13v3l2 1"/>'],
 ['CLIENT_BASE','Client Base','<path d="m2 12 10-8 10 8M5 10v11h14V10M12 4V1M9 14h6m-3-2v7"/>']
];
function nodeRoleMeta(value){
 let key=typeof value==='number'&&Number.isInteger(value)?NODE_ROLE_META[value]?.[0]:null;
 if(typeof value==='string'){
  const text=value.trim();
  key=/^\d+$/.test(text)?NODE_ROLE_META[Number(text)]?.[0]:text.toUpperCase().replace(/[\s-]+/g,'_');
 }
 return NODE_ROLE_META.find(row=>row[0]===key)||['UNKNOWN','Papel não informado','<path d="m12 2 10 10-10 10L2 12Z"/><path d="M9 8a3 3 0 0 1 6 0c0 2-3 2-3 5m0 3v1"/>'];
}
function nodeRoleSvg(role,statusColor){
 const meta=nodeRoleMeta(role);
 return '<svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" aria-hidden="true">'+
 '<circle cx="17" cy="17" r="15" fill="#142533" stroke="'+statusColor+'" stroke-width="2.5"/>'+
 '<g transform="translate(5 5)" fill="none" stroke="#f0f5f8" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">'+meta[2]+'</g></svg>';
}
function nodeRoleIcon(n){
 return L.divIcon({className:'mesh-role-marker',html:nodeRoleSvg(n.role,nodeTrafficAge(n).color),
  iconSize:[34,34],iconAnchor:[17,17],tooltipAnchor:[0,-18]});
}
function nodeRoleLegendHtml(){
 return '<details class="roleLegend"><summary>'+tr('Ícones por papel do nó')+'</summary><div class="roleLegendGrid">'+
 NODE_ROLE_META.map(([role,label])=>'<div class="roleLegendItem">'+nodeRoleSvg(role,'#8ea6b5')+'<span>'+label+'</span></div>').join('')+
 '<div class="roleLegendItem">'+nodeRoleSvg(null,'#8ea6b5')+'<span>'+tr('Papel não informado')+'</span></div></div></details>';
}

function roleFriendly(v){
  if(v===null||v===undefined||v==='')return null;
  const n=Number(v);return Number.isFinite(n)?(DEVICE_ROLES[n]||`Unknown (${v})`):String(v);
}
function nodeFmtPercent(v){
  const n=Number(v);return Number.isFinite(n)?`${n.toLocaleString(uiLocale(),{minimumFractionDigits:1,maximumFractionDigits:1})}%`:'—';
}
function telemetryDisplay(type,value,unit=''){
  if(!nodeHas(value))return 'sem valor';
  const key=String(type||'').toLowerCase(),u=String(unit||'').trim();
  if(u==='%'||/battery|channelutil|airutil|humidity/.test(key))return nodeFmtPercent(value);
  if(/voltage/.test(key)||u.toLowerCase()==='v')return `${Number(value).toLocaleString(uiLocale(),{minimumFractionDigits:2,maximumFractionDigits:2})} V`;
  if(/snr/.test(key)||u.toLowerCase()==='db')return `${Number(value).toLocaleString(uiLocale(),{minimumFractionDigits:1,maximumFractionDigits:1})} dB`;
  if(Number.isFinite(Number(value)))return `${Number(value).toLocaleString(uiLocale(),{maximumFractionDigits:3})}${u?` ${u}`:''}`;
  return `${value}${u?` ${u}`:''}`;
}

function normalizeObservedTimestampMs(value){
  const n=Number(value);
  if(!Number.isFinite(n)||n<=0)return 0;
  const ms=n<100000000000?n*1000:n;
  if(ms>Date.now()+5*60*1000)return 0;
  return ms;
}
function nodeLastTrafficMs(n){
  const archived=normalizeObservedTimestampMs(nodeTrafficLastSeen.get(Number(n.nodeNum)));
  const heard=normalizeObservedTimestampMs(n?.lastHeard);
  // lastSeenMs pertence à memória/topologia persistente e pode avançar por
  // NodeInfo, posição, status, backfill ou regeneração sem o nó transmitir.
  // Cor e "Último tráfego" representam somente tráfego real originado pelo nó.
  return Math.max(archived,heard);
}
function humanAge(ms){
  if(!ms) return 'sem registro';
  let sec=Math.max(0,Math.floor((Date.now()-Number(ms))/1000));
  if(sec<60) return sec<=1?'há poucos segundos':`há ${sec} segundos`;
  const min=Math.floor(sec/60); if(min<60) return `há ${min} ${min===1?'minuto':'minutos'}`;
  const h=Math.floor(min/60), m=min%60;
  if(h<24) return `há ${h} ${h===1?'hora':'horas'}${m?` e ${m} ${m===1?'minuto':'minutos'}`:''}`;
  const d=Math.floor(h/24), rh=h%24;
  return `há ${d} ${d===1?'dia':'dias'}${rh?` e ${rh} ${rh===1?'hora':'horas'}`:''}`;
}

function nodeTrafficAge(n){
  const ts=nodeLastTrafficMs(n);
  if(!ts) return {color:'#7f8c8d',label:'Sem tráfego registrado',className:'trafficUnknown',ts:0};
  const age=Math.max(0,Date.now()-ts);
  if(age<=2*3600*1000) return {color:'#2ecc71',label:'Tráfego nas últimas 2 h',className:'trafficFresh',ts};
  if(age<=24*3600*1000) return {color:'#f39c12',label:'Tráfego entre 2 e 24 h',className:'trafficWarm',ts};
  return {color:'#e74c3c',label:'Tráfego há mais de 24 h',className:'trafficOld',ts};
}

function cutoffForSelection(){
  const value = document.getElementById('ageHours').value;
  if(value === 'all') return null;
  const h = Number(value);
  return (topology?.generatedAtMs || Date.now()) - h * 3600 * 1000;
}

function edgeStatsForWindow(e, cutoff){
  const events = Array.isArray(e.events) ? e.events : null;
  // "Todos" usa os agregados persistentes completos. Os eventos enviados ao
  // navegador ficam limitados aos últimos 30 dias para manter o JSON leve.
  if(cutoff===null || !events){
    if(cutoff !== null && (e.lastSeenMs || 0) < cutoff) return null;
    const countOf=x=>Math.max(1,Number(x?.count||1));
    const hasRfEvidence=x=>x?.snr!==null&&x?.snr!==undefined&&Number.isFinite(Number(x.snr));
    const eventObservations=events?events.reduce((sum,x)=>sum+countOf(x),0):0;
    const observations=Number(e.observations || eventObservations || 0);
    let rf=0,nonRf=0,forward=Number(e.forwardObservations||0),back=Number(e.returnObservations||0);
    let avgSnr=e.avgSnr,minSnr=e.minSnr,maxSnr=e.maxSnr;
    if(e.historyPersistent || !events){
      const aggregateSnr=[e.avgSnr,e.minSnr,e.maxSnr].find(v=>v!==null&&v!==undefined&&Number.isFinite(Number(v)));
      const aggregateHasRf=aggregateSnr!==undefined;
      rf=e.historyPersistent?Math.max(0,Number(e.rfObservations||0)):(aggregateHasRf?Math.max(1,Number(e.rfObservations||observations||0)):0);
      nonRf=e.historyPersistent?Math.max(0,Number(e.nonRfObservations??e.mqttObservations??(observations-rf))):(aggregateHasRf?Math.max(0,observations-rf):observations);
    }else{
      rf=events.reduce((sum,x)=>sum+(hasRfEvidence(x)?countOf(x):0),0);
      nonRf=Math.max(0,observations-rf);
      forward=events.reduce((sum,x)=>sum+(x.leg==='forward'?countOf(x):0),0);
      back=events.reduce((sum,x)=>sum+(x.leg==='return'?countOf(x):0),0);
      const snrs=[];
      for(const x of events)if(hasRfEvidence(x))for(let i=0;i<countOf(x);i++)snrs.push(Number(x.snr));
      avgSnr=snrs.length?snrs.reduce((a,b)=>a+b,0)/snrs.length:null;
      minSnr=snrs.length?Math.min(...snrs):null;
      maxSnr=snrs.length?Math.max(...snrs):null;
    }
    const mqtt=nonRf;
    return {
      observations,forward,back,
      rf, mqtt, nonRf, otherNonRf:0,
      mixed:rf>0&&nonRf>0,
      displayTransport:rf>0?'rf':'mqtt',
      avgSnr,minSnr,maxSnr,
      lastSeenMs:e.lastSeenMs, latestTraceId:e.latestTraceId, latestChannel:e.latestChannel
    };
  }
  const active = events.filter(x => Number(x.timestampMs || 0) >= cutoff);
  if(!active.length) return null;
  const countOf=x=>Math.max(1,Number(x?.count||1));
  const hasRfEvidence=x=>x?.snr!==null&&x?.snr!==undefined&&Number.isFinite(Number(x.snr));
  const observations=active.reduce((sum,x)=>sum+countOf(x),0);
  const rf=active.reduce((sum,x)=>sum+(hasRfEvidence(x)?countOf(x):0),0);
  const mqtt=observations-rf;
  const nonRf=mqtt;
  const forward=active.reduce((sum,x)=>sum+(x.leg==='forward'?countOf(x):0),0);
  const back=active.reduce((sum,x)=>sum+(x.leg==='return'?countOf(x):0),0);
  let snrSum=0,snrCount=0,minSnr=null,maxSnr=null;
  for(const x of active){
    if(!hasRfEvidence(x))continue;
    const value=Number(x.snr),count=countOf(x);
    snrSum+=value*count;snrCount+=count;
    minSnr=minSnr===null?value:Math.min(minSnr,value);
    maxSnr=maxSnr===null?value:Math.max(maxSnr,value);
  }
  const latest = active.reduce((a,b) => Number(a.timestampMs||0) >= Number(b.timestampMs||0) ? a : b);
  return {
    observations,forward,back,
    rf, mqtt, nonRf, otherNonRf:0,
    mixed:rf>0&&nonRf>0,
    displayTransport:rf>0?'rf':'mqtt',
    avgSnr:snrCount?snrSum/snrCount:null,
    minSnr,maxSnr,
    lastSeenMs:Number(latest.timestampMs || e.lastSeenMs || 0),
    latestTraceId:latest.traceId ?? e.latestTraceId,
    latestChannel:e.latestChannel
  };
}

const NODE_QUERY_DEFS=[
  {id:'nodeinfo',label:'Informações do nó'},
  {id:'position',label:'Posição'},
  {id:'telemetry_power',label:'Métricas de energia'},
  {id:'traceroute',label:'Traceroute'},
  {id:'telemetry_device',label:'Métricas do dispositivo'},
  {id:'telemetry_environment',label:'Métricas ambientais'},
  {id:'telemetry_airQuality',label:'Qualidade do ar'},
  {id:'neighbors',label:'Informações de vizinhos'}
];
const nodeQueryRuns=new Map();
const NODE_QUERY_TIMEOUT_MS=20000;
const NODE_QUERY_TELEMETRY_TIMEOUT_MS=90000;
const NODE_QUERY_VIRTUAL_TIMEOUT_MS=30000;
const NODE_QUERY_LATE_WATCH_MS=180000;
const NODE_QUERY_POLL_MS=1000;
const NODE_QUERY_STAGGER_MS=2000;
function nodeQueryTimeoutMs(action,state=null){
  if(state?.diagnostic?.backend==='virtual-node')return NODE_QUERY_VIRTUAL_TIMEOUT_MS;
  return String(action||'').startsWith('telemetry_')?NODE_QUERY_TELEMETRY_TIMEOUT_MS:NODE_QUERY_TIMEOUT_MS;
}
function nodeHas(v){return v!==null&&v!==undefined&&!(typeof v==='string'&&v.trim()==='');}
function nodeHasValidMapPosition(n){
  if(!n)return false;
  const lat=Number(n.latitude),lon=Number(n.longitude);
  return nodeHas(n.latitude)&&nodeHas(n.longitude)&&Number.isFinite(lat)&&Number.isFinite(lon)&&lat>=-90&&lat<=90&&lon>=-180&&lon<=180&&!(Math.abs(lat)<0.01&&Math.abs(lon)<0.01);
}
function nodeFmtNum(v,d=1,suffix=''){const n=Number(v);return Number.isFinite(n)?`${n.toLocaleString(uiLocale(),{maximumFractionDigits:d})}${suffix}`:'—';}
function nodeFmtTs(v){
  const n=Number(v); if(!Number.isFinite(n)||n<=0)return '—';
  const ms=n<100000000000? n*1000:n;
  return new Date(ms).toLocaleString(uiLocale());
}
function nodeFmtDurationSeconds(v){
  const n=Math.max(0,Number(v)); if(!Number.isFinite(n))return '—';
  const d=Math.floor(n/86400),h=Math.floor((n%86400)/3600),m=Math.floor((n%3600)/60);
  return [d?`${d}d`:null,h?`${h}h`:null,m?`${m}min`:null].filter(Boolean).join(' ')||'< 1 min';
}
function nodeMetaLine(label,value,display=null){
  const ok=nodeHas(value);
  const text=ok?(display===null?String(value):String(display)):tr('sem informação');
  return `<div class="nodeMetaLabel">${ok?'<span class="nodeMetaPresent">✓</span>':'<span class="nodeMetaMissing">☐</span>'} ${esc(tr(label))}</div><div class="nodeMetaValue ${ok?'':'nodeMetaMissing'}">${esc(text)}</div>`;
}
function nodeBoolLine(label,value){
  if(value===null||value===undefined)return nodeMetaLine(label,null);
  return nodeMetaLine(label,value,value?tr('sim'):tr('não'));
}
function nodeQueryRun(nodeNum){
  const key=Number(nodeNum);
  if(!nodeQueryRuns.has(key)){
    const states={}; NODE_QUERY_DEFS.forEach(d=>states[d.id]={state:'idle',baseline:null,sentAt:0,receivedAt:0,message:'',acceptedMessage:'',diagnostic:null});
    nodeQueryRuns.set(key,{states,details:null,pollTimer:null});
  }
  return nodeQueryRuns.get(key);
}
function nodeQueryIsTerminal(s){return Boolean(s&&['received','timeout','error','unsupported'].includes(s.state));}
function nodeQueryProgressPct(s,action){
  if(!s||s.state==='idle')return 0;
  if(s.state==='sending')return 8;
  if(nodeQueryIsTerminal(s))return 100;
  const timeout=nodeQueryTimeoutMs(action,s);
  if(s.state==='waiting'&&s.sentAt)return Math.max(10,Math.min(96,Math.round(((Date.now()-Number(s.sentAt))/timeout)*100)));
  return 0;
}
function nodeQueryStateHtml(nodeNum){
  const run=nodeQueryRun(nodeNum);
  return NODE_QUERY_DEFS.map(d=>{
    const s=run.states[d.id]||{state:'idle'};
    let mark='☐',cls='',txt=tr('não consultado');
    if(s.state==='sending'){mark='…';cls='nodeQueryWait';txt=tr('enviando…');}
    else if(s.state==='waiting'){mark='☐';cls='nodeQueryWait';txt=s.message||tr('aguardando resposta');}
    else if(s.state==='received'){mark='✓';cls='nodeQueryOk';txt=s.message||`${tr('respondido')} ${s.receivedAt?nodeFmtTs(s.receivedAt):''}`;}
    else if(s.state==='timeout'){mark='⌛';cls='nodeQueryTimeout';txt=s.message||tr('sem resposta / timeout');}
    else if(s.state==='error'){mark='✕';cls='nodeQueryError';txt=s.message||tr('erro');}
    else if(s.state==='unsupported'){mark='—';cls='';txt=s.message||tr('não suportado / não aplicável');}
    const pct=nodeQueryProgressPct(s,d.id);
    return `<div class="nodeQueryRow ${cls}"><div class="nodeQueryMark">${mark}</div><div><b>${esc(tr(d.label))}</b></div><div class="nodeQueryState"><div>${esc(txt)}</div><div class="nodeQueryProgress" aria-hidden="true"><div class="nodeQueryProgressBar" style="width:${pct}%"></div></div></div></div>`;
  }).join('');
}
function nodeMetadataHtml(base,details){
  const n=(details&&details.node)||base||{};
  const lat=nodeHas(n.latitude)?Number(n.latitude):null,lon=nodeHas(n.longitude)?Number(n.longitude):null;
  const coords=Number.isFinite(lat)&&Number.isFinite(lon)?`${lat.toFixed(6)}, ${lon.toFixed(6)}`:null;
  return [
    nodeMetaLine('Node ID',n.nodeId),
    nodeMetaLine('Nome longo',n.longName||n.name),
    nodeMetaLine('Nome curto',n.shortName),
    nodeMetaLine('Hardware',n.hwModel,hardwareFriendly(n.hwModel)),
    nodeMetaLine('Role',n.role,roleFriendly(n.role)),
    nodeMetaLine('Firmware',n.firmwareVersion),
    nodeBoolLine('Public key',n.publicKeyAvailable!==undefined?n.publicKeyAvailable:n.publicKey),
    nodeMetaLine('Status',n.nodeStatus),
    nodeMetaLine('Coordenadas',coords),
    nodeMetaLine('Latitude',Number.isFinite(lat)?lat:null,Number.isFinite(lat)?lat.toFixed(6):null),
    nodeMetaLine('Longitude',Number.isFinite(lon)?lon:null,Number.isFinite(lon)?lon.toFixed(6):null),
    nodeMetaLine('Altitude',n.altitude,nodeHas(n.altitude)?`${n.altitude} m`:null),
    nodeMetaLine('Última posição',n.positionTimestamp,nodeFmtTs(n.positionTimestamp)),
    nodeMetaLine('Precisão da posição',n.positionPrecisionBits,nodeHas(n.positionPrecisionBits)?`${n.positionPrecisionBits} bits`:null),
    nodeMetaLine('Precisão GPS',n.positionGpsAccuracy,nodeHas(n.positionGpsAccuracy)?`${n.positionGpsAccuracy} m`:null),
    nodeMetaLine('HDOP',n.positionHdop),
    nodeMetaLine('Fonte da posição',n.positionLocationSource||n.positionSource),
    nodeMetaLine('Hops',n.hopsAway),
    nodeMetaLine('Hops da última mensagem',n.lastMessageHops),
    nodeMetaLine('SNR',n.snr,nodeHas(n.snr)?`${n.snr} dB`:null),
    nodeMetaLine('RSSI',n.rssi,nodeHas(n.rssi)?`${n.rssi} dBm`:null),
    nodeMetaLine('Canal',n.channel),
    nodeMetaLine('Último contato',n.lastHeard,nodeFmtTs(n.lastHeard)),
    nodeMetaLine('Bateria',n.batteryLevel,nodeHas(n.batteryLevel)?nodeFmtPercent(n.batteryLevel):null),
    nodeMetaLine('Tensão',n.voltage,nodeHas(n.voltage)?`${nodeFmtNum(n.voltage,2)} V`:null),
    nodeMetaLine('Utilização do canal',n.channelUtilization,nodeHas(n.channelUtilization)?nodeFmtPercent(n.channelUtilization):null),
    nodeMetaLine('Air util TX',n.airUtilTx,nodeHas(n.airUtilTx)?nodeFmtPercent(n.airUtilTx):null),
    nodeMetaLine('Uptime',n.uptimeSeconds,nodeHas(n.uptimeSeconds)?nodeFmtDurationSeconds(n.uptimeSeconds):null),
    nodeMetaLine('Reboots',n.rebootCount),
    nodeBoolLine('Store & Forward',n.isStoreForwardServer),
    nodeBoolLine('PKC disponível',n.hasPKC)
  ].join('');
}
function nodePopupHtml(n,draggable=true){
  const lat=Number(n.latitude),lon=Number(n.longitude);
  const coords=Number.isFinite(lat)&&Number.isFinite(lon)?`${lat.toFixed(6)}, ${lon.toFixed(6)}`:null;
  const trafficAge=nodeTrafficAge(n);
  const titleBlock=draggable
    ? `<div class="nodePopupDragHandle" data-node-drag="${Number(n.nodeNum)}" title="${esc(tr('Arraste para mover'))}"><span class="nodePopupDragGlyph" aria-hidden="true">⠿</span><div class="nodePopupDragText"><div class="nodePopupTitle">${esc(n.name||n.nodeId)}</div><div class="nodePopupId">${esc(n.nodeId||'')}</div></div><span class="nodePopupDragHint">${esc(tr('arraste'))}</span><div class="nodePopupHeaderActions"><button id="nodePopupExpand-${Number(n.nodeNum)}" class="nodePopupReset" type="button" onclick="event.stopPropagation();toggleNodePopupExpanded(${Number(n.nodeNum)})">⛶ ${esc(tr('Expandir'))}</button><button class="nodePopupReset" type="button" onclick="event.stopPropagation();resetNodePopupPosition(${Number(n.nodeNum)})">↺ ${esc(tr('Reposicionar'))}</button><button class="nodePopupCloseVisible" type="button" onclick="event.stopPropagation();closeNodePopupWindow(${Number(n.nodeNum)})">${esc(tr('Fechar'))}</button></div></div>`
    : `<div class="nodePopupStaticHandle"><div class="nodePopupTitle">${esc(n.name||n.nodeId)}</div><div class="nodePopupId">${esc(n.nodeId||'')}</div></div>`;
  return `<div class="nodePopup" id="nodePopup-${Number(n.nodeNum)}">
    ${titleBlock}
    <div class="nodePopupSectionTitle">${esc(tr('Resumo'))}</div>
    <div class="nodeMetaGrid">
      ${nodeMetaLine('Nome longo',n.longName)}
      ${nodeMetaLine('Nome curto',n.shortName)}
      ${nodeMetaLine('Estado',n.state)}
      ${nodeMetaLine('Coordenadas',coords)}
      ${nodeMetaLine('Altitude',n.altitude,nodeHas(n.altitude)?`${n.altitude} m`:null)}
      ${nodeMetaLine('Último tráfego',trafficAge.ts,trafficAge.ts?new Date(trafficAge.ts).toLocaleString(uiLocale()):null)}
    </div>
    <div class="nodePopupSection">
      <div class="nodePopupSectionTitle">${esc(tr('Informações do nó'))}</div>
      <div class="nodeMetaGrid" id="nodeMeta-${Number(n.nodeNum)}">${nodeMetadataHtml(n,null)}</div>
    </div>
    <div class="nodePopupSection">
      <div class="nodePopupSectionTitle">${esc(tr('Consultas ao nó'))}</div>
      <div class="nodeQueryButtons">
        <button type="button" onclick="sendNodeQuery(${Number(n.nodeNum)},'nodeinfo')">${esc(tr('Informações do nó'))}</button>
        <button type="button" onclick="sendNodeQuery(${Number(n.nodeNum)},'position')">${esc(tr('Posição'))}</button>
        <button type="button" onclick="sendNodeQuery(${Number(n.nodeNum)},'telemetry_power')">${esc(tr('Energia'))}</button>
        <button type="button" onclick="sendNodeQuery(${Number(n.nodeNum)},'traceroute')">Traceroute</button>
        <button type="button" onclick="sendNodeQuery(${Number(n.nodeNum)},'telemetry_device')">${esc(tr('Dispositivo'))}</button>
        <button type="button" onclick="sendNodeQuery(${Number(n.nodeNum)},'telemetry_environment')">${esc(tr('Ambiente'))}</button>
        <button type="button" onclick="sendNodeQuery(${Number(n.nodeNum)},'telemetry_airQuality')">${esc(tr('Qualidade do ar'))}</button>
        <button type="button" onclick="sendNodeQuery(${Number(n.nodeNum)},'neighbors')">${esc(tr('Vizinhos'))}</button>
        <button id="nodeAllBtn-${Number(n.nodeNum)}" type="button" class="primary" onclick="runAllNodeQueries(${Number(n.nodeNum)})">${esc(tr('Tudo'))}</button>
      </div>
      <div class="nodeQueryList" id="nodeQueries-${Number(n.nodeNum)}">${nodeQueryStateHtml(n.nodeNum)}</div>
      <div class="nodePopupActionsNote">${esc(tr('As consultas ativas usam o Virtual Node do MeshMonitor quando disponível. As respostas confirmadas atualizam este popup.'))}</div>
    </div>
    <div class="nodePopupSection">
      <div class="nodePopupSectionTitle">${esc(tr('Últimos metadados recebidos'))}</div>
      <div id="nodeTelemetry-${Number(n.nodeNum)}" class="nodeTelemetryRows"><span class="nodeSmall">Carregando dados do MeshMonitor…</span></div>
    </div>
  </div>`;
}
function telemetryFriendlyLabel(type){
  const key=String(type||'telemetria');
  const pt={
    messageHops:'Saltos da mensagem',snr_remote:'SNR remoto',batteryLevel:'Bateria',voltage:'Tensão',
    channelUtilization:'Utilização do canal',airUtilTx:'Air Util TX',uptimeSeconds:'Tempo ligado',
    temperature:'Temperatura',humidity:'Umidade',pressure:'Pressão',gasResistance:'Resistência do gás',
    current:'Corrente',power:'Potência',energy:'Energia',co2:'CO₂',pm25:'PM2,5',pm10:'PM10',
    latitude:'Latitude',longitude:'Longitude',altitude:'Altitude',linkQuality:'Qualidade do enlace'
  };
  const en={
    messageHops:'Message hops',snr_remote:'Remote SNR',batteryLevel:'Battery',voltage:'Voltage',
    channelUtilization:'Channel utilization',airUtilTx:'Air Util TX',uptimeSeconds:'Uptime',
    temperature:'Temperature',humidity:'Humidity',pressure:'Pressure',gasResistance:'Gas resistance',
    current:'Current',power:'Power',energy:'Energy',co2:'CO₂',pm25:'PM2.5',pm10:'PM10',
    latitude:'Latitude',longitude:'Longitude',altitude:'Altitude',linkQuality:'Link quality'
  };
  return (currentLang==='en'?en:pt)[key]||key;
}
function nodeTelemetryHtml(details){
  if(!details)return '<span class="nodeSmall">Sem dados carregados.</span>';
  const rows=(details.telemetry&&details.telemetry.latest)||[];
  const trace=details.traceroute;
  const neighbors=details.neighbors||{};
  let html='';
  if(rows.length){
    html+=rows.slice(0,18).map(r=>`<div>${nodeHas(r.value)?'<span class="nodeMetaPresent">✓</span>':'<span class="nodeMetaMissing">☐</span>'} <b>${esc(telemetryFriendlyLabel(r.telemetryType))}</b>: ${esc(telemetryDisplay(r.telemetryType,r.value,r.unit))} <span class="nodeSmall">· ${esc(nodeFmtTs(r.timestamp||r.createdAt))}</span></div>`).join('');
  }else html+='<div><span class="nodeMetaMissing">☐</span> Telemetria — sem registros</div>';
  if(trace)html+=`<div><span class="nodeMetaPresent">✓</span> <b>Último traceroute</b>: ${esc(trace.fromNodeId||'')} → ${esc(trace.toNodeId||'')} <span class="nodeSmall">· ${esc(nodeFmtTs(trace.timestamp||trace.createdAt))}</span></div>`;
  else html+='<div><span class="nodeMetaMissing">☐</span> Traceroute — sem registro envolvendo o nó</div>';
  if(neighbors.available===false)html+=`<div><span class="nodeMetaNA">—</span> Neighbor Info — ${esc(neighbors.error||'consulta histórica indisponível')}</div>`;
  else if((neighbors.data||[]).length)html+=`<div><span class="nodeMetaPresent">✓</span> <b>Neighbor Info</b>: ${neighbors.data.length} registro(s), último ${esc(nodeFmtTs(neighbors.latestTimestamp))}</div>`;
  else html+='<div><span class="nodeMetaMissing">☐</span> Neighbor Info — sem registro</div>';
  return html;
}
function renderNodePopupData(nodeNum,details){
  const run=nodeQueryRun(nodeNum); if(details)run.details=details;
  const base=(topology?.nodes||[]).find(x=>Number(x.nodeNum)===Number(nodeNum))||{};
  const meta=document.getElementById(`nodeMeta-${Number(nodeNum)}`);
  if(meta)meta.innerHTML=nodeMetadataHtml(base,run.details);
  const tel=document.getElementById(`nodeTelemetry-${Number(nodeNum)}`);
  if(tel)tel.innerHTML=nodeTelemetryHtml(run.details);
  const q=document.getElementById(`nodeQueries-${Number(nodeNum)}`);
  if(q)q.innerHTML=nodeQueryStateHtml(nodeNum);
  const allBtn=document.getElementById(`nodeAllBtn-${Number(nodeNum)}`);
  if(allBtn){
    const order=run.allOrder||NODE_QUERY_DEFS.map(d=>d.id);
    run.allDone=order.filter(id=>nodeQueryIsTerminal(run.states[id])).length;
    run.allTotal=order.length;
    allBtn.disabled=Boolean(run.allActive);
    allBtn.textContent=run.allActive?`${tr('Tudo')} ${Number(run.allDone||0)}/${Number(run.allTotal||0)}`:tr('Tudo');
  }
}
function telemetrySignal(details,kind){
  const rows=((details||{}).telemetry||{}).latest||[]; let max=0;
  for(const r of rows){
    if(r.kind!==kind)continue;
    let t=Number(r.timestamp||r.createdAt||0);
    if(t>0&&t<10000000000)t*=1000;
    if(t>max)max=t;
  }
  return max||null;
}
function latestResponsePacket(details,port){
  let best=null,bestTs=0;
  for(const p of (details?.responses||[])){
    if(String(p.port||'')!==port)continue;
    const t=Number(p.timestampMs||0);
    if(Number.isFinite(t)&&t>bestTs){best=p;bestTs=t;}
  }
  return best;
}
function latestResponsePacketMs(details,port){
  return Number(latestResponsePacket(details,port)?.timestampMs||0)||null;
}
function nodeResponsePort(action){
  if(action==='nodeinfo')return 'NODEINFO_APP';
  if(action==='position')return 'POSITION_APP';
  if(action==='neighbors')return 'NEIGHBORINFO_APP';
  if(String(action||'').startsWith('telemetry_'))return 'TELEMETRY_APP';
  return null;
}
function correlatedResponsePacket(action,details,state){
  const packetId=Number(state?.diagnostic?.correlationPacketId||state?.diagnostic?.packetId||0);
  const port=nodeResponsePort(action);
  if(!packetId||!port)return null;
  let best=null,bestTs=0;
  for(const p of (details?.responses||[])){
    if(String(p.port||'')!==port)continue;
    if(Number(p.requestId||0)!==packetId)continue;
    const ts=Number(p.timestampMs||0);
    if(state?.sentAt&&ts<Number(state.sentAt)-1000)continue;
    if(ts>bestTs){best=p;bestTs=ts;}
  }
  return best;
}
function nodeResponseDetail(action,details,signalMs,state=null){
  const port=nodeResponsePort(action);
  const p=state?.diagnostic?.backend==='virtual-node'
    ? correlatedResponsePacket(action,details,state)
    : (port?latestResponsePacket(details,port):null);
  if(!p)return '';
  const pts=Number(p.timestampMs||0),sig=Number(signalMs||0);
  if(sig&&pts&&Math.abs(pts-sig)>5000)return '';
  const bits=[String(p.port||port)];
  const ch=Number(p.channel);
  if(Number.isInteger(ch)&&ch>=0&&ch<=7)bits.push('canal '+ch);
  const sn=Number(p.snr);
  if(Number.isFinite(sn))bits.push('SNR '+sn.toLocaleString(uiLocale(),{minimumFractionDigits:1,maximumFractionDigits:1})+' dB');
  const rs=Number(p.rssi);
  if(Number.isFinite(rs))bits.push('RSSI '+Math.round(rs)+' dBm');
  return bits.join(' · ');
}
function nodeRequestPackets(action,details,sentAt=0){
  let port=null,telemetryType=null;
  if(action==='nodeinfo')port='NODEINFO_APP';
  else if(action==='position')port='POSITION_APP';
  else if(action==='neighbors')port='NEIGHBORINFO_APP';
  else if(action.startsWith('telemetry_')){port='TELEMETRY_APP';telemetryType=action.split('_',2)[1];}
  if(!port)return [];
  return (details?.requests||[]).filter(p=>{
    if(String(p.port||'')!==port)return false;
    const ts=Number(p.timestampMs||0);
    if(sentAt&&ts<Number(sentAt)-1000)return false;
    if(telemetryType&&String(p.telemetryType||'device')!==telemetryType)return false;
    return true;
  }).sort((a,b)=>Number(a.timestampMs||0)-Number(b.timestampMs||0));
}
function nodeRoutingEvidence(action,s,details){
  const txIds=new Set(nodeRequestPackets(action,details,s?.sentAt||0).map(p=>Number(p.packetId||0)).filter(Boolean));
  if(s?.diagnostic?.packetId)txIds.add(Number(s.diagnostic.packetId));
  if(!txIds.size)return null;
  for(const p of (details?.responses||[])){
    if(String(p.port||'')!=='ROUTING_APP')continue;
    const ts=Number(p.timestampMs||0);
    if(ts<Number(s?.sentAt||0)-1000)continue;
    const rid=Number(p.requestId||0);
    if(!rid||!txIds.has(rid))continue;
    return p;
  }
  return null;
}
function routingErrorCode(value){
  const numeric=Number(value);
  if(Number.isFinite(numeric))return numeric;
  const map={NONE:0,ACK:0,NO_ROUTE:1,GOT_NAK:2,TIMEOUT:3,NO_INTERFACE:4,MAX_RETRANSMIT:5,NO_CHANNEL:6,TOO_LARGE:7,NO_RESPONSE:8,DUTY_CYCLE_LIMIT:9,BAD_REQUEST:32,NOT_AUTHORIZED:33,PKI_FAILED:34,PKI_UNKNOWN_PUBKEY:35,ADMIN_BAD_SESSION_KEY:36,ADMIN_PUBLIC_KEY_UNAUTHORIZED:37,RATE_LIMIT_EXCEEDED:38,PKI_SEND_FAIL_PUBLIC_KEY:39};
  const key=String(value||'').trim().toUpperCase();
  return Object.prototype.hasOwnProperty.call(map,key)?map[key]:null;
}
function routingErrorName(code){
  const names={0:'ACK',1:'NO_ROUTE',2:'GOT_NAK',3:'TIMEOUT',4:'NO_INTERFACE',5:'MAX_RETRANSMIT',6:'NO_CHANNEL',7:'TOO_LARGE',8:'NO_RESPONSE',9:'DUTY_CYCLE_LIMIT',32:'BAD_REQUEST',33:'NOT_AUTHORIZED',34:'PKI_FAILED',35:'PKI_UNKNOWN_PUBKEY',36:'ADMIN_BAD_SESSION_KEY',37:'ADMIN_PUBLIC_KEY_UNAUTHORIZED',38:'RATE_LIMIT_EXCEEDED',39:'PKI_SEND_FAIL_PUBLIC_KEY'};
  const n=routingErrorCode(code);return n===null?String(code||'ROUTING'):(names[n]||('ROUTING_'+n));
}
function nodeRoutingResultMessage(code){
  const n=routingErrorCode(code),name=routingErrorName(code);
  if(n===8)return `${tr('destino respondeu')}: NO_RESPONSE · ${tr('o nó recebeu a solicitação, mas não forneceu esse dado')}`;
  if(n===1)return `${tr('destino respondeu')}: NO_ROUTE · ${tr('não foi encontrada rota até o nó')}`;
  if(n===6)return `${tr('destino respondeu')}: NO_CHANNEL · ${tr('canal não disponível para a solicitação')}`;
  if(n===33)return `${tr('destino respondeu')}: NOT_AUTHORIZED · ${tr('solicitação não autorizada nesse canal')}`;
  return `${tr('destino respondeu')}: ${name}`;
}
function nodeQueryWaitingMessage(action,s,details,now=Date.now()){
  const base=s?.acceptedMessage||tr('aguardando resposta');
  if(s?.diagnostic?.backend==='virtual-node')return base;
  const tx=nodeRequestPackets(action,details,s?.sentAt||0);
  const latestTx=tx.length?tx[tx.length-1]:null;
  const packetInfo=latestTx?.packetId&&!/packet\s+\d+/i.test(base)?` · TX packet ${latestTx.packetId}`:'';
  if(!String(action||'').startsWith('telemetry_'))return base+packetInfo;
  const elapsed=Math.max(0,Number(now)-Number(s?.sentAt||now));
  const n=tx.length;
  const txInfo=n?` · ${n} ${tr(n===1?'TX observado':'TX observados')}`:'';
  if(elapsed<20000)return base+txInfo;
  if(elapsed<45000){
    return n>=2?`${tr('retry 1 do MM observado')}${txInfo} · ${tr('aguardando resposta')}`:`${tr('sem resposta inicial')} · ${tr('aguardando possível retry do MM')}${txInfo}`;
  }
  if(elapsed<75000){
    return n>=2?`${tr('retry 1 do MM observado')}${txInfo} · ${tr('aguardando segunda tentativa do MM')}`:`${tr('sem retry observado')} · ${tr('aguardando resposta')} (${tr('janela do MM')})`;
  }
  return n>=3?`${tr('retry 2 do MM observado')}${txInfo} · ${tr('aguardando resposta')}`:n>=2?`${tr('retry 1 do MM observado')}${txInfo} · ${tr('aguardando resposta')}`:`${tr('sem retry observado')} · ${tr('aguardando resposta')} (${tr('janela do MM')})`;
}
function nodeQueryTimeoutMessage(action,s,details){
  const route=nodeRoutingEvidence(action,s,details);
  let routing='';
  if(route)routing=` · ${routingErrorName(route.routingErrorReason)}`;
  if(s?.diagnostic?.backend==='virtual-node'){
    return `${tr('sem resposta correlacionada')} em ${Math.round(nodeQueryTimeoutMs(action,s)/1000)} s${routing}`;
  }
  if(String(action||'').startsWith('telemetry_')){
    const tx=nodeRequestPackets(action,details,s?.sentAt||0);
    const n=tx.length;
    const txInfo=n?` · ${n} ${tr(n===1?'TX observado':'TX observados')}`:'';
    return `${tr('sem resposta após 90 s')}${txInfo}${routing}`;
  }
  const tx=nodeRequestPackets(action,details,s?.sentAt||0);const last=tx.length?tx[tx.length-1]:null;
  const packet=last?.packetId?` · TX packet ${last.packetId}`:'';
  return `${s?.acceptedMessage||'MM aceitou'}${packet} · sem RX em ${Math.round(nodeQueryTimeoutMs(action,s)/1000)} s${routing}`;
}
function nodeQueryNeedsPolling(action,s,now=Date.now()){
  if(!s)return false;
  if(['waiting','sending'].includes(s.state))return true;
  return s.state==='timeout'&&s.sentAt&&Number(now)-Number(s.sentAt)<NODE_QUERY_LATE_WATCH_MS;
}

function nodeResponseSignal(action,details,state=null){
  if(!details)return null;
  if(state?.diagnostic?.backend==='virtual-node'&&action!=='traceroute'){
    return Number(correlatedResponsePacket(action,details,state)?.timestampMs||0)||null;
  }
  const n=details.node||{};
  if(action==='nodeinfo')return latestResponsePacketMs(details,'NODEINFO_APP');
  if(action==='position'){
    let pos=Number(n.positionTimestamp||0);
    if(pos>0&&pos<10000000000)pos*=1000;
    return Math.max(Number(latestResponsePacketMs(details,'POSITION_APP')||0),Number(pos||0))||null;
  }
  if(action==='telemetry_device')return telemetrySignal(details,'device');
  if(action==='telemetry_environment')return telemetrySignal(details,'environment');
  if(action==='telemetry_airQuality')return telemetrySignal(details,'airQuality');
  if(action==='telemetry_power')return telemetrySignal(details,'power');
  if(action==='neighbors')return latestResponsePacketMs(details,'NEIGHBORINFO_APP')||Number(details.neighbors?.latestTimestamp||0)||null;
  if(action==='traceroute'){
    const tr=details.traceroute;
    if(!tr)return null;
    let t=Number(tr.timestamp||tr.createdAt||0);
    if(t>0&&t<10000000000)t*=1000;
    return t||null;
  }
  return null;
}
function virtualQueryDetail(status){
  const bits=[];
  if(status?.responsePort)bits.push(String(status.responsePort));
  const ch=Number(status?.channel);
  if(Number.isInteger(ch)&&ch>=0&&ch<=7)bits.push('canal '+ch);
  const sn=Number(status?.rxSnr);
  if(Number.isFinite(sn))bits.push('SNR '+sn.toLocaleString(uiLocale(),{minimumFractionDigits:1,maximumFractionDigits:1})+' dB');
  const rs=Number(status?.rxRssi);
  if(Number.isFinite(rs))bits.push('RSSI '+Math.round(rs)+' dBm');
  return bits.join(' · ');
}
async function refreshVirtualQueryState(action,s){
  const queryId=String(s?.diagnostic?.queryId||'');
  if(!queryId)return false;
  try{
    const r=await fetch(`/api/node-query-status?queryId=${encodeURIComponent(queryId)}&_=${Date.now()}`,{cache:'no-store'});
    const b=await r.json();
    if(r.status===401)return false;
    if(!r.ok){s.state='error';s.message=b.message||b.error||`HTTP ${r.status}`;return true;}
    if(b.packetId){
      const pid=Number(b.packetId);
      if(Number.isFinite(pid)&&pid>0){s.diagnostic.packetId=pid;s.diagnostic.correlationPacketId=pid;}
    }
    if(b.sentAtMs){
      const sent=Number(b.sentAtMs);
      if(Number.isFinite(sent)&&sent>0)s.sentAt=sent;
    }
    const state=String(b.state||'');
    if(state==='queued'){
      s.message=tr('aguardando vez no Virtual Node');
      return true;
    }
    if(state==='connecting'){
      s.message=tr('conectando ao Virtual Node');
      return true;
    }
    if(state==='waiting'){
      const pid=Number(b.packetId||s.diagnostic?.packetId||0);
      s.message=`Virtual Node enviou${pid?' · packet '+pid:''} · ${tr('aguardando resposta correlacionada')}`;
      return true;
    }
    if(state==='received'){
      const received=Number(b.receivedAtMs||Date.now());
      const latency=Math.max(0,(received-Number(s.sentAt||received))/1000);
      const detail=virtualQueryDetail(b);
      s.state='received';s.receivedAt=received;
      s.message=`${tr('respondido')} em ${latency.toLocaleString(uiLocale(),{minimumFractionDigits:1,maximumFractionDigits:1})} s · ${new Date(received).toLocaleTimeString(uiLocale())}${detail?' · '+detail:''}`;
      return true;
    }
    if(state==='routing_error'){
      s.state='error';
      s.message=nodeRoutingResultMessage(b.routingErrorReason??b.error);
      return true;
    }
    if(state==='timeout'){
      s.state='timeout';
      s.message=b.error||`${tr('sem resposta correlacionada')} em ${Number(s.diagnostic?.queryTimeout||30)} s`;
      return true;
    }
    if(state==='error'||state==='not_found'){
      s.state='error';s.message=b.error||b.message||tr('erro');
      return true;
    }
    return true;
  }catch(e){
    s.message=`${tr('aguardando resposta correlacionada')} · status: ${String(e.message||e)}`;
    return true;
  }
}

async function loadNodeDetails(nodeNum,checkResponses=true){
  const r=await fetch(`/api/node-details?nodeNum=${encodeURIComponent(Number(nodeNum))}&_=${Date.now()}`,{cache:'no-store'});
  const b=await r.json();
  if(!r.ok||!b.success)throw new Error(b.message||b.error||`HTTP ${r.status}`);
  const run=nodeQueryRun(nodeNum);run.details=b;
  if(checkResponses){
    const now=Date.now();
    for(const d of NODE_QUERY_DEFS){
      const s=run.states[d.id];if(!s||!['waiting','timeout'].includes(s.state)||!s.sentAt)continue;
      if(s.diagnostic?.backend==='virtual-node'&&s.diagnostic?.queryId){
        await refreshVirtualQueryState(d.id,s);
        continue;
      }
      const current=Number(nodeResponseSignal(d.id,b,s)||0);
      const responded=Number.isFinite(current)&&current>=Math.max(0,Number(s.sentAt||0)-1000);
      if(responded){
        const latency=Math.max(0,(Number(current||now)-Number(s.sentAt||now))/1000);
        const detail=nodeResponseDetail(d.id,b,current,s);
        const wasTimeout=s.state==='timeout';
        s.state='received';s.receivedAt=current||now;s.message=`${tr('respondido')} em ${latency.toLocaleString(uiLocale(),{minimumFractionDigits:1,maximumFractionDigits:1})} s · ${new Date(current||now).toLocaleTimeString(uiLocale())}${wasTimeout?' · '+tr('resposta tardia'):''}${detail?' · '+detail:''}`;
      }else if(s.state==='waiting'){
        const route=nodeRoutingEvidence(d.id,s,b);
        const routeCode=route?Number(route.routingErrorReason):null;
        if(route&&Number.isFinite(routeCode)&&routeCode!==0){
          s.state='error';
          s.message=nodeRoutingResultMessage(routeCode);
        }else{
          const timeout=nodeQueryTimeoutMs(d.id,s);
          if(now-s.sentAt>=timeout){
            s.state='timeout';
            s.message=nodeQueryTimeoutMessage(d.id,s,b);
          }else{
            s.message=nodeQueryWaitingMessage(d.id,s,b,now);
          }
        }
      }
    }
  }
  renderNodePopupData(nodeNum,b);
  const shouldPoll=NODE_QUERY_DEFS.some(d=>nodeQueryNeedsPolling(d.id,run.states[d.id]));
  if(shouldPoll&&!run.allActive)scheduleNodePolling(nodeNum);else if(!shouldPoll)stopNodePolling(nodeNum);
  return b;
}
function stopNodePolling(nodeNum){const run=nodeQueryRun(nodeNum);if(run.pollTimer){clearTimeout(run.pollTimer);run.pollTimer=null;}}
function scheduleNodePolling(nodeNum){
  const run=nodeQueryRun(nodeNum);if(run.pollTimer)return;
  run.pollTimer=setTimeout(async()=>{run.pollTimer=null;try{await loadNodeDetails(nodeNum,true);}catch(e){console.warn('Falha ao acompanhar respostas do nó:',e);if(NODE_QUERY_DEFS.some(d=>nodeQueryNeedsPolling(d.id,run.states[d.id])))scheduleNodePolling(nodeNum);}},NODE_QUERY_POLL_MS);
}
async function sendNodeQuery(nodeNum,action,fromAll=false){
  const def=NODE_QUERY_DEFS.find(x=>x.id===action);if(!def)return;
  if(!authCanWrite()){openAuthModal();return;}
  const run=nodeQueryRun(nodeNum);
  try{
    if(!run.details)await loadNodeDetails(nodeNum,false);
    const s=run.states[action];
    s.baseline=nodeResponseSignal(action,run.details,s);s.state='sending';s.sentAt=Date.now();s.receivedAt=0;s.acceptedMessage='';s.diagnostic=null;s.message='enviando…';
    renderNodePopupData(nodeNum,run.details);
    const r=await authFetch('/api/node-query',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nodeNum:Number(nodeNum),action})});
    const b=await r.json();
    if(!r.ok||!b.success){
      const message=b.message||b.error||`HTTP ${r.status}`,lower=String(message).toLowerCase();
      s.state=(r.status===403||r.status===429||lower.includes('direct')||lower.includes('not allowed')||lower.includes('rate'))?'unsupported':'error';s.message=message;
    }else{
      s.state='waiting';
      s.sentAt=Number(b.requestedAtMs||Date.now());
      s.acceptedMessage=String(b.acceptedMessage||'').trim();
      s.diagnostic=b.diagnostic||null;
      s.message=nodeQueryWaitingMessage(action,s,run.details,Date.now());
      if(!fromAll)scheduleNodePolling(nodeNum);
    }
  }catch(e){const s=run.states[action];s.state='error';s.message=String(e.message||e);}
  renderNodePopupData(nodeNum,run.details);
  if(!fromAll)scheduleNodePolling(nodeNum);
}
async function waitNodeQueryTerminal(nodeNum,action){
  const run=nodeQueryRun(nodeNum);
  const deadline=Date.now()+nodeQueryTimeoutMs(action,run.states[action])+2500;
  while(Date.now()<deadline){
    const s=run.states[action];
    if(!s||!['waiting','sending'].includes(s.state))return s;
    try{await loadNodeDetails(nodeNum,true);}catch(e){console.warn('Falha ao acompanhar consulta sequencial:',e);}
    const latest=run.states[action];
    if(!latest||!['waiting','sending'].includes(latest.state))return latest;
    await new Promise(resolve=>setTimeout(resolve,NODE_QUERY_POLL_MS));
  }
  const s=run.states[action];
  if(s&&['waiting','sending'].includes(s.state)){s.state='timeout';s.message=nodeQueryTimeoutMessage(action,s,run.details);renderNodePopupData(nodeNum,run.details);}
  return s;
}
async function runAllNodeQueries(nodeNum){
  if(!authCanWrite()){openAuthModal();return;}
  const run=nodeQueryRun(nodeNum);
  if(run.allActive)return;
  run.allActive=true;run.allDone=0;
  NODE_QUERY_DEFS.forEach(d=>{run.states[d.id]={state:'idle',baseline:null,sentAt:0,receivedAt:0,message:'',acceptedMessage:'',diagnostic:null};});
  try{
    if(!run.details)await loadNodeDetails(nodeNum,false);
    const hops=Number(run.details?.node?.hopsAway);
    if(Number.isFinite(hops)&&hops>0){
      const ns=run.states.neighbors;ns.state='unsupported';ns.message=tr('somente nó local ou 0-hop');
    }
    const order=['traceroute','telemetry_device','position','telemetry_power','telemetry_environment','telemetry_airQuality','neighbors','nodeinfo'];
    run.allOrder=order;
    run.allTotal=order.length;
    renderNodePopupData(nodeNum,run.details);
    const actions=order.filter(action=>run.states[action]?.state!=='unsupported');
    // "Tudo" dispara a rodada inteira sem aguardar resposta/timeout de uma
    // consulta antes de iniciar as demais. Cada sendNodeQuery mantém estado,
    // correlação e timeout próprios; o polling abaixo apenas acompanha respostas.
    await Promise.allSettled(actions.map(action=>sendNodeQuery(nodeNum,action,true)));
    renderNodePopupData(nodeNum,run.details);
    while(order.some(id=>['waiting','sending'].includes(run.states[id]?.state))){
      await new Promise(resolve=>setTimeout(resolve,NODE_QUERY_POLL_MS));
      try{await loadNodeDetails(nodeNum,true);}catch(e){console.warn('Falha ao acompanhar rodada de consultas:',e);}
      renderNodePopupData(nodeNum,run.details);
    }
  }finally{
    run.allActive=false;
    renderNodePopupData(nodeNum,run.details);
    if(NODE_QUERY_DEFS.some(d=>nodeQueryNeedsPolling(d.id,run.states[d.id])))scheduleNodePolling(nodeNum);
  }
}

function nodeWindowBounds(){
  const view=document.getElementById('viewMap');
  const mapEl=document.getElementById('map');
  if(!view||!mapEl)return {left:8,top:8,width:800,height:500};
  const vr=view.getBoundingClientRect(),mr=mapEl.getBoundingClientRect();
  return {left:mr.left-vr.left+8,top:mr.top-vr.top+8,width:Math.max(240,mr.width-16),height:Math.max(180,mr.height-16)};
}
function nodeWindowDefaultGeometry(){
  const b=nodeWindowBounds();
  const w=Math.min(b.width,Math.max(Math.min(900,b.width),Math.round(b.width*.72)));
  const h=Math.min(b.height,Math.max(Math.min(480,b.height),Math.round(b.height*.72)));
  return {left:b.left+Math.max(0,Math.round((b.width-w)/2)),top:b.top+Math.max(0,Math.round((b.height-h)/2)),width:w,height:h};
}
function clampNodeWindowGeometry(g){
  const b=nodeWindowBounds();
  const minW=Math.min(360,b.width),minH=Math.min(240,b.height);
  const width=Math.max(minW,Math.min(Number(g.width)||minW,b.width));
  const height=Math.max(minH,Math.min(Number(g.height)||minH,b.height));
  const left=Math.max(b.left,Math.min(Number(g.left)||b.left,b.left+b.width-width));
  const top=Math.max(b.top,Math.min(Number(g.top)||b.top,b.top+b.height-height));
  return {left,top,width,height};
}
function applyNodeWindowGeometry(){
  const el=document.getElementById('nodeWindow');if(!el)return;
  const btn=document.getElementById('nodeWindowExpand');
  if(nodeWindowState.maximized){
    if(el.parentElement!==document.body)document.body.appendChild(el);
    el.classList.add('maximized');
    if(btn)btn.textContent='↙ '+tr('Restaurar');
    return;
  }
  const mapView=document.getElementById('viewMap');
  if(mapView&&el.parentElement!==mapView)mapView.appendChild(el);
  el.classList.remove('maximized');
  if(nodeWindowState.left==null){
    const d=nodeWindowDefaultGeometry();
    Object.assign(nodeWindowState,d);
  }
  const g=clampNodeWindowGeometry(nodeWindowState);
  Object.assign(nodeWindowState,g);
  Object.assign(el.style,{left:g.left+'px',top:g.top+'px',width:g.width+'px',height:g.height+'px'});
  if(btn)btn.textContent='⛶ '+tr('Expandir');
}
function resetNodeWindowGeometry(){
  nodeWindowState.maximized=false;nodeWindowState.restore=null;
  Object.assign(nodeWindowState,nodeWindowDefaultGeometry());
  applyNodeWindowGeometry();
}
function toggleNodeWindowExpanded(){
  const el=document.getElementById('nodeWindow');if(!el?.classList.contains('open'))return;
  if(!nodeWindowState.maximized){
    nodeWindowState.restore={left:nodeWindowState.left,top:nodeWindowState.top,width:nodeWindowState.width,height:nodeWindowState.height};
    nodeWindowState.maximized=true;
  }else{
    nodeWindowState.maximized=false;
    if(nodeWindowState.restore)Object.assign(nodeWindowState,nodeWindowState.restore);
    nodeWindowState.restore=null;
  }
  applyNodeWindowGeometry();
}
function closeNodeWindow(updateRoute=true){
  const n=Number(nodeWindowState.nodeNum);
  if(Number.isFinite(n))stopNodePolling(n);
  const el=document.getElementById('nodeWindow');
  el?.classList.remove('open','maximized');
  const mapView=document.getElementById('viewMap');
  if(el&&mapView&&el.parentElement!==mapView)mapView.appendChild(el);
  nodeWindowState.maximized=false;nodeWindowState.restore=null;
  openNodeNum=null;nodeWindowState.nodeNum=null;
  if(updateRoute && typeof taActiveView==='function' && taActiveView()==='map')taSyncRoute({replace:true,view:'map'});
}
function openNodeWindow(nodeNum,updateRoute=true){
  const n=(topology?.nodes||[]).find(x=>Number(x.nodeNum)===Number(nodeNum));if(!n)return;
  const previous=Number(nodeWindowState.nodeNum);
  if(Number.isFinite(previous)&&previous!==Number(nodeNum))stopNodePolling(previous);
  nodeWindowState.nodeNum=Number(nodeNum);openNodeNum=Number(nodeNum);
  const title=document.getElementById('nodeWindowTitle'),id=document.getElementById('nodeWindowId'),body=document.getElementById('nodeWindowBody'),win=document.getElementById('nodeWindow');
  if(title)title.textContent=n.name||n.longName||n.nodeId||tr('Nó');
  if(id)id.textContent=n.nodeId||'';
  if(body){
    body.innerHTML=nodePopupHtml(n,false);
    body.scrollTop=0;
    const run=nodeQueryRun(nodeNum);
    if(run.details)renderNodePopupData(nodeNum,run.details);
  }
  win?.classList.add('open');
  applyNodeWindowGeometry();
  if(updateRoute && typeof taActiveView==='function' && taActiveView()==='map')taSyncRoute({view:'map'});
  loadNodeDetails(nodeNum,true).catch(e=>{
    const el=document.getElementById(`nodeTelemetry-${Number(nodeNum)}`);
    if(el)el.innerHTML=`<span class="nodeMetaMissing">Não foi possível carregar dados do MeshMonitor: ${esc(e.message||e)}</span>`;
  });
}
function initNodeWindowInteractions(){
  const win=document.getElementById('nodeWindow'),head=document.getElementById('nodeWindowHeader'),handle=document.getElementById('nodeWindowResizeHandle');
  if(!win||!head||!handle)return;
  let drag=null,resize=null;
  head.addEventListener('pointerdown',e=>{
    if(e.target.closest('button')||nodeWindowState.maximized)return;
    if(e.pointerType==='mouse'&&e.button!==0)return;
    e.preventDefault();
    drag={id:e.pointerId,x:e.clientX,y:e.clientY,left:Number(nodeWindowState.left)||0,top:Number(nodeWindowState.top)||0};
    win.classList.add('dragging');try{head.setPointerCapture(e.pointerId);}catch{}
  });
  head.addEventListener('pointermove',e=>{
    if(!drag||e.pointerId!==drag.id)return;
    e.preventDefault();
    const g=clampNodeWindowGeometry({left:drag.left+(e.clientX-drag.x),top:drag.top+(e.clientY-drag.y),width:nodeWindowState.width,height:nodeWindowState.height});
    Object.assign(nodeWindowState,g);applyNodeWindowGeometry();
  });
  const finishDrag=e=>{if(!drag)return;try{if(head.hasPointerCapture?.(drag.id))head.releasePointerCapture(drag.id);}catch{}drag=null;win.classList.remove('dragging');e?.preventDefault?.();};
  head.addEventListener('pointerup',finishDrag);head.addEventListener('pointercancel',finishDrag);
  head.addEventListener('dblclick',e=>{if(!e.target.closest('button'))toggleNodeWindowExpanded();});
  handle.addEventListener('pointerdown',e=>{
    if(nodeWindowState.maximized)return;
    if(e.pointerType==='mouse'&&e.button!==0)return;
    e.preventDefault();e.stopPropagation();
    resize={id:e.pointerId,x:e.clientX,y:e.clientY,width:Number(nodeWindowState.width)||400,height:Number(nodeWindowState.height)||300};
    win.classList.add('resizing');try{handle.setPointerCapture(e.pointerId);}catch{}
  });
  handle.addEventListener('pointermove',e=>{
    if(!resize||e.pointerId!==resize.id)return;
    e.preventDefault();e.stopPropagation();
    const g=clampNodeWindowGeometry({left:nodeWindowState.left,top:nodeWindowState.top,width:resize.width+(e.clientX-resize.x),height:resize.height+(e.clientY-resize.y)});
    Object.assign(nodeWindowState,g);applyNodeWindowGeometry();
  });
  const finishResize=e=>{if(!resize)return;try{if(handle.hasPointerCapture?.(resize.id))handle.releasePointerCapture(resize.id);}catch{}resize=null;win.classList.remove('resizing');e?.preventDefault?.();e?.stopPropagation?.();};
  handle.addEventListener('pointerup',finishResize);handle.addEventListener('pointercancel',finishResize);
  document.getElementById('nodeWindowClose').addEventListener('click',closeNodeWindow);
  document.getElementById('nodeWindowReset').addEventListener('click',resetNodeWindowGeometry);
  document.getElementById('nodeWindowExpand').addEventListener('click',toggleNodeWindowExpanded);
  window.addEventListener('resize',()=>{if(win.classList.contains('open'))applyNodeWindowGeometry();});
}
initNodeWindowInteractions();

function toggleNodePopupExpanded(nodeNum){
  const n=Number(nodeNum);
  nodePopupExpandedNode=Number(nodePopupExpandedNode)===n?null:n;
  const inner=document.getElementById('nodePopup-'+n);
  const popup=inner?.closest?.('.leaflet-popup');
  if(!popup)return;
  const expanded=Number(nodePopupExpandedNode)===n;
  popup.classList.toggle('nodePopupMaximized',expanded);
  const btn=document.getElementById('nodePopupExpand-'+n);
  if(btn)btn.textContent=expanded?`↙ ${tr('Restaurar')}`:`⛶ ${tr('Expandir')}`;
  if(!expanded)applyNodePopupDragOffset(n);
}
function resetNodePopupPosition(nodeNum){
  nodePopupExpandedNode=null;
  resetNodePopupDrag(nodeNum);
  applyNodePopupDragOffset(nodeNum);
}
function closeNodePopupWindow(nodeNum){
  if(Number(nodePopupDragState.nodeNum)===Number(nodeNum))nodePopupDragState={nodeNum:null,x:0,y:0,left:null,top:null};
  if(Number(nodePopupExpandedNode)===Number(nodeNum))nodePopupExpandedNode=null;
  openNodeNum=null;openNodePopupScrollTop=0;
  map.closePopup();
}
function resetNodePopupDrag(nodeNum){
  nodePopupDragState={nodeNum:Number(nodeNum),x:0,y:0,left:null,top:null};
}
function rememberNodePopupScreenPosition(nodeNum,popup){
  if(!popup)return;
  const mapRect=map.getContainer().getBoundingClientRect();
  const rect=popup.getBoundingClientRect();
  if(Number(nodePopupDragState.nodeNum)!==Number(nodeNum))resetNodePopupDrag(nodeNum);
  nodePopupDragState.left=rect.left-mapRect.left;
  nodePopupDragState.top=rect.top-mapRect.top;
}
function clampNodePopupDrag(popup,x,y){
  popup.style.marginLeft=String(x)+'px';
  popup.style.marginTop=String(y)+'px';
  const mapRect=map.getContainer().getBoundingClientRect();
  const rect=popup.getBoundingClientRect();
  const pad=6;
  const minLeft=mapRect.left+pad;
  const minTop=mapRect.top+pad;
  const maxLeft=Math.max(minLeft,mapRect.right-pad-rect.width);
  const maxTop=Math.max(minTop,mapRect.bottom-pad-rect.height);
  const targetLeft=Math.min(maxLeft,Math.max(minLeft,rect.left));
  const targetTop=Math.min(maxTop,Math.max(minTop,rect.top));
  return {x:x+(targetLeft-rect.left),y:y+(targetTop-rect.top)};
}
function applyNodePopupDragOffset(nodeNum){
  const n=Number(nodeNum);
  const inner=document.getElementById('nodePopup-'+n);
  const popup=inner?.closest?.('.leaflet-popup');
  if(!popup)return;
  if(Number(nodePopupDragState.nodeNum)!==n)resetNodePopupDrag(n);
  popup.classList.add('nodePopupFloating');
  const expanded=Number(nodePopupExpandedNode)===n;
  popup.classList.toggle('nodePopupMaximized',expanded);
  const expandBtn=document.getElementById('nodePopupExpand-'+n);
  if(expandBtn)expandBtn.textContent=expanded?`↙ ${tr('Restaurar')}`:`⛶ ${tr('Expandir')}`;
  if(expanded)return;

  let x=Number(nodePopupDragState.x)||0;
  let y=Number(nodePopupDragState.y)||0;
  const hasSaved=nodePopupDragState.left!==null&&nodePopupDragState.left!==undefined&&nodePopupDragState.top!==null&&nodePopupDragState.top!==undefined;
  const savedLeft=Number(nodePopupDragState.left);
  const savedTop=Number(nodePopupDragState.top);
  if(hasSaved&&Number.isFinite(savedLeft)&&Number.isFinite(savedTop)){
    popup.style.marginLeft='0px';
    popup.style.marginTop='0px';
    const mapRect=map.getContainer().getBoundingClientRect();
    const base=popup.getBoundingClientRect();
    x=(mapRect.left+savedLeft)-base.left;
    y=(mapRect.top+savedTop)-base.top;
  }
  const next=clampNodePopupDrag(popup,x,y);
  popup.style.marginLeft=String(next.x)+'px';
  popup.style.marginTop=String(next.y)+'px';
  nodePopupDragState.x=next.x;
  nodePopupDragState.y=next.y;
  rememberNodePopupScreenPosition(n,popup);
  popup.classList.toggle('nodePopupDetached',Math.abs(next.x)>3||Math.abs(next.y)>3);
}
function initNodePopupDrag(nodeNum){
  const n=Number(nodeNum);
  const inner=document.getElementById('nodePopup-'+n);
  const popup=inner?.closest?.('.leaflet-popup');
  const handle=inner?.querySelector?.('.nodePopupDragHandle');
  if(!popup||!handle)return;
  if(Number(nodePopupDragState.nodeNum)!==n)resetNodePopupDrag(n);
  applyNodePopupDragOffset(n);
  if(handle.dataset.dragReady==='1')return;
  handle.dataset.dragReady='1';
  if(window.L?.DomEvent){L.DomEvent.disableClickPropagation(handle);L.DomEvent.disableScrollPropagation(handle);}
  let active=false,startX=0,startY=0,startOffsetX=0,startOffsetY=0,mapWasDragging=false,pointerId=null;
  const finish=e=>{
    if(!active)return;
    active=false;
    popup.classList.remove('nodePopupDragging');
    try{if(pointerId!==null&&handle.hasPointerCapture?.(pointerId))handle.releasePointerCapture(pointerId);}catch{}
    if(mapWasDragging&&!map.dragging.enabled())map.dragging.enable();
    mapWasDragging=false;pointerId=null;
    e?.preventDefault?.();e?.stopPropagation?.();
  };
  handle.addEventListener('pointerdown',e=>{
    if(Number(nodePopupExpandedNode)===n)return;
    if(e.pointerType==='mouse'&&e.button!==0)return;
    e.preventDefault();e.stopPropagation();
    active=true;pointerId=e.pointerId;
    startX=e.clientX;startY=e.clientY;
    startOffsetX=Number(nodePopupDragState.x)||0;startOffsetY=Number(nodePopupDragState.y)||0;
    mapWasDragging=map.dragging.enabled();
    if(mapWasDragging)map.dragging.disable();
    popup.classList.add('nodePopupDragging');
    try{handle.setPointerCapture(e.pointerId);}catch{}
  });
  handle.addEventListener('pointermove',e=>{
    if(!active||e.pointerId!==pointerId)return;
    e.preventDefault();e.stopPropagation();
    const next=clampNodePopupDrag(popup,startOffsetX+(e.clientX-startX),startOffsetY+(e.clientY-startY));
    nodePopupDragState={nodeNum:n,x:next.x,y:next.y,left:null,top:null};
    applyNodePopupDragOffset(n);
  });
  handle.addEventListener('pointerup',finish);
  handle.addEventListener('pointercancel',finish);
}
function render(){
  if(!topology) return;
  lineLayer.clearLayers();
  nodeLayer.clearLayers();
  nodeMarkers.clear();
  if(heatLayer){ map.removeLayer(heatLayer); heatLayer = null; }

  const cutoff = cutoffForSelection();
  const minObs = Math.max(1, Number(document.getElementById('minObs').value || 1));
  const onlyIdentified = document.getElementById('onlyIdentified').checked;
  const showShortNames = document.getElementById('showShortNames').checked;
  const showLines = document.getElementById('showLines').checked;
  const showNodes = document.getElementById('showNodes').checked;
  const showHeatmap = document.getElementById('showHeatmap').checked;
  const nodeMap = new Map((topology.nodes || []).map(n => [Number(n.nodeNum), n]));
  const mapSearchActive=Boolean(mapSearchText.trim());
  const mapSearchAllowed=mapSearchActive?new Set(mapSearchMatches().map(n=>Number(n.nodeNum))):null;
  const isolatedEdge = isolatedEdgeId ? (topology.edges||[]).find(e=>String(e.id||'')===String(isolatedEdgeId)) : null;
  isolatedEdgeNodes = new Set(isolatedEdge ? [Number(isolatedEdge.a),Number(isolatedEdge.b)] : []);
  const isolationActive=Boolean(isolatedEdge);
  const isolationButton=document.getElementById('clearLinkIsolation');
  if(isolationButton)isolationButton.style.display=isolationActive?'':'none';
  const visibleNodes = new Set();
  const heatWeights = new Map();
  let edgeCount = 0, rfEdgeCount = 0, mqttOnlyEdgeCount = 0, mixedEdgeCount = 0;

  for(const e of topology.edges || []){
    if(isolationActive && String(e.id||'')!==String(isolatedEdgeId)) continue;
    if(mapSearchActive && (!mapSearchAllowed.has(Number(e.a)) || !mapSearchAllowed.has(Number(e.b)))) continue;
    if(!e.geometry) continue;
    const stats = edgeStatsForWindow(e, isolationActive?null:cutoff);
    if(!stats || (!isolationActive && stats.observations < minObs)) continue;
    const a = nodeMap.get(Number(e.a)), b = nodeMap.get(Number(e.b));
    if(!isolationActive && !mapSearchActive && onlyIdentified && ((a?.state !== 'identified') || (b?.state !== 'identified'))) continue;

    visibleNodes.add(Number(e.a)); visibleNodes.add(Number(e.b)); edgeCount++;
    if(stats.mixed) mixedEdgeCount++;
    else if(stats.displayTransport==='mqtt') mqttOnlyEdgeCount++;
    else rfEdgeCount++;
    const obs = Math.max(1, Number(stats.observations || 1));
    heatWeights.set(Number(e.a), (heatWeights.get(Number(e.a)) || 0) + obs);
    heatWeights.set(Number(e.b), (heatWeights.get(Number(e.b)) || 0) + obs);

    if(showLines || isolationActive){
      const mqttOnly=stats.displayTransport==='mqtt';
      const lineColor=mqttOnly?(document.getElementById('mqttLineColor').value||'#ff8c42'):(document.getElementById('rfLineColor').value||'#ffff00');
      const lineWidth=Math.max(1,Math.min(8,Number(document.getElementById(mqttOnly?'mqttLineWidth':'rfLineWidth').value||3)));
      const style={weight:lineWidth,opacity:.82,color:lineColor};
      if(mqttOnly) style.dashArray='10 8';
      const line = L.polyline(e.geometry, style);
      const classLabel=stats.mixed?'Misto RF + MQTT/não-RF (há evidência RF)':(mqttOnly?'MQTT / não-RF':'RF confirmado');
      let distanceLabel='Distância indisponível';
      if(Array.isArray(e.geometry)&&e.geometry.length>=2){
        const p1=e.geometry[0],p2=e.geometry[e.geometry.length-1];
        if(Array.isArray(p1)&&Array.isArray(p2)&&[p1[0],p1[1],p2[0],p2[1]].every(v=>Number.isFinite(Number(v)))){
          const meters=map.distance(L.latLng(Number(p1[0]),Number(p1[1])),L.latLng(Number(p2[0]),Number(p2[1])));
          if(Number.isFinite(meters))distanceLabel=`Distância: <b>${(meters/1000).toLocaleString(uiLocale(),{minimumFractionDigits:1,maximumFractionDigits:1})} km</b>`;
        }
      }
      line.bindPopup(
        `<b>${esc(e.aName)} ↔ ${esc(e.bName)}</b><br>`+
        `${esc(e.aId)} ↔ ${esc(e.bId)}<br>`+
        `${distanceLabel}<br>`+
        `Classificação: <b>${esc(classLabel)}</b><br>`+
        `Observações: <b>${stats.observations}</b> · RF: <b>${stats.rf}</b> · MQTT/não-RF: <b>${stats.nonRf}</b><br>`+
        `Critério RF: SNR válido observado no hop<br>`+
        `Ida: ${stats.forward} | Volta: ${stats.back}<br>`+
        `SNR médio RF conhecido: ${snr(stats.avgSnr)}<br>`+
        `Faixa SNR: ${snr(stats.minSnr)} a ${snr(stats.maxSnr)}<br>`+
        `Última observação: ${dt(stats.lastSeenMs)}<br>`+
        `Traceroute: ${esc(stats.latestTraceId ?? '—')} | canal: ${esc(stats.latestChannel ?? '—')}`
      );
      line.addTo(lineLayer);
    }
  }

  if(showHeatmap && typeof L.heatLayer === 'function' && heatWeights.size){
    const maxWeight = Math.max(...heatWeights.values(), 1);
    const heatPoints = [];
    for(const [nodeNum, weight] of heatWeights.entries()){
      const n = nodeMap.get(nodeNum);
      if(!nodeHasValidMapPosition(n)) continue;
      if(!mapSearchActive && onlyIdentified && n.state !== 'identified') continue;
      const intensity = Math.max(.08, Math.log1p(weight) / Math.log1p(maxWeight));
      heatPoints.push([Number(n.latitude), Number(n.longitude), intensity]);
    }
    if(heatPoints.length){
      heatLayer = L.heatLayer(heatPoints, {
        radius:34, blur:24, maxZoom:13, minOpacity:.28,
        gradient:{0.15:'#2b83ba',0.35:'#abdda4',0.55:'#ffffbf',0.75:'#fdae61',1:'#d7191c'}
      }).addTo(map);
    }
  }

  const coords = [];
  let markerCount = 0, mappableCount = 0;
  const mappableStates = {identified:0, stub:0, 'route-only':0};
  for(const n of topology.nodes || []){
    if(isolationActive && !isolatedEdgeNodes.has(Number(n.nodeNum))) continue;
    if(nodeCtxReadSet(NODE_CTX_HIDDEN_KEY).has(Number(n.nodeNum)) && !isolationActive && !mapSearchActive) continue;
    if(mapSearchActive && !mapSearchAllowed.has(Number(n.nodeNum))) continue;
    if(!nodeHasValidMapPosition(n)) continue;
    if(!isolationActive && !mapSearchActive && onlyIdentified && n.state !== 'identified') continue;
    const lat=Number(n.latitude),lon=Number(n.longitude);
    mappableCount++;
    mappableStates[n.state] = (mappableStates[n.state] || 0) + 1;
    coords.push([lat,lon]);
    if(!showNodes && !isolationActive && !mapSearchActive) continue;

    const trafficAge=nodeTrafficAge(n);
    const marker = L.marker([lat,lon], {
      icon:nodeRoleIcon(n),keyboard:true,riseOnHover:true,
      alt:(n.name||n.nodeId||'')+' · '+nodeRoleMeta(n.role)[1]
    });
    if(showShortNames && n.shortName){
      marker.bindTooltip(esc(n.shortName), {direction:'top', permanent:true, className:'short-label', offset:[0,0]});
    } else {
      marker.bindTooltip(esc(n.name || n.nodeId)+' · '+esc(nodeRoleMeta(n.role)[1])+' · '+esc(tr(trafficAge.label)), {direction:'top'});
    }
    marker.on('click',()=>openNodeWindow(n.nodeNum));
    marker.on('contextmenu',ev=>{
      if(ev?.originalEvent){ev.originalEvent.preventDefault();ev.originalEvent.stopPropagation();}
      showNodeContextMenu(n, ev?.originalEvent?.clientX ?? 0, ev?.originalEvent?.clientY ?? 0, 'map');
    });
    marker.addTo(nodeLayer); nodeMarkers.set(Number(n.nodeNum),marker); markerCount++;
  }

  if(openNodeNum!==null){
    const active=(topology.nodes||[]).find(x=>Number(x.nodeNum)===Number(openNodeNum));
    if(active){
      const title=document.getElementById('nodeWindowTitle'),id=document.getElementById('nodeWindowId');
      if(title)title.textContent=active.name||active.longName||active.nodeId||tr('Nó');
      if(id)id.textContent=active.nodeId||'';
      applyNodeWindowGeometry();
    }else closeNodeWindow();
  }
  renderNodesTable();
  const traceCount = (topology.traces || []).filter(t => cutoff === null || Number(t.timestampMs||0) >= cutoff).length;
  lastBounds = coords.length ? L.latLngBounds(coords) : null;
  document.getElementById('summary').innerHTML =
    `<span class="metric"><b>${edgeCount}</b> enlaces no filtro</span>`+
    `<span class="metric"><b>${rfEdgeCount}</b> RF</span>`+
    `<span class="metric"><b>${mqttOnlyEdgeCount}</b> MQTT/não-RF</span>`+
    (mixedEdgeCount?`<span class="metric"><b>${mixedEdgeCount}</b> mistos</span>`:'')+
    `<span class="metric"><b>${mappableCount}</b> nós no mapa</span>`+
    `<span class="metric"><b>${mappableStates.identified || 0}</b> identificados</span>`+
    `<span class="metric"><b>${mappableStates.stub || 0}</b> stubs</span>`+
    `<span class="metric"><b>${mappableStates['route-only'] || 0}</b> route-only</span>`+
    `<span class="metric"><b>${traceCount}</b> traceroutes no histórico</span>`+
    (showNodes ? `<span class="metric"><b>${markerCount}</b> ícones visíveis</span>` : '')+
    (showHeatmap ? `<span class="metric warn">Calor = atividade de roteamento observada</span>` : '');
  updatePlaybackStatusIdle();
}

const INVALID_NODES = new Set([0,1,2,3,255,65535,4294967295]);
function parseJsonArray(v){
  if(Array.isArray(v)) return v.map(Number);
  if(v === null || v === undefined || v === '' || v === 'null') return [];
  try { const x = JSON.parse(v); return Array.isArray(x) ? x.map(Number) : []; } catch { return []; }
}
function parseRoutePositions(v){
  if(!v) return {};
  try { return typeof v === 'string' ? JSON.parse(v) : v; } catch { return {}; }
}
function pointForLive(nodeNum, positions){
  const p = positions?.[String(nodeNum)] ?? positions?.[nodeNum];
  if(p && Number.isFinite(Number(p.lat)) && Number.isFinite(Number(p.lng)))
    return {nodeNum, nodeId:`!${(nodeNum>>>0).toString(16).padStart(8,'0')}`, name:(topology?.nodes||[]).find(n=>Number(n.nodeNum)===nodeNum)?.name || `!${(nodeNum>>>0).toString(16).padStart(8,'0')}`, lat:Number(p.lat), lon:Number(p.lng)};
  const n = (topology?.nodes || []).find(x => Number(x.nodeNum) === nodeNum);
  if(n && n.latitude !== null && n.longitude !== null)
    return {nodeNum, nodeId:n.nodeId, name:n.name || n.nodeId, lat:Number(n.latitude), lon:Number(n.longitude)};
  return null;
}
function liveLeg(start, midsRaw, end, positions){
  const nums = [Number(start), ...parseJsonArray(midsRaw), Number(end)].map(x => x >>> 0);
  if(nums.some(n => INVALID_NODES.has(n))) return null;
  const pts = nums.map(n => pointForLive(n, positions));
  return pts.every(Boolean) ? pts : null;
}
function normalizeLiveTrace(tr){
  const fromNum = Number(tr.fromNodeNum) >>> 0, toNum = Number(tr.toNodeNum) >>> 0;
  if(INVALID_NODES.has(fromNum) || INVALID_NODES.has(toNum)) return null;
  const positions = parseRoutePositions(tr.routePositions);
  const forward = (tr.route !== null && tr.route !== undefined && tr.route !== '' && tr.route !== 'null') ? liveLeg(fromNum, tr.route, toNum, positions) : null;
  const rb = parseJsonArray(tr.routeBack);
  const hasBack = rb.length > 0 || (tr.snrBack && tr.snrBack !== '[]' && tr.snrBack !== 'null');
  const back = hasBack ? liveLeg(toNum, tr.routeBack, fromNum, positions) : null;
  const nodeMap = new Map((topology?.nodes || []).map(n => [Number(n.nodeNum), n]));
  return {
    id:tr.id, packetId:tr.packetId,
    timestampMs:Number(tr.timestamp || tr.createdAt || Date.now()) < 10000000000 ? Number(tr.timestamp || tr.createdAt || Date.now())*1000 : Number(tr.timestamp || tr.createdAt || Date.now()),
    fromNodeNum:fromNum, toNodeNum:toNum,
    fromNodeId:tr.fromNodeId || `!${fromNum.toString(16).padStart(8,'0')}`,
    toNodeId:tr.toNodeId || `!${toNum.toString(16).padStart(8,'0')}`,
    fromName:nodeMap.get(fromNum)?.name || tr.fromNodeId || `!${fromNum.toString(16).padStart(8,'0')}`,
    toName:nodeMap.get(toNum)?.name || tr.toNodeId || `!${toNum.toString(16).padStart(8,'0')}`,
    channel:tr.channel,
    forwardPath:forward, returnPath:back,
    animatable:Boolean((forward && forward.length>1) || (back && back.length>1))
  };
}
function traceKey(t){
  if(t?.id !== null && t?.id !== undefined && String(t.id)!=='') return `id:${t.id}`;
  if(t?.packetId !== null && t?.packetId !== undefined && String(t.packetId)!=='') return `packet:${t.packetId}:${t.fromNodeNum}:${t.toNodeNum}`;
  return `fallback:${t?.timestamp ?? t?.timestampMs ?? ''}:${t?.fromNodeNum}:${t?.toNodeNum}`;
}
function historyTraces(){
  const cutoff = cutoffForSelection();
  return (topology?.traces || []).filter(t => t.animatable && (cutoff === null || Number(t.timestampMs||0) >= cutoff));
}
function geoDistanceMeters(a,b){
  if(!a || !b) return null;
  if(!Number.isFinite(Number(a.lat)) || !Number.isFinite(Number(a.lon)) || !Number.isFinite(Number(b.lat)) || !Number.isFinite(Number(b.lon))) return null;
  return L.latLng(Number(a.lat),Number(a.lon)).distanceTo(L.latLng(Number(b.lat),Number(b.lon)));
}
function pathDistanceMeters(points){
  if(!points || points.length<2) return null;
  let total=0;
  for(let i=0;i<points.length-1;i++){
    const d=geoDistanceMeters(points[i],points[i+1]);
    if(!Number.isFinite(d)) return null;
    total+=d;
  }
  return total;
}
function fmtDistance(m){
  if(!Number.isFinite(Number(m))) return '—';
  const v=Number(m);
  if(v<1000) return `${Math.round(v).toLocaleString(uiLocale())} m`;
  return `${(v/1000).toLocaleString(uiLocale(),{minimumFractionDigits:v<10000?1:0,maximumFractionDigits:1})} km`;
}
function traceDistanceInfo(trace){
  const forward=pathDistanceMeters(trace?.forwardPath);
  const back=pathDistanceMeters(trace?.returnPath);
  const a=trace?.forwardPath?.[0] || trace?.returnPath?.[trace?.returnPath?.length-1];
  const b=trace?.forwardPath?.[trace?.forwardPath?.length-1] || trace?.returnPath?.[0];
  const direct=geoDistanceMeters(a,b);
  const roundTrip=(Number.isFinite(forward)&&Number.isFinite(back)) ? forward+back : null;
  const known=[forward,back].filter(Number.isFinite).reduce((x,y)=>x+y,0);
  return {direct,forward,back,roundTrip,known};
}
function ensureTraceHud(){
  if(traceHudContainer) return;
  const ctrl=L.control({position:'bottomleft'});
  ctrl.onAdd=()=>{
    traceHudContainer=L.DomUtil.create('div','traceHud');
    L.DomEvent.disableClickPropagation(traceHudContainer);
    return traceHudContainer;
  };
  ctrl.addTo(map);
}
function renderTraceHud(){
  ensureTraceHud();
  if(!traceHudContainer) return;
  const entries=[...traceHudEntries.values()];
  traceHudContainer.innerHTML=entries.map(e=>{
    const d=e.dist;
    const topTotal=Number.isFinite(d.roundTrip) ? `Total ida + volta: ${fmtDistance(d.roundTrip)}` : (d.known>0 ? `Total conhecido: ${fmtDistance(d.known)}` : 'Total ida + volta: —');
    const idaClass=e.leg==='forward'?' active':'';
    const voltaClass=e.leg==='return'?' active':'';
    const ida=e.trace.forwardPath?.length>1 ? `<span class="forward">IDA</span> · direta ${fmtDistance(d.direct)} · percurso ${fmtDistance(d.forward)}` : `<span class="forward">IDA</span> · <span class="traceHudDim">sem percurso completo</span>`;
    const volta=e.trace.returnPath?.length>1 ? `<span class="return">VOLTA</span> · direta ${fmtDistance(d.direct)} · percurso ${fmtDistance(d.back)}` : `<span class="return">VOLTA</span> · <span class="traceHudDim">sem percurso completo</span>`;
    return `<div class="traceHudItem"><div class="traceHudHead">${esc(e.trace.fromName)} → ${esc(e.trace.toName)} <span class="traceHudTotal">${esc(topTotal)}</span></div><div class="traceHudLeg${idaClass}">${ida}</div><div class="traceHudLeg${voltaClass}">${volta}</div></div>`;
  }).join('');
}
function beginTraceHud(key,trace){
  traceHudEntries.set(key,{trace,dist:traceDistanceInfo(trace),leg:null});
  renderTraceHud();
}
function setTraceHudLeg(key,leg){
  const e=traceHudEntries.get(key); if(!e) return;
  e.leg=leg; renderTraceHud();
}
function endTraceHud(key){ traceHudEntries.delete(key); renderTraceHud(); }
function clearTraceHud(){ traceHudEntries.clear(); renderTraceHud(); }
function updatePlaybackControl(){
  const btn=document.getElementById('playTrace');
  if(!btn) return;
  const live=document.getElementById('playMode').value==='live';
  const paused=live ? (!playbackRunning || liveAnimationPaused) : (!playbackRunning || historyAnimationPaused);
  btn.textContent=paused?'▶':'⏸';
  btn.title=live
    ? (paused?'Retomar animações ao vivo':'Pausar animações ao vivo')
    : (paused?'Reproduzir/retomar histórico':'Pausar histórico');
}
function updatePlaybackStatusIdle(){
  updatePlaybackControl();
  const el = document.getElementById('playStatus');
  if(document.getElementById('playMode').value === 'live'){
    if(!liveInitialized) el.innerHTML = '<span class="liveBadge">AO VIVO</span> · conectando…';
    else if(liveAnimationPaused){
      const queued=liveQueue.length,activity=pausedActivityQueue.length,active=activeLiveAnimations.size;
      el.innerHTML = `<span class="liveBadge">AO VIVO</span> · ANIMAÇÃO PAUSADA · ${active} pacote(s) congelado(s) · ${queued} traceroute(s) aguardando · ${activity} evento(s) aguardando`;
    }else{
      const active=activeLiveAnimations.size;
      if(active>0) el.innerHTML=`<span class="liveBadge">AO VIVO</span> · ${active} pacote(s) em trânsito`;
      else if(liveQueue.length) el.innerHTML=`<span class="liveBadge">AO VIVO</span> · ${liveQueue.length} pacote(s) aguardando animação`;
      else el.innerHTML='<span class="liveBadge">AO VIVO</span>';
    }
    return;
  }
  const list=historyTraces(),active=activeHistoryAnimations.size,state=historySchedulerState;
  if(historyAnimationPaused){
    const waiting=state?Math.max(0,state.list.length-state.nextIndex):Math.max(0,list.length-historyIndex);
    el.textContent=`Histórico pausado · ${active} pacote(s) congelado(s) · ${waiting} aguardando`;
    return;
  }
  if(playbackRunning){
    const launched=state?state.nextIndex:historyIndex;
    el.textContent=`Histórico · ${active} pacote(s) em trânsito · ${launched}/${state?.list.length||list.length} iniciados`;
    return;
  }
  if(historyIndex>=list.length)historyIndex=Math.max(0,list.length-1);
  el.textContent=list.length?`Histórico: ${list.length} traceroutes animáveis · posição ${historyIndex+1}/${list.length}`:'Histórico: nenhum traceroute completamente mapeável no filtro atual.';
}
function pathNames(path){ return (path || []).map(p => p.name || p.nodeId).join(' → '); }
function setTraceStatus(trace, leg, idx, total){
  const live=document.getElementById('playMode').value==='live';
  const concurrent=live?activeLiveAnimations.size:activeHistoryAnimations.size;
  if(concurrent>1){updatePlaybackStatusIdle();return;}
  const mode=live?'<span class="liveBadge">AO VIVO</span>':`Histórico ${idx+1}/${total}`;
  const path=leg==='return'?trace.returnPath:trace.forwardPath;
  document.getElementById('playStatus').innerHTML=`${mode} · ${dt(trace.timestampMs)} · ${leg==='return'?'VOLTA':'IDA'} · ${esc(pathNames(path))}`;
}
function stopAnimation(){
  playbackRunning=false;
  historyAnimationPaused=false;
  liveAnimationPaused=false;
  animationGeneration++;
  if(historySchedulerRaf){cancelAnimationFrame(historySchedulerRaf);historySchedulerRaf=null;}
  historySchedulerState=null;
  activeHistoryAnimations.clear();
  activeLiveAnimations.clear();
  liveProcessing=false;
  animationLayer.clearLayers();
  clearTraceHud();
  updatePlaybackStatusIdle();
}
function latLngAt(points, segIndex, ratio){
  const a=points[segIndex], b=points[segIndex+1];
  return L.latLng(a.lat + (b.lat-a.lat)*ratio, a.lon + (b.lon-a.lon)*ratio);
}
function traceBounds(trace){
  const pts=[...(trace?.forwardPath||[]),...(trace?.returnPath||[])].filter(p=>Number.isFinite(Number(p?.lat))&&Number.isFinite(Number(p?.lon)));
  if(!pts.length) return null;
  const b=L.latLngBounds(pts.map(p=>[Number(p.lat),Number(p.lon)]));
  return b.isValid()?b:null;
}
function autoMapMotionAllowed(){ return !!document.getElementById('autoZoomTraceroute')?.checked; }
function refitAutoZoom(){
  if(!autoZoomEngaged || !autoMapMotionAllowed()) return;
  let combined=null;
  for(const b of autoZoomActive.values()){
    if(!b || !b.isValid()) continue;
    if(!combined) combined=L.latLngBounds(b.getSouthWest(),b.getNorthEast());
    else combined.extend(b);
  }
  if(combined && combined.isValid() && document.getElementById('viewMap').classList.contains('active')){
    map.fitBounds(combined.pad(.12),{maxZoom:15,animate:true});
  }
}
function beginAutoZoom(key,trace){
  if(!autoMapMotionAllowed()) return false;
  const b=traceBounds(trace);
  if(!b) return false;
  if(autoZoomRestoreTimer){ clearTimeout(autoZoomRestoreTimer); autoZoomRestoreTimer=null; }
  if(!autoZoomEngaged){
    autoZoomSavedCenter=map.getCenter();
    autoZoomSavedZoom=map.getZoom();
    autoZoomEngaged=true;
  }
  autoZoomActive.set(key,b);
  refitAutoZoom();
  return true;
}
function endAutoZoom(key){
  autoZoomActive.delete(key);
  if(!autoZoomEngaged) return;
  if(autoZoomActive.size){ refitAutoZoom(); return; }
  if(autoZoomRestoreTimer) clearTimeout(autoZoomRestoreTimer);
  autoZoomRestoreTimer=setTimeout(()=>{
    if(!autoZoomEngaged || autoZoomActive.size) return;
    const center=autoZoomSavedCenter, zoom=autoZoomSavedZoom;
    autoZoomEngaged=false; autoZoomSavedCenter=null; autoZoomSavedZoom=null; autoZoomRestoreTimer=null;
    if(center && Number.isFinite(Number(zoom)) && document.getElementById('viewMap').classList.contains('active')) map.setView(center,zoom,{animate:true});
  },5000);
}
function disableAutoZoomAndRestore(restore=true){
  if(autoZoomRestoreTimer){ clearTimeout(autoZoomRestoreTimer); autoZoomRestoreTimer=null; }
  autoZoomActive.clear();
  const center=autoZoomSavedCenter, zoom=autoZoomSavedZoom;
  const shouldRestore=restore && autoZoomEngaged && center && Number.isFinite(Number(zoom));
  autoZoomEngaged=false; autoZoomSavedCenter=null; autoZoomSavedZoom=null;
  if(shouldRestore && document.getElementById('viewMap').classList.contains('active')) map.setView(center,zoom,{animate:true});
}
function animatePath(points, color, isActive, isPaused=()=>false){
  return new Promise(resolve => {
    if(!points || points.length < 2){ resolve(true); return; }
    const latlngs = points.map(p => L.latLng(p.lat,p.lon));
    const screen = latlngs.map(ll => map.latLngToContainerPoint(ll));
    const lengths=[]; let total=0;
    for(let i=0;i<screen.length-1;i++){ const d=screen[i].distanceTo(screen[i+1]); lengths.push(d); total+=d; }
    if(total < 1){ resolve(true); return; }
    const routeGlow = L.polyline(latlngs,{color,weight:5,opacity:.38,dashArray:'8 7',interactive:false}).addTo(animationLayer);
    const pulse = L.circleMarker(latlngs[0],{radius:7,color:'#ffffff',weight:2,fillColor:color,fillOpacity:1,interactive:false}).addTo(animationLayer);
    const emitted = new Set();
    const emitNode = (idx) => {
      if(idx < 0 || idx >= points.length || emitted.has(idx)) return;
      emitted.add(idx);
      const n = Number(points[idx]?.nodeNum);
      if(!Number.isFinite(n) || INVALID_NODES.has(n>>>0)) return;
      const kind = idx===0 ? 'origin' : (idx===points.length-1 ? 'response' : 'relay');
      activityPulseAtPoint(points[idx],n>>>0,kind);
      playMeshSound(idx===0?'origin':(idx===points.length-1?'destination':'relay'),{category:'routing',point:points[idx]});
    };
    emitNode(0);
    let travelled=0;
    let lastFrame=performance.now();
    function cleanup(){ try{ animationLayer.removeLayer(pulse); }catch{} try{ animationLayer.removeLayer(routeGlow); }catch{} }
    function frame(now){
      if(!isActive()){ cleanup(); resolve(false); return; }
      const dt=Math.max(0,Math.min(250,now-lastFrame)); lastFrame=now;
      if(isPaused()){ requestAnimationFrame(frame); return; }
      const speed=Math.max(20,Number(document.getElementById('animSpeed').value||150));
      travelled += (dt/1000)*speed;
      if(travelled >= total){
        pulse.setLatLng(latlngs[latlngs.length-1]);
        for(let i=1;i<points.length;i++) emitNode(i);
        cleanup(); resolve(true); return;
      }
      let rem=travelled, seg=0;
      while(seg<lengths.length-1 && rem>lengths[seg]){ rem-=lengths[seg]; seg++; }
      for(let i=1;i<=seg;i++) emitNode(i);
      const ratio=lengths[seg] ? Math.max(0,Math.min(1,rem/lengths[seg])) : 1;
      pulse.setLatLng(latLngAt(points,seg,ratio));
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  });
}
async function animateTrace(trace, isActive, idx=0, total=1, hudKey=null, isPaused=()=>false){
  if(trace.forwardPath?.length > 1){
    if(hudKey) setTraceHudLeg(hudKey,'forward');
    setTraceStatus(trace,'forward',idx,total);
    if(!await animatePath(trace.forwardPath,'#00e5ff',isActive,isPaused)) return false;
  }
  if(trace.returnPath?.length > 1){
    if(hudKey) setTraceHudLeg(hudKey,'return');
    setTraceStatus(trace,'return',idx,total);
    if(!await animatePath(trace.returnPath,'#ff4fd8',isActive,isPaused)) return false;
  }
  playMeshSound('complete',{category:'routing'});
  return true;
}
function historySpeedMultiplier(){
  const v=Number(document.getElementById('animSpeed').value||150);
  if(v<=80)return .5;if(v>=500)return 4;if(v>=280)return 2;return 1;
}
function historyLaunchPlan(list){
  const sorted=list.slice().sort((a,b)=>Number(a.timestampMs||0)-Number(b.timestampMs||0));
  if(!sorted.length)return {list:[],offsets:[]};
  const valid=sorted.map(t=>Number(t.timestampMs||0)).filter(Number.isFinite);
  const first=valid.length?valid[0]:0,last=valid.length?valid[valid.length-1]:first,rawSpan=Math.max(0,last-first);
  // Preserve real intervals for short captures. Long windows are proportionally
  // compressed to 45 s so a 24 h/7 d history remains observable without serializing packets.
  const scale=rawSpan>45000?45000/rawSpan:1;
  const offsets=sorted.map((t,i)=>{
    const ts=Number(t.timestampMs||0);
    return Number.isFinite(ts)&&first?Math.max(0,(ts-first)*scale):i*120;
  });
  return {list:sorted,offsets};
}
function finishHistoryPlayback(generation){
  if(generation!==animationGeneration)return;
  if(historySchedulerRaf){cancelAnimationFrame(historySchedulerRaf);historySchedulerRaf=null;}
  const count=historySchedulerState?.list?.length||historyTraces().length;
  historySchedulerState=null;
  playbackRunning=false;historyAnimationPaused=false;activeHistoryAnimations.clear();
  updatePlaybackControl();
  historyIndex=0;
  document.getElementById('playStatus').textContent=`Histórico concluído · ${count} traceroute(s) reproduzido(s)`;
}
function maybeFinishHistoryPlayback(generation){
  const s=historySchedulerState;
  if(!s||generation!==animationGeneration)return;
  if(s.nextIndex>=s.list.length&&activeHistoryAnimations.size===0)finishHistoryPlayback(generation);
}
function runHistoryTrace(trace,index,total,generation){
  const token=++historyAnimationSeq;
  activeHistoryAnimations.set(token,{trace,index});
  const autoKey=`history:${generation}:${token}`;
  const zoomed=beginAutoZoom(autoKey,trace);
  beginTraceHud(autoKey,trace);
  const active=()=>playbackRunning&&generation===animationGeneration&&document.getElementById('playMode').value==='history'&&activeHistoryAnimations.has(token);
  (async()=>{
    try{await animateTrace(trace,active,index,total,autoKey,()=>historyAnimationPaused);}
    finally{
      endTraceHud(autoKey);if(zoomed)endAutoZoom(autoKey);
      activeHistoryAnimations.delete(token);updatePlaybackStatusIdle();maybeFinishHistoryPlayback(generation);
    }
  })();
}
function playHistoryLoop(){
  stopLivePolling();
  const plan=historyLaunchPlan(historyTraces());
  if(!plan.list.length){updatePlaybackStatusIdle();return;}
  if(historySchedulerRaf){cancelAnimationFrame(historySchedulerRaf);historySchedulerRaf=null;}
  activeHistoryAnimations.clear();
  historyAnimationPaused=false;playbackRunning=true;historyIndex=0;
  const generation=++animationGeneration;
  historySchedulerState={list:plan.list,offsets:plan.offsets,nextIndex:0,elapsed:0,lastFrame:performance.now(),generation};
  updatePlaybackControl();
  function frame(now){
    const s=historySchedulerState;
    if(!s||generation!==animationGeneration||!playbackRunning||document.getElementById('playMode').value!=='history'){historySchedulerRaf=null;return;}
    const dt=Math.max(0,Math.min(1000,now-s.lastFrame));s.lastFrame=now;
    if(!historyAnimationPaused){
      s.elapsed+=dt*historySpeedMultiplier();
      while(s.nextIndex<s.list.length&&s.offsets[s.nextIndex]<=s.elapsed){
        const idx=s.nextIndex++,trace=s.list[idx];historyIndex=idx;
        runHistoryTrace(trace,idx,s.list.length,generation);
      }
      maybeFinishHistoryPlayback(generation);
      if(!historySchedulerState)return;
    }
    updatePlaybackStatusIdle();
    historySchedulerRaf=requestAnimationFrame(frame);
  }
  // Always launch every trace whose offset is zero immediately, allowing true concurrency.
  while(historySchedulerState.nextIndex<plan.list.length&&plan.offsets[historySchedulerState.nextIndex]<=0){
    const idx=historySchedulerState.nextIndex++,trace=plan.list[idx];historyIndex=idx;
    runHistoryTrace(trace,idx,plan.list.length,generation);
  }
  historySchedulerRaf=requestAnimationFrame(frame);
  updatePlaybackStatusIdle();
}
async function playHistoryOnce(index){
  stopLivePolling();
  if(historySchedulerRaf){cancelAnimationFrame(historySchedulerRaf);historySchedulerRaf=null;}
  historySchedulerState=null;activeHistoryAnimations.clear();animationLayer.clearLayers();clearTraceHud();
  const list=historyTraces();
  if(!list.length){ updatePlaybackStatusIdle(); return; }
  historyIndex=Math.max(0,Math.min(index,list.length-1));
  historyAnimationPaused=false;
  playbackRunning=true;
  updatePlaybackControl();
  const generation=++animationGeneration;
  const active=()=>playbackRunning && generation===animationGeneration && document.getElementById('playMode').value==='history';
  const trace=list[historyIndex];
  const autoKey=`history-once:${generation}:${historyIndex}`;
  const zoomed=beginAutoZoom(autoKey,trace);
  beginTraceHud(autoKey,trace);
  try{ await animateTrace(trace,active,historyIndex,list.length,autoKey,()=>historyAnimationPaused); }
  finally{ endTraceHud(autoKey); if(zoomed) endAutoZoom(autoKey); }
  if(generation===animationGeneration){
    playbackRunning=false;
    historyAnimationPaused=false;
    updatePlaybackStatusIdle();
  }
}
async function pollLive(){
  if(document.getElementById('playMode').value !== 'live') return;
  try{
    const r=await fetch('/api/live-traceroutes?limit=200',{cache:'no-store'});
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    const body=await r.json();
    const rows=(body.data || []).slice().sort((a,b)=>Number(a.timestamp||a.createdAt||0)-Number(b.timestamp||b.createdAt||0));
    if(!liveInitialized){
      // Traceroutes já completos ao abrir a tela são considerados históricos.
      // Registros ainda incompletos NÃO são marcados como vistos: se o MeshMonitor
      // completar a rota depois, o evento poderá ser animado normalmente.
      for(const row of rows){
        const t=normalizeLiveTrace(row);
        if(t?.animatable) liveSeen.add(traceKey(row));
      }
      liveInitialized=true; updatePlaybackStatusIdle(); return;
    }
    const fresh=[];
    for(const row of rows){
      const key=traceKey(row);
      if(liveSeen.has(key)) continue;
      const t=normalizeLiveTrace(row);
      if(!t?.animatable) continue;
      liveSeen.add(key);
      fresh.push(t);
    }
    if(liveSeen.size>12000) liveSeen=new Set([...liveSeen].slice(-6000));
    if(fresh.length){
      liveQueue.push(...fresh);
      processLiveQueue();
    }
  }catch(e){ document.getElementById('playStatus').innerHTML=`<span class="liveBadge">AO VIVO</span> · erro: ${esc(e)}`; }
}
function runLiveTrace(trace){
  const token=++liveAnimationSeq;
  activeLiveAnimations.set(token,{trace});
  liveProcessing=true;
  const autoKey=`live:${token}`;
  const zoomed=beginAutoZoom(autoKey,trace);
  beginTraceHud(autoKey,trace);
  const active=()=>playbackRunning && document.getElementById('playMode').value==='live' && activeLiveAnimations.has(token);
  (async()=>{
    try{
      await animateTrace(trace,active,0,1,autoKey,()=>liveAnimationPaused);
    } finally {
      endTraceHud(autoKey);
      if(zoomed) endAutoZoom(autoKey);
      activeLiveAnimations.delete(token);
      liveProcessing=activeLiveAnimations.size>0;
      updatePlaybackStatusIdle();
    }
  })();
}
function processLiveQueue(){
  if(!playbackRunning || liveAnimationPaused || document.getElementById('playMode').value !== 'live') return;
  // Cada traceroute novo ganha sua própria animação. Assim, um novo evento começa
  // imediatamente mesmo quando outro traceroute ainda está percorrendo o mapa.
  while(liveQueue.length){ runLiveTrace(liveQueue.shift()); }
  updatePlaybackStatusIdle();
}
function startLivePolling(){
  if(livePollTimer) clearInterval(livePollTimer);
  liveSeen=new Set(); liveQueue=[]; pausedActivityQueue=[]; liveInitialized=false; liveProcessing=false; liveAnimationPaused=false;
  activeLiveAnimations.clear();
  playbackRunning=true;
  updatePlaybackControl();
  pollLive();
  livePollTimer=setInterval(pollLive,3000);
}
function stopLivePolling(){
  if(livePollTimer){ clearInterval(livePollTimer); livePollTimer=null; }
  activeLiveAnimations.clear();
  liveQueue=[]; pausedActivityQueue=[];
  liveProcessing=false; liveAnimationPaused=false;
  for(const key of [...traceHudEntries.keys()]) if(String(key).startsWith('live:')) traceHudEntries.delete(key);
  renderTraceHud();
  updatePlaybackControl();
}


// ---------------- Traffic Analyzer: packet monitor ----------------
let trafficPackets=[];
let trafficInitialized=false;
let trafficLastTs=0;
let trafficTimer=null;
let trafficPaused=false;
let trafficTotal=0;
let selectedPacketId=null;
let audioCtx=null;
let lastSoundAt=0;
let journeySeen=new Set();
let flowGeneration=0;
let flowToastTimer=null;
let nodeInfoRecent=new Map();
let nodeInfoTriggered=new Set();
let nodeInfoActivePacket=null;
const NODEINFO_PAIR_WINDOW_MS=45000;
const NODEINFO_TRACE_WINDOW_MS=180000;
const NODEINFO_ROUTE_WAIT_MS=30000;

let authState={enabled:false,configured:false,authenticated:true,user:null,csrfToken:'',expiresAtMs:null};

function authCanWrite(){return !authState.enabled||!!authState.authenticated;}

function authWriteHeaders(headers={}){
  const out={...headers};
  if(authState.enabled&&authState.authenticated&&authState.csrfToken)out['X-CSRF-Token']=authState.csrfToken;
  return out;
}

async function authFetch(url,options={}){
  const opts={...options,headers:authWriteHeaders(options.headers||{})};
  const r=await fetch(url,opts);
  if((r.status===401||r.status===403)&&authState.enabled){
    setTimeout(()=>loadAuthStatus(false),0);
  }
  return r;
}

function openAuthModal(){
  if(!authState.enabled||!authState.configured)return;
  document.getElementById('authError').textContent='';
  document.getElementById('authUsername').value=authState.user||'admin';
  document.getElementById('authPassword').value='';
  document.getElementById('authModalBackdrop').classList.add('open');
  setTimeout(()=>document.getElementById('authUsername').focus(),30);
}
function closeAuthModal(){document.getElementById('authModalBackdrop').classList.remove('open');}

function applyAuthState(){
  const locked=authState.enabled&&!authState.authenticated;
  const badge=document.getElementById('authStateBadge'),action=document.getElementById('authAction');
  badge.className='authBadge';
  if(!authState.enabled){
    badge.classList.add('disabled');badge.textContent=tr('Autenticação desativada');action.style.display='none';
  }else if(authState.authenticated){
    badge.classList.add('admin');badge.textContent=`${tr('Administrador')} · ${authState.user||'admin'}`;action.style.display='';action.disabled=false;action.textContent=tr('Sair');
  }else if(!authState.configured){
    badge.textContent=tr('Senha administrativa não configurada');action.style.display='';action.disabled=true;action.textContent=tr('Entrar');
  }else{
    badge.textContent=tr('Somente leitura');action.style.display='';action.disabled=false;action.textContent=tr('Entrar');
  }
  const settings=document.getElementById('viewSettings');
  settings.classList.toggle('authLocked',locked);
  document.getElementById('settingsReadOnly').classList.toggle('open',locked);
  settings.querySelectorAll('[data-admin-only]').forEach(el=>{el.disabled=locked;});
  document.querySelectorAll('.adminOnlySection').forEach(el=>el.classList.toggle('locked',locked));
  document.getElementById('messageReadOnly').classList.toggle('open',locked);
  const composer=document.getElementById('messageComposer');composer.classList.toggle('readOnly',locked);
  for(const id of ['messageInput','messageSend','messageEmojiBtn','replyComposerClose']){
    const el=document.getElementById(id);if(el)el.disabled=locked;
  }
  const refresh=document.getElementById('reload');if(refresh)refresh.disabled=locked;
  const accessLocked=document.getElementById('accessLocked'),accessContent=document.getElementById('accessContent');
  if(accessLocked&&accessContent){
    accessLocked.style.display=locked?'':'none';
    accessContent.style.display=locked?'none':'';
    if(locked){accessPayload=null;accessLoadedAt=0;}
    else if(document.getElementById('viewAccess')?.classList.contains('active'))setTimeout(()=>loadAccessStats(true),0);
  }
  if(typeof applyAutomationAccess==='function')applyAutomationAccess(locked);
  if(locked){clearReply();closeMentionSuggestions();document.getElementById('emojiPicker').classList.remove('open');}
  if(messagesInitialized)renderMessages({forceBottom:false});
}

async function loadAuthStatus(showError=false){
  try{
    const r=await fetch('/api/auth/status',{cache:'no-store'});
    const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||`HTTP ${r.status}`);
    authState={...authState,...b};
    applyAuthState();
    return b;
  }catch(e){
    if(showError)alert(`${tr('Erro')}: ${e}`);
    return null;
  }
}

async function submitAuthLogin(){
  const btn=document.getElementById('authLoginSubmit'),error=document.getElementById('authError');
  btn.disabled=true;error.textContent='';
  try{
    const username=document.getElementById('authUsername').value.trim(),password=document.getElementById('authPassword').value;
    const r=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})});
    const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||`HTTP ${r.status}`);
    authState={...authState,enabled:true,configured:true,authenticated:true,user:b.user,csrfToken:b.csrfToken||'',expiresAtMs:b.expiresAtMs||null};
    closeAuthModal();applyAuthState();
  }catch(e){error.textContent=String(e.message||e);}
  finally{btn.disabled=false;}
}

async function authLogout(){
  try{
    const r=await authFetch('/api/auth/logout',{method:'POST'});
    const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||`HTTP ${r.status}`);
  }catch{}
  authState={...authState,authenticated:false,user:null,csrfToken:'',expiresAtMs:null};
  applyAuthState();
}

function toNodeMs(v){
  const n=Number(v);if(!Number.isFinite(n)||n<=0)return 0;
  return n<100000000000?n*1000:n;
}
function compactAgeFromMs(ms){
  if(!ms)return '—';
  const sec=Math.max(0,Math.floor((Date.now()-ms)/1000));
  if(sec<60)return `${sec} s`;
  const min=Math.floor(sec/60);if(min<60)return `${min} min`;
  const h=Math.floor(min/60);if(h<24)return `${h} h`;
  const d=Math.floor(h/24);return `${d} d`;
}
function nodeAgeClass(ms){
  if(!ms)return 'nodeAgeUnknown';
  const age=Date.now()-ms;
  if(age<=3600000)return 'nodeAgeFresh';
  if(age<=12*3600000)return 'nodeAgeWarm';
  return 'nodeAgeOld';
}
function haversineKm(aLat,aLon,bLat,bLon){
  const vals=[aLat,aLon,bLat,bLon].map(Number);if(vals.some(v=>!Number.isFinite(v)))return null;
  const [la1,lo1,la2,lo2]=vals,rad=Math.PI/180;
  const dLat=(la2-la1)*rad,dLon=(lo2-lo1)*rad;
  const x=Math.sin(dLat/2)**2+Math.cos(la1*rad)*Math.cos(la2*rad)*Math.sin(dLon/2)**2;
  return 6371*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));
}
function nodesReferenceNode(){
  const nodes=topology?.nodes||[];
  const exact=nodes.find(n=>{
    const values=[n.shortName,n.longName,n.name].filter(Boolean).map(v=>String(v).trim().toUpperCase());
    return values.includes('VHF3');
  }) || nodes.find(n=>{
    const values=[n.shortName,n.longName,n.name].filter(Boolean).map(v=>String(v).trim().toUpperCase());
    return values.some(v=>v.includes('VHF3'));
  });
  if(exact&&Number.isFinite(Number(exact.latitude))&&Number.isFinite(Number(exact.longitude)))return exact;
  return null;
}
function nodeTableRows(){
  const ref=nodesReferenceNode();
  return (topology?.nodes||[]).map(n=>{
    const interaction=nodeLastTrafficMs(n);
    const position=toNodeMs(n.positionTimestamp);
    const distance=ref?haversineKm(ref.latitude,ref.longitude,n.latitude,n.longitude):null;
    return {
      raw:n,
      longName:n.longName||n.name||n.nodeId||'',
      shortName:n.shortName||'',
      role:roleFriendly(n.role)||'',
      hardware:hardwareFriendly(n.hwModel)||'',
      hops:nodeHas(n.hopsAway)?Number(n.hopsAway):null,
      battery:nodeHas(n.batteryLevel)?Number(n.batteryLevel):null,
      voltage:nodeHas(n.voltage)?Number(n.voltage):null,
      distance:Number.isFinite(distance)?distance:null,
      snr:nodeHas(n.snr)?Number(n.snr):null,
      lastInteraction:interaction||0,
      lastPosition:position||0,
      rssi:nodeHas(n.rssi)?Number(n.rssi):null,
      channelUtilization:nodeHas(n.channelUtilization)?Number(n.channelUtilization):null,
      airUtilTx:nodeHas(n.airUtilTx)?Number(n.airUtilTx):null,
      nodeId:n.nodeId||'',
      pkc:n.hasPKC===true?1:(n.hasPKC===false?0:null),
      state:n.state||''
    };
  });
}
function nodesCompare(a,b,key,dir=1){
  const av=a[key],bv=b[key];
  const missingA=av===null||av===undefined||av===''||((key==='lastInteraction'||key==='lastPosition')&&av===0);
  const missingB=bv===null||bv===undefined||bv===''||((key==='lastInteraction'||key==='lastPosition')&&bv===0);
  if(missingA!==missingB)return missingA?1:-1;
  let cmp=0;
  if(typeof av==='number'&&typeof bv==='number')cmp=av-bv;
  else cmp=String(av??'').localeCompare(String(bv??''),uiLocale(),{numeric:true,sensitivity:'base'});
  return cmp*dir;
}
function renderNodesSortIndicators(){
  document.querySelectorAll('#nodesTable th[data-node-sort]').forEach(th=>{
    let marker=th.querySelector('.nodesSort');
    if(!marker){marker=document.createElement('span');marker.className='nodesSort';th.appendChild(marker);}
    marker.textContent=th.dataset.nodeSort===nodesSortKey?(nodesSortDir==='asc'?'▲':'▼'):'';
  });
}
function loadNodesColumnPrefs(){
  try{
    const raw=JSON.parse(localStorage.getItem(NODES_COLUMNS_KEY)||'[]');
    nodesOptionalColumns=new Set(Array.isArray(raw)?raw:[]);
  }catch{nodesOptionalColumns=new Set();}
  document.querySelectorAll('[data-node-column]').forEach(cb=>{cb.checked=nodesOptionalColumns.has(cb.dataset.nodeColumn);});
  applyNodesColumns();
}
function applyNodesColumns(){
  const table=document.getElementById('nodesTable');if(!table)return;
  table.className='nodesTable '+[...nodesOptionalColumns].map(x=>`nodesShow-${x}`).join(' ');
}
function saveNodesColumnPrefs(){
  localStorage.setItem(NODES_COLUMNS_KEY,JSON.stringify([...nodesOptionalColumns]));
  applyNodesColumns();
}
function mapSearchFields(n){
  // O índice usa a mesma normalização da aba Nós, mas somente nomes/IDs.
  const aliases=Array.isArray(n?.nameAliases)?n.nameAliases:[];
  return [n?.name,n?.longName,n?.shortName,n?.customName,n?.originalName,
    n?.factoryName,n?.defaultName,n?.nodeId,n?.nodeNum,...aliases]
    .filter(x=>x!==null&&x!==undefined&&x!=='').map(nodesNormalizeText);
}
function mapSearchMatches(){
  const needle=nodesNormalizeText(mapSearchText).trim();
  if(!needle)return topology?.nodes||[];
  return (topology?.nodes||[]).filter(n=>mapSearchFields(n).some(x=>x.includes(needle)));
}
function renderMapSearchResults(){
  const panel=document.getElementById('mapSearchPanel'),results=document.getElementById('mapSearchMatches'),count=document.getElementById('mapSearchCount');
  if(!panel||!results||!count)return;
  const matches=mapSearchMatches();
  count.textContent=mapSearchText.trim()?matches.length+' de '+(topology?.nodes?.length||0):'Todos os nós';
  if(!mapSearchText.trim()){results.hidden=true;results.innerHTML='';return;}
  results.hidden=false;
  results.innerHTML=matches.slice(0,15).map(n=>{
    const pos=nodeHasValidMapPosition(n),historical=Boolean(n.historical);
    const name=n.name||n.longName||n.shortName||n.nodeId||'Nó desconhecido';
    const other=[n.shortName&&n.shortName!==name?n.shortName:null,n.nodeId].filter(Boolean).join(' · ');
    return '<button type="button" data-map-search-node="'+Number(n.nodeNum)+'">'+
      '<strong>'+esc(name)+'</strong><small>'+esc(other)+
      ' · '+esc(!pos?'Sem localização':historical?'Posição histórica':'Com posição')+'</small></button>';
  }).join('')||'<div style="padding:10px;color:#d8b6a4">Nenhum nó encontrado.</div>';
  results.querySelectorAll('[data-map-search-node]').forEach(btn=>btn.addEventListener('click',()=>focusMapSearchNode(Number(btn.dataset.mapSearchNode))));
  positionMapToolbarPopovers();
}
function updateMapSearch(next,updateRoute=true){
  mapSearchText=String(next??'').slice(0,120);
  if(openNodeNum!==null)closeNodeWindow(false);
  const field=document.getElementById('mapSearchInput');if(field&&field.value!==mapSearchText)field.value=mapSearchText;
  mapSearchHighlightLayer.clearLayers();
  render();
  renderMapSearchResults();
  if(updateRoute)taSyncRoute({replace:true,view:'map'});
}
function focusMapSearchNode(nodeNum,updateRoute=true){
  const n=(topology?.nodes||[]).find(x=>Number(x.nodeNum)===Number(nodeNum));
  if(!n)return;
  setView('map',false);
  if(nodeHasValidMapPosition(n)){
    const point=L.latLng(Number(n.latitude),Number(n.longitude));
    map.setView(point,Math.max(map.getZoom(),14),{animate:true});
    mapSearchHighlightLayer.clearLayers();
    L.circleMarker(point,{radius:19,weight:4,color:'#ffe66d',fillColor:'#ffe66d',fillOpacity:.05,
      interactive:false,className:'mapSearchPulse'}).addTo(mapSearchHighlightLayer);
    if(mapSearchHintTimer)clearTimeout(mapSearchHintTimer);
    mapSearchHintTimer=setTimeout(()=>mapSearchHighlightLayer.clearLayers(),7600);
    const status=document.getElementById('mapSearchCount');
    if(status)status.textContent=n.historical?'Posição histórica · '+(n.nodeId||''):'Nó destacado · '+(n.nodeId||'');
  }else{
    const status=document.getElementById('mapSearchCount');
    if(status)status.textContent='Sem coordenadas · '+(n.nodeId||'');
  }
  document.getElementById('mapSearchMatches').hidden=true;
  openNodeWindow(nodeNum,false);
  if(updateRoute)taSyncRoute({view:'map'});
}
function positionMapToolbarPopovers(){
  const margin=7, viewportW=document.documentElement.clientWidth;
  const results=document.getElementById('mapSearchMatches');
  const input=document.getElementById('mapSearchInput');
  if(results&&!results.hidden&&input){
    const rect=input.getBoundingClientRect(),width=results.getBoundingClientRect().width||385;
    results.style.left=Math.round(Math.max(margin,Math.min(rect.left,viewportW-width-margin)))+'px';
    results.style.top=Math.round(rect.bottom+5)+'px';
  }
  const layers=document.querySelector('#mapLayersMenu .mapLayersPanel');
  const anchor=document.getElementById('mapLayersMenu');
  if(layers&&anchor&&anchor.open){
    const rect=anchor.getBoundingClientRect(),width=layers.getBoundingClientRect().width||230;
    layers.style.left=Math.round(Math.max(margin,Math.min(rect.right-width,viewportW-width-margin)))+'px';
    layers.style.top=Math.round(rect.bottom+5)+'px';
  }
}
function initMapSearch(){
  const field=document.getElementById('mapSearchInput');
  field.addEventListener('input',()=>updateMapSearch(field.value));
  field.addEventListener('keydown',event=>{
    if(event.key==='Escape'){event.preventDefault();updateMapSearch('');field.focus();}
    if(event.key==='Enter'){const matches=mapSearchMatches();if(matches.length===1){event.preventDefault();focusMapSearchNode(Number(matches[0].nodeNum));}}
  });
  document.getElementById('mapSearchClear').addEventListener('click',()=>{updateMapSearch('');field.focus();});
  const playback=document.getElementById('playback');
  playback.addEventListener('scroll',positionMapToolbarPopovers,{passive:true});
  window.addEventListener('resize',positionMapToolbarPopovers,{passive:true});
  document.getElementById('mapLayersMenu').addEventListener('toggle',positionMapToolbarPopovers);
}
initMapSearch();

const NODE_CTX_FAVORITES_KEY='trafficAnalyzerNodeFavoritesV165';
const NODE_CTX_HIDDEN_KEY='trafficAnalyzerNodeHiddenV165';
function nodeCtxReadSet(key){
  try{return new Set((JSON.parse(localStorage.getItem(key)||'[]')||[]).map(Number).filter(Number.isFinite));}
  catch{return new Set();}
}
function nodeCtxWriteSet(key,set){localStorage.setItem(key,JSON.stringify([...set]));}
function nodeCtxNode(nodeNum){return (topology?.nodes||[]).find(x=>Number(x.nodeNum)===Number(nodeNum))||null;}
function nodeCtxToast(message){
  const el=document.getElementById('flowToast');
  if(el){el.className='flowKnown';el.textContent=String(message);el.style.display='block';setTimeout(()=>{el.style.display='none';},4500);}
  else alert(String(message));
}
function closeNodeContextMenu(){
  document.getElementById('nodeContextMenuV165')?.remove();
}
function nodeCtxButton(menu,label,handler,{danger=false,disabled=false,title=''}={}){
  const b=document.createElement('button');b.type='button';b.textContent=label;b.disabled=disabled;b.title=title;
  Object.assign(b.style,{display:'block',width:'100%',textAlign:'left',padding:'8px 10px',border:'0',borderBottom:'1px solid #314353',background:danger?'#4b2026':'#172532',color:'#e8edf2',cursor:disabled?'not-allowed':'pointer',fontSize:'14px',lineHeight:'1.25'});
  if(!disabled)b.addEventListener('click',async()=>{closeNodeContextMenu();try{await handler();}catch(e){nodeCtxToast(e?.message||e);}});
  menu.appendChild(b);return b;
}
function nodeCtxSeparator(menu,label=''){
  const d=document.createElement('div');d.textContent=label;
  Object.assign(d.style,{padding:label?'5px 9px':'2px 0',fontSize:'10px',fontWeight:'700',color:'#8fa5b7',background:'#101a23',borderBottom:'1px solid #314353',textTransform:label?'uppercase':'none'});
  menu.appendChild(d);
}
async function nodeCtxCopy(text,label='Copiado'){
  await navigator.clipboard.writeText(String(text??''));nodeCtxToast(label);
}
function nodeCtxAllInfo(n){
  const raw=n||{};return [
    ['Nome longo',raw.longName||raw.name],['Nome curto',raw.shortName],['Node ID',raw.nodeId],
    ['Node num',raw.nodeNum],['Role',raw.role],['Hardware',raw.hwModel||raw.hardware],
    ['Latitude',raw.latitude],['Longitude',raw.longitude],['Altitude',raw.altitude],
    ['Último contato',raw.lastHeard],['SNR',raw.snr],['RSSI',raw.rssi]
  ].filter(x=>x[1]!==null&&x[1]!==undefined&&String(x[1])!=='').map(x=>x[0]+': '+x[1]).join('\n');
}
function nodeCtxCenter(n){
  if(nodeHasValidMapPosition(n)){setView('map');map.setView([Number(n.latitude),Number(n.longitude)],Math.max(map.getZoom(),14));openNodeWindow(Number(n.nodeNum));}
  else throw new Error('Este nó não possui posição válida conhecida.');
}
function nodeCtxViewTraffic(n){
  setView('traffic');
  const field=document.getElementById('trafficSearch');
  if(field)field.value=String(n.nodeId||n.shortName||n.longName||n.nodeNum||'');
  renderTraffic();taSyncRoute({replace:true,view:'traffic'});
}
async function nodeCtxPrivateMessage(n){
  const text=prompt('Mensagem privada para '+String(n.longName||n.name||n.nodeId||n.nodeNum)+':','');
  if(text===null||!String(text).trim())return;
  if(!authCanWrite()){openAuthModal();return;}
  const r=await authFetch('/api/messages/private',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nodeNum:Number(n.nodeNum),text:String(text)})});
  const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||b.error||('HTTP '+r.status));
  nodeCtxToast('Mensagem privada encaminhada'+(b.packetId?' · packet '+b.packetId:''));
}
async function nodeCtxPing(n){
  if(!authCanWrite()){openAuthModal();return;}
  const r=await authFetch('/api/node-ping',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nodeNum:Number(n.nodeNum)})});
  const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||b.error||('HTTP '+r.status));
  nodeCtxToast('PING encaminhado'+(b.packetId?' · packet '+b.packetId:''));
}
async function nodeCtxDeleteEverywhere(n){
  const label=String(n.longName||n.name||n.nodeId||n.nodeNum);
  if(!confirm('Excluir '+label+' da base local E da lista de nós do dispositivo Meshtastic conectado?\n\nEsta ação tentará as duas exclusões e mostrará o resultado de cada uma.'))return;
  if(!authCanWrite()){openAuthModal();return;}
  const r=await authFetch('/api/node-delete-everywhere',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nodeNum:Number(n.nodeNum)})});
  const b=await r.json();
  if(!r.ok)throw new Error(b.message||b.error||('HTTP '+r.status));
  const hidden=nodeCtxReadSet(NODE_CTX_HIDDEN_KEY);hidden.delete(Number(n.nodeNum));nodeCtxWriteSet(NODE_CTX_HIDDEN_KEY,hidden);
  const favorites=nodeCtxReadSet(NODE_CTX_FAVORITES_KEY);favorites.delete(Number(n.nodeNum));nodeCtxWriteSet(NODE_CTX_FAVORITES_KEY,favorites);
  closeNodeWindow();closeNodeDetailsModal(false);await load(false);
  const local=b.localDeleted?'base local: excluído':'base local: falhou';
  const device=b.deviceDeleted?'dispositivo: excluído':'dispositivo: falhou'+(b.deviceError?' ('+b.deviceError+')':'');
  nodeCtxToast((b.success?'Exclusão concluída. ':'Exclusão parcial. ')+local+' · '+device);
}
async function nodeCtxDeleteLocal(n){
  const label=String(n.longName||n.name||n.nodeId||n.nodeNum);
  if(!confirm('Excluir '+label+' somente do banco local do Traffic Analyzer?\n\nO nó poderá reaparecer se for recebido novamente do MeshMonitor.'))return;
  if(!authCanWrite()){openAuthModal();return;}
  const r=await authFetch('/api/node-local-delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nodeNum:Number(n.nodeNum)})});
  const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||b.error||('HTTP '+r.status));
  const hidden=nodeCtxReadSet(NODE_CTX_HIDDEN_KEY);hidden.delete(Number(n.nodeNum));nodeCtxWriteSet(NODE_CTX_HIDDEN_KEY,hidden);
  closeNodeWindow();closeNodeDetailsModal(false);await load(false);nodeCtxToast('Nó removido do banco local.');
}
async function nodeCtxSetFavorite(n,enabled){
  if(!authCanWrite()){openAuthModal();return;}
  const r=await authFetch('/api/node-favorite',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nodeNum:Number(n.nodeNum),favorite:Boolean(enabled)})});
  const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||b.error||('HTTP '+r.status));
  const s=nodeCtxReadSet(NODE_CTX_FAVORITES_KEY);enabled?s.add(Number(n.nodeNum)):s.delete(Number(n.nodeNum));nodeCtxWriteSet(NODE_CTX_FAVORITES_KEY,s);
  nodeCtxToast(enabled?'Favorito salvo também no dispositivo Meshtastic.':'Favorito removido também do dispositivo Meshtastic.');
}
function showNodeContextMenu(n,x,y,source='map'){
  closeNodeContextMenu();
  const menu=document.createElement('div');menu.id='nodeContextMenuV165';
  Object.assign(menu.style,{position:'fixed',zIndex:'10050',left:Math.max(4,Math.min(Number(x)||4,window.innerWidth-280))+'px',top:Math.max(4,Math.min(Number(y)||4,window.innerHeight-500))+'px',width:'270px',maxHeight:'calc(100vh - 12px)',overflowY:'auto',background:'#172532',border:'1px solid #496176',borderRadius:'7px',boxShadow:'0 10px 30px rgba(0,0,0,.45)'});
  const title=document.createElement('div');title.textContent=String(n.longName||n.name||n.nodeId||n.nodeNum);
  Object.assign(title.style,{padding:'8px 10px',fontWeight:'800',fontSize:'12px',background:'#101a23',borderBottom:'1px solid #496176'});menu.appendChild(title);
  nodeCtxButton(menu,'🗑 Excluir da base e do dispositivo',()=>nodeCtxDeleteEverywhere(n),{danger:true});
  nodeCtxButton(menu,'✉ Enviar mensagem privada',()=>nodeCtxPrivateMessage(n));
  nodeCtxSeparator(menu,'Consultas');
  nodeCtxButton(menu,'ℹ Solicitar Node Info',()=>sendNodeQuery(Number(n.nodeNum),'nodeinfo'));
  nodeCtxButton(menu,'⌖ Solicitar posição',()=>sendNodeQuery(Number(n.nodeNum),'position'));
  nodeCtxButton(menu,'⚡ Solicitar telemetria de energia',()=>sendNodeQuery(Number(n.nodeNum),'telemetry_power'));
  nodeCtxButton(menu,'▣ Solicitar telemetria do dispositivo',()=>sendNodeQuery(Number(n.nodeNum),'telemetry_device'));
  nodeCtxButton(menu,'⇢ Executar Traceroute',()=>sendNodeQuery(Number(n.nodeNum),'traceroute'));
  nodeCtxButton(menu,'● Executar Ping',()=>nodeCtxPing(n));
  nodeCtxSeparator(menu,'Nó');
  const fav=nodeCtxReadSet(NODE_CTX_FAVORITES_KEY),isFav=fav.has(Number(n.nodeNum));
  nodeCtxButton(menu,isFav?'★ Remover dos favoritos':'☆ Adicionar aos favoritos',()=>nodeCtxSetFavorite(n,!isFav));
  nodeCtxButton(menu,'▤ Abrir detalhes do nó',()=>{source==='nodes'?openNodeDetailsModal(Number(n.nodeNum)):openNodeWindow(Number(n.nodeNum));});
  nodeCtxButton(menu,'◎ Centralizar no mapa',()=>nodeCtxCenter(n));
  nodeCtxButton(menu,'☷ Ver tráfego deste nó',()=>nodeCtxViewTraffic(n));
  nodeCtxSeparator(menu,'Copiar');
  nodeCtxButton(menu,'Copiar nome longo',()=>nodeCtxCopy(n.longName||n.name||'','Nome longo copiado.'));
  nodeCtxButton(menu,'Copiar nome curto',()=>nodeCtxCopy(n.shortName||'','Nome curto copiado.'));
  nodeCtxButton(menu,'Copiar ID',()=>nodeCtxCopy(n.nodeId||'','Node ID copiado.'));
  nodeCtxButton(menu,'Copiar coordenadas',()=>nodeCtxCopy(nodeHasValidMapPosition(n)?Number(n.latitude).toFixed(6)+', '+Number(n.longitude).toFixed(6):'','Coordenadas copiadas.'));
  nodeCtxButton(menu,'Copiar todas as informações',()=>nodeCtxCopy(nodeCtxAllInfo(n),'Informações do nó copiadas.'));
  nodeCtxSeparator(menu,'Visualização / banco');
  const hidden=nodeCtxReadSet(NODE_CTX_HIDDEN_KEY),isHidden=hidden.has(Number(n.nodeNum));
  nodeCtxButton(menu,isHidden?'Mostrar nó no mapa':'Ocultar nó do mapa',()=>{const s=nodeCtxReadSet(NODE_CTX_HIDDEN_KEY);isHidden?s.delete(Number(n.nodeNum)):s.add(Number(n.nodeNum));nodeCtxWriteSet(NODE_CTX_HIDDEN_KEY,s);render();});
  nodeCtxButton(menu,'⚙ Criar automação para este nó',()=>{setView('automations');nodeCtxToast('Automação por nó: use a aba Automações; agendamento específico por nó permanece no backlog.');});
  nodeCtxButton(menu,'🗑 Excluir nó do banco local',()=>nodeCtxDeleteLocal(n),{danger:true});
  document.body.appendChild(menu);
  const close=e=>{if(!menu.contains(e.target)){closeNodeContextMenu();document.removeEventListener('pointerdown',close,true);}};
  setTimeout(()=>document.addEventListener('pointerdown',close,true),0);
  menu.addEventListener('contextmenu',e=>e.preventDefault());
}
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeNodeContextMenu();});
map.on('movestart zoomstart',closeNodeContextMenu);

function nodesNormalizeText(value){
  return String(value??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
}
function nodeMatchesFilter(row){
  const q=nodesNormalizeText(nodesFilterText).trim();
  if(!q)return true;
  const n=row.raw||{};
  const hay=[
    row.longName,row.shortName,row.role,row.hardware,row.hops,row.battery,row.voltage,row.distance,row.snr,
    row.rssi,row.channelUtilization,row.airUtilTx,row.nodeId,row.state,
    n.name,n.nodeNum,n.firmwareVersion
  ].map(nodesNormalizeText).join(' ');
  return hay.includes(q);
}
function batteryClass(value){
  const n=Number(value);
  if(!Number.isFinite(n))return '';
  if(n<20)return 'batteryBad';
  if(n<50)return 'batteryWarn';
  return 'batteryGood';
}
function renderNodesTable(){
  const body=document.getElementById('nodesRows');if(!body||!topology)return;
  const known=new Set((topology.nodes||[]).map(n=>Number(n.nodeNum)));
  for(const num of [...nodesSelected])if(!known.has(num))nodesSelected.delete(num);
  const allRows=nodeTableRows();
  const rows=allRows.filter(nodeMatchesFilter);
  rows.sort((a,b)=>nodesCompare(a,b,nodesSortKey,nodesSortDir==='asc'?1:-1));
  const ref=nodesReferenceNode();
  const countText=nodesFilterText.trim()?`${rows.length} de ${allRows.length}`:`${allRows.length}`;
  document.getElementById('nodesSummary').textContent=`${countText} ${tr('nós conhecidos')}${ref?` · ${tr('Distância')}: VHF3`:` · ${tr('VHF3 sem posição')}`}`;
  body.innerHTML=rows.map(x=>{
    const n=x.raw,ageCls=nodeAgeClass(x.lastInteraction);
    const interaction=x.lastInteraction?compactAgeFromMs(x.lastInteraction):'—';
    const position=x.lastPosition?compactAgeFromMs(x.lastPosition):'—';
    const num=Number(n.nodeNum),sel=nodesSelected.has(num);
    return `<tr data-node-num="${num}" tabindex="0" class="${sel?'nodeSelected':''}" aria-selected="${sel}" title="${esc(tr('Clique para selecionar · duplo clique para abrir os detalhes'))}">`+
      `<td class="nodeSelectCol"><input type="checkbox" data-node-select ${sel?'checked':''} aria-label="${esc(tr('Selecionar nó'))}"><button type="button" class="nodeOpenBtn" data-node-open title="${esc(tr('Abrir detalhes do nó'))}">▤</button></td>`+
      `<td class="nodeNameCell">${esc(x.longName||'—')}</td><td>${esc(x.shortName||'—')}</td><td>${esc(x.role||'—')}</td><td>${esc(x.hardware||'—')}</td>`+
      `<td>${x.hops==null?'—':esc(x.hops)}</td><td>${x.battery==null?'—':`<span class="${batteryClass(x.battery)}">${esc(nodeFmtPercent(x.battery))}</span>`}</td><td>${x.voltage==null?'—':esc(nodeFmtNum(x.voltage,2)+' V')}</td>`+
      `<td>${x.distance==null?'—':esc(`${x.distance.toLocaleString(uiLocale(),{minimumFractionDigits:x.distance<10?1:0,maximumFractionDigits:1})} km`)}</td>`+
      `<td>${x.snr==null?'—':esc(`${x.snr.toLocaleString(uiLocale(),{minimumFractionDigits:1,maximumFractionDigits:1})} dB`)}</td>`+
      `<td><span class="nodeAge ${ageCls}"><span class="nodeAgeDot"></span>${esc(interaction)}</span></td><td>${esc(position)}</td>`+
      `<td class="nodeOptional col-rssi">${x.rssi==null?'—':esc(`${x.rssi} dBm`)}</td>`+
      `<td class="nodeOptional col-channelUtilization">${x.channelUtilization==null?'—':esc(nodeFmtPercent(x.channelUtilization))}</td>`+
      `<td class="nodeOptional col-airUtilTx">${x.airUtilTx==null?'—':esc(nodeFmtPercent(x.airUtilTx))}</td>`+
      `<td class="nodeOptional col-nodeId">${esc(x.nodeId||'—')}</td><td class="nodeOptional col-pkc">${x.pkc==null?'—':(x.pkc?'✓':'—')}</td><td class="nodeOptional col-state">${esc(x.state||'—')}</td></tr>`;
  }).join('')||'<tr><td colspan="18">Nenhum nó disponível.</td></tr>';
  nodesVisibleOrder=rows.map(x=>Number(x.raw.nodeNum));
  body.querySelectorAll('tr[data-node-num]').forEach(tr=>{
    const num=Number(tr.dataset.nodeNum);
    tr.addEventListener('click',event=>{
      if(event.target.closest('[data-node-open]')){event.stopPropagation();openNodeFromList(num);return;}
      nodesSelectClick(num,event);
    });
    tr.addEventListener('dblclick',event=>{
      if(event.target.closest('[data-node-select],[data-node-open]'))return;
      window.getSelection?.().removeAllRanges?.();openNodeFromList(num);
    });
    tr.addEventListener('keydown',event=>{
      if(event.target!==tr)return;
      if(event.key==='Enter'){event.preventDefault();openNodeFromList(num);}
      else if(event.key===' '){event.preventDefault();nodesSelectClick(num,event);}
    });
    tr.addEventListener('contextmenu',event=>{
      event.preventDefault();event.stopPropagation();
      if(nodesSelected.size>1&&nodesSelected.has(num)){showNodesBulkMenu(event.clientX,event.clientY);return;}
      const n=(topology?.nodes||[]).find(x=>Number(x.nodeNum)===num);
      if(n)showNodeContextMenu(n,event.clientX,event.clientY,'nodes');
    });
  });
  updateNodesBulkBar();
  renderNodesSortIndicators();
}
function closeNodeDetailsModal(updateRoute=true){
  if(Number.isFinite(Number(nodeDetailsModalNodeNum)))stopNodePolling(Number(nodeDetailsModalNodeNum));
  nodeDetailsModalNodeNum=null;
  document.getElementById('nodeDetailsBackdrop')?.classList.remove('open');
  if(updateRoute && taActiveView()==='nodes')taSyncRoute({replace:true,view:'nodes'});
}
let nodeDetailsModalNodeNum=null;
function openNodeDetailsModal(nodeNum,updateRoute=true){
  const n=(topology?.nodes||[]).find(x=>Number(x.nodeNum)===Number(nodeNum));if(!n)return;
  closeNodeWindow();
  map.closePopup();
  nodeDetailsModalNodeNum=Number(nodeNum);
  const body=document.getElementById('nodeDetailsModalBody');
  if(body){
    body.innerHTML=nodePopupHtml(n,false);
    body.scrollTop=0;
    const run=nodeQueryRun(nodeNum);
    if(run.details)renderNodePopupData(nodeNum,run.details);
  }
  document.getElementById('nodeDetailsBackdrop')?.classList.add('open');
  if(updateRoute)taSyncRoute({view:'nodes'});
  loadNodeDetails(nodeNum,true).catch(e=>{
    const el=document.getElementById(`nodeTelemetry-${Number(nodeNum)}`);
    if(el)el.innerHTML=`<span class="nodeMetaMissing">Não foi possível carregar dados do MeshMonitor: ${esc(e.message||e)}</span>`;
  });
}
function openNodeFromList(nodeNum){openNodeDetailsModal(nodeNum);}
// Seleção múltipla da aba Nós: clique marca/desmarca, Shift+clique seleciona intervalo,
// duplo clique (ou ▤/Enter) abre os detalhes.
const nodesSelected=new Set();
let nodesVisibleOrder=[],nodesSelectAnchor=null;
const NODE_BULK_RF_MAX=10,NODE_BULK_RF_GAP_MS=4000;
function nodesSelectClick(num,event){
  if(event.shiftKey&&nodesSelectAnchor!=null&&nodesVisibleOrder.includes(nodesSelectAnchor)){
    const a=nodesVisibleOrder.indexOf(nodesSelectAnchor),b=nodesVisibleOrder.indexOf(num);
    const on=nodesSelected.has(nodesSelectAnchor);
    for(const n of nodesVisibleOrder.slice(Math.min(a,b),Math.max(a,b)+1))on?nodesSelected.add(n):nodesSelected.delete(n);
  }else{
    nodesSelected.has(num)?nodesSelected.delete(num):nodesSelected.add(num);
    nodesSelectAnchor=num;
  }
  syncNodesSelectionRows();
}
function syncNodesSelectionRows(){
  document.querySelectorAll('#nodesRows tr[data-node-num]').forEach(tr=>{
    const sel=nodesSelected.has(Number(tr.dataset.nodeNum));
    tr.classList.toggle('nodeSelected',sel);tr.setAttribute('aria-selected',String(sel));
    const cb=tr.querySelector('[data-node-select]');if(cb)cb.checked=sel;
  });
  updateNodesBulkBar();
}
function updateNodesBulkBar(){
  const count=nodesSelected.size,bar=document.getElementById('nodesBulkBar');
  if(bar)bar.hidden=count===0;
  const label=document.getElementById('nodesBulkCount');
  if(label)label.textContent=count===1?tr('1 nó selecionado'):`${count} ${tr('nós selecionados')}`;
  const all=document.getElementById('nodesSelectAll');
  if(all){
    const visible=nodesVisibleOrder.filter(n=>nodesSelected.has(n)).length;
    all.checked=visible>0&&visible===nodesVisibleOrder.length;
    all.indeterminate=visible>0&&visible<nodesVisibleOrder.length;
  }
}
function nodesSelectedList(){return [...nodesSelected].map(nodeCtxNode).filter(Boolean);}
function nodesBulkLabel(nodes){
  const names=nodes.slice(0,12).map(n=>'• '+String(n.longName||n.name||n.nodeId||n.nodeNum));
  return names.join('\n')+(nodes.length>12?`\n… e mais ${nodes.length-12}`:'');
}
async function nodesBulkFavorite(nodes,enabled){
  if(!authCanWrite()){openAuthModal();return;}
  let ok=0;const failed=[];
  for(const n of nodes){
    try{
      const r=await authFetch('/api/node-favorite',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nodeNum:Number(n.nodeNum),favorite:enabled})});
      const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||b.error||('HTTP '+r.status));
      const s=nodeCtxReadSet(NODE_CTX_FAVORITES_KEY);enabled?s.add(Number(n.nodeNum)):s.delete(Number(n.nodeNum));nodeCtxWriteSet(NODE_CTX_FAVORITES_KEY,s);ok++;
    }catch(e){failed.push(String(n.shortName||n.nodeId||n.nodeNum)+': '+(e.message||e));}
  }
  nodeCtxToast(`${enabled?'Favoritados':'Desfavoritados'}: ${ok} de ${nodes.length}`+(failed.length?` · falhas: ${failed.join('; ')}`:''));
}
function nodesBulkHide(nodes,hide){
  const s=nodeCtxReadSet(NODE_CTX_HIDDEN_KEY);
  for(const n of nodes)hide?s.add(Number(n.nodeNum)):s.delete(Number(n.nodeNum));
  nodeCtxWriteSet(NODE_CTX_HIDDEN_KEY,s);render();
  nodeCtxToast(`${nodes.length} ${hide?'nó(s) ocultado(s) no mapa':'nó(s) visível(is) no mapa'}.`);
}
async function nodesBulkQuery(nodes,action){
  if(!authCanWrite()){openAuthModal();return;}
  if(nodes.length>NODE_BULK_RF_MAX){alert(`Consultas por RF em lote são limitadas a ${NODE_BULK_RF_MAX} nós por vez, para não congestionar a malha.`);return;}
  const label=action==='traceroute'?'Traceroute':'Node Info';
  if(!confirm(`Enviar ${label} por RF para ${nodes.length} nó(s), um a cada ${NODE_BULK_RF_GAP_MS/1000} s?\n\n${nodesBulkLabel(nodes)}`))return;
  let ok=0;const failed=[];
  for(const [i,n] of nodes.entries()){
    nodeCtxToast(`${label} ${i+1}/${nodes.length}: ${String(n.shortName||n.longName||n.nodeId)}…`);
    try{
      const r=await authFetch('/api/node-query',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nodeNum:Number(n.nodeNum),action})});
      const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||b.error||('HTTP '+r.status));ok++;
    }catch(e){failed.push(String(n.shortName||n.nodeId||n.nodeNum)+': '+(e.message||e));}
    if(i<nodes.length-1)await new Promise(res=>setTimeout(res,NODE_BULK_RF_GAP_MS));
  }
  nodeCtxToast(`${label} enviado para ${ok} de ${nodes.length}. Respostas chegam pela malha.`+(failed.length?` Falhas: ${failed.join('; ')}`:''));
}
function nodesBulkCsv(nodes){
  const nums=new Set(nodes.map(n=>Number(n.nodeNum)));
  const rows=nodeTableRows().filter(x=>nums.has(Number(x.raw.nodeNum)));
  const cols=[['Nome longo',x=>x.longName],['Nome curto',x=>x.shortName],['Node ID',x=>x.nodeId||x.raw.nodeId],['nodeNum',x=>x.raw.nodeNum],
    ['Role',x=>x.role],['Hardware',x=>x.hardware],['Saltos',x=>x.hops],['Bateria',x=>x.battery],['Tensão',x=>x.voltage],['SNR',x=>x.snr],
    ['Distância km',x=>x.distance==null?'':x.distance.toFixed(2)],['Última interação',x=>x.lastInteraction?new Date(x.lastInteraction).toISOString():''],
    ['Latitude',x=>x.raw.latitude],['Longitude',x=>x.raw.longitude]];
  const cell=v=>{const t=String(v??'');return /[",;\n]/.test(t)?'"'+t.replace(/"/g,'""')+'"':t;};
  const csv='﻿'+[cols.map(c=>cell(c[0])).join(';'),...rows.map(x=>cols.map(c=>cell(c[1](x))).join(';'))].join('\r\n');
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  a.download=`nos-traffic-analyzer-${new Date().toISOString().slice(0,10)}.csv`;document.body.appendChild(a);a.click();
  setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},1000);
  nodeCtxToast(`${rows.length} nó(s) exportado(s) em CSV.`);
}
async function nodesBulkDelete(nodes,scope){
  if(!authCanWrite()){openAuthModal();return;}
  const where=scope==='local'?'somente do banco local do Traffic Analyzer':'da base local E da lista de nós do dispositivo Meshtastic';
  if(!confirm(`Excluir ${nodes.length} nó(s) ${where}?\n\n${nodesBulkLabel(nodes)}\n\nO resultado de cada nó será mostrado ao final.`))return;
  nodeCtxToast(`Excluindo ${nodes.length} nó(s)…`);
  const r=await authFetch('/api/nodes-bulk-delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nodeNums:nodes.map(n=>Number(n.nodeNum)),scope})});
  const b=await r.json();if(!r.ok||!Array.isArray(b.results))throw new Error(b.message||b.error||('HTTP '+r.status));
  const hidden=nodeCtxReadSet(NODE_CTX_HIDDEN_KEY),favorites=nodeCtxReadSet(NODE_CTX_FAVORITES_KEY);
  for(const x of b.results)if(x.localDeleted){hidden.delete(Number(x.nodeNum));favorites.delete(Number(x.nodeNum));nodesSelected.delete(Number(x.nodeNum));}
  nodeCtxWriteSet(NODE_CTX_HIDDEN_KEY,hidden);nodeCtxWriteSet(NODE_CTX_FAVORITES_KEY,favorites);
  closeNodeDetailsModal(false);await load(false);
  const failed=b.results.filter(x=>!x.success).map(x=>{
    const n=nodeCtxNode(x.nodeNum)||nodes.find(y=>Number(y.nodeNum)===Number(x.nodeNum))||{};
    const parts=[];if(!x.localDeleted)parts.push('base local: '+(x.localError||'falhou'));if(scope!=='local'&&!x.deviceDeleted)parts.push('dispositivo: '+(x.deviceError||'falhou'));
    return String(n.shortName||n.longName||n.nodeId||x.nodeNum)+' ('+parts.join(', ')+')';
  });
  const msg=`Exclusão: ${b.succeeded} de ${b.total} concluída(s).`+(failed.length?`\n\nCom falha:\n${failed.join('\n')}`:'');
  nodeCtxToast(msg.split('\n')[0]);if(failed.length)alert(msg);
}
async function runNodesBulk(action){
  const nodes=nodesSelectedList();
  if(action==='clear'){nodesSelected.clear();syncNodesSelectionRows();return;}
  if(!nodes.length)return;
  try{
    if(action==='favorite'||action==='unfavorite')await nodesBulkFavorite(nodes,action==='favorite');
    else if(action==='hide'||action==='show')nodesBulkHide(nodes,action==='hide');
    else if(action==='nodeinfo'||action==='traceroute')await nodesBulkQuery(nodes,action);
    else if(action==='copy')await nodeCtxCopy(nodes.map(n=>`${n.nodeId||''}\t${n.longName||n.name||''}`).join('\n'),`${nodes.length} ID(s) copiado(s).`);
    else if(action==='csv')nodesBulkCsv(nodes);
    else if(action==='deleteLocal')await nodesBulkDelete(nodes,'local');
    else if(action==='deleteEverywhere')await nodesBulkDelete(nodes,'everywhere');
  }catch(e){nodeCtxToast(String(e?.message||e));}
}
function showNodesBulkMenu(x,y){
  closeNodeContextMenu();
  const menu=document.createElement('div');menu.id='nodeContextMenuV165';
  Object.assign(menu.style,{position:'fixed',zIndex:'10050',left:Math.max(4,Math.min(Number(x)||4,window.innerWidth-280))+'px',top:Math.max(4,Math.min(Number(y)||4,window.innerHeight-460))+'px',width:'270px',maxHeight:'calc(100vh - 12px)',overflowY:'auto',background:'#172532',border:'1px solid #496176',borderRadius:'8px',boxShadow:'0 12px 30px rgba(0,0,0,.45)',color:'#e8edf2'});
  const title=document.createElement('div');title.textContent=`${nodesSelected.size} ${tr('nós selecionados')}`;
  Object.assign(title.style,{padding:'8px 10px',fontWeight:'800',fontSize:'12px',background:'#101a23',borderBottom:'1px solid #496176'});menu.appendChild(title);
  document.querySelectorAll('#nodesBulkBar [data-node-bulk]').forEach(btn=>{
    nodeCtxButton(menu,btn.textContent,()=>runNodesBulk(btn.dataset.nodeBulk),{danger:btn.classList.contains('nodesBulkDanger')});
  });
  document.body.appendChild(menu);
  const close=e=>{if(!menu.contains(e.target)){closeNodeContextMenu();document.removeEventListener('pointerdown',close,true);}};
  setTimeout(()=>document.addEventListener('pointerdown',close,true),0);
  menu.addEventListener('contextmenu',e=>e.preventDefault());
}
document.querySelectorAll('#nodesBulkBar [data-node-bulk]').forEach(btn=>btn.addEventListener('click',()=>runNodesBulk(btn.dataset.nodeBulk)));
document.getElementById('nodesSelectAll').addEventListener('click',e=>{
  e.stopPropagation();
  const allSelected=nodesVisibleOrder.length>0&&nodesVisibleOrder.every(n=>nodesSelected.has(n));
  for(const n of nodesVisibleOrder)allSelected?nodesSelected.delete(n):nodesSelected.add(n);
  syncNodesSelectionRows();
});
document.getElementById('nodesFilter').addEventListener('input',e=>{nodesFilterText=String(e.target.value||'');renderNodesTable();taSyncRoute({replace:true,view:'nodes'});});
document.getElementById('nodesFilterClear').addEventListener('click',()=>{const el=document.getElementById('nodesFilter');el.value='';nodesFilterText='';el.focus();renderNodesTable();taSyncRoute({replace:true,view:'nodes'});});
document.getElementById('nodesColumnsButton').addEventListener('click',e=>{
  e.stopPropagation();
  document.getElementById('nodesColumnsPanel').classList.toggle('open');
});
document.getElementById('nodesColumnsPanel').addEventListener('click',e=>e.stopPropagation());
document.addEventListener('click',()=>document.getElementById('nodesColumnsPanel')?.classList.remove('open'));
document.querySelectorAll('[data-node-column]').forEach(cb=>cb.addEventListener('change',()=>{
  if(cb.checked)nodesOptionalColumns.add(cb.dataset.nodeColumn);else nodesOptionalColumns.delete(cb.dataset.nodeColumn);
  saveNodesColumnPrefs();
}));
document.querySelectorAll('#nodesTable th[data-node-sort]').forEach(th=>th.addEventListener('click',()=>{
  const key=th.dataset.nodeSort;
  if(nodesSortKey===key)nodesSortDir=nodesSortDir==='asc'?'desc':'asc';
  else{
    nodesSortKey=key;
    nodesSortDir=(key==='longName'||key==='shortName'||key==='role'||key==='hardware'||key==='nodeId'||key==='state')?'asc':'desc';
  }
  renderNodesTable();
  taSyncRoute({replace:true,view:'nodes'});
}));
document.getElementById('nodesReload').addEventListener('click',()=>load(false));
document.getElementById('nodeDetailsClose').addEventListener('click',closeNodeDetailsModal);
document.getElementById('nodeDetailsBackdrop').addEventListener('click',e=>{if(e.target===e.currentTarget)closeNodeDetailsModal();});
loadNodesColumnPrefs();
setInterval(()=>{
  if(document.getElementById('viewNodes')?.classList.contains('active'))renderNodesTable();
},30000);
const TA_ROUTE_PATHS={map:'/mapa',nodes:'/nos',traffic:'/trafego',messages:'/mensagens/canal/0',statistics:'/estatisticas',automations:'/automacoes',settings:'/configuracoes',help:'/ajuda'};
const TA_ROUTE_VIEWS={mapa:'map',nos:'nodes',trafego:'traffic',mensagens:'messages',estatisticas:'statistics',automacoes:'automations',configuracoes:'settings',ajuda:'help'};
let taRouteApplying=false;
let taCurrentStatsTab='overview';
let taCurrentAutomation='';
let taPendingStatsNode='';

function taActiveView(){
  const btn=document.querySelector('.navbtn.active');
  return btn?.dataset?.view||'map';
}
function taRouteUrl(view=taActiveView()){
  const params=new URLSearchParams();
  let path=TA_ROUTE_PATHS[view]||'/mapa';
  if(view==='nodes'){
    if(nodeDetailsModalNodeNum!==null && Number.isFinite(Number(nodeDetailsModalNodeNum))) path+='/'+encodeURIComponent(String(nodeDetailsModalNodeNum));
    else{
      if(nodesFilterText.trim())params.set('filtro',nodesFilterText.trim());
      if(nodesSortKey)params.set('ordem',nodesSortKey);
      if(nodesSortDir)params.set('dir',nodesSortDir);
    }
  }else if(view==='automations'){
    const selected=window.automationSelectedBot||taCurrentAutomation;
    if(selected==='ping'||selected==='clima'||selected==='meshtastic')path+='/'+selected;
  }else if(view==='traffic'){
    const dir=document.getElementById('trafficDirection')?.value||'all';
    const type=document.getElementById('trafficType')?.value||'all';
    const q=document.getElementById('trafficSearch')?.value?.trim()||'';
    if(dir!=='all')params.set('direcao',dir);
    if(type!=='all')params.set('tipo',type);
    if(q)params.set('busca',q);
    if(selectedPacketId)params.set('pacote',selectedPacketId);
  }else if(view==='statistics'){
    path+='/'+encodeURIComponent(taCurrentStatsTab||'overview');
    const period=document.getElementById('statsPeriod')?.value;
    const node=document.getElementById('statsNodeFilter')?.value;
    if(period && period!=='all')params.set('periodo',period);
    if(node)params.set('no',node);
    if(taCurrentStatsTab==='access'){
      const days=document.getElementById('accessDays')?.value;
      if(days && days!=='30')params.set('dias',days);
    }
  }else if(view==='map'){
    if(mapSearchText.trim())params.set('busca',mapSearchText.trim());
    if(openNodeNum!==null && Number.isFinite(Number(openNodeNum)))path+='/no/'+encodeURIComponent(String(openNodeNum));
    else if(isolatedEdgeId)params.set('enlace',isolatedEdgeId);
  }
  const qs=params.toString();
  return path+(qs?'?'+qs:'');
}
function taSyncRoute({replace=false,view}={}){
  if(taRouteApplying)return;
  const url=taRouteUrl(view||taActiveView());
  if(location.pathname+location.search===url)return;
  history[replace?'replaceState':'pushState']({ta:true},'',url);
}
function taApplyRoute(){
  taRouteApplying=true;
  try{
    const url=new URL(location.href);
    const seg=url.pathname.split('/').filter(Boolean);
    const view=TA_ROUTE_VIEWS[seg[0]]||'map';
    setView(view,false);
    if(view==='automations'){
      taCurrentAutomation=(seg[1]==='ping'||seg[1]==='clima'||seg[1]==='meshtastic')?seg[1]:'';
      if(typeof showAutomationDetails==='function')showAutomationDetails(taCurrentAutomation,false);
    }else if(view==='statistics'){
      const valid=new Set(['overview','network','rf','ranking','routing','traffic','queries','chat','energy','anomalies','access']);
      const tab=valid.has(seg[1])?seg[1]:'overview';
      setStatisticsTab(tab,false);
      const period=url.searchParams.get('periodo');
      const node=url.searchParams.get('no');
      const days=url.searchParams.get('dias');
      if(period && document.getElementById('statsPeriod'))document.getElementById('statsPeriod').value=period;
      taPendingStatsNode=node||'';
      if(node && document.getElementById('statsNodeFilter') && [...document.getElementById('statsNodeFilter').options].some(o=>o.value===node))document.getElementById('statsNodeFilter').value=node;
      if(days && document.getElementById('accessDays'))document.getElementById('accessDays').value=days;
      statisticsPayload=null;
      loadStatistics(true);
    }else if(view==='nodes'){
      const filter=url.searchParams.get('filtro')||'';
      const order=url.searchParams.get('ordem');
      const dir=url.searchParams.get('dir');
      nodesFilterText=filter;
      const f=document.getElementById('nodesFilter');if(f)f.value=filter;
      if(order)nodesSortKey=order;
      if(dir==='asc'||dir==='desc')nodesSortDir=dir;
      renderNodesTable();
      if(seg[1]){
        const nodeNum=Number(decodeURIComponent(seg[1]));
        if(Number.isFinite(nodeNum)){
          let tries=0;
          const openWhenReady=()=>{
            if((topology?.nodes||[]).some(n=>Number(n.nodeNum)===nodeNum))openNodeDetailsModal(nodeNum,false);
            else if(++tries<30)setTimeout(openWhenReady,400);
          };
          setTimeout(openWhenReady,50);
        }
      }
    }else if(view==='traffic'){
      const dir=url.searchParams.get('direcao');
      const type=url.searchParams.get('tipo');
      const q=url.searchParams.get('busca')||'';
      if(dir && document.getElementById('trafficDirection'))document.getElementById('trafficDirection').value=dir;
      if(type && document.getElementById('trafficType'))document.getElementById('trafficType').value=type;
      if(document.getElementById('trafficSearch'))document.getElementById('trafficSearch').value=q;
      renderTraffic();
      const packet=url.searchParams.get('pacote');
      if(packet){
        let tries=0;
        const selectWhenReady=()=>{
          if(trafficPackets.some(x=>trafficKey(x)===packet))selectPacket(packet,false);
          else if(++tries<30)setTimeout(selectWhenReady,350);
        };
        setTimeout(selectWhenReady,100);
      }
    }else if(view==='map'){
      mapSearchText=url.searchParams.get('busca')||'';
      const input=document.getElementById('mapSearchInput');if(input)input.value=mapSearchText;
      // A pesquisa permanece sempre visível, mesmo com campo vazio ou após F5.
      render();renderMapSearchResults();
      const edge=url.searchParams.get('enlace');
      if(edge){isolatedEdgeId=edge;setTimeout(()=>{render();fitMapTight();},120);}
      if(seg[1]==='no' && seg[2]){
        const nodeNum=Number(decodeURIComponent(seg[2]));
        if(Number.isFinite(nodeNum)){
          let tries=0;
          const openMapNodeWhenReady=()=>{
            if((topology?.nodes||[]).some(n=>Number(n.nodeNum)===nodeNum)){openNodeWindow(nodeNum,false);const m=nodeMarkers.get(nodeNum);if(m)map.setView(m.getLatLng(),Math.max(map.getZoom(),14));}
            else if(++tries<30)setTimeout(openMapNodeWhenReady,400);
          };
          setTimeout(openMapNodeWhenReady,80);
        }
      }
    }
  }finally{
    setTimeout(()=>{taRouteApplying=false;},0);
  }
}

function setView(name,updateRoute=true){
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
  const ids={map:'viewMap',nodes:'viewNodes',traffic:'viewTraffic',messages:'viewMessages',statistics:'viewStatistics',automations:'viewAutomations',settings:'viewSettings',help:'viewHelp'};
  const target=document.getElementById(ids[name]||'viewMap');
  target.classList.add('active');
  if(name==='map') setTimeout(()=>{map.invalidateSize();renderMapSearchResults();},40);
  if(name==='nodes') renderNodesTable();
  if(name==='traffic' && !trafficInitialized) loadTrafficInitial();
  if(name==='messages'){messageAutoScroll=true;messagePendingBelow=0;updateMessageNewBelowButton();loadPrimaryMessages(true,false);}
  if(name==='settings'||name==='messages')applyAuthState();
  if(name==='statistics') loadStatistics(false);
  if(name==='automations'&&typeof loadAutomations==='function')loadAutomations(false);
  if(updateRoute)taSyncRoute({view:name});
}

function packetTypeClass(name){
  if(name==='TEXT_MESSAGE_APP') return 'type-text';
  if(name==='POSITION_APP') return 'type-position';
  if(name==='NODEINFO_APP') return 'type-nodeinfo';
  if(name==='TELEMETRY_APP') return 'type-telemetry';
  if(name==='TRACEROUTE_APP') return 'type-traceroute';
  if(name==='ROUTING_APP') return 'type-routing';
  if(name==='NEIGHBORINFO_APP') return 'type-neighbor';
  return '';
}
function packetTypeLabel(name){ return String(name||'UNKNOWN').replace(/_APP$/,'').replaceAll('_',' '); }
function packetNode(p,prefix){ return p[`${prefix}_node_longName`] || p[`${prefix}_node_id`] || (p[`${prefix}_node`]!==null && p[`${prefix}_node`]!==undefined ? String(p[`${prefix}_node`]) : '—'); }
function packetHops(p){ const hs=Number(p.hop_start), hl=Number(p.hop_limit); return Number.isFinite(hs)&&Number.isFinite(hl) ? hs-hl : null; }
function packetTime(p){ let t=Number(p.timestamp||0); if(t>0&&t<10000000000)t*=1000; return t; }
function fmtTime(ms){ return ms?new Date(ms).toLocaleTimeString(uiLocale(),{hour12:false}):'—'; }
function fmtNum(v,d=1){ return v===null||v===undefined||v===''?'—':Number(v).toFixed(d); }
function trafficKey(p){ return `${p.id ?? ''}:${p.packet_id ?? ''}:${p.timestamp ?? ''}:${p.from_node ?? ''}:${p.to_node ?? ''}:${p.portnum ?? ''}:${p.direction ?? ''}`; }
function packetNodeNum(p,prefix){
  const v=Number(p?.[`${prefix}_node`]);
  return Number.isFinite(v) ? (v >>> 0) : null;
}
function isDirectedNodeInfo(p){
  if(!p || p.portnum_name!=='NODEINFO_APP') return false;
  const a=packetNodeNum(p,'from'), b=packetNodeNum(p,'to');
  return a!==null && b!==null && a!==b && !INVALID_NODES.has(a) && !INVALID_NODES.has(b);
}
function isConfirmedNodeInfoRequest(p){
  if(!isDirectedNodeInfo(p)) return false;
  const preview=String(p.payload_preview||'').toLowerCase();
  if(preview.includes('nodeinfo request') || preview.includes('node info request')) return true;
  // Na v4.16.1, NodeInfo TX originado pelo próprio MeshMonitor é registrado por logOutgoingPacket.
  return String(p.direction||'').toLowerCase()==='tx';
}
function topologyPoint(nodeNum){
  const n=(topology?.nodes||[]).find(x=>Number(x.nodeNum)===Number(nodeNum));
  if(!nodeHasValidMapPosition(n)) return null;
  return {nodeNum:Number(nodeNum),nodeId:n.nodeId,name:n.name||n.nodeId,lat:Number(n.latitude),lon:Number(n.longitude)};
}
function sameEndpoints(path,a,b){
  if(!Array.isArray(path) || path.length<2) return false;
  return Number(path[0].nodeNum)===Number(a) && Number(path[path.length-1].nodeNum)===Number(b);
}
function bestObservedTracePath(traces,a,b,eventTs){
  let best=null;
  for(const t of traces||[]){
    const ts=Number(t.timestampMs||0); if(!ts) continue;
    const delta=Math.abs(ts-eventTs); if(delta>NODEINFO_TRACE_WINDOW_MS) continue;
    for(const [leg,path] of [['forward',t.forwardPath],['return',t.returnPath]]){
      if(!sameEndpoints(path,a,b)) continue;
      if(!best || delta<best.delta) best={path,trace:t,leg,delta};
    }
  }
  return best;
}
async function fetchObservedTracePath(a,b,eventTs){
  let best=bestObservedTracePath(topology?.traces||[],a,b,eventTs);
  try{
    const r=await fetch('/api/live-traceroutes?limit=200',{cache:'no-store'});
    if(r.ok){
      const body=await r.json();
      const live=(body.data||[]).map(normalizeLiveTrace).filter(Boolean);
      const cand=bestObservedTracePath(live,a,b,eventTs);
      if(cand && (!best || cand.delta<best.delta)) best=cand;
    }
  }catch{}
  return best;
}
function flowToast(html,known=false){
  const el=document.getElementById('flowToast');
  el.className=known?'flowKnown':'flowUnknown'; el.innerHTML=html; el.style.display='block';
  if(flowToastTimer) clearTimeout(flowToastTimer);
  flowToastTimer=setTimeout(()=>{el.style.display='none';},12000);
}
function clearFlowLater(generation,ms=45000){
  setTimeout(()=>{ if(generation===flowGeneration) flowLayer.clearLayers(); },ms);
}
function nodeInfoToast(html,known=false){
  if(document.getElementById('nodeInfoToastEnabled')?.checked)flowToast(html,known);
}
function nodeInfoStatus(message){
  const box=document.getElementById('nodeInfoRouteStatus');
  if(box)box.textContent=String(message);
}
function nodeInfoTraceEligible(p){
  return String(p?.direction||'').toLowerCase()==='tx' &&
    Number(p?.packet_id)>0 && Number.isFinite(packetNodeNum(p,'to')) &&
    packetNodeNum(p,'to')!==0xffffffff;
}
function highlightNodeInfoEndpoints(a,b){
  let shown=0;
  for(const num of [a,b]){
    const pt=topologyPoint(num);
    if(!pt)continue;
    L.circleMarker([pt.lat,pt.lon],{radius:12,color:'#ffb347',weight:3,fillOpacity:.06,
      interactive:false,dashArray:'3 4'}).addTo(flowLayer);
    shown++;
  }
  return shown;
}
async function requestNodeInfoTrace(p){
  if(!authCanWrite()){openAuthModal();throw new Error('Faça login para solicitar traceroute por RF');}
  if(!nodeInfoTraceEligible(p))throw new Error('Consulta local não disponível: este NodeInfo não é um TX local confirmado');
  const response=await authFetch('/api/nodeinfo/traceroute',{method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({packetId:Number(p.packet_id),nodeNum:packetNodeNum(p,'to')})});
  const body=await response.json();
  if(!response.ok||!body.success)throw new Error(body.message||('HTTP '+response.status));
  return body;
}
function animateFlowPath(points,generation,color='#a970ff'){
  return new Promise(resolve=>{
    if(!points||points.length<2){resolve(false);return;}
    const latlngs=points.map(p=>L.latLng(p.lat,p.lon));
    const screen=latlngs.map(ll=>map.latLngToContainerPoint(ll));
    const lengths=[];let total=0;
    for(let i=0;i<screen.length-1;i++){const d=screen[i].distanceTo(screen[i+1]);lengths.push(d);total+=d;}
    if(total<1){resolve(true);return;}
    const speed=Math.max(20,Number(document.getElementById('animSpeed').value||150));
    const pulse=L.circleMarker(latlngs[0],{radius:7,color:'#fff',weight:2,fillColor:color,fillOpacity:1,interactive:false}).addTo(flowLayer);
    const start=performance.now();
    function frame(now){
      if(generation!==flowGeneration){try{flowLayer.removeLayer(pulse)}catch{} resolve(false);return;}
      const travelled=((now-start)/1000)*speed;
      if(travelled>=total){pulse.setLatLng(latlngs[latlngs.length-1]);setTimeout(()=>{try{flowLayer.removeLayer(pulse)}catch{}},350);resolve(true);return;}
      let rem=travelled,seg=0;while(seg<lengths.length-1&&rem>lengths[seg]){rem-=lengths[seg];seg++;}
      const ratio=lengths[seg]?Math.max(0,Math.min(1,rem/lengths[seg])):1;
      pulse.setLatLng(latLngAt(points,seg,ratio));requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  });
}
async function showNodeInfoFlow(p,opts={}){
  if(!document.getElementById('nodeInfoFlowEnabled').checked||!isDirectedNodeInfo(p))return;
  const aNum=packetNodeNum(p,'from'),bNum=packetNodeNum(p,'to');
  const originalTs=packetTime(p)||Date.now();
  const from=packetNode(p,'from'),to=packetNode(p,'to');
  nodeInfoActivePacket=p;
  const canTrace=nodeInfoTraceEligible(p);
  const button=document.getElementById('nodeInfoTraceNow');
  if(button)button.disabled=!canTrace||!authCanWrite();
  const generation=++flowGeneration;
  flowLayer.clearLayers();
  const endpoints=highlightNodeInfoEndpoints(aNum,bNum);
  nodeInfoStatus('NodeInfo '+from+' → '+to+': procurando rota observada no histórico. Nenhuma linha direta presumida.');
  let evidence=null,referenceTs=originalTs,initiated=false,queryError='';
  try{
    evidence=await fetchObservedTracePath(aNum,bNum,originalTs);
    if(generation!==flowGeneration)return;
    const automatic=document.getElementById('nodeInfoAutoTraceEnabled')?.checked &&
      canTrace&&authCanWrite()&&!evidence&&opts.wait!==false;
    if((opts.forceTrace||automatic)&&canTrace){
      nodeInfoStatus('NodeInfo: solicitando traceroute local com limite de RF; a resposta mede o caminho atual da consulta.');
      try{
        await requestNodeInfoTrace(p);
        initiated=true;
        referenceTs=Date.now();
      }catch(error){
        queryError=String(error.message||error);
      }
    }else if(opts.forceTrace&&!canTrace){
      queryError='A consulta só é aplicável a NodeInfo TX local, não a pacotes entre terceiros.';
    }
    const deadline=Date.now()+(opts.wait===false?0:NODEINFO_ROUTE_WAIT_MS);
    while(!evidence&&generation===flowGeneration){
      evidence=await fetchObservedTracePath(aNum,bNum,referenceTs);
      if(evidence||Date.now()>=deadline)break;
      await new Promise(resolve=>setTimeout(resolve,5000));
    }
  }catch(error){
    queryError=String(error.message||error);
  }
  if(generation!==flowGeneration)return;
  flowLayer.clearLayers();
  if(!evidence){
    highlightNodeInfoEndpoints(aNum,bNum);
    const base='Caminho original desconhecido; nenhum enlace RF direto presumido.';
    const more=queryError?' · Consulta: '+queryError:(initiated?' · Traceroute solicitado, sem rota compatível até o timeout.':' · Não há traceroute compatível registrado.');
    nodeInfoStatus(base+more);
    nodeInfoToast('<b>NodeInfo: '+esc(from)+' → '+esc(to)+'</b><div class="flowNote">'+esc(base+more)+'</div>');
    clearFlowLater(generation,30000);
    return;
  }
  // Somente segmentos adjacentes de uma rota registrada podem virar geometria.
  // Ponto intermediário sem posição interrompe a linha: não encurtar por reta.
  const points=evidence.path||[];
  const hasCoords=pt=>pt&&Number.isFinite(Number(pt.lat))&&Number.isFinite(Number(pt.lon))&&
    Math.abs(Number(pt.lat))<=90&&Math.abs(Number(pt.lon))<=180&&
    !(Math.abs(Number(pt.lat))<.01&&Math.abs(Number(pt.lon))<.01);
  const paths=[];
  for(let i=0;i<points.length-1;i++){
    if(!hasCoords(points[i])||!hasCoords(points[i+1]))continue;
    const line=L.polyline([[points[i].lat,points[i].lon],[points[i+1].lat,points[i+1].lon]],
      {color:'#a970ff',weight:5,opacity:.88,interactive:true}).addTo(flowLayer);
    line.bindTooltip('Hop observado em traceroute · não comprova o percurso do pacote NodeInfo');
    paths.push(line);
  }
  for(const pt of points){
    if(hasCoords(pt))L.circleMarker([pt.lat,pt.lon],{radius:6,color:'#d8c8ff',
      fillColor:'#a970ff',fillOpacity:.85,weight:1,interactive:false}).addTo(flowLayer);
  }
  const deltaS=Math.round(Math.abs(Number(evidence.trace?.timestampMs||originalTs)-originalTs)/1000);
  const complete=paths.length===points.length-1;
  const label=complete?'Rota observada por traceroute':'Rota parcialmente observada';
  const note=label+' ('+points.length+' nós, medição a '+deltaS+
    ' s do evento). Não é prova do caminho exato do NodeInfo.';
  nodeInfoStatus(note);
  nodeInfoToast('<b>NodeInfo: '+esc(from)+' → '+esc(to)+'</b><div class="flowNote">'+esc(note)+'</div>',true);
  if(paths.length&&autoMapMotionAllowed()&&document.getElementById('viewMap').classList.contains('active')){
    const coords=paths.flatMap(x=>x.getLatLngs());
    map.fitBounds(L.latLngBounds(coords),{padding:[18,18],maxZoom:13,animate:true});
  }
  if(complete&&paths.length)await animateFlowPath(points,generation,'#a970ff');
  clearFlowLater(generation,45000);
}
function handleNodeInfoPacket(p){
  if(!isDirectedNodeInfo(p) || !document.getElementById('nodeInfoFlowEnabled').checked) return;
  const key=trafficKey(p); if(nodeInfoTriggered.has(key)) return;
  const a=packetNodeNum(p,'from'), b=packetNodeNum(p,'to'), now=packetTime(p)||Date.now();
  const pair=`${a}:${b}`, reverse=`${b}:${a}`;
  // Pedido confirmado: TX do MeshMonitor ou preview explícito.
  if(isConfirmedNodeInfoRequest(p)){
    nodeInfoTriggered.add(key); showNodeInfoFlow(p); return;
  }
  // Em RX o Packet Monitor v4.16.1 não persiste want_response. Só promovemos o
  // primeiro frame a "pedido provável" quando observamos a resposta reversa.
  const prev=nodeInfoRecent.get(reverse);
  if(prev && Math.abs(now-packetTime(prev))<=NODEINFO_PAIR_WINDOW_MS){
    const prevKey=trafficKey(prev);
    if(!nodeInfoTriggered.has(prevKey)){
      nodeInfoTriggered.add(prevKey);
      showNodeInfoFlow(prev,{wait:false});
    }
  }
  nodeInfoRecent.set(pair,p);
  // limpeza simples
  for(const [k,v] of [...nodeInfoRecent.entries()]) if(now-packetTime(v)>NODEINFO_PAIR_WINDOW_MS) nodeInfoRecent.delete(k);
}
function filteredTraffic(){
  const dir=document.getElementById('trafficDirection').value;
  const type=document.getElementById('trafficType').value;
  const q=document.getElementById('trafficSearch').value.trim().toLowerCase();
  return trafficPackets.filter(p=>{
    if(dir!=='all' && String(p.direction||'').toLowerCase()!==dir)return false;
    if(type!=='all' && p.portnum_name!==type)return false;
    if(q){ const hay=[packetNode(p,'from'),packetNode(p,'to'),p.from_node_id,p.to_node_id,p.portnum_name,p.payload_preview].join(' ').toLowerCase(); if(!hay.includes(q))return false; }
    return true;
  });
}
function renderTraffic(){
  const rows=filteredTraffic();
  const now=Date.now();
  const rx=trafficPackets.filter(p=>String(p.direction||'').toLowerCase()==='rx').length;
  const tx=trafficPackets.filter(p=>String(p.direction||'').toLowerCase()==='tx').length;
  const lastMin=trafficPackets.filter(p=>now-packetTime(p)<=60000).length;
  document.getElementById('trafficStats').innerHTML=
    `<span class="metric"><b>${trafficTotal}</b> armazenados no MM</span>`+
    `<span class="metric"><b>${trafficPackets.length}</b> carregados</span>`+
    `<span class="metric"><b>${rx}</b> RX</span>`+
    `<span class="metric"><b>${tx}</b> TX</span>`+
    `<span class="metric"><b>${lastMin}</b> último minuto</span>`+
    `<span class="metric"><b>${rows.length}</b> no filtro</span>`;
  const body=document.getElementById('trafficRows');
  body.innerHTML=rows.length?rows.slice(0,1000).map(p=>{
    const id=trafficKey(p); const dir=String(p.direction||'?').toLowerCase(); const hops=packetHops(p);
    return `<tr data-packet="${esc(id)}" class="${selectedPacketId===id?'selected':''}">`+
      `<td>${fmtTime(packetTime(p))}</td><td><span class="badge ${dir==='rx'?'rx':'tx'}">${esc(dir.toUpperCase())}</span></td>`+
      `<td title="${esc(p.from_node_id||'')}">${esc(packetNode(p,'from'))}</td><td title="${esc(p.to_node_id||'')}">${esc(packetNode(p,'to'))}</td>`+
      `<td><span class="badge typeBadge ${packetTypeClass(p.portnum_name)}" title="Clique para ver o payload formatado">${esc(packetTypeLabel(p.portnum_name))}</span></td>`+
      `<td>${p.snr==null?'—':fmtNum(p.snr,2)}</td><td>${p.rssi==null?'—':esc(p.rssi)}</td><td>${hops==null?'—':esc(hops)}</td></tr>`;
  }).join(''):'<tr><td colspan="8">Nenhum pacote corresponde ao filtro.</td></tr>';
  body.querySelectorAll('tr[data-packet]').forEach(tr=>tr.addEventListener('click',()=>selectPacket(tr.dataset.packet)));
}
function isBroadcastPacket(p){
  const to=packetNodeNum(p,'to');
  const id=String(p?.to_node_id||'').toLowerCase();
  return to===0xffffffff || id==='!ffffffff' || id==='broadcast';
}
function parsedMetadata(p){
  if(!p?.metadata) return {};
  if(typeof p.metadata==='object') return p.metadata;
  try{ const x=JSON.parse(p.metadata); return x&&typeof x==='object'?x:{}; }catch{return {};}
}
const FRIENDLY_LABELS={
  latitude:'Latitude',longitude:'Longitude',latitudeI:'Latitude',longitudeI:'Longitude',altitude:'Altitude',altitudeHae:'Altitude HAE',
  time:'Horário',timestamp:'Horário',batteryLevel:'Bateria',voltage:'Tensão',channelUtilization:'Utilização do canal',airUtilTx:'Air Util TX',uptimeSeconds:'Uptime',
  temperature:'Temperatura',relativeHumidity:'Umidade',barometricPressure:'Pressão',gasResistance:'Resistência do gás',current:'Corrente',lux:'Luminosidade',
  longName:'Nome',shortName:'Nome curto',id:'ID',macaddr:'MAC',hwModel:'Hardware',role:'Role',publicKey:'Chave pública',isLicensed:'Licenciado',
  nodeId:'Nó',snr:'SNR',lastRxTime:'Última recepção',neighbors:'Vizinhos',route:'Rota',routeBack:'Rota de volta',routingError:'Erro de roteamento',errorReason:'Motivo',
  requestId:'ID da solicitação',replyId:'ID da resposta',packetId:'ID do pacote',telemetryType:'Tipo de telemetria',wantResponse:'Solicita resposta',wantAck:'Solicita ACK',destination:'Destino',direction:'Direção',
  channel:'Canal',portnum:'PortNum',portnumName:'Tipo de pacote',relayNode:'Relay',transportMechanism:'Transporte',rxTime:'Recebido em',viaMqtt:'Via MQTT',priority:'Prioridade',
  deviceMetrics:'Métricas do dispositivo',environmentMetrics:'Métricas ambientais',localStats:'Estatísticas locais',powerMetrics:'Métricas de energia',airQualityMetrics:'Qualidade do ar'
};
function friendlyKey(k){
  if(FRIENDLY_LABELS[k]) return FRIENDLY_LABELS[k];
  return String(k).replace(/([a-z0-9])([A-Z])/g,'$1 $2').replaceAll('_',' ').replace(/^./,c=>c.toUpperCase());
}
function friendlyScalar(k,v){
  if(v===null||v===undefined||v==='') return '—';
  if(typeof v==='boolean') return v?'Sim':'Não';
  if(typeof v==='number'){
    if(/hwModel/i.test(k)) return hardwareFriendly(v) || String(v);
    if(/^role$/i.test(k)) return roleFriendly(v) || String(v);
    if(/latitudeI|longitudeI/.test(k) && Math.abs(v)>180) return (v/1e7).toFixed(7)+'°';
    if(/latitude|longitude/.test(k) && Math.abs(v)<=180) return Number(v).toFixed(7)+'°';
    if(/batteryLevel|channelUtilization|airUtilTx/i.test(k)) return nodeFmtPercent(v);
    if(/voltage/i.test(k)) return `${Number(v).toFixed(3)} V`;
    if(/temperature/i.test(k)) return `${Number(v).toFixed(1)} °C`;
    if(/humidity/i.test(k)) return nodeFmtPercent(v);
    if(/pressure/i.test(k)) return `${Number(v).toFixed(1)} hPa`;
    if(/snr/i.test(k)) return `${Number(v).toFixed(2)} dB`;
    if(/rssi/i.test(k)) return `${v} dBm`;
    if(/uptimeSeconds/i.test(k)){
      const d=Math.floor(v/86400),h=Math.floor((v%86400)/3600),m=Math.floor((v%3600)/60); return [d?`${d}d`:null,h?`${h}h`:null,`${m}min`].filter(Boolean).join(' ');
    }
    if((/time|timestamp|lastRxTime/i.test(k)) && v>1000000000){const ms=v<10000000000?v*1000:v;return new Date(ms).toLocaleString(uiLocale());}
    return String(v);
  }
  return String(v);
}
function flattenFriendly(obj,prefix='',out=[]){
  if(obj===null||obj===undefined) return out;
  if(Array.isArray(obj)){
    if(obj.every(x=>x===null||['string','number','boolean'].includes(typeof x))){ out.push([prefix||'Valores',obj.map((x,i)=>friendlyScalar(prefix,x)).join(' → ')]); }
    else obj.forEach((x,i)=>flattenFriendly(x,`${prefix||'Item'} ${i+1}`,out));
    return out;
  }
  if(typeof obj!=='object'){out.push([prefix||'Valor',friendlyScalar(prefix,obj)]);return out;}
  for(const [k,v] of Object.entries(obj)){
    const label=prefix?`${prefix} · ${friendlyKey(k)}`:friendlyKey(k);
    if(v!==null && typeof v==='object') flattenFriendly(v,label,out); else out.push([label,friendlyScalar(k,v)]);
  }
  return out;
}
function friendlyPayloadHtml(p){
  const meta=parsedMetadata(p);
  const decoded=meta.decoded_payload;
  const preview=String(p.payload_preview||'').trim();
  const broadcast=isBroadcastPacket(p);
  const directHidden=p.portnum_name==='TEXT_MESSAGE_APP' && !broadcast && preview==='[conteúdo oculto]';
  if(directHidden) return '<div class="payloadBox">Conteúdo de mensagem direta ocultado por padrão.</div>';
  let rows=[];
  if(decoded!==undefined && decoded!==null) rows=flattenFriendly(decoded);
  if(p.portnum_name==='TEXT_MESSAGE_APP' && preview && preview!=='[conteúdo oculto]'){
    return `<div class="payloadBox"><b>Mensagem${broadcast?' broadcast':''}:</b><br>${esc(preview)}</div>`;
  }
  if(!rows.length && preview && preview!=='[conteúdo oculto]') return `<div class="payloadBox">${esc(preview)}</div>`;
  if(!rows.length) return '<div class="payloadBox">Nenhum payload decodificado disponível.</div>';
  const html=rows.slice(0,120).map(([k,v])=>`<span class="k">${esc(k)}</span><span class="v">${esc(v)}</span>`).join('');
  return `<div class="payloadBox"><div class="payloadRows">${html}</div></div>`;
}
function technicalNodeValue(v){
  if(v===null||v===undefined||v==='') return '—';
  const n=Number(v);
  if(!Number.isFinite(n)) return String(v);
  const u=n>>>0;
  if(u===0xffffffff) return 'Broadcast (!ffffffff)';
  const node=(topology?.nodes||[]).find(x=>(Number(x.nodeNum)>>>0)===u);
  const id=`!${u.toString(16).padStart(8,'0')}`;
  return node ? `${node.name||node.shortName||node.nodeId||id} (${node.nodeId||id})` : id;
}
function friendlyTechnicalScalar(k,v){
  if(k==='destination' || k==='source' || k==='fromNode' || k==='toNode' || k==='nodeNum') return technicalNodeValue(v);
  if(k==='direction') return String(v||'—').toUpperCase();
  if(k==='telemetryType'){
    const m={device:'Métricas do dispositivo',environment:'Métricas ambientais',localStats:'Estatísticas locais',power:'Métricas de energia',airQuality:'Qualidade do ar'};
    return m[String(v)] || friendlyScalar(k,v);
  }
  if(k==='viaMqtt') return v?'Sim':'Não';
  return friendlyScalar(k,v);
}
function flattenFriendlyTechnical(obj,prefix='',out=[]){
  if(obj===null||obj===undefined) return out;
  if(Array.isArray(obj)){
    if(obj.every(x=>x===null||['string','number','boolean'].includes(typeof x))) out.push([prefix||'Valores',obj.map(x=>friendlyTechnicalScalar(prefix,x)).join(' → ')]);
    else obj.forEach((x,i)=>flattenFriendlyTechnical(x,`${prefix||'Item'} ${i+1}`,out));
    return out;
  }
  if(typeof obj!=='object'){out.push([prefix||'Valor',friendlyTechnicalScalar(prefix,obj)]);return out;}
  for(const [k,v] of Object.entries(obj)){
    if(k==='decoded_payload') continue; // já aparece em Payload, em formato amigável
    const label=prefix?`${prefix} · ${friendlyKey(k)}`:friendlyKey(k);
    if(v!==null && typeof v==='object') flattenFriendlyTechnical(v,label,out); else out.push([label,friendlyTechnicalScalar(k,v)]);
  }
  return out;
}
function technicalDetailsHtml(p){
  const meta=parsedMetadata(p);
  const rows=flattenFriendlyTechnical(meta);
  if(!rows.length) return '<details class="techDetails"><summary>Dados técnicos</summary><div class="payloadBox">Nenhum dado técnico adicional disponível.</div></details>';
  const html=rows.slice(0,160).map(([k,v])=>`<span class="k">${esc(k)}</span><span class="v">${esc(v)}</span>`).join('');
  const raw=`<details class="rawJson"><summary>Ver JSON bruto</summary><pre>${esc(JSON.stringify(meta,null,2))}</pre></details>`;
  return `<details class="techDetails"><summary>Dados técnicos</summary><div class="payloadBox"><div class="payloadRows">${html}</div>${raw}</div></details>`;
}
function selectPacket(key,updateRoute=true){
  selectedPacketId=key; const p=trafficPackets.find(x=>trafficKey(x)===key); if(!p)return;
  const hops=packetHops(p); const broadcast=isBroadcastPacket(p);
  document.getElementById('packetDetail').innerHTML=`<div class="detailTitle">${esc(packetTypeLabel(p.portnum_name))}${broadcast?'<span class="broadcastTag">BROADCAST</span>':''}</div>`+
    `<div class="detailGrid"><b>Hora</b><span>${esc(new Date(packetTime(p)).toLocaleString(uiLocale()))}</span>`+
    `<b>Direção</b><span>${esc(String(p.direction||'?').toUpperCase())}</span>`+
    `<b>Origem</b><span>${esc(packetNode(p,'from'))}<br>${esc(p.from_node_id||'')}</span>`+
    `<b>Destino</b><span>${esc(packetNode(p,'to'))}<br>${esc(p.to_node_id||'')}</span>`+
    `<b>Canal</b><span>${p.channel==null?'—':esc(p.channel)}</span>`+
    `<b>SNR</b><span>${p.snr==null?'—':fmtNum(p.snr,2)+' dB'}</span>`+
    `<b>RSSI</b><span>${p.rssi==null?'—':esc(p.rssi)+' dBm'}</span>`+
    `<b>Hops</b><span>${hops==null?'—':esc(hops)}</span>`+
    `<b>Relay</b><span>${p.relay_node==null?'—':esc(p.relay_node)}</span>`+
    `<b>Criptografado</b><span>${p.encrypted?'sim':'não'}</span>`+
    `<b>Payload</b><span>${friendlyPayloadHtml(p)}${technicalDetailsHtml(p)}</span>`+
    (isDirectedNodeInfo(p)?`<b>Mapa</b><span><button id="showNodeInfoFlowBtn">Mostrar fluxo</button></span>`:'')+`</div>`;
  const flowBtn=document.getElementById('showNodeInfoFlowBtn'); if(flowBtn) flowBtn.addEventListener('click',()=>{setView('map');showNodeInfoFlow(p);});
  renderTraffic();
  if(updateRoute)taSyncRoute({view:'traffic'});
}
function ensureAudio(){ if(!audioCtx){ const C=window.AudioContext||window.webkitAudioContext; if(C) audioCtx=new C(); } if(audioCtx?.state==='suspended') audioCtx.resume(); return audioCtx; }
function toneOsc(ctx,type,f0,f1,start,duration,amp,output=ctx.destination){
  const osc=ctx.createOscillator(),gain=ctx.createGain(); osc.type=type; osc.frequency.setValueAtTime(f0,start); if(f1&&f1!==f0) osc.frequency.exponentialRampToValueAtTime(f1,start+duration*.65);
  gain.gain.setValueAtTime(0.0001,start); gain.gain.exponentialRampToValueAtTime(Math.max(0.001,amp),start+0.01); gain.gain.exponentialRampToValueAtTime(0.0001,start+duration);
  osc.connect(gain);gain.connect(output);osc.start(start);osc.stop(start+duration+.02);
}
let activeSoundVoices=0;
let relaySoundCounter=0;
let lastMessageSoundAt=0;
function soundOutput(ctx,pan=0){
  if(!document.getElementById('soundStereoEnabled')?.checked || !ctx.createStereoPanner) return ctx.destination;
  const p=ctx.createStereoPanner();p.pan.value=Math.max(-0.8,Math.min(0.8,Number(pan)||0));p.connect(ctx.destination);return p;
}
function soundPanForPoint(pt){
  if(!pt || !document.getElementById('soundStereoEnabled')?.checked || !map) return 0;
  try{const b=map.getBounds(),center=map.getCenter(),span=Math.max(.01,b.getEast()-b.getWest());return Math.max(-.8,Math.min(.8,(Number(pt.lon)-center.lng)/(span*.5)));}catch{return 0;}
}
function noiseBurst(ctx,start,duration,amp,output,highpass=700){
  const frames=Math.max(1,Math.floor(ctx.sampleRate*duration)),buffer=ctx.createBuffer(1,frames,ctx.sampleRate),data=buffer.getChannelData(0);
  for(let i=0;i<frames;i++)data[i]=(Math.random()*2-1)*(1-i/frames);
  const src=ctx.createBufferSource(),filter=ctx.createBiquadFilter(),gain=ctx.createGain();filter.type='highpass';filter.frequency.value=highpass;
  gain.gain.setValueAtTime(Math.max(.0001,amp),start);gain.gain.exponentialRampToValueAtTime(.0001,start+duration);
  src.buffer=buffer;src.connect(filter);filter.connect(gain);gain.connect(output);src.start(start);src.stop(start+duration+.02);
}
function canPlayMeshSound(event,category,force=false){
  if(!force){
    if(!document.getElementById('soundEnabled')?.checked)return false;
    if(document.getElementById('soundTheme')?.value==='silent')return false;
    if(category==='routing'&&!document.getElementById('soundRoutingEnabled')?.checked)return false;
    if(category==='messages'&&!document.getElementById('soundMessagesEnabled')?.checked)return false;
    if(category==='alerts'&&!document.getElementById('soundAlertsEnabled')?.checked)return false;
    const now=performance.now();
    if(category==='messages'){
      // Mensagens têm campainha própria e não são suprimidas por uma rajada
      // de sons de roteamento. Apenas deduplica notificações muito próximas.
      if(now-lastMessageSoundAt<650)return false;
      lastMessageSoundAt=now;
      return true;
    }
    const density=document.getElementById('soundDensity')?.value||'normal';
    if(event==='relay'&&density==='low'&&(++relaySoundCounter%3)!==0)return false;
    const minBase=Math.max(40,Number(document.getElementById('soundMinInterval')?.value||120));
    const min=density==='high'?Math.max(40,minBase*.6):(density==='low'?Math.max(250,minBase*1.8):minBase);
    if(now-lastSoundAt<min)return false;lastSoundAt=now;
    const maxVoices=Math.max(1,Math.min(8,Number(document.getElementById('soundMaxVoices')?.value||3)));if(activeSoundVoices>=maxVoices)return false;
  }
  return true;
}
function playMeshSound(event,{category='routing',point=null,force=false}={}){
  if(!canPlayMeshSound(event,category,force))return;
  const ctx=ensureAudio();if(!ctx)return;
  const theme=document.getElementById('soundTheme')?.value||'formal';if(theme==='silent')return;
  const vol=Math.max(0,Math.min(1,Number(document.getElementById('soundVolume')?.value||35)/100));
  const out=soundOutput(ctx,soundPanForPoint(point)),t=ctx.currentTime+.01,a=Math.max(.001,vol*.16);
  activeSoundVoices++;
  const done=(ms=500)=>setTimeout(()=>{activeSoundVoices=Math.max(0,activeSoundVoices-1);},ms);
  if(theme==='pinball70'){
    if(event==='origin'){noiseBurst(ctx,t,.12,a*.42,out,450);toneOsc(ctx,'sawtooth',180,520,t,.16,a*.45,out);toneOsc(ctx,'triangle',880,420,t+.07,.12,a*.25,out);done(260);}
    else if(event==='relay'){noiseBurst(ctx,t,.055,a*.5,out,1200);toneOsc(ctx,'triangle',1900,720,t,.085,a*.62,out);toneOsc(ctx,'sine',2700,1350,t+.012,.07,a*.28,out);done(150);}
    else if(event==='destination'){toneOsc(ctx,'triangle',740,1080,t,.13,a*.6,out);toneOsc(ctx,'sine',1480,1480,t+.08,.20,a*.42,out);done(330);}
    else if(event==='ack'||event==='complete'){toneOsc(ctx,'sine',784,784,t,.13,a*.55,out);toneOsc(ctx,'sine',1047,1047,t+.09,.15,a*.5,out);toneOsc(ctx,'sine',1568,1568,t+.18,.25,a*.38,out);done(520);}
    else if(event==='message'){toneOsc(ctx,'triangle',1175,1175,t,.13,a*.62,out);toneOsc(ctx,'sine',1568,1568,t+.10,.16,a*.50,out);toneOsc(ctx,'sine',2093,2093,t+.22,.26,a*.36,out);done(560);}
    else {noiseBurst(ctx,t,.10,a*.32,out,500);toneOsc(ctx,'sawtooth',420,110,t,.30,a*.45,out);done(430);}
  }else if(theme==='radio'){
    if(event==='origin'){noiseBurst(ctx,t,.07,a*.22,out,900);toneOsc(ctx,'sine',980,1080,t+.035,.10,a*.5,out);done(200);}
    else if(event==='relay'){toneOsc(ctx,'square',1450,950,t,.045,a*.28,out);done(100);}
    else if(event==='destination'||event==='ack'||event==='complete'){toneOsc(ctx,'sine',1180,1320,t,.12,a*.5,out);toneOsc(ctx,'sine',1520,1520,t+.10,.13,a*.35,out);done(300);}
    else if(event==='message'){noiseBurst(ctx,t,.035,a*.14,out,1300);toneOsc(ctx,'sine',880,880,t+.02,.08,a*.48,out);toneOsc(ctx,'sine',1320,1320,t+.15,.10,a*.46,out);toneOsc(ctx,'sine',1760,1760,t+.28,.12,a*.32,out);done(460);}
    else {noiseBurst(ctx,t,.08,a*.18,out,500);toneOsc(ctx,'square',360,180,t,.18,a*.28,out);done(280);}
  }else{
    if(event==='origin'){toneOsc(ctx,'sine',620,760,t,.10,a*.42,out);done(160);}
    else if(event==='relay'){toneOsc(ctx,'sine',1050,900,t,.045,a*.27,out);done(100);}
    else if(event==='destination'){toneOsc(ctx,'sine',820,1040,t,.12,a*.43,out);done(200);}
    else if(event==='ack'||event==='complete'){toneOsc(ctx,'sine',880,880,t,.11,a*.42,out);toneOsc(ctx,'sine',1175,1175,t+.09,.16,a*.35,out);done(320);}
    else if(event==='message'){toneOsc(ctx,'sine',660,660,t,.11,a*.46,out);toneOsc(ctx,'sine',990,990,t+.14,.17,a*.40,out);done(360);}
    else {toneOsc(ctx,'sine',320,190,t,.22,a*.38,out);done(300);}
  }
}
function testSoundTheme(){
  ensureAudio();
  const seq=[['origin',0],['relay',240],['relay',430],['destination',650],['ack',900]];
  seq.forEach(([event,delay])=>setTimeout(()=>playMeshSound(event,{force:true,category:'routing'}),delay));
}
function journeyKey(p){
  const meta=parsedMetadata(p);
  const pid=(p.packet_id!==null&&p.packet_id!==undefined&&Number(p.packet_id)!==0)?p.packet_id:(meta.id!==null&&meta.id!==undefined&&Number(meta.id)!==0?meta.id:null);
  if(pid!==null) return `pid:${pid}:${packetNodeNum(p,'from')}:${p.portnum||p.portnum_name||''}`;
  // TXs gerados internamente nem sempre carregam packet_id no log. Neste caso,
  // cada linha TX é tratada como o início de uma nova viagem.
  if(String(p.direction||'').toLowerCase()==='tx') return `tx:${trafficKey(p)}`;
  // Fallback conservador para RX sem id: agrega cópias próximas do mesmo quadro.
  return `rx:${packetNodeNum(p,'from')}:${packetNodeNum(p,'to')}:${p.portnum||p.portnum_name||''}:${Math.floor(packetTime(p)/3000)}`;
}
function nodePointForActivity(nodeNum,p=null){
  const t=topologyPoint(nodeNum); if(t) return t;
  // Para POSITION_APP, a própria posição decodificada pode servir de fallback
  // para o nó de origem, sem fabricar coordenadas para outros nós.
  if(p && Number(nodeNum)===packetNodeNum(p,'from')){
    const meta=parsedMetadata(p), d=meta.decoded_payload;
    if(d && typeof d==='object'){
      let lat=d.latitude ?? d.latitudeI, lon=d.longitude ?? d.longitudeI;
      lat=Number(lat); lon=Number(lon);
      if(Number.isFinite(lat)&&Number.isFinite(lon)){
        if(Math.abs(lat)>90) lat/=1e7; if(Math.abs(lon)>180) lon/=1e7;
        if(Math.abs(lat)<=90&&Math.abs(lon)<=180) return {nodeNum:Number(nodeNum),nodeId:p.from_node_id||'',name:packetNode(p,'from'),lat,lon};
      }
    }
  }
  return null;
}
function resolveRelayNodeNum(relay){
  const rv=Number(relay); if(!Number.isFinite(rv)||rv<=0) return null;
  const nodes=(topology?.nodes||[]).filter(n=>Number.isFinite(Number(n.nodeNum)));
  const exact=nodes.find(n=>(Number(n.nodeNum)>>>0)===(rv>>>0));
  if(exact) return Number(exact.nodeNum)>>>0;
  if(rv<=255){
    const matches=nodes.filter(n=>((Number(n.nodeNum)>>>0)&0xff)===(rv&0xff) && topologyPoint(Number(n.nodeNum)));
    if(matches.length===1) return Number(matches[0].nodeNum)>>>0;
  }
  return null;
}
function activityPulseAtPoint(pt,nodeNum,kind='origin'){
  if(!document.getElementById('activityAnimationEnabled').checked) return;
  if(kind==='relay' && !document.getElementById('activityRelayEnabled').checked) return;
  if(kind!=='relay' && !document.getElementById('activityOriginEnabled').checked) return;
  if(!pt || !Number.isFinite(Number(pt.lat)) || !Number.isFinite(Number(pt.lon))) return;
  const key=`${kind}:${nodeNum}`;
  const old=activityMarkers.get(key); if(old){try{activityLayer.removeLayer(old)}catch{} clearTimeout(old.__taTimer);}
  const symbol=kind==='relay'?'↻':'📡';
  const cls=kind==='relay'?'relay':(kind==='response'?'response':'origin');
  const duration=Math.max(400,Number(document.getElementById('activityDuration').value||1000));
  const icon=L.divIcon({className:'activityLeafletIcon',iconSize:[46,46],iconAnchor:[23,23],html:`<div class="activityPulse ${cls}" style="--taDur:${duration}ms"><div class="activityCore">${symbol}</div></div>`});
  const marker=L.marker([Number(pt.lat),Number(pt.lon)],{icon,interactive:false,zIndexOffset:1200}).addTo(activityLayer);
  marker.__taTimer=setTimeout(()=>{try{activityLayer.removeLayer(marker)}catch{} if(activityMarkers.get(key)===marker)activityMarkers.delete(key);},duration);
  activityMarkers.set(key,marker);
}
function activityPulse(nodeNum,kind='origin',p=null){
  const pt=nodePointForActivity(nodeNum,p); if(!pt) return;
  activityPulseAtPoint(pt,nodeNum,kind);
}
function animatePacketActivityNow(p,isNewJourney){
  const from=packetNodeNum(p,'from');
  const relay=resolveRelayNodeNum(p.relay_node);
  const dir=String(p.direction||'').toLowerCase();
  const port=String(p.portnum_name||p.portnum||'').toUpperCase();
  const isTraceroute=port.includes('TRACEROUTE');
  if(!isTraceroute){
    if(isNewJourney && from!==null){
      playMeshSound('origin',{category:'routing',point:nodePointForActivity(from,p)});
      if(relay!==null && relay!==from){
        const delay=Math.max(90,Number(document.getElementById('soundMinInterval')?.value||120)+20);
        setTimeout(()=>playMeshSound('relay',{category:'routing',point:nodePointForActivity(relay,p)}),delay);
      }
    }else if(relay!==null && relay!==from){
      playMeshSound('relay',{category:'routing',point:nodePointForActivity(relay,p)});
    }
  }
  if(!document.getElementById('activityAnimationEnabled').checked) return;
  if(from!==null) activityPulse(from,dir==='rx'?'response':'origin',p);
  if(relay!==null && relay!==from) activityPulse(relay,'relay',p);
}
function animatePacketActivity(p,isNewJourney){
  if(document.getElementById('playMode').value==='live' && liveAnimationPaused){
    pausedActivityQueue.push({p,isNewJourney});
    updatePlaybackStatusIdle();
    return;
  }
  animatePacketActivityNow(p,isNewJourney);
}
function flushPausedActivityQueue(){
  if(liveAnimationPaused || !pausedActivityQueue.length) return;
  const queued=pausedActivityQueue.splice(0);
  queued.forEach(x=>animatePacketActivityNow(x.p,x.isNewJourney));
}
function mergeTraffic(rows, notify){
  const existing=new Set(trafficPackets.map(trafficKey)); const fresh=[];
  for(const p of rows||[]){
    const k=trafficKey(p); if(existing.has(k))continue; existing.add(k); trafficPackets.push(p); fresh.push(p);
    const t=packetTime(p); if(t>trafficLastTs)trafficLastTs=t;
    // O carregamento inicial também semeia as viagens conhecidas para não tocar som retroativo.
    if(!notify) journeySeen.add(journeyKey(p));
  }
  trafficPackets.sort((a,b)=>packetTime(b)-packetTime(a)); if(trafficPackets.length>1500)trafficPackets=trafficPackets.slice(0,1500);
  if(notify) fresh.slice().sort((a,b)=>packetTime(a)-packetTime(b)).forEach(p=>{
    const jk=journeyKey(p); const newJourney=!journeySeen.has(jk);
    if(newJourney)journeySeen.add(jk);
    animatePacketActivity(p,newJourney);
    handleNodeInfoPacket(p);
  });
  if(journeySeen.size>6000) journeySeen=new Set([...journeySeen].slice(-3000));
  renderTraffic();
}
async function fetchTraffic(url){ const r=await fetch(url,{cache:'no-store'}); if(!r.ok)throw new Error(`HTTP ${r.status}`); return r.json(); }
function downloadTrafficDump(){
  const btn=document.getElementById('trafficDump');
  if(!btn)return;
  const old=btn.textContent;
  btn.disabled=true; btn.textContent='Preparando dump…';
  const a=document.createElement('a');
  a.href='/api/archive/dump';
  a.download='';
  a.style.display='none';
  document.body.appendChild(a);
  a.click();
  setTimeout(()=>{ try{a.remove();}catch{} btn.disabled=false; btn.textContent=old; },2500);
}
async function loadTrafficInitial(){
  try{ const body=await fetchTraffic('/api/packets?limit=250'); trafficTotal=Number(body.total||0); trafficPackets=[]; trafficLastTs=0; journeySeen=new Set(); mergeTraffic(body.data||[],false); trafficInitialized=true; document.getElementById('trafficLive').textContent='● AO VIVO'; startTrafficPolling(); }
  catch(e){ document.getElementById('trafficLive').textContent=`erro: ${e}`; }
}
async function pollTraffic(){
  if(trafficPaused)return;
  try{ const since=trafficLastTs?`&since=${trafficLastTs+1}`:''; const body=await fetchTraffic(`/api/packets?limit=250${since}`); trafficTotal=Math.max(trafficTotal,Number(body.total||0)); mergeTraffic(body.data||[],trafficInitialized); trafficInitialized=true; document.getElementById('trafficLive').textContent='● AO VIVO'; }
  catch(e){ document.getElementById('trafficLive').textContent=`erro ${e}`; }
}
function startTrafficPolling(){ if(trafficTimer)clearInterval(trafficTimer); trafficTimer=setInterval(pollTraffic,2000); }
function toggleTrafficPause(){ trafficPaused=!trafficPaused; document.getElementById('trafficPause').textContent=trafficPaused?'Retomar':'Pausar'; document.getElementById('trafficLive').textContent=trafficPaused?'● PAUSADO':'● AO VIVO'; if(!trafficPaused)pollTraffic(); }


let healthLoadedAt=0, healthPayload=null, anomalyLoadedAt=0, anomalyPayload=null, accessLoadedAt=0, accessPayload=null, statisticsLoadedAt=0, statisticsPayload=null;
function fmtNum(v,dec=0){ const n=Number(v); return Number.isFinite(n)?n.toLocaleString(uiLocale(),{minimumFractionDigits:dec,maximumFractionDigits:dec}):'—'; }
function healthCard(value,label,sub=''){return `<div class="dashCard"><div class="value">${esc(value)}</div><div class="label">${esc(label)}</div>${sub?`<div class="sub">${esc(sub)}</div>`:''}</div>`;}
async function loadNetworkHealth(force=false){
  if(!force && Date.now()-healthLoadedAt<30000)return;
  const cards=document.getElementById('healthCards');
  cards.innerHTML=healthCard('…','Calculando indicadores');
  try{
    const r=await fetch('/api/network-health',{cache:'no-store'}); if(!r.ok)throw new Error(`HTTP ${r.status}`); const b=await r.json();
    healthLoadedAt=Date.now(); healthPayload=b; document.getElementById('healthUpdated').textContent=`atualizado ${new Date(b.generatedAtMs).toLocaleTimeString(uiLocale())}`;
    cards.innerHTML=[
      healthCard(b.nodes.active2h,'Nós ativos - 2 h',`${b.nodes.total} nós conhecidos`),
      healthCard(b.nodes.active24h,'Nós ativos - 24 h',`${b.nodes.silent24h} sem tráfego > 24 h`),
      healthCard(b.traffic.packets24h,'Pacotes - 24 h',`${b.traffic.rx24h} RX · ${b.traffic.tx24h} TX`),
      healthCard(b.links.observed,'Enlaces observados',`${b.links.recent24h} vistos nas últimas 24 h`),
      healthCard(b.traceroutes.total,'Traceroutes','histórico carregado'),
      healthCard(`${fmtNum(b.traceroutes.roundTripRate,1)}%`,'Com ida e volta',`${b.traceroutes.roundTrip} completos nos 2 sentidos`),
      healthCard(fmtNum(b.traceroutes.medianHops,1),'Mediana de hops','por perna observada'),
      healthCard(b.nodes.noTraffic,'Sem registro','nós sem timestamp confiável')
    ].join('');
    const daily=b.daily||[], max=Math.max(1,...daily.map(x=>Number(x.packets||0)));
    document.getElementById('healthDaily').innerHTML=daily.map(x=>{const pct=Math.max(2,Math.round(90*Number(x.packets||0)/max));return `<div class="miniBarWrap"><div class="miniBarValue" style="--h:${pct}px">${fmtNum(x.packets)}</div><div class="miniBar" style="height:${pct}px"></div><div class="miniBarLabel">${esc(x.label)}</div></div>`}).join('')||'<div class="emptyPanel">Sem dados no período.</div>';
    document.getElementById('healthRoutes').innerHTML=`<div class="dashGrid">${healthCard(b.traceroutes.forward,'Idas observadas')}${healthCard(b.traceroutes.return,'Voltas observadas')}${healthCard(b.traceroutes.incomplete,'Traceroutes incompletos')}${healthCard(fmtNum(b.traceroutes.avgHops,1),'Média de hops')}</div>`;
    document.getElementById('healthChatRows').innerHTML=(b.chatInteractions||[]).map(n=>`<tr><td><b>${esc(n.name||n.nodeId||'Nó desconhecido')}</b>${n.nodeId?`<br><span class="settingDesc">${esc(n.nodeId)}</span>`:''}</td><td><b>${fmtNum(n.interactions)}</b></td></tr>`).join('')||'<tr><td colspan="2" class="emptyPanel">Nenhuma interação de chat registrada no canal primário.</td></tr>';
    document.getElementById('healthSilentRows').innerHTML=(b.attentionNodes||[]).map(n=>`<tr><td><b>${esc(n.name||n.nodeId)}</b><br><span class="settingDesc">${esc(n.nodeId||'')}</span></td><td>${n.lastSeen?new Date(n.lastSeen).toLocaleString(uiLocale()):'—'}</td><td>${esc(n.lastSeen?humanAge(n.lastSeen):'sem registro')}</td><td>${fmtNum(n.packets7d)}</td><td>${n.avgSnr7d==null?'—':`${fmtNum(n.avgSnr7d,1)} dB`}</td></tr>`).join('')||'<tr><td colspan="5" class="emptyPanel">Nenhum nó requer atenção pelo critério atual.</td></tr>';
  }catch(e){cards.innerHTML=healthCard('Erro','Não foi possível calcular',String(e));}
}

function statisticsSinceMs(){
  const raw=document.getElementById('statsPeriod')?.value||'all';
  if(raw==='all') return null;
  const h=Number(raw); return Number.isFinite(h)?Date.now()-h*3600000:null;
}
function statisticsQuery(){
  const q=new URLSearchParams(), since=statisticsSinceMs(), node=document.getElementById('statsNodeFilter')?.value||'';
  if(since) q.set('since',String(Math.floor(since)));
  if(node) q.set('node',node);
  return q.toString() ? '&'+q.toString() : '';
}
function statisticsReportHtml(){
  const p=statisticsPayload||{}, s=p.stats||{}, nodes=p.nodes||[], longest=(p.longestRfLinks||[]).slice(0,10);
  const anomalies=(anomalyPayload?.data||[]).slice(0,10), health=healthPayload||{};
  const period=document.getElementById('statsPeriod')?.selectedOptions?.[0]?.textContent||'Todo';
  const node=document.getElementById('statsNodeFilter')?.selectedOptions?.[0]?.textContent||'Todos';
  const en=currentLang==='en';
  const L=en?{
    title:'Traffic Analyzer - Statistics Report',generated:'Generated',period:'Period',node:'Node',summary:'Executive summary',
    packets:'Packets',rx:'RX',tx:'TX',active:'Active nodes',known:'known',anomalies:'Points of attention',critical:'critical',
    longest:'10 longest direct RF links',rank:'#',a:'Node A',b:'Node B',distance:'Distance',observations:'RF observations',snr:'Average SNR',
    activeNodes:'Most active nodes',messages:'Chat interactions',issues:'Points of attention',severity:'Severity',subject:'Subject',description:'Description',
    print:'Print / Save as PDF',note:'Direct RF ranking trusts only MeshMonitor traceroute API adjacency plus valid SNR. The All period includes revalidated historical links, including offline nodes, and keeps that evidence until the Traffic Analyzer database is explicitly reset.'
  }:{
    title:'Traffic Analyzer - Relatório de Estatísticas',generated:'Gerado em',period:'Período',node:'Nó',summary:'Resumo executivo',
    packets:'Pacotes',rx:'RX',tx:'TX',active:'Nós ativos',known:'conhecidos',anomalies:'Pontos de atenção',critical:'críticos',
    longest:'10 enlaces RF diretos mais longos',rank:'#',a:'Nó A',b:'Nó B',distance:'Distância',observations:'Observações RF',snr:'SNR médio',
    activeNodes:'Nós mais ativos',messages:'Interações por chat',issues:'Pontos de atenção',severity:'Severidade',subject:'Assunto',description:'Descrição',
    print:'Imprimir / Salvar como PDF',note:'O ranking RF confia somente em adjacências da API de traceroutes do MeshMonitor com SNR válido. O período Todo inclui enlaces históricos revalidados, inclusive nós offline, e preserva essa evidência até reset explícito do banco do Traffic Analyzer.'
  };
  const rfRows=longest.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.aName||x.aId||String(x.a||'—'))}</td><td>${esc(x.bName||x.bId||String(x.b||'—'))}</td><td>${esc(fmtNum(x.distanceKm,1))} km</td><td>${esc(fmtNum(x.rfObservations))}</td><td>${x.avgSnr==null?'—':esc(fmtNum(x.avgSnr,1))+' dB'}</td></tr>`).join('')||'<tr><td colspan="6">—</td></tr>';
  const nodeRows=nodes.slice(0,10).map(x=>`<tr><td>${esc(statsNodeName(x.nodeNum,x.nodeId))}</td><td>${esc(fmtNum(x.packets))}</td><td>${x.avgSnr==null?'—':esc(fmtNum(x.avgSnr,1))+' dB'}</td></tr>`).join('')||'<tr><td colspan="3">—</td></tr>';
  const chatRows=(health.chatInteractions||[]).slice(0,10).map(x=>`<tr><td>${esc(x.name||x.nodeId||'—')}</td><td>${esc(fmtNum(x.interactions))}</td></tr>`).join('')||'<tr><td colspan="2">—</td></tr>';
  const anomalyRows=anomalies.map(x=>`<tr><td>${esc(x.severity||'—')}</td><td>${esc(x.subject||x.title||'—')}</td><td>${esc(x.message||'—')}</td></tr>`).join('')||'<tr><td colspan="3">—</td></tr>';
  const totalKnown=(topology?.nodes||[]).length;
  return `<!doctype html><html lang="${en?'en':'pt-BR'}"><head><meta charset="utf-8"><title>${esc(L.title)}</title><style>
    @page{size:A4;margin:14mm}body{font-family:Arial,Helvetica,sans-serif;color:#17212b;font-size:11px;line-height:1.35;margin:0}
    header{border-bottom:2px solid #17212b;margin-bottom:14px;padding-bottom:8px}h1{font-size:21px;margin:0 0 5px}h2{font-size:15px;margin:18px 0 6px}
    .meta{color:#526575}.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:7px}.kpi{border:1px solid #bcc8d1;border-radius:6px;padding:8px}.kpi b{font-size:18px;display:block}
    table{width:100%;border-collapse:collapse;margin:5px 0 12px}th,td{border-bottom:1px solid #d6dde2;padding:5px;text-align:left;vertical-align:top}th{background:#eef2f5}
    .note{font-size:10px;color:#526575}.toolbar{margin:0 0 12px}.toolbar button{padding:7px 11px;font-weight:700}@media print{.toolbar{display:none}h2{break-after:avoid}table{break-inside:auto}tr{break-inside:avoid}}
  </style></head><body><div class="toolbar"><button onclick="window.print()">${esc(L.print)}</button></div>
  <header><h1>${esc(L.title)}</h1><div class="meta">${esc(L.generated)}: ${esc(new Date().toLocaleString(uiLocale()))} · ${esc(L.period)}: ${esc(period)} · ${esc(L.node)}: ${esc(node)}</div></header>
  <h2>${esc(L.summary)}</h2><div class="kpis">
    <div class="kpi"><b>${esc(fmtNum(s.total||0))}</b>${esc(L.packets)}<br><span class="meta">${esc(fmtNum(s.rx||0))} ${esc(L.rx)} · ${esc(fmtNum(s.tx||0))} ${esc(L.tx)}</span></div>
    <div class="kpi"><b>${esc(fmtNum(nodes.length))}</b>${esc(L.active)}<br><span class="meta">${esc(fmtNum(totalKnown))} ${esc(L.known)}</span></div>
    <div class="kpi"><b>${esc(fmtNum(anomalyPayload?.summary?.total||0))}</b>${esc(L.anomalies)}<br><span class="meta">${esc(fmtNum(anomalyPayload?.summary?.critical||0))} ${esc(L.critical)}</span></div>
  </div>
  <h2>${esc(L.longest)}</h2><table><thead><tr><th>${esc(L.rank)}</th><th>${esc(L.a)}</th><th>${esc(L.b)}</th><th>${esc(L.distance)}</th><th>${esc(L.observations)}</th><th>${esc(L.snr)}</th></tr></thead><tbody>${rfRows}</tbody></table><div class="note">${esc(L.note)}</div>
  <h2>${esc(L.activeNodes)}</h2><table><thead><tr><th>${esc(L.node)}</th><th>${esc(L.packets)}</th><th>${esc(L.snr)}</th></tr></thead><tbody>${nodeRows}</tbody></table>
  <h2>${esc(L.messages)}</h2><table><thead><tr><th>${esc(L.node)}</th><th>${esc(L.messages)}</th></tr></thead><tbody>${chatRows}</tbody></table>
  <h2>${esc(L.issues)}</h2><table><thead><tr><th>${esc(L.severity)}</th><th>${esc(L.subject)}</th><th>${esc(L.description)}</th></tr></thead><tbody>${anomalyRows}</tbody></table>
  </body></html>`;
}
async function openStatisticsReport(){
  const w=window.open('','_blank');
  if(!w){alert(currentLang==='en'?'The browser blocked the report window. Allow pop-ups for this site.':'O navegador bloqueou a janela do relatório. Permita pop-ups para este site.');return;}
  w.opener=null;
  w.document.write('<!doctype html><meta charset="utf-8"><p style="font-family:Arial;padding:20px">Carregando relatório...</p>');
  try{
    if(!statisticsPayload)await loadStatistics(true);
    if(!statisticsPayload)throw new Error('statistics unavailable');
    w.document.open();w.document.write(statisticsReportHtml());w.document.close();
  }catch(e){
    w.document.open();w.document.write('<!doctype html><meta charset="utf-8"><p style="font-family:Arial;padding:20px">Falha ao gerar relatório: '+esc(String(e.message||e))+'</p>');w.document.close();
  }
}
function exportStatisticsCsv(){
  const q=statisticsQuery();
  const a=document.createElement('a');
  a.href='/api/archive/export?format=csv'+q;
  a.download='traffic-analyzer-estatisticas-'+new Date().toISOString().slice(0,10)+'.csv';
  document.body.appendChild(a);a.click();a.remove();
}
function statsPct(n,d){return d ? fmtNum(100*Number(n||0)/Number(d),1)+'%' : '—';}
function statsAvg(arr){const a=(arr||[]).map(Number).filter(Number.isFinite);return a.length?a.reduce((x,y)=>x+y,0)/a.length:null;}
function statsNodeName(num,id){
  const n=(topology?.nodes||[]).find(x=>Number(x.nodeNum)===Number(num)||String(x.nodeId||'')===String(id||''));
  return n?.name||n?.longName||n?.shortName||id||(num==null?'—':String(num));
}
function statsSimpleTable(rows,cols){
  if(!rows?.length) return '<div class="emptyPanel">Sem dados no período.</div>';
  let out='<table class="dashTable statsCompactTable"><thead><tr>';
  for(const col of cols) out+='<th>'+esc(col[0])+'</th>';
  out+='</tr></thead><tbody>';
  for(const row of rows){out+='<tr>';for(const col of cols)out+='<td>'+col[1](row)+'</td>';out+='</tr>';}
  return out+'</tbody></table>';
}
function statsPopulateNodeFilter(){
  const el=document.getElementById('statsNodeFilter'); if(!el)return;
  const keep=el.value;
  const rows=[...(topology?.nodes||[])].sort((a,b)=>String(a.name||a.longName||a.nodeId||'').localeCompare(String(b.name||b.longName||b.nodeId||''),uiLocale()));
  let html='<option value="">Todos</option>';
  for(const n of rows){
    const value=String(n.nodeId||n.nodeNum||''), label=n.name||n.longName||n.shortName||n.nodeId||String(n.nodeNum);
    html+='<option value="'+esc(value)+'">'+esc(label)+'</option>';
  }
  el.innerHTML=html;
  const wanted=taPendingStatsNode||keep;
  if([...el.options].some(o=>o.value===wanted)){el.value=wanted;taPendingStatsNode='';}
}
function renderStatistics(){
  const p=statisticsPayload;if(!p)return;
  const s=p.stats||{}, nodes=p.nodes||[], links=p.links||[], packets=p.packets||[], longestRf=p.longestRfLinks||[];
  const totalKnown=(topology?.nodes||[]).length, activeNodes=nodes.length;
  const snr=packets.map(x=>x.snr), rssi=packets.map(x=>x.rssi);
  const avgSnr=statsAvg(snr), avgRssi=statsAvg(rssi);
  const msgCount=packets.filter(x=>x.portnum_name==='TEXT_MESSAGE_APP').length;
  const traceCount=packets.filter(x=>x.portnum_name==='TRACEROUTE_APP').length;
  const telemetryCount=packets.filter(x=>x.portnum_name==='TELEMETRY_APP').length;
  const anomalySummary=anomalyPayload?.summary||{};
  document.getElementById('statsOverviewCards').innerHTML=[
    healthCard(fmtNum(activeNodes),'Nós ativos no período',fmtNum(totalKnown)+' conhecidos'),
    healthCard(fmtNum(s.total),'Pacotes',fmtNum(s.rx)+' RX · '+fmtNum(s.tx)+' TX'),
    healthCard(fmtNum(msgCount),'Mensagens','tráfego observado'),
    healthCard(fmtNum(traceCount),'Traceroutes','pacotes observados'),
    healthCard(fmtNum(links.length),'Relações observadas','origem → destino'),
    healthCard(avgSnr==null?'—':fmtNum(avgSnr,1)+' dB','SNR médio'),
    healthCard(avgRssi==null?'—':fmtNum(avgRssi,0)+' dBm','RSSI médio'),
    healthCard(fmtNum(anomalySummary.total||0),'Pontos de atenção',fmtNum(anomalySummary.critical||0)+' críticos')
  ].join('');
  const busiest=nodes[0];
  const summary=[];
  summary.push(fmtNum(activeNodes)+' nós originaram tráfego no período selecionado, de '+fmtNum(totalKnown)+' nós conhecidos.');
  summary.push('Foram registrados '+fmtNum(s.total)+' pacotes ('+fmtNum(s.rx)+' RX e '+fmtNum(s.tx)+' TX), incluindo '+fmtNum(msgCount)+' mensagens, '+fmtNum(traceCount)+' traceroutes e '+fmtNum(telemetryCount)+' pacotes de telemetria.');
  if(busiest) summary.push(statsNodeName(busiest.nodeNum,busiest.nodeId)+' foi o nó mais ativo, com '+fmtNum(busiest.packets)+' pacotes.');
  summary.push(anomalySummary.total ? 'A análise atual registra '+fmtNum(anomalySummary.total)+' pontos de atenção, sendo '+fmtNum(anomalySummary.critical||0)+' críticos.' : 'Nenhum ponto de atenção está registrado pelos critérios atuais.');
  document.getElementById('statsOverviewText').textContent=summary.join(' ');
  document.getElementById('statsOverviewTypes').innerHTML=statsSimpleTable((s.byType||[]).slice(0,10),[
    ['Tipo',x=>esc(packetTypeLabel(x.type))],['Pacotes',x=>'<b>'+fmtNum(x.count)+'</b>'],['%',x=>statsPct(x.count,s.total)]
  ]);
  document.getElementById('statsOverviewNodes').innerHTML=statsSimpleTable(nodes.slice(0,10),[
    ['Nó',x=>'<b>'+esc(statsNodeName(x.nodeNum,x.nodeId))+'</b>'],['Pacotes',x=>fmtNum(x.packets)],['SNR',x=>x.avgSnr==null?'—':fmtNum(x.avgSnr,1)+' dB']
  ]);

  document.getElementById('statsRfCards').innerHTML=[
    healthCard(fmtNum(links.length),'Pares observados'),
    healthCard(avgSnr==null?'—':fmtNum(avgSnr,1)+' dB','SNR médio'),
    healthCard(avgRssi==null?'—':fmtNum(avgRssi,0)+' dBm','RSSI médio'),
    healthCard(fmtNum(links.filter(x=>Number(x.packets||0)>=10).length),'Enlaces recorrentes','10+ pacotes')
  ].join('');
  document.getElementById('statsRfLongestRows').innerHTML=longestRf.slice(0,10).map((x,i)=>{
    const traces=(x.evidenceTraceIds||[]).join(', ')||'—';
    const packets=(x.evidencePacketIds||[]).join(', ')||'—';
    const source=x.evidenceSource==='api-traceroute'?'API traceroute':(x.evidenceSource==='mixed'?'RF observado + API traceroute':'RF observado no hop');
    const audit='Evidência: '+source+' · traceroute(s): '+traces+' · pacote(s): '+packets;
    const title=tr('Clique para mostrar somente este enlace no mapa')+' · '+audit;
    return '<tr class="clickableStatRow" tabindex="0" role="button" data-edge-id="'+esc(x.edgeId||'')+'" title="'+esc(title)+'"><td><b>'+(i+1)+'</b></td><td><b>'+esc(x.aName||x.aId||String(x.a))+'</b>'+(x.aId?'<br><span class="settingDesc">'+esc(x.aId)+'</span>':'')+'</td><td><b>'+esc(x.bName||x.bId||String(x.b))+'</b>'+(x.bId?'<br><span class="settingDesc">'+esc(x.bId)+'</span>':'')+'</td><td><b>'+fmtNum(x.distanceKm,1)+' km</b></td><td title="'+esc(audit)+'">'+fmtNum(x.rfObservations)+'<br><span class="settingDesc">'+esc(source)+'</span></td><td>'+(x.avgSnr==null?'—':fmtNum(x.avgSnr,1)+' dB')+'</td><td>'+(x.lastRfSeenMs?esc(humanAge(Number(x.lastRfSeenMs))):'—')+'</td></tr>';
  }).join('')||'<tr><td colspan="7" class="emptyPanel">Sem enlaces RF diretos com posição válida no período.</td></tr>';
  const rankingAudit=(p.rankingAudit||[]).filter(x=>x.reason!=='elegivel').slice(0,20);
  const reasonLabel=x=>x==='multihop_confirmado'?'Multi-hop confirmado pela API':x==='sem_posicao'?'Sem posição válida':x==='fora_top10'?'Elegível, fora do Top 10':x;
  document.getElementById('statsRankingAuditRows').innerHTML=rankingAudit.map(x=>
    '<tr><td><b>'+esc(x.aName||String(x.a))+'</b></td><td><b>'+esc(x.bName||String(x.b))+'</b></td><td>'+(x.distanceKm==null?'—':fmtNum(x.distanceKm,1)+' km')+'</td><td>'+fmtNum(x.rfObservations||0)+'</td><td>'+fmtNum(x.directObservations||0)+'</td><td>'+esc(reasonLabel(x.reason))+'</td></tr>'
  ).join('')||'<tr><td colspan="6" class="emptyPanel">Nenhum enlace RF excluído pelos critérios atuais.</td></tr>';

  document.querySelectorAll('#statsRfLongestRows tr[data-edge-id]').forEach(row=>{
    const activate=()=>isolateStatsRfLink(row.dataset.edgeId);
    row.addEventListener('click',activate);
    row.addEventListener('keydown',ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();activate();}});
  });
  document.getElementById('statsRfRows').innerHTML=links.slice(0,40).map(x=>
    '<tr><td><b>'+esc(statsNodeName(x.fromNode,x.fromNodeId))+'</b></td><td>'+esc(statsNodeName(x.toNode,x.toNodeId))+'</td><td>'+fmtNum(x.packets)+'</td><td>'+(x.avgSnr==null?'—':fmtNum(x.avgSnr,1)+' dB')+'</td><td>'+(x.avgRssi==null?'—':fmtNum(x.avgRssi,0)+' dBm')+'</td><td>'+(x.lastSeen?esc(humanAge(Number(x.lastSeen))):'—')+'</td></tr>'
  ).join('')||'<tr><td colspan="6" class="emptyPanel">Sem enlaces no período.</td></tr>';

  const hops=new Map(), relay=new Map();
  for(const x of packets){
    const hs=Number(x.hop_start),hl=Number(x.hop_limit);
    if(Number.isFinite(hs)&&Number.isFinite(hl)){const h=Math.max(0,hs-hl);hops.set(h,(hops.get(h)||0)+1);}
    if(x.relay_node!==null&&x.relay_node!==undefined&&x.relay_node!==''){const k=String(x.relay_node);relay.set(k,(relay.get(k)||0)+1);}
  }
  const hopRows=[...hops.entries()].sort((a,b)=>a[0]-b[0]).map(x=>({h:x[0],n:x[1]}));
  const relayRows=[...relay.entries()].sort((a,b)=>b[1]-a[1]).slice(0,12).map(x=>({relay:x[0],n:x[1]}));
  document.getElementById('statsRoutingCards').innerHTML=[
    healthCard(fmtNum(traceCount),'Traceroutes observados'),
    healthCard(fmtNum(healthPayload?.traceroutes?.roundTrip||0),'Ida e volta'),
    healthCard(healthPayload?.traceroutes?.medianHops==null?'—':fmtNum(healthPayload.traceroutes.medianHops,1),'Mediana de hops'),
    healthCard(fmtNum(relay.size),'Relays observados')
  ].join('');
  document.getElementById('statsHopDistribution').innerHTML=statsSimpleTable(hopRows,[['Hops',x=>'<b>'+fmtNum(x.h)+'</b>'],['Pacotes',x=>fmtNum(x.n)],['%',x=>statsPct(x.n,packets.length)]]);
  document.getElementById('statsRelayRows').innerHTML=statsSimpleTable(relayRows,[['Relay',x=>'<code>'+esc(x.relay)+'</code>'],['Ocorrências',x=>'<b>'+fmtNum(x.n)+'</b>']]);

  document.getElementById('statsTrafficCards').innerHTML=[
    healthCard(fmtNum(s.total),'Pacotes'),healthCard(fmtNum(s.rx),'RX'),healthCard(fmtNum(s.tx),'TX'),healthCard(fmtNum(s.originNodes),'Nós originadores')
  ].join('');
  document.getElementById('statsTrafficTypeRows').innerHTML=(s.byType||[]).map(x=>'<tr><td><b>'+esc(packetTypeLabel(x.type))+'</b></td><td>'+fmtNum(x.count)+'</td><td>'+statsPct(x.count,s.total)+'</td></tr>').join('')||'<tr><td colspan="3" class="emptyPanel">Sem tráfego.</td></tr>';

  const qtypes=['NODEINFO_APP','POSITION_APP','TELEMETRY_APP','TRACEROUTE_APP','ROUTING_APP'];
  const qrows=qtypes.map(type=>{const a=packets.filter(x=>x.portnum_name===type);return {type:type,tx:a.filter(x=>String(x.direction).toLowerCase()==='tx').length,rx:a.filter(x=>String(x.direction).toLowerCase()==='rx').length,total:a.length};});
  document.getElementById('statsQueryCards').innerHTML=[
    healthCard(fmtNum(qrows.reduce((a,x)=>a+x.tx,0)),'Consultas/TX observados'),
    healthCard(fmtNum(qrows.reduce((a,x)=>a+x.rx,0)),'Respostas/RX observadas'),
    healthCard(fmtNum(qrows.find(x=>x.type==='TRACEROUTE_APP')?.total||0),'Traceroute'),
    healthCard(fmtNum(qrows.find(x=>x.type==='TELEMETRY_APP')?.total||0),'Telemetria')
  ].join('');
  document.getElementById('statsQueryRows').innerHTML=qrows.map(x=>'<tr><td><b>'+esc(packetTypeLabel(x.type))+'</b></td><td>'+fmtNum(x.tx)+'</td><td>'+fmtNum(x.rx)+'</td><td>'+fmtNum(x.total)+'</td></tr>').join('');

  const chatRows=healthPayload?.chatInteractions||[];
  document.getElementById('statsChatCards').innerHTML=[healthCard(fmtNum(msgCount),'Mensagens no período'),healthCard(fmtNum(chatRows.length),'Nós com interação acumulada')].join('');
  document.getElementById('statsChatRows').innerHTML=chatRows.map(x=>'<tr><td><b>'+esc(x.name||x.nodeId||'Nó desconhecido')+'</b>'+(x.nodeId?'<br><span class="settingDesc">'+esc(x.nodeId)+'</span>':'')+'</td><td>'+fmtNum(x.interactions)+'</td></tr>').join('')||'<tr><td colspan="2" class="emptyPanel">Sem interações registradas.</td></tr>';

  const energy=(topology?.nodes||[]).map(n=>{
    const batt=Number(n.batteryLevel??n.battery_level??n.battery),volt=Number(n.voltage);
    return {n:n,batt:Number.isFinite(batt)?batt:null,volt:Number.isFinite(volt)?volt:null,last:Number(nodeTrafficLastSeen.get(Number(n.nodeNum))||0)};
  }).filter(x=>x.batt!==null||x.volt!==null).sort((a,b)=>(a.batt??999)-(b.batt??999));
  const low=energy.filter(x=>x.batt!==null&&x.batt<20),critical=energy.filter(x=>x.batt!==null&&x.batt<10),batteryVals=energy.map(x=>x.batt).filter(x=>x!==null);
  document.getElementById('statsEnergyCards').innerHTML=[
    healthCard(fmtNum(energy.length),'Nós com energia'),healthCard(fmtNum(low.length),'Bateria < 20%'),healthCard(fmtNum(critical.length),'Bateria < 10%'),
    healthCard(batteryVals.length?fmtNum(statsAvg(batteryVals),0)+'%':'—','Bateria média')
  ].join('');
  document.getElementById('statsEnergyRows').innerHTML=energy.map(x=>'<tr><td><b>'+esc(x.n.name||x.n.longName||x.n.nodeId||String(x.n.nodeNum))+'</b></td><td>'+(x.batt==null?'—':fmtNum(x.batt,0)+'%')+'</td><td>'+(x.volt==null?'—':fmtNum(x.volt,2)+' V')+'</td><td>'+(x.last?esc(humanAge(x.last)):'—')+'</td></tr>').join('')||'<tr><td colspan="4" class="emptyPanel">Nenhuma telemetria de energia disponível.</td></tr>';
}
async function loadStatistics(force=false){
  statsPopulateNodeFilter();
  if(!force&&statisticsPayload&&Date.now()-statisticsLoadedAt<30000){renderStatistics();return;}
  document.getElementById('statsUpdated').textContent='atualizando...';
  try{
    const q=statisticsQuery();
    await Promise.all([loadNetworkHealth(force),loadAnomalies(force)]);
    const rs=await Promise.all([
      fetch('/api/archive/stats?x=1'+q,{cache:'no-store'}),
      fetch('/api/archive/nodes?x=1'+q,{cache:'no-store'}),
      fetch('/api/archive/links?x=1'+q,{cache:'no-store'}),
      fetch('/api/archive/packets?limit=5000'+q,{cache:'no-store'}),
      fetch('/api/archive/rf-longest-links?x=1'+q,{cache:'no-store'}),
      fetch('/api/archive/rf-ranking-audit?x=1'+q,{cache:'no-store'})
    ]);
    for(const r of rs) if(!r.ok) throw new Error('HTTP '+r.status);
    const body=await Promise.all(rs.map(r=>r.json()));
    statisticsPayload={stats:body[0],nodes:body[1].data||[],links:body[2].data||[],packets:body[3].data||[],longestRfLinks:body[4].data||[],rankingAudit:body[5].data||[],rankingAuditSummary:body[5].summary||{}};
    statisticsLoadedAt=Date.now();renderStatistics();
    document.getElementById('statsUpdated').textContent='atualizado '+new Date().toLocaleTimeString(uiLocale());
  }catch(e){
    document.getElementById('statsOverviewText').textContent='Erro ao carregar estatísticas: '+String(e.message||e);
    document.getElementById('statsUpdated').textContent='erro';
  }
}
function isolateStatsRfLink(edgeId){
  const edge=(topology?.edges||[]).find(e=>String(e.id||'')===String(edgeId||''));
  if(!edge){alert(tr('Este enlace não está disponível na topologia atual.'));return;}
  const nodeMap=new Map((topology?.nodes||[]).map(n=>[Number(n.nodeNum),n]));
  const a=nodeMap.get(Number(edge.a)),b=nodeMap.get(Number(edge.b));
  if(!nodeHasValidMapPosition(a)||!nodeHasValidMapPosition(b)){
    alert(tr('Este enlace não pode ser enquadrado porque um dos nós não possui posição válida.'));
    return;
  }
  isolatedEdgeId=String(edge.id||edgeId);
  closeNodeWindow(false);
  setView('map');
  render();
  setTimeout(()=>fitMapTight(),80);
}
function clearStatsRfLinkIsolation(){
  if(!isolatedEdgeId)return;
  isolatedEdgeId=null;
  isolatedEdgeNodes=new Set();
  render();
}
document.getElementById('clearLinkIsolation').addEventListener('click',clearStatsRfLinkIsolation);

function setStatisticsTab(name,updateRoute=true){
  taCurrentStatsTab=name||'overview';
  document.querySelectorAll('.statsTab').forEach(b=>b.classList.toggle('active',b.dataset.statsTab===name));
  document.querySelectorAll('.statsPanel').forEach(p=>p.classList.remove('active'));
  const id='statsPanel'+name.charAt(0).toUpperCase()+name.slice(1);
  document.getElementById(id)?.classList.add('active');
  document.getElementById('statsAccessControls')?.classList.toggle('open',name==='access');
  if(name==='network')loadNetworkHealth(false);
  if(name==='anomalies')loadAnomalies(false);
  if(name==='access')loadAccessStats(false);
  if(updateRoute)taSyncRoute({view:'statistics'});
}
document.querySelectorAll('.statsTab').forEach(b=>b.addEventListener('click',()=>setStatisticsTab(b.dataset.statsTab)));
document.getElementById('statsReload').addEventListener('click',()=>loadStatistics(true));
document.getElementById('statsReport').addEventListener('click',openStatisticsReport);
document.getElementById('statsExportCsv').addEventListener('click',exportStatisticsCsv);
document.getElementById('statsPeriod').addEventListener('change',()=>{statisticsPayload=null;loadStatistics(true);taSyncRoute({replace:true,view:'statistics'});});
document.getElementById('statsNodeFilter').addEventListener('change',()=>{statisticsPayload=null;loadStatistics(true);taSyncRoute({replace:true,view:'statistics'});});

function sevLabel(s){if(currentLang==='en')return s==='critical'?'Critical':s==='warning'?'Warning':s==='info'?'Informational':'OK';return s==='critical'?'Crítica':s==='warning'?'Atenção':s==='info'?'Informativa':'OK';}
function renderAnomalies(){
  if(!anomalyPayload)return;
  const b=anomalyPayload;
  const filter=document.getElementById('anomalySeverity')?.value||'all';
  const rows=(b.data||[]).filter(a=>filter==='all'||String(a.severity)===filter);
  document.getElementById('anomalyCards').innerHTML=[healthCard(b.summary.total,'Pontos de atenção'),healthCard(b.summary.critical,'Críticos'),healthCard(b.summary.warning,'Atenção'),healthCard(b.summary.info,'Informativos')].join('');
  document.getElementById('anomalyList').innerHTML=rows.map(a=>`<div class="anomalyRow"><div><span class="severity sev-${esc(a.severity)}">${esc(sevLabel(a.severity))}</span></div><div><div class="anomalyTitle">${esc(a.title)}</div><div class="anomalyEvidence">${esc(a.subject||'')}</div></div><div class="anomalyMsg">${esc(a.message)}${a.evidence?`<div class="anomalyEvidence">${esc(a.evidence)}</div>`:''}</div><div class="anomalyTime">${a.timestampMs?esc(humanAge(a.timestampMs)):'—'}</div></div>`).join('')||'<div class="emptyPanel"><span class="severity sev-ok">OK</span> Nenhum ponto de atenção foi identificado pelos critérios atuais.</div>';
}
async function loadAnomalies(force=false){
  if(!force && Date.now()-anomalyLoadedAt<30000){renderAnomalies();return;}
  try{
    const r=await fetch('/api/anomalies',{cache:'no-store'}); if(!r.ok)throw new Error(`HTTP ${r.status}`); const b=await r.json(); anomalyLoadedAt=Date.now(); anomalyPayload=b;
    document.getElementById('anomalyUpdated').textContent=`analisado ${new Date(b.generatedAtMs).toLocaleTimeString(uiLocale())}`;
    renderAnomalies();
  }catch(e){document.getElementById('anomalyList').innerHTML=`<div class="emptyPanel">Erro ao analisar: ${esc(e)}</div>`;}
}
document.getElementById('healthReload').addEventListener('click',()=>loadNetworkHealth(true));
document.getElementById('anomalyReload').addEventListener('click',()=>loadAnomalies(true));
document.getElementById('anomalySeverity').addEventListener('change',renderAnomalies);

function accessCountryLabel(value){
  const raw=String(value||'').trim();
  if(!raw)return tr('Não informado');
  if(/^[A-Za-z]{2}$/.test(raw)){
    try{return new Intl.DisplayNames([uiLocale()],{type:'region'}).of(raw.toUpperCase())||raw.toUpperCase();}catch{}
  }
  return tr(raw);
}
function accessClientSummary(rows,label){
  const items=(rows||[]).slice(0,8);
  if(!items.length)return '<div class="emptyPanel">Sem dados.</div>';
  return '<div class="dashGrid">'+items.map(x=>healthCard(fmtNum(x.accesses),x.name,label)).join('')+'</div>';
}
function renderAccessStats(){
  const b=accessPayload;if(!b)return;
  document.getElementById('accessLocked').style.display='none';
  document.getElementById('accessContent').style.display='';
  document.getElementById('accessUpdated').textContent=`${tr('Atualizado ✓')} · ${new Date(b.generatedAtMs).toLocaleTimeString(uiLocale())}`;
  const s=b.summary||{};
  document.getElementById('accessCards').innerHTML=[
    healthCard(fmtNum(s.today),tr('Acessos hoje')),
    healthCard(fmtNum(s.last7d),tr('Acessos - 7 dias')),
    healthCard(fmtNum(s.last30d),tr('Acessos - 30 dias')),
    healthCard(fmtNum(s.uniqueIps30d),tr('IPs únicos - 30 dias')),
    healthCard(fmtNum(s.loginSuccess30d),tr('Logins com sucesso - 30 dias')),
    healthCard(fmtNum(s.loginFailed30d),tr('Falhas de login - 30 dias'))
  ].join('');

  const daily=b.daily||[],max=Math.max(1,...daily.map(x=>Number(x.accesses||0)));
  document.getElementById('accessDaily').innerHTML=daily.map(x=>{
    const pct=Math.max(2,Math.round(90*Number(x.accesses||0)/max));
    const label=String(x.day||'').slice(5).split('-').reverse().join('/');
    return `<div class="miniBarWrap"><div class="miniBarValue" style="--h:${pct}px">${fmtNum(x.accesses)}</div><div class="miniBar" style="height:${pct}px"></div><div class="miniBarLabel">${esc(label)}</div></div>`;
  }).join('')||'<div class="emptyPanel">Sem dados no período.</div>';

  document.getElementById('accessCountryRows').innerHTML=(b.countries||[]).map(x=>`<tr><td><b>${esc(accessCountryLabel(x.country))}</b></td><td>${fmtNum(x.accesses)}</td><td>${fmtNum(x.unique_ips)}</td></tr>`).join('')||'<tr><td colspan="3" class="emptyPanel">Sem dados.</td></tr>';
  document.getElementById('accessCityRows').innerHTML=(b.cities||[]).map(x=>`<tr><td><b>${esc(tr(x.city||'Não informado'))}</b></td><td>${esc(accessCountryLabel(x.country))}</td><td>${fmtNum(x.accesses)}</td><td>${fmtNum(x.unique_ips)}</td></tr>`).join('')||'<tr><td colspan="4" class="emptyPanel">Sem dados.</td></tr>';
  document.getElementById('accessIpRows').innerHTML=(b.ips||[]).map(x=>{
    const where=[x.city,x.country].filter(Boolean).map((v,i)=>i===1?accessCountryLabel(v):tr(v)).join(' / ')||tr('Não informado');
    return `<tr><td><code>${esc(x.ip||'—')}</code></td><td>${esc(where)}</td><td><b>${fmtNum(x.accesses)}</b></td><td>${x.first_seen?esc(new Date(Number(x.first_seen)).toLocaleString(uiLocale())):'—'}</td><td>${x.last_seen?esc(new Date(Number(x.last_seen)).toLocaleString(uiLocale())):'—'}</td><td>${esc(x.user_agent||'—')}</td></tr>`;
  }).join('')||'<tr><td colspan="6" class="emptyPanel">Sem dados.</td></tr>';

  document.getElementById('accessClients').innerHTML=
    '<h4>'+esc(tr('Navegador'))+'</h4>'+accessClientSummary(b.browsers,'')+
    '<h4>Sistema operacional</h4>'+accessClientSummary(b.operatingSystems,'');

  const geoText=b.geoipConfigured
    ? 'GeoIP externo configurado no servidor.'
    : 'Cidade/país usam cabeçalhos do proxy/CDN quando disponíveis. Sem esses cabeçalhos, IPs públicos permanecem como “Não informado”; nenhum IP é enviado a serviço externo por padrão.';
  document.getElementById('accessNote').textContent=`Log: ${b.logFile}. Retenção: ${b.retentionDays||0} dias. ${geoText}`;
}
async function loadAccessStats(force=false){
  if(!force&&accessPayload&&Date.now()-accessLoadedAt<30000){renderAccessStats();return;}
  const days=Number(document.getElementById('accessDays')?.value||30);
  try{
    const r=await fetch(`/api/access-stats?days=${encodeURIComponent(days)}`,{cache:'no-store'});
    if(r.status===401){
      document.getElementById('accessLocked').style.display='';
      document.getElementById('accessContent').style.display='none';
      document.getElementById('accessUpdated').textContent='';
      return;
    }
    const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||`HTTP ${r.status}`);
    accessPayload=b;accessLoadedAt=Date.now();renderAccessStats();
  }catch(e){
    document.getElementById('accessCards').innerHTML=healthCard('Erro','Acessos',String(e.message||e));
  }
}
document.getElementById('accessReload').addEventListener('click',()=>loadAccessStats(true));
document.getElementById('accessDays').addEventListener('change',()=>{loadAccessStats(true);taSyncRoute({replace:true,view:'statistics'});});
document.getElementById('accessDownload').addEventListener('click',()=>{
  window.location.href='/api/access-log';
});

async function loadNodeTrafficActivity(){
  try{
    const r=await fetch('/api/archive/nodes',{cache:'no-store'});
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    const body=await r.json();
    nodeTrafficLastSeen.clear();
    for(const row of body.data||[]){
      const n=Number(row.nodeNum), ts=Number(row.lastSeen);
      if(Number.isFinite(n)&&Number.isFinite(ts)&&ts>0) nodeTrafficLastSeen.set(n,ts);
    }
  }catch(e){ console.warn('Não foi possível atualizar a atividade dos nós:',e); }
}

async function load(fit=false){
  try{
    const r = await fetch('/api/topology', {cache:'no-store'});
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    topology = await r.json();
    await loadNodeTrafficActivity();
    render();
    map.invalidateSize();
    if(document.getElementById('playMode').value === 'history') updatePlaybackStatusIdle();
    if(fit && lastBounds && lastBounds.isValid()) await fitMapTight();
  }catch(e){
    console.error('Erro ao carregar topologia:', e);
    document.getElementById('summary').innerHTML = `<span class="metric warn">Erro ao carregar topologia: ${esc(e.message||e)}</span>`;
  }
}

async function refreshTopologyNow(){
  if(!authCanWrite()){openAuthModal();return;}
  const btn=document.getElementById('reload'); if(btn.disabled) return;
  btn.disabled=true; btn.textContent='Atualizando...';
  try{
    const r=await authFetch('/api/topology/refresh',{method:'POST',cache:'no-store'});
    const b=await r.json();
    if(!r.ok||!b.success) throw new Error(b.message||`HTTP ${r.status}`);
    await load(false);
    btn.textContent='Atualizado ✓';
    setTimeout(()=>{btn.textContent='Atualizar';},1600);
  }catch(e){
    console.error('Falha ao atualizar topologia:',e);
    btn.textContent='Erro';
    document.getElementById('playStatus').textContent=`Falha ao atualizar: ${String(e.message||e)}`;
    setTimeout(()=>{btn.textContent='Atualizar';},2500);
  }finally{ btn.disabled=false; }
}
function nextPaint(){
  return new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
}
function mapContentFits(margin=6){
  const size=map.getSize();
  if(!size || size.x<=0 || size.y<=0) return true;

  if(lastBounds && lastBounds.isValid()){
    const sw=map.latLngToContainerPoint(lastBounds.getSouthWest());
    const ne=map.latLngToContainerPoint(lastBounds.getNorthEast());
    const minX=Math.min(sw.x,ne.x), maxX=Math.max(sw.x,ne.x);
    const minY=Math.min(sw.y,ne.y), maxY=Math.max(sw.y,ne.y);
    if(minX<margin || minY<margin || maxX>size.x-margin || maxY>size.y-margin) return false;
  }

  const mapRect=map.getContainer().getBoundingClientRect();
  let fits=true;
  nodeLayer.eachLayer(layer=>{
    if(!fits) return;
    if(typeof layer.getLatLng==='function'){
      const p=map.latLngToContainerPoint(layer.getLatLng());
      const radius=Number(layer?.options?.radius||7)+Number(layer?.options?.weight||0)+2;
      if(p.x-radius<margin || p.y-radius<margin || p.x+radius>size.x-margin || p.y+radius>size.y-margin){
        fits=false; return;
      }
    }
    const tooltip=typeof layer.getTooltip==='function' ? layer.getTooltip() : null;
    if(tooltip?.options?.permanent){
      const el=typeof tooltip.getElement==='function' ? tooltip.getElement() : null;
      if(el){
        const r=el.getBoundingClientRect();
        if(r.left<mapRect.left+margin || r.top<mapRect.top+margin || r.right>mapRect.right-margin || r.bottom>mapRect.bottom-margin){
          fits=false;
        }
      }
    }
  });
  return fits;
}
async function fitMapTight(){
  if(!lastBounds || !lastBounds.isValid()) return;

  map.stop();
  map.fitBounds(lastBounds,{padding:[6,6],animate:false,maxZoom:18});
  await nextPaint();

  let safeZoom=map.getZoom();
  let attempts=0;

  while(!mapContentFits(6) && attempts<20 && safeZoom>map.getMinZoom()){
    safeZoom=Math.max(map.getMinZoom(),safeZoom-0.05);
    map.setZoom(safeZoom,{animate:false});
    await nextPaint();
    attempts++;
  }

  attempts=0;
  while(attempts<20){
    const candidate=Math.min(map.getMaxZoom(),safeZoom+0.05);
    if(candidate<=safeZoom+0.001) break;
    map.setZoom(candidate,{animate:false});
    await nextPaint();
    if(!mapContentFits(6)){
      map.setZoom(safeZoom,{animate:false});
      await nextPaint();
      break;
    }
    safeZoom=candidate;
    attempts++;
  }
}

for(const id of ['ageHours','minObs','onlyIdentified']) document.getElementById(id).addEventListener('change', () => { historyIndex=0; savePrefs(); render(); if(id==='ageHours'&&document.getElementById('rfCoverageEnabled')?.checked)refreshRfCoverage(); });
document.getElementById('showShortNames').addEventListener('change', () => { savePrefs(); render(); });
for(const id of ['showLines','showNodes','showHeatmap']) document.getElementById(id).addEventListener('change', () => { savePrefs(); render(); });
document.getElementById('mapType').addEventListener('change', (ev) => { setBaseMap(ev.target.value); savePrefs(); });
document.getElementById('mapToolbarType').addEventListener('change', (ev) => { setBaseMap(ev.target.value); savePrefs(); });
document.getElementById('weatherRadarEnabled').addEventListener('change',ev=>setWeatherRadarEnabled(ev.target.checked));
document.getElementById('rfCoverageEnabled').addEventListener('change',ev=>setRfCoverageEnabled(ev.target.checked));
document.getElementById('hillshadeEnabled').addEventListener('change',ev=>setHillshadeEnabled(ev.target.checked));
document.getElementById('elevationEnabled').addEventListener('change',ev=>setElevationEnabled(ev.target.checked));
document.getElementById('elevationSliderMax').addEventListener('input',ev=>{if(ev.target.value!=='')setElevationSliderMax(ev.target.value);});
document.getElementById('elevationSliderMax').addEventListener('change',ev=>setElevationSliderMax(ev.target.value,{persist:true}));
document.getElementById('elevationOpacity').addEventListener('input',ev=>setElevationOpacity(ev.target.value));
document.getElementById('elevationOpacity').addEventListener('change',ev=>setElevationOpacity(ev.target.value,{persist:true}));
document.getElementById('lightningEnabled').addEventListener('change',ev=>setLightningEnabled(ev.target.checked));
document.getElementById('alertsEnabled').addEventListener('change',ev=>setAlertsEnabled(ev.target.checked));
document.getElementById('cloudsEnabled').addEventListener('change',ev=>setCloudsEnabled(ev.target.checked));
map.on('moveend',()=>{if(document.getElementById('lightningEnabled')?.checked)refreshLightning();});
document.getElementById('mapBrightness').addEventListener('input', () => { applyBrightness(); savePrefs(); });
for(const id of ['rfLineColor','mqttLineColor']) document.getElementById(id).addEventListener('input', () => { savePrefs(); render(); renderLegend(); });
document.getElementById('rfLineWidth').addEventListener('input',()=>{document.getElementById('rfLineWidthValue').textContent=`${document.getElementById('rfLineWidth').value} px`;savePrefs();render();renderLegend();});
document.getElementById('mqttLineWidth').addEventListener('input',()=>{document.getElementById('mqttLineWidthValue').textContent=`${document.getElementById('mqttLineWidth').value} px`;savePrefs();render();renderLegend();});
document.getElementById('lineStyleReset').addEventListener('click',()=>{document.getElementById('rfLineColor').value='#ffff00';document.getElementById('rfLineWidth').value='3';document.getElementById('mqttLineColor').value='#ff8c42';document.getElementById('mqttLineWidth').value='3';document.getElementById('rfLineWidthValue').textContent='3 px';document.getElementById('mqttLineWidthValue').textContent='3 px';savePrefs();render();renderLegend();});
document.getElementById('animSpeed').addEventListener('change', savePrefs);
document.getElementById('playMode').addEventListener('change', () => {
  stopAnimation(); stopLivePolling();
  if(document.getElementById('playMode').value === 'live') startLivePolling();
  else updatePlaybackStatusIdle();
});
document.getElementById('playTrace').addEventListener('click', () => {
  if(document.getElementById('playMode').value==='live'){
    if(!livePollTimer){
      startLivePolling();
      return;
    }
    playbackRunning=true;
    liveAnimationPaused=!liveAnimationPaused;
    if(!liveAnimationPaused){ processLiveQueue(); flushPausedActivityQueue(); }
    updatePlaybackStatusIdle();
    return;
  }
  if(playbackRunning){
    historyAnimationPaused=!historyAnimationPaused;
    updatePlaybackStatusIdle();
  }else{
    playHistoryLoop();
  }
});
document.getElementById('prevTrace').addEventListener('click', () => { if(document.getElementById('playMode').value==='history') playHistoryOnce(historyIndex-1); });
document.getElementById('nextTrace').addEventListener('click', () => { if(document.getElementById('playMode').value==='history') playHistoryOnce(historyIndex+1); });
document.getElementById('reload').addEventListener('click',refreshTopologyNow);
document.getElementById('fit').addEventListener('click',fitMapTight);



// ===== Canal primário / chat =====
let primaryMessages=[];
let messagesInitialized=false;
let messageFetchLimit=250;
let messageNewestSeen=0;
let messageSeenIds=new Set();
let replyingTo=null;
let messageAutoScroll=true;
let messagePendingBelow=0;
let messageScrollRestoring=false;
const MESSAGE_BOTTOM_THRESHOLD=90;
const MESSAGE_READ_KEY='trafficAnalyzerPrimaryLastReadV117';
const MESSAGE_EMOJIS=['😀','😄','😉','👍','👎','❤️','😂','😮','😢','🙏','🔥','🎉','✅','❌','📡','📍','⚡','🚙','🛰️','📻','🔧'];
const QUICK_REACTIONS=['👍','👎','❤️','😂','😮','😢'];
function msgTimeMs(m){return Number(m.receivedAt||m.createdAt||m.timestamp||0)||0;}
function messageKey(m){return String(m.id||`${m.fromNodeId||''}|${m.requestId||''}|${msgTimeMs(m)}|${m.text||''}`);}
function messagePacketId(m){
  const parts=String(m?.id||'').split('_'),last=parts[parts.length-1],n=Number(last);
  if(Number.isInteger(n)&&n>0)return n;
  const req=Number(m?.requestId);return Number.isInteger(req)&&req>0?req:null;
}
function looksLikeEmojiOnly(text){const s=String(text||'').trim();return !!s&&s.length<=12&&!/[A-Za-z0-9]/.test(s);}
function isReactionMessage(m){return Number(m?.emoji)===1 || (Number(m?.replyId)>0&&looksLikeEmojiOnly(m?.text));}
function messageByPacketId(id){const n=Number(id);return primaryMessages.find(m=>!isReactionMessage(m)&&messagePacketId(m)===n)||null;}
function dateKey(ms){const d=new Date(ms);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function dayLabel(ms){const d=new Date(ms),now=new Date();const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());const that=new Date(d.getFullYear(),d.getMonth(),d.getDate());const delta=Math.round((today-that)/86400000);if(delta===0)return 'Hoje';if(delta===1)return 'Ontem';return d.toLocaleDateString(uiLocale(),{day:'2-digit',month:'long',year:'numeric'});}
function lastReadMs(){return Number(localStorage.getItem(MESSAGE_READ_KEY)||0)||0;}
function markMessagesRead(){if(!primaryMessages.length)return;const newest=Math.max(...primaryMessages.filter(m=>!m.mine&&!isReactionMessage(m)).map(msgTimeMs),0);if(newest>lastReadMs())localStorage.setItem(MESSAGE_READ_KEY,String(newest));updateUnreadBadge();document.querySelectorAll('#messageList .msgNewMark').forEach(el=>el.remove());}
function updateUnreadBadge(){const lr=lastReadMs();const unread=primaryMessages.filter(m=>!m.mine&&!isReactionMessage(m)&&msgTimeMs(m)>lr).length;const nav=document.getElementById('messagesNav'),count=document.getElementById('messagesUnreadCount');count.textContent=String(unread);nav.classList.toggle('unread',unread>0);nav.title=unread?`${unread} mensagem(ns) não lida(s)`:'Sem mensagens não lidas';}
function messageIsNearBottom(threshold=MESSAGE_BOTTOM_THRESHOLD){
  const el=document.getElementById('messageList');if(!el)return true;
  return (el.scrollHeight-el.scrollTop-el.clientHeight)<=threshold;
}
function updateMessageNewBelowButton(){
  const btn=document.getElementById('messageNewBelow');if(!btn)return;
  btn.classList.toggle('open',!messageAutoScroll&&messagePendingBelow>0);
  btn.textContent=messagePendingBelow>1?`↓ ${tr('Novas mensagens')} (${messagePendingBelow})`:`↓ ${tr('Novas mensagens')}`;
}
function setMessageScrollTop(top){
  const el=document.getElementById('messageList');if(!el)return;
  messageScrollRestoring=true;
  const previous=el.style.scrollBehavior;el.style.scrollBehavior='auto';el.scrollTop=Math.max(0,top);
  requestAnimationFrame(()=>{el.style.scrollBehavior=previous;messageScrollRestoring=false;});
}
function scrollMessagesToBottom(smooth=true){
  const el=document.getElementById('messageList');if(!el)return;
  messageAutoScroll=true;messagePendingBelow=0;updateMessageNewBelowButton();
  if(smooth)el.scrollTo({top:el.scrollHeight,behavior:'smooth'});else setMessageScrollTop(el.scrollHeight);
  if(document.getElementById('viewMessages').classList.contains('active'))markMessagesRead();
}
let mentionMatches=[];
let mentionActiveIndex=0;
let mentionStart=-1;
function mentionNodeList(){
  return (topology?.nodes||[]).filter(n=>n && (n.name||n.shortName||n.nodeId)).map(n=>({nodeNum:n.nodeNum,nodeId:n.nodeId||'',shortName:n.shortName||'',name:n.longName||n.name||n.shortName||n.nodeId||''}));
}
function mentionContext(){
  const input=document.getElementById('messageInput'),pos=input.selectionStart??input.value.length,before=input.value.slice(0,pos);
  const m=before.match(/(^|[\s,;:!?])@([^@\s,;:!?]*)$/);
  if(!m) return null;
  return {query:(m[2]||'').toLowerCase(),start:pos-(m[2]||'').length-1,end:pos};
}
function closeMentionSuggestions(){const box=document.getElementById('mentionSuggestions');box.classList.remove('open');box.innerHTML='';mentionMatches=[];mentionStart=-1;}
function refreshMentionSuggestions(){
  const ctx=mentionContext(); if(!ctx){closeMentionSuggestions();return;}
  mentionStart=ctx.start;
  const q=ctx.query;
  mentionMatches=mentionNodeList().filter(n=>!q||[n.shortName,n.name,n.nodeId].some(v=>String(v||'').toLowerCase().includes(q))).sort((a,b)=>{
    const ae=String(a.shortName||'').toLowerCase()===q?0:1,be=String(b.shortName||'').toLowerCase()===q?0:1;
    return ae-be||String(a.shortName||a.name).localeCompare(String(b.shortName||b.name),uiLocale());
  }).slice(0,12);
  mentionActiveIndex=Math.min(mentionActiveIndex,Math.max(0,mentionMatches.length-1));
  const box=document.getElementById('mentionSuggestions');
  if(!mentionMatches.length){closeMentionSuggestions();return;}
  box.innerHTML=mentionMatches.map((n,i)=>`<div class="mentionItem ${i===mentionActiveIndex?'active':''}" data-mi="${i}"><div class="mentionShort">${esc(n.shortName||'@')}</div><div><div class="mentionLong">${esc(n.name)}</div><div class="mentionId">${esc(n.nodeId)}</div></div></div>`).join('');
  box.classList.add('open');
  box.querySelectorAll('.mentionItem').forEach(el=>el.addEventListener('mousedown',e=>{e.preventDefault();selectMention(Number(el.dataset.mi));}));
}
function selectMention(index){
  const n=mentionMatches[index]; if(!n)return;
  const input=document.getElementById('messageInput'),pos=input.selectionStart??input.value.length,start=mentionStart>=0?mentionStart:pos;
  const full=n.name||n.shortName||n.nodeId;
  input.value=input.value.slice(0,start)+full+' '+input.value.slice(pos);
  const next=start+full.length+1; input.setSelectionRange(next,next);closeMentionSuggestions();updateMessageCounter();input.focus();
}
function chatMentionsHtml(text){
  let html=esc(text||'');
  const names=[...new Set(mentionNodeList().flatMap(n=>[n.name,n.shortName].filter(Boolean)))].sort((a,b)=>b.length-a.length);
  for(const name of names){
    const token=esc('@'+name);
    if(token) html=html.split(token).join(`<span class="chatMention">${token}</span>`);
  }
  return html;
}
function tracerouteDirectionHtml(title,body,cls=''){
  const normalized=String(body||'').replace(/\r/g,'').trim();
  if(!normalized)return '';
  const hops=normalized.split(/\s*(?:-->|→|->)\s*/).map(x=>x.trim()).filter(Boolean);
  const rows=hops.length>1?hops:[normalized];
  return `<div class="traceBlock ${cls}"><div class="traceBlockTitle">${esc(title)}</div>${rows.map((hop,i)=>`<span class="traceHop">${i?'<span class="traceArrow">→</span>':''}${chatMentionsHtml(hop)}</span>`).join('')}</div>`;
}
function renderTracerouteChatText(text){
  const raw=String(text||'').replace(/\r/g,'').trim();
  const match=raw.match(/^\s*Rota:\s*([\s\S]*?)\s+Voltar para:\s*([\s\S]*)$/i);
  if(!match)return null;
  const outbound=tracerouteDirectionHtml('Rota de ida',match[1],'outbound');
  const returned=String(match[2]||'').trim()
    ?tracerouteDirectionHtml('Rota de volta',match[2],'return')
    :'<div class="traceBlock return"><div class="traceBlockTitle">Rota de volta</div><span class="traceHop">Rota de volta não disponível</span></div>';
  return `<div class="traceBlocks">${outbound}${returned}</div>`;
}
function renderChatText(text){
  const trace=renderTracerouteChatText(text);
  return trace!==null?trace:chatMentionsHtml(text);
}
function deliveryVisual(m){const st=String(m.deliveryState||'').toLowerCase();if(m.ackFailed||m.routingErrorReceived||st==='failed')return {icon:'!',cls:'failed',tip:'Falha de entrega/roteamento reportada pelo MeshMonitor'};if(st==='confirmed'||m.ackFromNode)return {icon:'✓✓',cls:'confirmed',tip:'ACK confirmado pelo protocolo; não significa leitura humana'};if(st==='delivered')return {icon:'✓',cls:'',tip:'Transmitida para a malha pelo rádio local'};if(st==='queued'||st==='pending'||!st)return {icon:'◷',cls:'',tip:'Aguardando confirmação de transmissão'};return {icon:'✓',cls:'',tip:`Estado: ${st}`};}
function reactionGroups(){
  const groups=new Map();
  for(const r of primaryMessages){
    if(!isReactionMessage(r)||!Number(r.replyId))continue;
    const key=Number(r.replyId);
    if(!groups.has(key))groups.set(key,[]);
    groups.get(key).push(r);
  }
  return groups;
}
function reactionHtml(packetId,groups){
  const rows=groups.get(Number(packetId))||[];
  if(!rows.length)return '';
  const byEmoji=new Map();
  for(const r of rows){
    const e=String(r.text||'').trim();if(!e)continue;
    if(!byEmoji.has(e))byEmoji.set(e,[]);
    byEmoji.get(e).push(r);
  }
  return '<div class="msgReactions">'+[...byEmoji.entries()].map(([emoji,list])=>{
    const names=list.map(x=>x.fromName||x.fromNodeId||'Nó').filter(Boolean);
    const mine=list.some(x=>x.mine);
    return `<span class="reactionChip ${mine?'mine':''}" title="${esc(names.join(', '))}">${esc(emoji)}${list.length>1?` <b>${list.length}</b>`:''}</span>`;
  }).join('')+'</div>';
}
function replyQuoteHtml(m){
  const rid=Number(m?.replyId||0);if(!rid||isReactionMessage(m))return '';
  const original=messageByPacketId(rid);
  if(!original)return `<div class="msgReplyQuote"><b>${tr('Resposta')}</b><span>${tr('Mensagem original não carregada')} #${rid}</span></div>`;
  const who=original.fromName||original.fromNodeId||'Nó';
  const excerpt=String(original.text||'').replace(/\s+/g,' ').slice(0,120);
  return `<div class="msgReplyQuote"><b>${esc(who)}</b><span>${renderChatText(excerpt)}</span></div>`;
}
function bindMessageActions(){
  document.querySelectorAll('[data-message-node]').forEach(btn=>btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openNodeDetailsModal(Number(btn.dataset.messageNode));}));
  document.querySelectorAll('[data-replymsg]').forEach(btn=>btn.addEventListener('click',()=>beginReply(btn.dataset.replymsg)));
  document.querySelectorAll('[data-reacttoggle]').forEach(btn=>btn.addEventListener('click',()=>{
    const picker=document.querySelector(`[data-reactpicker="${CSS.escape(btn.dataset.reacttoggle)}"]`);
    document.querySelectorAll('.reactionPickerInline.open').forEach(x=>{if(x!==picker)x.classList.remove('open');});
    picker?.classList.toggle('open');
  }));
  document.querySelectorAll('[data-reaction-msg]').forEach(btn=>btn.addEventListener('click',()=>sendReaction(btn.dataset.reactionMsg,btn.dataset.emoji)));
  document.querySelectorAll('.msgRow[data-mid]').forEach(row=>row.addEventListener('dblclick',()=>beginReply(row.dataset.mid)));
}
function renderMessages(options={}){
  const {forceBottom=false,preserveOffset=false,oldHeight=null,oldTop=null}=options||{};
  const el=document.getElementById('messageList'),visible=primaryMessages.filter(m=>!isReactionMessage(m));
  const beforeHeight=oldHeight===null?el.scrollHeight:Number(oldHeight),beforeTop=oldTop===null?el.scrollTop:Number(oldTop);
  const wasNearBottom=messageIsNearBottom();
  if(!visible.length){el.innerHTML='<div class="emptyPanel">Nenhuma mensagem encontrada no canal primário.</div>';updateMessageNewBelowButton();return;}
  const groups=reactionGroups(),lr=lastReadMs();let html='',lastDay='';
  for(const m of visible){
    const ms=msgTimeMs(m),dk=dateKey(ms);if(dk!==lastDay){html+=`<div class="msgDay"><span>${esc(dayLabel(ms))}</span></div>`;lastDay=dk;}
    const dv=deliveryVisual(m),transport=m.viaMqtt?'MQTT':(m.viaStoreForward?'Store&Forward':'RF'),unread=!m.mine&&ms>lr;
    const mid=String(m.id||messageKey(m)),pid=messagePacketId(m);
    const actions=authCanWrite()?`<div class="msgActions"><button type="button" data-replymsg="${esc(mid)}" title="${tr('Responder')}">↩ ${tr('Responder')}</button>${!m.mine&&pid?`<button type="button" data-reacttoggle="${esc(mid)}" title="${tr('Reagir')}">☺ ${tr('Reagir')}</button>`:''}</div>`:'';
    const picker=authCanWrite()&&!m.mine&&pid?`<div class="reactionPickerInline" data-reactpicker="${esc(mid)}">${QUICK_REACTIONS.map(e=>`<button type="button" data-reaction-msg="${esc(mid)}" data-emoji="${esc(e)}">${esc(e)}</button>`).join('')}</div>`:'';
    const senderNum=Number(m.fromNodeNum);
    const senderName=esc(m.fromName||m.fromNodeId||'Nó');
    const senderHtml=!m.mine?(Number.isFinite(senderNum)&&senderNum>0
      ?`<div class="msgSender"><button type="button" class="msgSenderNode" data-message-node="${senderNum}" title="${esc(tr('Abrir informações do nó'))}">${senderName}</button> ${unread?'<span class="msgNewMark">nova</span>':''}</div>`
      :`<div class="msgSender">${senderName} ${unread?'<span class="msgNewMark">nova</span>':''}</div>`):'';
    html+=`<div class="msgRow ${m.mine?'mine':'theirs'}" data-mid="${esc(mid)}"><div class="msgBubble">${senderHtml}${replyQuoteHtml(m)}<div class="msgText">${renderChatText(m.text||'')}</div><div class="msgMeta">${new Date(ms).toLocaleString(uiLocale(),{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}${m.mine?`<span class="msgStatus ${dv.cls}" title="${esc(dv.tip)}">${dv.icon}</span>`:`<span class="msgTransport">${transport}</span>`}</div>${reactionHtml(pid,groups)}${actions}${picker}</div></div>`;
  }
  el.innerHTML=html;bindMessageActions();
  if(preserveOffset){
    const delta=Math.max(0,el.scrollHeight-beforeHeight);setMessageScrollTop(beforeTop+delta);messageAutoScroll=false;
  }else if(forceBottom||(messageAutoScroll&&wasNearBottom)){
    scrollMessagesToBottom(false);
  }else{
    setMessageScrollTop(beforeTop);messageAutoScroll=false;
  }
  updateMessageNewBelowButton();
}
async function loadPrimaryMessages(force=false,preserveScroll=false){
  const list=document.getElementById('messageList');
  const oldHeight=list.scrollHeight,oldTop=list.scrollTop,wasNearBottom=messageIsNearBottom();
  const shouldFollow=Boolean(force||(messageAutoScroll&&wasNearBottom));
  try{
    const r=await fetch(`/api/messages?limit=${messageFetchLimit}&_=${Date.now()}`,{cache:'no-store'});
    const b=await r.json();
    if(!r.ok||!b.success)throw new Error(b.message||`HTTP ${r.status}`);
    const rows=(b.data||[]).slice().sort((a,b)=>msgTimeMs(a)-msgTimeMs(b));
    const newIncoming=messagesInitialized?rows.filter(m=>!m.mine&&!isReactionMessage(m)&&!messageSeenIds.has(messageKey(m))):[];
    primaryMessages=rows;
    messageNewestSeen=Math.max(...rows.map(msgTimeMs),0);
    document.getElementById('messageStatus').textContent=`${rows.length} mensagens · atualizado ${new Date().toLocaleTimeString(uiLocale())}`;
    if(!messagesInitialized){
      messagesInitialized=true;
      messageSeenIds=new Set(rows.map(messageKey));
      if(!localStorage.getItem(MESSAGE_READ_KEY))localStorage.setItem(MESSAGE_READ_KEY,String(messageNewestSeen));
    }else{
      for(const m of rows)messageSeenIds.add(messageKey(m));
    }
    updateUnreadBadge();
    if(newIncoming.length){
      playMeshSound('message',{category:'messages'});
      if(!shouldFollow&&!preserveScroll)messagePendingBelow+=newIncoming.length;
    }
    renderMessages({forceBottom:shouldFollow&&!preserveScroll,preserveOffset:preserveScroll,oldHeight,oldTop});
    if(document.getElementById('viewMessages').classList.contains('active')&&shouldFollow&&!preserveScroll)markMessagesRead();
    updateMessageNewBelowButton();
    return true;
  }catch(e){
    document.getElementById('messageStatus').textContent=`Erro: ${e}`;
    return false;
  }
}
async function reloadPrimaryMessages(){
  const btn=document.getElementById('messageReload');
  btn.disabled=true;
  document.getElementById('messageStatus').textContent='Atualizando...';
  try{await loadPrimaryMessages(false,false);}finally{btn.disabled=false;}
}
async function loadOlderPrimaryMessages(){
  const btn=document.getElementById('messageLoadOlder');
  btn.disabled=true;
  try{
    if(messageFetchLimit>=1500){
      document.getElementById('messageStatus').textContent='Limite de 1.500 mensagens já carregado.';
      return;
    }
    const before=primaryMessages.map(msgTimeMs).filter(Boolean);
    const oldestBefore=before.length?Math.min(...before):Infinity;
    messageFetchLimit=Math.min(1500,messageFetchLimit+250);
    document.getElementById('messageStatus').textContent=`Carregando histórico anterior (até ${messageFetchLimit})...`;
    const ok=await loadPrimaryMessages(false,true);
    if(!ok)return;
    const after=primaryMessages.map(msgTimeMs).filter(Boolean);
    const oldestAfter=after.length?Math.min(...after):Infinity;
    document.getElementById('messageStatus').textContent=oldestAfter<oldestBefore
      ? `${primaryMessages.length} mensagens · histórico ampliado`
      : 'Nenhuma mensagem anterior adicional disponível.';
  }finally{btn.disabled=false;}
}
function renderReplyComposer(){
  const bar=document.getElementById('replyComposerBar'),box=document.getElementById('replyComposerText');
  if(!replyingTo){bar.classList.remove('open');box.innerHTML='';return;}
  const who=replyingTo.fromName||replyingTo.fromNodeId||'Nó',excerpt=String(replyingTo.text||'').replace(/\s+/g,' ').slice(0,150);
  box.innerHTML=`<b>${tr('Respondendo a')} ${esc(who)}</b><span>${esc(excerpt)}</span>`;bar.classList.add('open');
}
function beginReply(mid){
  if(!authCanWrite()){openAuthModal();return;}
  const m=primaryMessages.find(x=>String(x.id||messageKey(x))===String(mid)&&!isReactionMessage(x));if(!m)return;
  const pid=messagePacketId(m);if(!pid){alert(tr('Não foi possível identificar o pacote original para responder.'));return;}
  replyingTo=m;renderReplyComposer();document.getElementById('messageInput').focus();
}
function clearReply(){replyingTo=null;renderReplyComposer();}
function buildEmojiPicker(){
  const p=document.getElementById('emojiPicker');p.innerHTML=MESSAGE_EMOJIS.map(e=>`<button type="button" data-compose-emoji="${esc(e)}">${esc(e)}</button>`).join('');
  p.querySelectorAll('[data-compose-emoji]').forEach(b=>b.addEventListener('click',()=>{insertComposerEmoji(b.dataset.composeEmoji);p.classList.remove('open');}));
}
function insertComposerEmoji(emoji){
  const input=document.getElementById('messageInput'),start=input.selectionStart??input.value.length,end=input.selectionEnd??start;
  input.value=input.value.slice(0,start)+emoji+input.value.slice(end);
  const next=start+emoji.length;input.setSelectionRange(next,next);updateMessageCounter();input.focus();
}
function toggleComposerEmojiPicker(){document.getElementById('emojiPicker').classList.toggle('open');closeMentionSuggestions();}
async function sendReaction(mid,emoji){
  if(!authCanWrite()){openAuthModal();return;}
  const m=primaryMessages.find(x=>String(x.id||messageKey(x))===String(mid)&&!isReactionMessage(x));if(!m)return;
  const replyId=messagePacketId(m);if(!replyId){alert(tr('Não foi possível identificar o pacote original para reagir.'));return;}
  try{
    const r=await authFetch('/api/messages/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:emoji,replyId,emoji:1})});
    const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||b.error||`HTTP ${r.status}`);
    const compat=b.reactionMode==='compat_reply';
    document.getElementById('messageStatus').textContent=compat?tr('Reação enviada em modo compatível'):tr('Reação enviada ao MeshMonitor');
    setTimeout(()=>loadPrimaryMessages(false,false),450);
  }catch(e){document.getElementById('messageStatus').textContent=`${tr('Falha no envio')}: ${e}`;alert(tr(`Não foi possível reagir: ${e}`));}
}
function stripMentionMarkers(text){
  let out=String(text||'');
  const names=[...new Set(mentionNodeList().flatMap(n=>[n.name,n.shortName,n.nodeId].filter(Boolean)))].sort((a,b)=>b.length-a.length);
  for(const name of names) out=out.split('@'+name).join(name);
  return out;
}
async function sendPrimaryMessage(){if(!authCanWrite()){openAuthModal();return;}const input=document.getElementById('messageInput');const text=stripMentionMarkers(input.value.trim());if(!text)return;const bytes=new TextEncoder().encode(text).length;if(bytes>600){alert(tr('Mensagem muito longa. Reduza o texto para até aproximadamente 600 bytes.'));return;}const btn=document.getElementById('messageSend');btn.disabled=true;document.getElementById('messageStatus').textContent='Enviando...';try{const body={text};const replyId=replyingTo?messagePacketId(replyingTo):null;if(replyId)body.replyId=replyId;const r=await authFetch('/api/messages/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||b.error||`HTTP ${r.status}`);input.value='';clearReply();updateMessageCounter();document.getElementById('messageStatus').textContent='Mensagem enviada ao MeshMonitor';setTimeout(()=>loadPrimaryMessages(true),450);}catch(e){document.getElementById('messageStatus').textContent=`Falha no envio: ${e}`;alert(tr(`Não foi possível enviar: ${e}`));}finally{btn.disabled=false;input.focus();}}
function updateMessageCounter(){const el=document.getElementById('messageInput'),n=new TextEncoder().encode(el.value).length,c=document.getElementById('messageCounter');c.textContent=`${n} B`;c.classList.toggle('over',n>600);}
document.getElementById('authAction').addEventListener('click',()=>{if(authState.authenticated)authLogout();else openAuthModal();});
document.getElementById('authModalClose').addEventListener('click',closeAuthModal);
document.getElementById('authModalBackdrop').addEventListener('click',e=>{if(e.target===e.currentTarget)closeAuthModal();});
document.getElementById('authLoginSubmit').addEventListener('click',submitAuthLogin);
document.getElementById('authPassword').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();submitAuthLogin();}});
document.getElementById('authUsername').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();document.getElementById('authPassword').focus();}});
document.getElementById('messageReload').addEventListener('click',reloadPrimaryMessages);document.getElementById('messageLoadOlder').addEventListener('click',loadOlderPrimaryMessages);document.getElementById('messageSend').addEventListener('click',sendPrimaryMessage);document.getElementById('messageNewBelow').addEventListener('click',()=>scrollMessagesToBottom(true));document.getElementById('messageList').addEventListener('scroll',()=>{if(messageScrollRestoring)return;const near=messageIsNearBottom();if(near){messageAutoScroll=true;messagePendingBelow=0;updateMessageNewBelowButton();if(document.getElementById('viewMessages').classList.contains('active'))markMessagesRead();}else{messageAutoScroll=false;updateMessageNewBelowButton();}},{passive:true});document.getElementById('replyComposerClose').addEventListener('click',clearReply);document.getElementById('messageEmojiBtn').addEventListener('click',toggleComposerEmojiPicker);buildEmojiPicker();document.getElementById('messageInput').addEventListener('input',()=>{updateMessageCounter();mentionActiveIndex=0;refreshMentionSuggestions();});document.getElementById('messageInput').addEventListener('click',refreshMentionSuggestions);document.getElementById('messageInput').addEventListener('keydown',e=>{const box=document.getElementById('mentionSuggestions');if(box.classList.contains('open')){if(e.key==='ArrowDown'){e.preventDefault();mentionActiveIndex=(mentionActiveIndex+1)%mentionMatches.length;refreshMentionSuggestions();return;}if(e.key==='ArrowUp'){e.preventDefault();mentionActiveIndex=(mentionActiveIndex-1+mentionMatches.length)%mentionMatches.length;refreshMentionSuggestions();return;}if((e.key==='Enter'||e.key==='Tab')&&mentionMatches.length){e.preventDefault();selectMention(mentionActiveIndex);return;}if(e.key==='Escape'){e.preventDefault();closeMentionSuggestions();return;}}if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendPrimaryMessage();}});document.addEventListener('click',e=>{if(!document.getElementById('messageComposer').contains(e.target)){closeMentionSuggestions();document.getElementById('emojiPicker').classList.remove('open');}});updateMessageCounter();renderReplyComposer();setInterval(()=>loadPrimaryMessages(false),2500);loadPrimaryMessages(false);


document.querySelectorAll('.navbtn').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
window.addEventListener('popstate',taApplyRoute);
setTimeout(taApplyRoute,0);
for(const id of ['trafficDirection','trafficType']) document.getElementById(id).addEventListener('change',()=>{renderTraffic();taSyncRoute({replace:true,view:'traffic'});});
document.getElementById('trafficSearch').addEventListener('input',()=>{renderTraffic();taSyncRoute({replace:true,view:'traffic'});});
document.getElementById('trafficPause').addEventListener('click',toggleTrafficPause);
document.getElementById('trafficReload').addEventListener('click',async()=>{ trafficPackets=[];trafficInitialized=false;selectedPacketId=null;journeySeen=new Set();await loadTrafficInitial(); });
document.getElementById('trafficDump').addEventListener('click',downloadTrafficDump);
document.getElementById('soundEnabled').addEventListener('change',()=>{ ensureAudio(); savePrefs(); });
document.getElementById('soundVolume').addEventListener('input',()=>{ document.getElementById('soundVolumeValue').textContent=`${document.getElementById('soundVolume').value}%`; savePrefs(); });
document.getElementById('soundTheme').addEventListener('change',savePrefs);
document.getElementById('soundDensity').addEventListener('change',savePrefs);
document.getElementById('soundMinInterval').addEventListener('input',()=>{document.getElementById('soundMinIntervalValue').textContent=`${document.getElementById('soundMinInterval').value} ms`;savePrefs();});
document.getElementById('soundMaxVoices').addEventListener('change',savePrefs);
for(const id of ['soundRoutingEnabled','soundMessagesEnabled','soundAlertsEnabled','soundStereoEnabled'])document.getElementById(id).addEventListener('change',savePrefs);
document.getElementById('soundTest').addEventListener('click',testSoundTheme);
for(const id of ['activityAnimationEnabled','activityOriginEnabled','activityRelayEnabled','activityDuration']) document.getElementById(id).addEventListener('change',()=>{savePrefs(); if(!document.getElementById('activityAnimationEnabled').checked){activityLayer.clearLayers();activityMarkers.clear();}});
document.getElementById('autoZoomTraceroute').addEventListener('change',()=>{savePrefs(); if(!document.getElementById('autoZoomTraceroute').checked) disableAutoZoomAndRestore(false);});
document.getElementById('nodeInfoFlowEnabled').addEventListener('change',()=>{savePrefs(); if(!document.getElementById('nodeInfoFlowEnabled').checked){flowGeneration++;flowLayer.clearLayers();}});
for(const id of ['nodeInfoToastEnabled','nodeInfoAutoTraceEnabled'])document.getElementById(id).addEventListener('change',savePrefs);
document.getElementById('nodeInfoTraceNow').addEventListener('click',()=>{if(nodeInfoActivePacket)showNodeInfoFlow(nodeInfoActivePacket,{forceTrace:true,wait:true});});
document.getElementById('messageFontSize').addEventListener('input',()=>{applyMessageAppearance();savePrefs();});
document.getElementById('messageFontFamily').addEventListener('change',()=>{applyMessageAppearance();savePrefs();});
for(const id of ['messageBold','messageItalic','messageUnderline']) document.getElementById(id).addEventListener('change',()=>{applyMessageAppearance();savePrefs();});
document.getElementById('messageLineHeight').addEventListener('input',()=>{applyMessageAppearance();savePrefs();});
document.getElementById('messageRowGap').addEventListener('input',()=>{applyMessageAppearance();savePrefs();});
document.getElementById('uiTheme').addEventListener('change',()=>{applyTheme();savePrefs();});
document.getElementById('restoreAdminDefaults').addEventListener('click',restoreAdminDefaults);
document.getElementById('saveVisitorDefaults').addEventListener('click',saveVisitorDefaults);
document.getElementById('flowToast').addEventListener('click',()=>setView('map'));

let autoNoticeData=null;
function renderAutoNoticeStatus(data){
  autoNoticeData=data||{};
  const settings=(data&&data.settings)||{};
  const a=document.getElementById("autoNoticeInmet"),s=document.getElementById("autoNoticeMeshtasticStable"),u=document.getElementById("autoNoticeMeshtasticUnstable");
  if(a)a.checked=settings.inmetEnabled!==false;
  if(s)s.checked=settings.meshtasticStableEnabled!==false;
  if(u)u.checked=settings.meshtasticUnstableEnabled!==false;
  const nightly=document.getElementById("autoNoticeMeshtasticNightly");if(nightly)nightly.checked=settings.meshtasticNightlyEnabled!==false;
  const box=document.getElementById("autoNoticeStatus");if(!box)return;
  const st=(data&&data.state)||{};
  const checked=st.lastCheckAtMs?new Date(Number(st.lastCheckAtMs)).toLocaleString(uiLocale()):tr("Nunca");
  const sent=st.lastSendAtMs?new Date(Number(st.lastSendAtMs)).toLocaleString(uiLocale()):tr("Nunca");
  const err=st.lastError?(" · "+tr("Erro")+": "+esc(st.lastError)):"";
  box.innerHTML=tr("Última verificação:")+" "+esc(checked)+" · "+tr("Último envio:")+" "+esc(sent)+err;
}
async function loadAutoNoticeStatus(){
  try{
    const r=await fetch("/api/automatic-notices",{cache:"no-store"}),b=await r.json();
    if(!r.ok||!b.success)throw new Error(b.message||("HTTP "+r.status));
    renderAutoNoticeStatus(b);return b;
  }catch(e){const box=document.getElementById("autoNoticeStatus");if(box)box.textContent=tr("Erro")+": "+e;return null;}
}
async function saveAutoNoticeSettings(){
  if(!authCanWrite()){openAuthModal();throw new Error(tr("Somente leitura"));}
  const payload={
    inmetEnabled:document.getElementById("autoNoticeInmet").checked,
    meshtasticStableEnabled:document.getElementById("autoNoticeMeshtasticStable").checked,
    meshtasticUnstableEnabled:document.getElementById("autoNoticeMeshtasticUnstable").checked,
    meshtasticNightlyEnabled:document.getElementById("autoNoticeMeshtasticNightly").checked
  };
  const r=await authFetch("/api/automatic-notices",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||("HTTP "+r.status));renderAutoNoticeStatus(b);return b;
}
async function checkAutoNoticesNow(){
  if(!authCanWrite()){openAuthModal();return;}
  const btn=document.getElementById("autoNoticeCheckNow");btn.disabled=true;
  try{
    await saveAutoNoticeSettings();
    const r=await authFetch("/api/automatic-notices/check",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});
    const b=await r.json();if(!r.ok&&!b.success)throw new Error(b.message||("HTTP "+r.status));renderAutoNoticeStatus(b);
  }catch(e){alert(tr("Erro")+": "+e);}finally{btn.disabled=false;}
}
for(const id of ["autoNoticeInmet","autoNoticeMeshtasticStable","autoNoticeMeshtasticUnstable","autoNoticeMeshtasticNightly"]){
  document.getElementById(id).addEventListener("change",async()=>{try{await saveAutoNoticeSettings();}catch(e){alert(tr("Erro")+": "+e);await loadAutoNoticeStatus();}});
}
document.getElementById("autoNoticeCheckNow").addEventListener("click",checkAutoNoticesNow);

function formatArchiveBytes(value){
  const n=Math.max(0,Number(value||0));
  if(n<1024)return n+' B';
  if(n<1024*1024)return (n/1024).toFixed(1)+' KiB';
  if(n<1024*1024*1024)return (n/(1024*1024)).toFixed(1)+' MiB';
  return (n/(1024*1024*1024)).toFixed(2)+' GiB';
}
function renderArchiveRetention(data){
  const settings=data?.settings||{};
  const status=data?.status||{};
  const days=Number(settings.retentionDays??status.retentionDays??0);
  const select=document.getElementById('archiveRetentionDays');
  if(select)select.value=['0','1','7','30'].includes(String(days))?String(days):'0';
  const box=document.getElementById('archiveRetentionStatus');if(!box)return;
  const oldest=status.firstTimestamp?new Date(Number(status.firstTimestamp)).toLocaleString(uiLocale()):tr('Nunca');
  box.textContent=
    `${fmtNum(status.packets||0)} ${tr('pacotes')} · ${fmtNum(status.persistentNodes||0)} ${tr('nós históricos')} · `+
    `${fmtNum(status.persistentEdges||0)} ${tr('enlaces históricos')} · ${tr('registro mais antigo')}: ${oldest} · `+
    `${tr('tamanho do banco')}: ${formatArchiveBytes(status.dbBytes||0)}`;
}
async function loadArchiveRetentionSettings(){
  try{
    const r=await fetch('/api/archive/settings',{cache:'no-store'}),b=await r.json();
    if(!r.ok||!b.success)throw new Error(b.message||('HTTP '+r.status));
    renderArchiveRetention(b);return b;
  }catch(e){
    const box=document.getElementById('archiveRetentionStatus');if(box)box.textContent=tr('Erro')+': '+e;
    return null;
  }
}
async function saveArchiveRetentionSettings(){
  if(!authCanWrite()){openAuthModal();throw new Error(tr('Somente leitura'));}
  const retentionDays=Number(document.getElementById('archiveRetentionDays').value||0);
  const r=await authFetch('/api/archive/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({retentionDays})});
  const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||('HTTP '+r.status));
  renderArchiveRetention(b);return b;
}
document.getElementById('archiveRetentionDays').addEventListener('change',async()=>{
  try{await saveArchiveRetentionSettings();}
  catch(e){alert(tr('Erro')+': '+e);await loadArchiveRetentionSettings();}
});

const PAGE_VERSION='__APP_VERSION__';
let versionCheckTimer=null;
let versionCheckIntervalMinutes=15;
function normalizeVersionCheckInterval(value){
  const n=Math.round(Number(value));
  return Number.isFinite(n)?Math.max(5,Math.min(1440,n)):15;
}
function scheduleVersionChecks(value){
  const minutes=normalizeVersionCheckInterval(value);
  if(versionCheckTimer&&minutes===versionCheckIntervalMinutes)return minutes;
  versionCheckIntervalMinutes=minutes;
  if(versionCheckTimer)clearInterval(versionCheckTimer);
  versionCheckTimer=setInterval(()=>checkVersionStatus(false),minutes*60*1000);
  return minutes;
}
let updateRuntimeData=null;
function updateStateLabel(state){
  const labels={idle:'—',pending:'Pendente',running:'Atualizando',success:'Concluída',failed:'Falhou',rolled_back:'Rollback executado',no_change:'Concluída'};
  return tr(labels[state]||state||'—');
}
function renderUpdateStatus(data){
  updateRuntimeData=data||{};
  const box=document.getElementById('updateStatusBox');if(!box)return;
  const settings=data?.settings||{};
  document.getElementById('autoUpdateEnabled').checked=true;
  document.getElementById('rollbackEnabled').checked=settings.rollbackEnabled!==false;
  const interval=normalizeVersionCheckInterval(settings.checkIntervalMinutes);
  const intervalInput=document.getElementById('versionCheckInterval');if(intervalInput)intervalInput.value=String(interval);
  scheduleVersionChecks(interval);
  const state=String(data?.state||'idle');
  const runtimeVersion=String(data?.localVersion||PAGE_VERSION);
  if(runtimeVersion!==PAGE_VERSION && ['success','no_change','idle'].includes(state)){
    setTimeout(()=>window.location.reload(),800);
  }
  const target=data?.targetVersion?`v${esc(data.targetVersion)}`:'—';
  const previous=data?.previousVersion?`v${esc(data.previousVersion)}`:'—';
  const completed=data?.completedAtMs?new Date(Number(data.completedAtMs)).toLocaleString(uiLocale()):tr('Nunca');
  const msg=data?.message?`<br>${esc(tr(data.message))}`:'';
  box.innerHTML=`<b>${tr('Versão atual:')}</b> v__APP_VERSION__<br><b>${tr('Status:')}</b> <span class="updateState-${esc(state)}">${esc(updateStateLabel(state))}</span> · <b>${tr('Destino')}</b> ${target}<br><b>${tr('Versão anterior:')}</b> ${previous} · <b>${tr('Última atualização:')}</b> ${esc(completed)}${msg}`;
}
async function loadUpdateStatus(){
  try{
    const r=await fetch('/api/update/status',{cache:'no-store'});const b=await r.json();
    if(!r.ok||!b.success)throw new Error(b.message||`HTTP ${r.status}`);
    renderUpdateStatus(b);return b;
  }catch(e){
    const box=document.getElementById('updateStatusBox');if(box)box.textContent=`${tr('Erro')}: ${e}`;return null;
  }
}
async function saveUpdateSettings(){
  if(!authCanWrite()){openAuthModal();throw new Error(tr('Somente leitura'));}
  const payload={enabled:true,rollbackEnabled:document.getElementById('rollbackEnabled').checked,checkIntervalMinutes:normalizeVersionCheckInterval(document.getElementById('versionCheckInterval').value)};
  const r=await authFetch('/api/update/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const b=await r.json();if(!r.ok||!b.success)throw new Error(b.message||`HTTP ${r.status}`);renderUpdateStatus(b.status||{});return b;
}
async function triggerUpdateNow(){
  if(!authCanWrite()){openAuthModal();return;}
  const btn=document.getElementById('updateNow');btn.disabled=true;btn.textContent=tr('Atualizando...');
  try{
    const r=await authFetch('/api/update/trigger',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'update'})});const b=await r.json();
    if(!r.ok||!b.success)throw new Error(b.message||`HTTP ${r.status}`);
    await loadUpdateStatus();btn.textContent=tr(b.requested?'Solicitação de atualização enviada.':'Nenhuma atualização disponível.');
  }catch(e){btn.textContent=tr('Erro');alert(`${tr('Erro')}: ${e}`);}
  finally{setTimeout(()=>{btn.disabled=false;btn.textContent=tr('Atualizar agora');},2200);}
}
document.getElementById('rollbackEnabled').addEventListener('change',async()=>{try{await saveUpdateSettings();}catch(e){alert(`${tr('Erro')}: ${e}`);await loadUpdateStatus();}});
document.getElementById('versionCheckInterval').addEventListener('change',async()=>{const el=document.getElementById('versionCheckInterval');el.value=String(normalizeVersionCheckInterval(el.value));try{await saveUpdateSettings();}catch(e){alert(`${tr('Erro')}: ${e}`);await loadUpdateStatus();}});
document.getElementById('updateNow').addEventListener('click',triggerUpdateNow);

const WHATS_NEW_SEEN_KEY='trafficAnalyzerWhatsNewSeen';
async function showWhatsNewIfNeeded(){
  try{
    const r=await fetch('/api/current-release-notes',{cache:'no-store'});const b=await r.json();if(!r.ok||!b.success)return;
    const current=String(b.version||'__APP_VERSION__'),install=b.lastInstall||{},previous=String(install.previousVersion||'');
    if(!previous||previous===current||localStorage.getItem(WHATS_NEW_SEEN_KEY)===current)return;
    document.getElementById('whatsNewTitle').textContent=currentLang==='en'?'Traffic Analyzer updated':'Traffic Analyzer atualizado';
    document.getElementById('whatsNewSummary').textContent=currentLang==='en'?`Updated from v${previous} to v${current}.`:`Atualizado da v${previous} para a v${current}.`;
    const notes=b.notes||[];
    document.getElementById('whatsNewNotes').innerHTML=notes.length?notes.map(n=>`<div class="wnItem">• ${esc(tr(n))}</div>`).join(''):`<div>${esc(tr('Não há notas de versão disponíveis.'))}</div>`;
    const link=document.getElementById('whatsNewReleaseLink');if(b.releaseUrl)link.href=b.releaseUrl;
    document.getElementById('whatsNewBackdrop').classList.add('open');
    localStorage.setItem(WHATS_NEW_SEEN_KEY,current);
  }catch{}
}
function closeWhatsNew(){document.getElementById('whatsNewBackdrop').classList.remove('open');}
document.getElementById('whatsNewClose').addEventListener('click',closeWhatsNew);
document.getElementById('whatsNewOk').addEventListener('click',closeWhatsNew);
document.getElementById('whatsNewBackdrop').addEventListener('click',e=>{if(e.target===e.currentTarget)closeWhatsNew();});

let versionStatusData=null;
function renderVersionStatus(data){
  versionStatusData=data||null;
  const badge=document.getElementById('versionBadge');
  if(!badge) return;
  badge.classList.remove('checking','current','update','error');
  if(!data || data.status==='unavailable'){
    badge.classList.add('error'); badge.textContent=`v${data?.localVersion||'__APP_VERSION__'} · não verificado`; badge.title='Não foi possível verificar a versão mais recente'; return;
  }
  if(data.updateAvailable){
    badge.classList.add('update'); badge.textContent=`v${data.localVersion} → v${data.latestVersion} · NOVA`; badge.title=tr('Nova versão disponível - clique para ver as novidades');
  }else{
    badge.classList.add('current'); badge.textContent=`v${data.localVersion} · ATUALIZADO`; badge.title='Esta é a versão mais recente publicada';
  }
}
async function checkVersionStatus(force=false){
  const badge=document.getElementById('versionBadge');
  if(badge && !versionStatusData){ badge.classList.add('checking'); badge.textContent='v__APP_VERSION__ · verificando…'; }
  try{
    const r=await fetch(`/api/version-status${force?'?force=1':''}`,{cache:'no-store'});
    const data=await r.json();
    if(!r.ok) throw new Error(data.message||`HTTP ${r.status}`);
    renderVersionStatus(data); return data;
  }catch(e){
    const data={status:'unavailable',localVersion:'__APP_VERSION__',message:String(e?.message||e)};
    renderVersionStatus(data); return data;
  }
}
function cleanReleaseNotesForModal(raw){
  let s=String(raw||'').replace(/\r/g,'');
  s=s.replace(/\n##\s+Screenshots[\s\S]*$/i,'');
  s=s.split('\n').filter(line=>!/^!\[[^\]]*\]\([^)]*\)\s*$/.test(line.trim())).join('\n');
  return s.replace(/^#{1,6}\s+/gm,'').trim();
}
function openVersionModal(){
  const d=versionStatusData||{localVersion:'__APP_VERSION__',status:'unavailable'};
  const summary=document.getElementById('versionModalSummary');
  const notes=document.getElementById('versionNotes');
  const link=document.getElementById('versionReleaseLink');
  if(d.updateAvailable) summary.textContent=`Instalada: v${d.localVersion} · disponível: v${d.latestVersion} · publicada em ${d.publishedAt?new Date(d.publishedAt).toLocaleString(uiLocale()):tr('data não informada')}.`;
  else if(d.status==='unavailable') summary.textContent=`Instalada: v${d.localVersion}. Não foi possível consultar o GitHub agora.`;
  else summary.textContent=`Instalada: v${d.localVersion}. Esta é a versão mais recente publicada.`;
  notes.textContent=cleanReleaseNotesForModal(d.notes||d.message)||'Não há notas de versão disponíveis.';
  if(d.releaseUrl && /^https:\/\/github\.com\/alexpmr\/traffic-analyzer\//.test(d.releaseUrl)) link.href=d.releaseUrl;
  else link.href='https://github.com/alexpmr/traffic-analyzer/releases/latest';
  document.getElementById('versionModalBackdrop').classList.add('open');
}
function closeVersionModal(){ document.getElementById('versionModalBackdrop').classList.remove('open'); }
function latestPackageUrl(data){
  const url=String(data?.downloadUrl||'');
  return /^https:\/\/github\.com\/alexpmr\/traffic-analyzer\/releases\/download\/v[^/]+\/traffic-analyzer-(?:v[^/]+|latest)\.zip(?:\?.*)?$/i.test(url)?url:'';
}
async function handleVersionBadgeClick(){
  const badge=document.getElementById('versionBadge');
  if(badge){badge.classList.add('checking');badge.textContent=`v__APP_VERSION__ · ${tr('verificando…')}`;}
  const summary=document.getElementById('versionModalSummary');
  const notes=document.getElementById('versionNotes');
  if(summary)summary.textContent=tr('Consultando a versão publicada…');
  if(notes)notes.textContent=tr('Sem informações carregadas.');
  document.getElementById('versionModalBackdrop').classList.add('open');
  const d=await checkVersionStatus(true);
  renderVersionStatus(d);
  openVersionModal();
}
document.getElementById('versionBadge').addEventListener('click',handleVersionBadgeClick);
document.getElementById('versionModalClose').addEventListener('click',closeVersionModal);
document.getElementById('versionCloseAction').addEventListener('click',closeVersionModal);
document.getElementById('versionModalBackdrop').addEventListener('click',e=>{if(e.target===e.currentTarget)closeVersionModal();});
document.getElementById('versionContinue').addEventListener('click',closeVersionModal);
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeVersionModal();closeWhatsNew();closeAuthModal();}});

let legendContainer=null;
function renderLegend(){
  if(!legendContainer)return;
  const rfColor=document.getElementById('rfLineColor')?.value||'#ffff00';
  const mqttColor=document.getElementById('mqttLineColor')?.value||'#ff8c42';
  const rfWidth=Math.max(1,Math.min(8,Number(document.getElementById('rfLineWidth')?.value||3)));
  const mqttWidth=Math.max(1,Math.min(8,Number(document.getElementById('mqttLineWidth')?.value||3)));
  legendContainer.innerHTML =
    '<b>'+tr('Último tráfego')+'</b><br><span class="dot trafficFresh"></span>'+tr('até 2 h')+'<br><span class="dot trafficWarm"></span>'+tr('2 a 24 h')+'<br><span class="dot trafficOld"></span>'+tr('mais de 24 h')+'<br><span class="dot trafficUnknown"></span>'+tr('sem registro')+
    '<div class="legendSection"><b>'+tr('Tipo de enlace')+'</b><br>'+
    '<span class="legendLine" style="border-top-color:'+esc(rfColor)+';border-top-width:'+rfWidth+'px"></span>'+tr('RF confirmado')+'<br>'+
    '<span class="legendLine mqtt" style="border-top-color:'+esc(mqttColor)+';border-top-width:'+mqttWidth+'px"></span>'+tr('MQTT / não-RF')+
    '<div class="legendNote">'+tr('Enlace misto permanece contínuo quando houver ao menos uma observação RF no período.')+'</div></div>'+nodeRoleLegendHtml();
}
const legend = L.control({position:'bottomright'});
legend.onAdd = () => {
  legendContainer = L.DomUtil.create('div','legend');
  L.DomEvent.disableClickPropagation(legendContainer);
  renderLegend();
  return legendContainer;
};
legend.addTo(map);

async function bootstrap(){
  await loadUiDefaults();
  initVisualPrefs();
  applyLanguage(currentLang,false);
  initI18nObserver();
  loadAuthStatus(false);
  checkVersionStatus(true);
  scheduleVersionChecks(15);
  loadUpdateStatus();
  loadAutoNoticeStatus();
  loadArchiveRetentionSettings();
  showWhatsNewIfNeeded();
  setInterval(()=>loadAuthStatus(false),60*1000);
  setInterval(()=>loadUpdateStatus(),15000);
  setInterval(()=>loadArchiveRetentionSettings(),60000);
  load(true).then(()=>{ if(document.getElementById('playMode').value==='live') startLivePolling(); });
  loadTrafficInitial();
  setInterval(() => load(false), 60000);
}
bootstrap();
</script>
<script src="/automations_ui.js"></script>
</body>
</html>'''.replace('__TITLE__', TITLE.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')).replace('__DISPLAY_TITLE__', DISPLAY_TITLE.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')).replace('__APP_VERSION__', APP_VERSION.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;'))


def _mm_api_request(path: str, method: str = "GET", payload=None):
    if not MM_API_TOKEN:
        raise RuntimeError("MM_API_TOKEN não configurado; integração com MeshMonitor indisponível")
    url = f"{MM_BASE_URL}{path}"
    headers = {"Authorization": f"Bearer {MM_API_TOKEN}", "Accept": "application/json"}
    data = None
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"MeshMonitor HTTP {e.code}: {raw[:800]}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Falha ao acessar MeshMonitor: {e}") from e


def _mm_api_get(path: str):
    return _mm_api_request(path, "GET")


def _mm_api_post(path: str, payload: dict):
    return _mm_api_request(path, "POST", payload)


def _message_name_index():
    try:
        top = json.loads(TOPOLOGY_FILE.read_text(encoding="utf-8"))
    except Exception:
        top = {}
    by_num, by_id = {}, {}
    for n in top.get("nodes", []) or []:
        name = n.get("longName") or n.get("name") or n.get("shortName") or n.get("nodeId")
        try:
            by_num[int(n.get("nodeNum"))] = name
        except Exception:
            pass
        if n.get("nodeId"):
            by_id[str(n.get("nodeId"))] = name
    return by_num, by_id


def _primary_messages(limit: int = 250):
    source = urllib.parse.quote(MM_SOURCE, safe="")
    body = _mm_api_get(f"/api/v1/sources/{source}/messages?channel=0&limit={max(1, min(limit, 1500))}")
    rows = body.get("data", []) if isinstance(body, dict) else []
    by_num, by_id = _message_name_index()
    keep = {
        "id", "fromNodeNum", "toNodeNum", "fromNodeId", "toNodeId", "text", "channel",
        "requestId", "replyId", "emoji", "timestamp", "createdAt", "hopStart", "hopLimit", "relayNode",
        "viaMqtt", "viaStoreForward", "xeddsaSigned", "rxSnr", "rxRssi", "ackFailed",
        "routingErrorReceived", "deliveryState", "wantAck", "ackFromNode", "routingErrorCode",
        "sourcePath", "spoofSuspected"
    }
    out = []
    for row in rows:
        if not isinstance(row, dict) or int(row.get("channel") or 0) != 0:
            continue
        item = {k: row.get(k) for k in keep if k in row}
        fnum = row.get("fromNodeNum")
        fid = row.get("fromNodeId")
        try:
            item["fromName"] = by_num.get(int(fnum)) or by_id.get(str(fid)) or fid
        except Exception:
            item["fromName"] = by_id.get(str(fid)) or fid
        item["receivedAt"] = row.get("createdAt") or row.get("timestamp")
        item["mine"] = bool(row.get("sourcePath") == "http_api" and not row.get("spoofSuspected"))
        out.append(item)
    return {"success": True, "count": len(out), "data": out}


def _send_primary_message(text: str, reply_id=None, emoji: bool = False):
    clean = str(text or "").strip()
    if not clean:
        raise ValueError("Mensagem vazia")
    if len(clean.encode("utf-8")) > 800:
        raise ValueError("Mensagem excede o limite de segurança do Traffic Analyzer")
    reply = None
    if reply_id not in (None, ""):
        try:
            reply = int(reply_id)
        except (TypeError, ValueError):
            raise ValueError("replyId inválido")
        if reply <= 0:
            raise ValueError("replyId inválido")
    source = urllib.parse.quote(MM_SOURCE, safe="")
    if emoji:
        if reply is None:
            raise ValueError("Reação exige replyId")
        native_payload = {
            "text": clean,
            "channel": 0,
            "replyId": reply,
            "emoji": 1,
            "sourceId": MM_SOURCE,
        }
        try:
            body = _mm_api_post("/api/messages/send", native_payload)
            if isinstance(body, dict):
                body = dict(body)
                body["reactionMode"] = "tapback"
            return body
        except RuntimeError as exc:
            # MeshMonitor 4.x currently checks the legacy /api/messages/send
            # permission without the same source scoping used by API v1. A token
            # that can write channel_0 through /api/v1/sources/:source/messages
            # can therefore receive HTTP 403 only for the tapback endpoint.
            # In that exact case, send an emoji-only threaded reply through API v1.
            # Traffic Analyzer renders it as a reaction, while other clients see a
            # compatible reply instead of losing the user's action entirely.
            if "MeshMonitor HTTP 403" not in str(exc):
                raise
            body = _mm_api_post(f"/api/v1/sources/{source}/messages", {
                "text": clean,
                "channel": 0,
                "replyId": reply,
            })
            if isinstance(body, dict):
                body = dict(body)
                body["reactionMode"] = "compat_reply"
                body["reactionWarning"] = "MeshMonitor recusou o tapback nativo (HTTP 403); enviada como resposta emoji compatível."
            return body
    payload = {"text": clean, "channel": 0}
    if reply is not None:
        payload["replyId"] = reply
    return _mm_api_post(f"/api/v1/sources/{source}/messages", payload)



def _send_private_node_message(node_num, text: str):
    n = _node_num(node_num)
    clean = str(text or "").strip()
    if not clean:
        raise ValueError("Mensagem vazia")
    if len(clean.encode("utf-8")) > 200:
        raise ValueError("Mensagem privada excede 200 bytes")
    destination = _node_hex_id(n)
    channel = _node_query_channel(n, _resolved_mm_source_id())
    try:
        from meshtastic.tcp_interface import TCPInterface
    except Exception as exc:
        raise RuntimeError(f"Cliente Meshtastic indisponível: {exc}") from exc
    interface = TCPInterface(hostname=VIRTUAL_NODE_HOST, portNumber=VIRTUAL_NODE_PORT,
                             timeout=max(5, VIRTUAL_NODE_CONNECT_TIMEOUT))
    try:
        packet = interface.sendText(clean, destinationId=destination, channelIndex=channel, wantAck=True)
        packet_id = packet.get("id") if isinstance(packet, dict) else getattr(packet, "id", None)
        return {"success": True, "nodeNum": n, "destination": destination,
                "channel": channel, "packetId": packet_id, "transport": "meshtastic-tcp"}
    finally:
        try:
            interface.close()
        except Exception:
            pass


def _ping_node(node_num):
    result = _send_private_node_message(node_num, "ping")
    result["kind"] = "ping"
    return result


def _device_node_admin_action(node_num, action: str):
    """Executa alteração na NodeDB do dispositivo Meshtastic conectado."""
    n = _node_num(node_num)
    try:
        from meshtastic.tcp_interface import TCPInterface
    except Exception as exc:
        raise RuntimeError(f"Cliente Meshtastic indisponível: {exc}") from exc
    interface = TCPInterface(
        hostname=VIRTUAL_NODE_HOST,
        portNumber=VIRTUAL_NODE_PORT,
        timeout=max(5, VIRTUAL_NODE_CONNECT_TIMEOUT),
    )
    try:
        local = interface.localNode
        if action == "remove":
            result = local.removeNode(n)
        elif action == "favorite":
            result = local.setFavorite(n)
        elif action == "unfavorite":
            result = local.removeFavorite(n)
        else:
            raise ValueError("Ação administrativa de nó inválida")
        packet_id = result.get("id") if isinstance(result, dict) else getattr(result, "id", None)
        return {"success": True, "nodeNum": n, "action": action,
                "packetId": packet_id, "transport": "meshtastic-tcp"}
    finally:
        try:
            interface.close()
        except Exception:
            pass


def _set_device_node_favorite(node_num, favorite):
    if type(favorite) is not bool:
        raise ValueError("favorite deve ser verdadeiro ou falso")
    return _device_node_admin_action(node_num, "favorite" if favorite else "unfavorite")


def _delete_local_node(node_num):
    n = _node_num(node_num)
    source_id = MM_SOURCE
    counts = {}
    with _archive_connect() as conn:
        for table, sql, params in [
            ("topology_edge_events", "DELETE FROM topology_edge_events WHERE source_id=? AND (a=? OR b=?)", (source_id, n, n)),
            ("topology_nodes", "DELETE FROM topology_nodes WHERE source_id=? AND node_num=?", (source_id, n)),
            ("positions", "DELETE FROM positions WHERE source_id=? AND node_num=?", (source_id, n)),
            ("packets", "DELETE FROM packets WHERE source_id=? AND (from_node=? OR to_node=?)", (source_id, n, n)),
        ]:
            cur = conn.execute(sql, params)
            counts[table] = max(0, int(cur.rowcount if cur.rowcount is not None else 0))
        # Impede que o snapshot do MeshMonitor reinsira o nó sem evidência nova.
        conn.execute(
            """INSERT INTO deleted_nodes(source_id,node_num,deleted_at_ms) VALUES(?,?,?)
               ON CONFLICT(source_id,node_num) DO UPDATE SET deleted_at_ms=excluded.deleted_at_ms""",
            (source_id, n, int(time.time() * 1000)),
        )
    print(f"Exclusão local do nó !{n:08x}: {counts}", flush=True)
    return {"success": True, "nodeNum": n, "deleted": counts,
            "message": "Nó removido do histórico local; poderá reaparecer se for recebido novamente."}


def _delete_node_everywhere(node_num):
    n = _node_num(node_num)
    device_deleted = False
    local_deleted = False
    device_error = ""
    local_error = ""
    device_result = None
    local_result = None
    try:
        device_result = _device_node_admin_action(n, "remove")
        device_deleted = bool(device_result.get("success"))
    except Exception as exc:
        device_error = str(exc)[:500]
    try:
        local_result = _delete_local_node(n)
        local_deleted = bool(local_result.get("success"))
    except Exception as exc:
        local_error = str(exc)[:500]
    print(f"Exclusão do nó !{n:08x}: base local={'ok' if local_deleted else 'falhou ' + local_error}; "
          f"dispositivo={'ok' if device_deleted else 'falhou ' + device_error}", flush=True)
    return {
        "success": bool(device_deleted and local_deleted),
        "partial": bool(device_deleted != local_deleted),
        "nodeNum": n,
        "deviceDeleted": device_deleted,
        "localDeleted": local_deleted,
        "deviceError": device_error,
        "localError": local_error,
        "device": device_result,
        "local": local_result,
    }


NODE_BULK_DELETE_MAX = 100


def _bulk_delete_nodes(node_nums, scope):
    """Exclui vários nós, um por vez, devolvendo o resultado de cada um."""
    if scope not in ("local", "everywhere"):
        raise ValueError("Escopo de exclusão inválido")
    if not isinstance(node_nums, list) or not node_nums:
        raise ValueError("Selecione ao menos um nó")
    nums = list(dict.fromkeys(_node_num(x) for x in node_nums))
    if len(nums) > NODE_BULK_DELETE_MAX:
        raise ValueError(f"Selecione no máximo {NODE_BULK_DELETE_MAX} nós por exclusão")
    results = []
    for n in nums:
        if scope == "local":
            try:
                _delete_local_node(n)
                results.append({"nodeNum": n, "success": True, "localDeleted": True})
            except Exception as exc:
                results.append({"nodeNum": n, "success": False, "localDeleted": False, "localError": str(exc)[:300]})
        else:
            row = _delete_node_everywhere(n)
            results.append({k: row[k] for k in ("nodeNum", "success", "deviceDeleted", "localDeleted",
                                                 "deviceError", "localError")})
    ok = sum(1 for r in results if r["success"])
    return {"success": ok == len(results), "scope": scope, "total": len(results), "succeeded": ok, "results": results}


def _automation_defaults():
    return automgr.defaults(
        ping_label=MESH_COMMAND_NODE_LABEL, ping_cooldown=PING_COOLDOWN_SECONDS,
        ping_route_timeout=PING_ROUTE_TIMEOUT_SECONDS, clima_cooldown=CLIMA_COOLDOWN_SECONDS,
        clima_api_url=CLIMA_API_URL, clima_reply_gap=CLIMA_REPLY_GAP_SECONDS,
    )


def _automation_settings():
    return automgr.load(AUTOMATION_SETTINGS_FILE, _automation_defaults())


def _automation_events(limit=80, bot=None):
    limit = max(1, min(int(limit), 200))
    if bot not in (None, "", "ping", "clima"):
        raise ValueError("Automação desconhecida")
    with _archive_connect() as conn:
        if bot:
            rows = conn.execute(
                """SELECT command,from_node,from_node_id,received_at,processed_at,status,detail
                FROM mesh_command_events WHERE command=? ORDER BY processed_at DESC LIMIT ?""",
                (bot, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT command,from_node,from_node_id,received_at,processed_at,status,detail
                FROM mesh_command_events ORDER BY processed_at DESC LIMIT ?""",
                (limit,),
            ).fetchall()
    return [dict(row) for row in rows]


def _home_assistant_config():
    saved = _read_json_file(HOME_ASSISTANT_SETTINGS_FILE, {})
    config = dict(CLIMA_HOME_ASSISTANT_ENV)
    for key in ("url", "lightningEntity", "forecastEntity", "token"):
        value = str(saved.get(key) or "").strip()
        if value:
            config[key] = value
    config["tokenSource"] = "tela" if str(saved.get("token") or "").strip() else ("env" if config["token"] else "")
    config["forecastLatitude"] = saved.get("forecastLatitude")
    config["forecastLongitude"] = saved.get("forecastLongitude")
    return config


FORECAST_FALLBACK_LOCATION = (-15.7939, -47.8828)  # Brasília/DF


def _forecast_location():
    """Local da previsão: coordenadas salvas na tela, posição do nó local (ex.: VHF3) ou Brasília."""
    saved = _home_assistant_config()
    try:
        lat, lon = float(saved["forecastLatitude"]), float(saved["forecastLongitude"])
        return lat, lon, "coordenadas salvas"
    except (TypeError, ValueError, KeyError):
        pass
    label = MESH_COMMAND_NODE_LABEL.strip().lower()
    try:
        nodes = json.loads(TOPOLOGY_FILE.read_text(encoding="utf-8")).get("nodes") or []
    except Exception:
        nodes = []
    for node in nodes:
        names = [str(node.get(k) or "").strip().lower() for k in ("shortName", "longName", "name")]
        if label and (label in names or any(label in n.split() for n in names)) \
                and _history_valid_position(node.get("latitude"), node.get("longitude")):
            return float(node["latitude"]), float(node["longitude"]), f"posição do nó {MESH_COMMAND_NODE_LABEL}"
    return FORECAST_FALLBACK_LOCATION[0], FORECAST_FALLBACK_LOCATION[1], "Brasília (padrão)"


def _home_assistant_public():
    """Configuração exibida no navegador: o token nunca sai do servidor."""
    config = _home_assistant_config()
    configured = bool(config["url"] and config["token"])
    lat, lon, origin = _forecast_location()
    return {"url": config["url"], "lightningEntity": config["lightningEntity"],
            "forecastEntity": config["forecastEntity"], "tokenConfigured": bool(config["token"]),
            "tokenSource": config["tokenSource"], "configured": configured,
            "forecastLatitude": config["forecastLatitude"], "forecastLongitude": config["forecastLongitude"],
            "forecastLocation": {"latitude": lat, "longitude": lon, "origin": origin},
            "forecastSource": "Home Assistant (Open-Meteo se falhar)" if configured else "Open-Meteo",
            "warning": "" if configured else
            "Home Assistant não configurado: a linha \"Raios próximos\" (segurança) não será enviada. A previsão do tempo vem do Open-Meteo."}


def _save_home_assistant(payload: dict):
    allowed = {"url", "lightningEntity", "forecastEntity", "token", "clearToken", "forecastLatitude", "forecastLongitude"}
    if set(payload) - allowed:
        raise ValueError("Campos do Home Assistant desconhecidos")
    saved = _read_json_file(HOME_ASSISTANT_SETTINGS_FILE, {})
    if "url" in payload:
        url = str(payload["url"] or "").strip().rstrip("/")
        parsed = urllib.parse.urlsplit(url)
        if url and (parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username
                    or parsed.password or parsed.query or parsed.fragment or len(url) > 256):
            raise ValueError("URL do Home Assistant inválida (use http(s)://host:porta, sem credenciais)")
        saved["url"] = url
    for key in ("lightningEntity", "forecastEntity"):
        if key in payload:
            value = str(payload[key] or "").strip()
            if value and not re.fullmatch(r"[a-z_]+\.[a-z0-9_]+", value):
                raise ValueError("Entidade inválida: " + value)
            saved[key] = value
    if "forecastLatitude" in payload or "forecastLongitude" in payload:
        lat, lon = payload.get("forecastLatitude"), payload.get("forecastLongitude")
        if lat in (None, "") and lon in (None, ""):
            saved["forecastLatitude"] = saved["forecastLongitude"] = None
        else:
            try:
                lat, lon = float(str(lat).replace(",", ".")), float(str(lon).replace(",", "."))
            except ValueError:
                raise ValueError("Latitude e longitude devem ser números")
            if not (-90 <= lat <= 90 and -180 <= lon <= 180):
                raise ValueError("Latitude/longitude fora do intervalo")
            saved["forecastLatitude"], saved["forecastLongitude"] = round(lat, 4), round(lon, 4)
    if payload.get("clearToken") is True:
        saved["token"] = ""
    elif str(payload.get("token") or "").strip():
        token = str(payload["token"]).strip()
        if len(token) > 1000 or not re.fullmatch(r"[\x21-\x7e]+", token):
            raise ValueError("Token inválido")
        saved["token"] = token
    saved["updatedAtMs"] = int(time.time() * 1000)
    _write_json_file(HOME_ASSISTANT_SETTINGS_FILE, saved)
    try:
        HOME_ASSISTANT_SETTINGS_FILE.chmod(0o600)
    except OSError:
        pass
    return _home_assistant_public()


def _test_home_assistant():
    """Testa as fontes do bloco de raios e da previsão, sem transmitir."""
    config = _home_assistant_config()
    errors = []
    lightning = forecast = None
    if config["url"] and config["token"]:
        lightning, forecast = meshcmd.fetch_home_assistant_weather(
            config["url"], config["token"], config["lightningEntity"], config["forecastEntity"], 8.0, errors)
    else:
        errors.append("Home Assistant não configurado (sem \"Raios próximos\")")
    source = "Home Assistant"
    if not forecast or forecast == ["Previsão indisponível"]:
        lat, lon, origin = _forecast_location()
        forecast = meshcmd.fetch_open_meteo_forecast(lat, lon, 8.0, errors)
        source = f"Open-Meteo ({origin}: {lat:.4f}, {lon:.4f})"
    return {"success": bool(forecast), "lightning": lightning, "forecast": forecast or [], "errors": errors,
            "forecastSource": source,
            "message": ("Previsão obtida de " + source + "." if forecast else "Nenhuma fonte de previsão respondeu.")
                       + ("" if not errors else " Avisos: " + "; ".join(errors))}


def _automation_ping_sample(settings):
    return meshcmd.format_ping_message(
        destination_label=settings["label"], origin="Estação exemplo [TEST] (!00000001)",
        message={"timestamp": int(time.time() * 1000), "hopStart": 3, "hopLimit": 2,
                 "rxRssi": -92, "rxSnr": 5.5, "viaMqtt": False},
        heard_nodes_24h=42,
        route_lines=["Rota de ida:", f"{settings['label']} → RPT1: 5.5 dB", "RPT1 → TEST: -11.0 dB",
                     "Rota de volta:", "TEST → RPT2: 6.0 dB", "RPT2 → MOVEL: -12.2 dB", f"MOVEL → {settings['label']}: 6.2 dB"],
    )


def _automation_preview(bot, settings=None):
    if bot not in automgr.AUTOMATION_IDS:
        raise ValueError("Automação desconhecida")
    config = settings or _automation_settings()[bot]
    if bot == "ping":
        return automgr.preview(bot, config, default_ping_text=_automation_ping_sample(config))
    result = automgr.preview(bot, config, clima_responses=meshcmd.fetch_clima_responses(config["apiUrl"], home_assistant=_home_assistant_config(), forecast_location=_forecast_location()[:2]))
    warning = _home_assistant_public()["warning"]
    if warning:
        result["warnings"] = [warning]
    return result


def _automation_test_send(bot):
    global _automation_last_test_at
    if bot not in automgr.AUTOMATION_IDS:
        raise ValueError("Automação desconhecida")
    # Serialize tests and apply a global cooldown even on failed attempts.
    if not _automation_test_lock.acquire(blocking=False):
        raise ValueError("Outro teste de envio está em andamento")
    try:
        if time.monotonic() - _automation_last_test_at < 180:
            raise ValueError("Aguarde 180 segundos entre testes reais de transmissão")
        settings = _automation_settings()[bot]
        result = _automation_preview(bot, settings)
        parts = result["parts"]
        if len(parts) > 4:
            raise ValueError("Teste real limitado a quatro mensagens para proteger o canal")
        _automation_last_test_at = time.monotonic()
        sent = _mesh_command_send_parts(parts, send_func=_send_primary_message,
                                        gap_seconds=1.5 if bot == "ping" else settings["replyGapSeconds"])
        return {"success": True, "bot": bot, "sentParts": len(sent),
                "transport": "MeshMonitor/canal primário; RF ou MQTT depende da configuração",
                "delivered": False, "notice": "A API aceitou o envio; a entrega e o transporte RF não foram confirmados."}
    finally:
        _automation_test_lock.release()


def _mesh_command_message_key(row: dict) -> str:
    for key in ("id", "requestId"):
        value = row.get(key)
        if value not in (None, ""):
            return f"{key}:{value}"
    raw = "|".join(str(row.get(k) or "") for k in ("fromNodeNum","fromNodeId","timestamp","createdAt","text"))
    return "sha256:" + hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _mesh_command_timestamp_ms(row: dict) -> int:
    for key in ("receivedAt","createdAt","timestamp"):
        value = row.get(key)
        try:
            if value is not None:
                n = float(value)
                if n > 0:
                    return int(n * 1000 if n < 100000000000 else n)
        except (TypeError, ValueError):
            pass
    return int(time.time() * 1000)


def _mesh_command_node_index():
    try:
        top = json.loads(TOPOLOGY_FILE.read_text(encoding="utf-8"))
    except Exception:
        top = {}
    by_num, by_id = {}, {}
    for node in top.get("nodes", []) or []:
        if not isinstance(node, dict):
            continue
        try:
            by_num[int(node.get("nodeNum"))] = node
        except Exception:
            pass
        node_id = str(node.get("nodeId") or "").strip()
        if node_id:
            by_id[node_id.lower()] = node
    return by_num, by_id


def _mesh_command_node_for_message(row: dict):
    by_num, by_id = _mesh_command_node_index()
    try:
        node = by_num.get(int(row.get("fromNodeNum")))
        if node:
            return node
    except Exception:
        pass
    return by_id.get(str(row.get("fromNodeId") or "").lower()) or {}


def _mesh_command_heard_nodes_24h() -> int:
    since = int(time.time() * 1000) - 24 * 3600 * 1000
    with _archive_connect() as conn:
        row = conn.execute(
            "SELECT COUNT(DISTINCT from_node) AS n FROM packets WHERE timestamp>=? AND from_node IS NOT NULL AND COALESCE(direction,'rx')!='tx'",
            (since,),
        ).fetchone()
    return int(row["n"] or 0) if row else 0


def _mesh_command_seen(message_key: str) -> bool:
    with _archive_connect() as conn:
        row = conn.execute("SELECT 1 FROM mesh_command_events WHERE message_key=?", (message_key,)).fetchone()
    return bool(row)


def _mesh_command_record(row: dict, command: str, status: str, response_text="", detail=""):
    key = _mesh_command_message_key(row)
    try:
        from_node = int(row.get("fromNodeNum")) if row.get("fromNodeNum") is not None else None
    except (TypeError, ValueError):
        from_node = None
    with _archive_connect() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO mesh_command_events(
                 message_key,command,from_node,from_node_id,received_at,processed_at,status,response_text,detail
               ) VALUES(?,?,?,?,?,?,?,?,?)""",
            (
                key, str(command), from_node, str(row.get("fromNodeId") or "") or None,
                _mesh_command_timestamp_ms(row), int(time.time()*1000), str(status),
                str(response_text or "")[:4000], str(detail or "")[:4000],
            ),
        )


def _mesh_command_cooldown_active(row: dict, command: str) -> int:
    cooldown = _automation_settings()[command]["cooldownSeconds"]
    if cooldown <= 0:
        return 0
    try:
        from_node = int(row.get("fromNodeNum"))
    except (TypeError, ValueError):
        return 0
    cutoff = int(time.time()*1000) - cooldown * 1000
    with _archive_connect() as conn:
        last = conn.execute(
            """SELECT MAX(processed_at) AS ts FROM mesh_command_events
               WHERE from_node=? AND command=? AND status='sent' AND processed_at>=?""",
            (from_node, command, cutoff),
        ).fetchone()
    if not last or not last["ts"]:
        return 0
    remaining = cooldown - int((int(time.time()*1000) - int(last["ts"])) / 1000)
    return max(1, remaining)


def _trace_has_response(trace: dict) -> bool:
    """Registro com dados da resposta: o pedido gravado antes da resposta não traz SNR nem rota."""
    def items(key):
        value = trace.get(key)
        if isinstance(value, str):
            try:
                value = json.loads(value) if value.strip() else []
            except ValueError:
                return []
        return value if isinstance(value, list) else []
    return any(items(key) for key in ("snrTowards", "route", "routeBack", "snrBack"))


def _mesh_command_route_trace(node_num: int, timeout_seconds=None):
    """Solicita um traceroute ao nó e devolve o registro do MeshMonitor (ida e volta), ou None no timeout.

    Sem resposta na metade do prazo, repete o pedido uma vez: rádios em economia
    de energia (ex.: Tracker) e enlaces fracos costumam perder o primeiro pedido.
    """
    requested = int(time.time() * 1000)
    _request_node_query(node_num, "traceroute")
    timeout = PING_ROUTE_TIMEOUT_SECONDS if timeout_seconds is None else int(timeout_seconds)
    deadline = time.time() + timeout
    retry_at = time.time() + timeout / 2
    retried = False
    pending_seen = False
    while time.time() < deadline and not _mesh_command_stop.is_set():
        if not retried and time.time() >= retry_at:
            retried = True
            try:
                _request_node_query(node_num, "traceroute")
                print(f"PING traceroute !{int(node_num) & 0xFFFFFFFF:08x}: sem resposta em {timeout // 2} s; "
                      "segunda tentativa enviada", flush=True)
            except Exception as exc:
                print(f"PING traceroute !{int(node_num) & 0xFFFFFFFF:08x}: segunda tentativa falhou: {exc}", flush=True)
        try:
            traces = _live_traceroutes(120)
        except Exception:
            traces = []
        for trace in traces:
            try:
                if int(trace.get("toNodeNum")) != int(node_num):
                    continue
            except (TypeError, ValueError):
                continue
            ts = 0
            for key in ("createdAt","timestamp"):
                try:
                    value = float(trace.get(key))
                    if value > 0:
                        ts = int(value * 1000 if value < 100000000000 else value)
                        break
                except (TypeError, ValueError):
                    pass
            if not ts or ts + 2000 < requested:
                continue
            if not _trace_has_response(trace):
                pending_seen = True  # pedido registrado; a resposta ainda não chegou
                continue
            print(f"PING traceroute !{int(node_num) & 0xFFFFFFFF:08x}: route={trace.get('route')} "
                  f"snrTowards={trace.get('snrTowards')} routeBack={trace.get('routeBack')} snrBack={trace.get('snrBack')}",
                  flush=True)
            return trace
        _mesh_command_stop.wait(1.0)
    print(f"PING traceroute !{int(node_num) & 0xFFFFFFFF:08x}: sem resposta no prazo"
          + (" após 2 tentativas" if retried else "")
          + (" (somente o pedido foi registrado)" if pending_seen else ""), flush=True)
    return None


def _mesh_command_route_lines(node_num, timeout_seconds, local_label):
    """Linhas "Rota de ida"/"Rota de volta" para o final da resposta do PING."""
    timeout = PING_ROUTE_TIMEOUT_SECONDS if timeout_seconds is None else int(timeout_seconds)
    try:
        trace = _mesh_command_route_trace(int(node_num), timeout)
    except Exception:
        return ["Traceroute: não foi possível solicitar"]
    by_num, _ = _mesh_command_node_index()
    local_num = None
    try:
        local_num = int((trace or {}).get("fromNodeNum")) & 0xFFFFFFFF
    except (TypeError, ValueError):
        pass

    def label(num):
        node = by_num.get(num, {})
        name = str(node.get("shortName") or node.get("longName") or node.get("name") or "").strip()
        if not name and num == local_num:
            name = local_label
        return name or _node_hex_id(num)

    return meshcmd.format_traceroute_lines(trace, label, timeout)


def _mesh_command_send_parts(parts, send_func=None, gap_seconds=None):
    sender = send_func or _send_primary_message
    sent = []
    gap = CLIMA_REPLY_GAP_SECONDS if gap_seconds is None else max(0.0, float(gap_seconds))
    for idx, part in enumerate(parts):
        if _mesh_command_stop.is_set():
            break
        clean = str(part or "").strip()
        if not clean:
            continue
        receipt = sender(clean)
        if isinstance(receipt, dict) and receipt.get("success") is False:
            raise RuntimeError("Backend recusou envio: " + str(receipt.get("message") or receipt.get("error") or receipt))
        sent.append(clean)
        if idx < len(parts)-1 and gap > 0:
            _mesh_command_stop.wait(gap)
    return sent


def _mesh_command_handle(row: dict, command: str, send_func=None):
    cfg = _automation_settings()[command]
    if not cfg["enabled"]:
        _mesh_command_record(row, command, "disabled", detail="Desativado em Automações")
        return
    remaining = _mesh_command_cooldown_active(row, command)
    if remaining:
        _mesh_command_record(row, command, "cooldown", detail=f"{remaining}s restantes")
        return

    if command == "ping":
        node = _mesh_command_node_for_message(row)
        origin = meshcmd.node_identity(node, str(row.get("fromNodeId") or ""))
        try:
            route_lines = _mesh_command_route_lines(int(row.get("fromNodeNum")), cfg["routeTimeoutSeconds"], cfg["label"])
        except (TypeError, ValueError):
            route_lines = ["Traceroute: estação sem nodeNum"]
        text = meshcmd.format_ping_message(
            destination_label=cfg["label"],
            origin=origin,
            message=row,
            heard_nodes_24h=_mesh_command_heard_nodes_24h(),
            route_lines=route_lines,
        )
        parts = automgr.preview("ping", cfg, default_ping_text=text)["parts"]
        sent = _mesh_command_send_parts(parts, send_func=send_func, gap_seconds=1.5)
        _mesh_command_record(row, command, "sent", response_text="\n---\n".join(sent))
        return

    if command == "clima":
        try:
            responses = meshcmd.fetch_clima_responses(cfg["apiUrl"], home_assistant=_home_assistant_config(), forecast_location=_forecast_location()[:2])
            parts = automgr.preview("clima", cfg, clima_responses=responses)["parts"]
            sent = _mesh_command_send_parts(parts, send_func=send_func, gap_seconds=cfg["replyGapSeconds"])
            detail = f"{len(sent)}/{len(parts)} blocos aceitos para envio"
            if not _home_assistant_public()["configured"]:
                detail += "; Home Assistant não configurado: sem descargas próximas"
            if not any(p.startswith("Previsão do tempo") for p in parts):
                detail += "; previsão do tempo indisponível (Home Assistant e Open-Meteo)"
            _mesh_command_record(row, command, "sent", response_text="\n---\n".join(sent), detail=detail)
        except Exception as exc:
            fallback = "CLIMA indisponível no momento."
            try:
                (send_func or _send_primary_message)(fallback)
            except Exception:
                pass
            _mesh_command_record(row, command, "error", response_text=fallback, detail=str(exc))
        return



def _mesh_command_archive_rows(limit: int = 300):
    """Fallback robusto: lê comandos diretamente do arquivo de pacotes RX.

    O Packet Monitor/arquivador já recebe TEXT_MESSAGE_APP mesmo quando o
    endpoint de mensagens do MeshMonitor não projeta a mensagem para o bot.
    Apenas broadcasts do canal primário são elegíveis; mensagens diretas
    permanecem sanitizadas no arquivo e não são usadas como comandos.
    """
    with _archive_connect() as conn:
        rows = conn.execute(
            """SELECT archive_id,packet_id,timestamp,created_at,direction,
                      from_node,from_node_id,channel,portnum_name,snr,rssi,
                      hop_limit,hop_start,transport_mechanism,payload_preview
               FROM packets
               WHERE COALESCE(channel,0)=0
                 AND COALESCE(direction,'rx')!='tx'
                 AND COALESCE(portnum_name,'')='TEXT_MESSAGE_APP'
                 AND payload_preview IS NOT NULL
               ORDER BY timestamp DESC
               LIMIT ?""",
            (max(1, min(int(limit), 1500)),),
        ).fetchall()
    out=[]
    for row in reversed(rows):
        text=str(row["payload_preview"] or "").strip()
        if not meshcmd.normalize_command(text):
            continue
        transport = row["transport_mechanism"]
        out.append({
            "id": f"archive:{row['archive_id']}",
            "requestId": row["packet_id"],
            "fromNodeNum": row["from_node"],
            "fromNodeId": row["from_node_id"],
            "text": text,
            "channel": row["channel"] if row["channel"] is not None else 0,
            "timestamp": row["timestamp"],
            "createdAt": row["created_at"],
            "receivedAt": row["created_at"] or row["timestamp"],
            "hopStart": row["hop_start"],
            "hopLimit": row["hop_limit"],
            "rxSnr": row["snr"],
            "rxRssi": row["rssi"],
            "viaMqtt": bool(transport not in (None,0,1)),
            "mine": False,
            "_source": "traffic.db",
        })
    return out


def _mesh_command_candidates(limit: int = 300):
    """Une API de mensagens e arquivo RX sem duplicar comandos."""
    combined=[]
    errors=[]
    try:
        body=_primary_messages(limit)
        rows=body.get("data",[]) if isinstance(body,dict) else []
        combined.extend(r for r in rows if isinstance(r,dict))
    except Exception as exc:
        errors.append(f"messages-api: {exc}")
    try:
        combined.extend(_mesh_command_archive_rows(limit))
    except Exception as exc:
        errors.append(f"traffic-db: {exc}")

    dedup={}
    for row in combined:
        command=meshcmd.normalize_command(row.get("text"))
        if not command:
            continue
        # A mesma mensagem pode aparecer tanto em /messages quanto no arquivo
        # de pacotes com IDs internos diferentes. Deduplica por remetente,
        # comando e janela temporal curta antes da persistência.
        sender=str(row.get("fromNodeNum") or row.get("fromNodeId") or "")
        bucket=int(_mesh_command_timestamp_ms(row)/5000)
        semantic_key=f"{sender}:{command}:{bucket}"
        existing=dedup.get(semantic_key)
        if existing is None or (row.get("_source")!="traffic.db" and existing.get("_source")=="traffic.db"):
            dedup[semantic_key]=row
    rows=list(dedup.values())
    rows.sort(key=_mesh_command_timestamp_ms)
    return rows, errors


def _mesh_command_packet_text(packet: dict) -> str:
    decoded = packet.get("decoded") if isinstance(packet, dict) else {}
    decoded = decoded if isinstance(decoded, dict) else {}
    value = decoded.get("text")
    # Algumas versões do cliente Python informam apenas payload no decode.
    if value is None and str(decoded.get("portnum") or "") in ("TEXT_MESSAGE_APP", "1"):
        value = decoded.get("payload")
    if value is None:
        value = packet.get("text") if isinstance(packet, dict) else None
    if isinstance(value, bytes):
        try:
            value = value.decode("utf-8", errors="replace")
        except Exception:
            value = ""
    return str(value or "").strip()


def _mesh_command_live_row(packet: dict, interface=None):
    packet = packet or {}
    decoded = packet.get("decoded") if isinstance(packet.get("decoded"), dict) else {}
    text = _mesh_command_packet_text(packet)
    command = meshcmd.normalize_command(text)
    if not command:
        return None

    try:
        channel = int(packet.get("channel", 0) or 0)
    except (TypeError, ValueError):
        channel = 0
    if channel != 0:
        return None

    local_num = None
    try:
        info = interface.getMyNodeInfo() if interface is not None else {}
        local_num = int((info or {}).get("num") or (info or {}).get("nodeNum") or 0) or None
    except Exception:
        try:
            local_num = int(getattr(getattr(interface, "myInfo", None), "my_node_num", 0) or 0) or None
        except Exception:
            local_num = None

    try:
        to_num = int(packet.get("to")) if packet.get("to") is not None else None
    except (TypeError, ValueError):
        to_num = None

    # Não responder a comandos transmitidos pelo próprio nó nem a DMs alheias.
    try:
        origin_num = int(packet.get("from")) if packet.get("from") is not None else None
    except (TypeError, ValueError):
        origin_num = None
    if local_num is not None and origin_num == local_num:
        return None
    if to_num not in (None, 0xFFFFFFFF, -1):
        if local_num is None or to_num != local_num:
            return None

    rx_time = packet.get("rxTime") or packet.get("rx_time") or packet.get("timestamp")
    try:
        rx_ms = int(float(rx_time) * 1000) if rx_time and float(rx_time) < 100000000000 else int(float(rx_time)) if rx_time else int(time.time()*1000)
    except Exception:
        rx_ms = int(time.time()*1000)

    try:
        from_num = int(packet.get("from")) if packet.get("from") is not None else None
    except (TypeError, ValueError):
        from_num = None
    from_id = _node_hex_id(from_num) if from_num else ""

    packet_id = packet.get("id")
    if packet_id is None:
        packet_id = decoded.get("requestId") or decoded.get("request_id")

    return {
        "id": f"live:{packet_id or hashlib.sha256((from_id+'|'+text+'|'+str(rx_ms)).encode()).hexdigest()[:16]}",
        "requestId": packet_id,
        "fromNodeNum": from_num,
        "fromNodeId": from_id,
        "text": text,
        "channel": channel,
        "timestamp": rx_ms,
        "createdAt": rx_ms,
        "receivedAt": rx_ms,
        "hopStart": packet.get("hopStart", packet.get("hop_start")),
        "hopLimit": packet.get("hopLimit", packet.get("hop_limit")),
        "rxSnr": packet.get("rxSnr", packet.get("rx_snr")),
        "rxRssi": packet.get("rxRssi", packet.get("rx_rssi")),
        "viaMqtt": bool(packet.get("viaMqtt", packet.get("via_mqtt", False))),
        "mine": False,
        "_source": "meshtastic-live",
        "_command": command,
    }


def _mesh_command_receive_packet(packet, connection, dispatcher):
    """Valida um comando RF e coloca na fila; sem I/O lento nem transmissão."""
    pkt = packet if isinstance(packet, dict) else {}
    decoded = pkt.get("decoded") if isinstance(pkt.get("decoded"), dict) else {}
    port = str(decoded.get("portnum") or "")
    if port not in ("TEXT_MESSAGE_APP", "1"):
        return False
    row = _mesh_command_live_row(pkt, interface=connection)
    return bool(row and dispatcher.submit(row, row["_command"]))


def _nodeinfo_trace_request(payload):
    """Consulta apenas para NodeInfo TX local recente; nunca para terceiros."""
    global _nodeinfo_last_trace_global
    if not isinstance(payload, dict):
        raise ValueError("Pedido inválido")
    try:
        packet_id = int(payload["packetId"])
        destination = _node_num(payload["nodeNum"])
    except (KeyError, TypeError, ValueError):
        raise ValueError("Informe o packetId do NodeInfo TX e o destino")
    if packet_id < 1 or destination in (0, 1, 2, 3, 255, 65535, 0xffffffff):
        raise ValueError("NodeInfo ou destino inválido")
    since_ms = int(time.time() * 1000) - 2 * 3600 * 1000
    with _archive_connect() as conn:
        row = conn.execute(
            """SELECT packet_id,to_node,channel,timestamp FROM packets
               WHERE source_id=? AND packet_id=? AND to_node=? AND LOWER(direction)='tx'
               AND portnum_name='NODEINFO_APP' AND timestamp >= ?
               ORDER BY timestamp DESC LIMIT 1""",
            (MM_SOURCE, packet_id, destination, since_ms),
        ).fetchone()
    if not row or row["channel"] not in (None, 0):
        raise ValueError("Não há NodeInfo TX local recente confirmado para esse destino")
    now = time.monotonic()
    with _nodeinfo_trace_lock:
        remaining_global = 300 - (now - _nodeinfo_last_trace_global) if _nodeinfo_last_trace_global else 0
        last_dest = _nodeinfo_last_trace_destinations.get(destination, 0)
        remaining_dest = 1800 - (now - last_dest) if last_dest else 0
        if remaining_global > 0 or remaining_dest > 0:
            raise ValueError(f"Limite de RF: aguarde {int(max(remaining_global, remaining_dest)) + 1} s antes de consultar novamente")
        _nodeinfo_last_trace_global = now
        _nodeinfo_last_trace_destinations[destination] = now
        result = _request_node_query(destination, "traceroute")
    return {"success": True, "query": result,
            "note": "Rota do traceroute atual, não prova do percurso anterior do NodeInfo."}


def _mesh_command_live_status():
    with _mesh_dispatcher_lock:
        dispatcher = _mesh_dispatcher_active
        last_error = _mesh_last_listener_error
    if dispatcher is None:
        return {"connected": False, "lastError": last_error,
                "bots": {c: {"rxCount": 0, "txCount": 0, "errorCount": 0,
                              "lastRxMs": None, "lastTxMs": None,
                              "lastError": None, "processing": False, "pending": 0}
                         for c in ("ping", "clima")}}
    return dispatcher.snapshot()


def _mesh_command_live_worker():
    """Recebe TEXT_MESSAGE_APP sem bloquear o callback de recepção Meshtastic.

    Um único TCPInterface permanece conectado; duas filas independentes
    processam PING e CLIMA. A conexão é reiniciada em perda anunciada pela
    biblioteca PubSub. Sem resposta RF garantida até validação no rádio.
    """
    global _mesh_dispatcher_active, _mesh_last_listener_error
    if not MESH_COMMANDS_ENABLED:
        print("Comandos da malha integrados: desativados no ambiente.", flush=True)
        return

    while not _mesh_command_stop.is_set():
        connection = None
        dispatcher = None
        subscribed_receive = False
        subscribed_lost = False
        disconnected = threading.Event()
        try:
            from meshtastic.tcp_interface import TCPInterface
            from pubsub import pub
            print(f"Comandos da malha: conectando ao Virtual Node "
                  f"{VIRTUAL_NODE_HOST}:{VIRTUAL_NODE_PORT}...", flush=True)
            connection = TCPInterface(
                hostname=VIRTUAL_NODE_HOST,
                portNumber=VIRTUAL_NODE_PORT,
                timeout=max(5, VIRTUAL_NODE_CONNECT_TIMEOUT),
            )
            send_lock = threading.Lock()

            def send_rf(text, command):
                with send_lock:
                    if disconnected.is_set():
                        raise RuntimeError("Conexão RF perdida antes do envio")
                    result = connection.sendText(str(text), destinationId="^all", channelIndex=0)
                    print(f"Resposta RF encaminhada: {command.upper()} · "
                          f"{len(str(text).encode('utf-8'))} bytes", flush=True)
                    return {"success": True, "transport": "meshtastic-tcp",
                            "packetId": result.get("id") if isinstance(result, dict) else None}

            dispatcher = MeshCommandDispatcher(
                process=_mesh_command_handle,
                seen=_mesh_command_seen,
                record=_mesh_command_record,
                send=send_rf,
                key=_mesh_command_message_key,
                stop_event=_mesh_command_stop,
                log=lambda message: print(message, flush=True),
            ).start()
            dispatcher.set_connected(True)

            with _mesh_dispatcher_lock:
                _mesh_dispatcher_active = dispatcher
                _mesh_last_listener_error = None

            def on_packet(packet=None, interface=None, **kwargs):
                # Nunca consultar banco/API/traceroute ou enviar RF no callback.
                # Ignorar eventos de conexões de outras rotinas Meshtastic.
                if interface is not None and interface is not connection:
                    return
                try:
                    _mesh_command_receive_packet(packet, connection, dispatcher)
                except Exception as exc:
                    print(f"Falha no callback RF (parsing/fila): {exc}", flush=True)

            def on_lost(interface=None, **kwargs):
                if interface is None or interface is connection:
                    print("Listener RF: perda de conexão anunciada pelo Meshtastic.", flush=True)
                    disconnected.set()

            pub.subscribe(on_packet, "meshtastic.receive")
            subscribed_receive = True
            pub.subscribe(on_lost, "meshtastic.connection.lost")
            subscribed_lost = True
            print(
                f"Comandos da malha integrados: PING, CLIMA e #CLIMA ativos em "
                f"{VIRTUAL_NODE_HOST}:{VIRTUAL_NODE_PORT} no canal primário "
                f"(listener assíncrono meshtastic.receive).", flush=True,
            )
            while not _mesh_command_stop.wait(1.0):
                if disconnected.is_set():
                    raise ConnectionError("Conexão Meshtastic perdida")
        except Exception as exc:
            with _mesh_dispatcher_lock:
                _mesh_last_listener_error = str(exc)[:320]
            print(f"Listener Meshtastic dos comandos caiu: {exc}; reconectando em 5 s.", flush=True)
        finally:
            disconnected.set()
            if dispatcher is not None:
                dispatcher.stop()
            with _mesh_dispatcher_lock:
                if _mesh_dispatcher_active is dispatcher:
                    _mesh_dispatcher_active = None
            if subscribed_receive:
                try:
                    from pubsub import pub
                    pub.unsubscribe(on_packet, "meshtastic.receive")
                except Exception:
                    pass
            if subscribed_lost:
                try:
                    from pubsub import pub
                    pub.unsubscribe(on_lost, "meshtastic.connection.lost")
                except Exception:
                    pass
            if connection is not None:
                try:
                    connection.close()
                except Exception:
                    pass
            if not _mesh_command_stop.is_set():
                _mesh_command_stop.wait(5.0)

def _mesh_command_worker():
    if not MESH_COMMANDS_ENABLED:
        print("Comandos da malha integrados: desativados.", flush=True)
        return
    print(
        f"Comandos da malha integrados: PING e CLIMA ativos no canal primário; "
        f"clima={CLIMA_API_URL}",
        flush=True,
    )
    meta_key = f"mesh-commands-initialized-v2:{MM_SOURCE}"
    while not _mesh_command_stop.is_set():
        try:
            rows, errors = _mesh_command_candidates(300)
            if errors:
                print("Comandos da malha: " + " | ".join(errors), flush=True)

            with _archive_connect() as conn:
                initialized = conn.execute(
                    "SELECT meta_value FROM topology_history_meta WHERE meta_key=?",
                    (meta_key,),
                ).fetchone()
            if not initialized:
                for row in rows:
                    command = meshcmd.normalize_command(row.get("text"))
                    if command and not row.get("mine"):
                        _mesh_command_record(row, command, "baseline")
                with _archive_connect() as conn:
                    conn.execute(
                        "INSERT OR REPLACE INTO topology_history_meta(meta_key,meta_value) VALUES(?,?)",
                        (meta_key, json.dumps({"initializedAtMs":int(time.time()*1000)})),
                    )
                print(f"Comandos da malha: inicializados; {len(rows)} comando(s) antigo(s) ignorado(s).", flush=True)
                _mesh_command_stop.wait(MESH_COMMAND_POLL_SECONDS)
                continue

            for row in rows:
                if row.get("mine") or row.get("emoji"):
                    continue
                command = meshcmd.normalize_command(row.get("text"))
                if not command:
                    continue
                key = _mesh_command_message_key(row)
                if _mesh_command_seen(key):
                    continue
                print(
                    f"Comando recebido: {command.upper()} de "
                    f"{row.get('fromNodeId') or row.get('fromNodeNum') or 'desconhecido'} "
                    f"via {row.get('_source') or 'messages-api'}",
                    flush=True,
                )
                try:
                    _mesh_command_handle(row, command)
                    print(f"Comando concluído: {command.upper()}", flush=True)
                except Exception as exc:
                    _mesh_command_record(row, command, "error", detail=str(exc))
                    print(f"Comando {command} falhou: {exc}", flush=True)
        except Exception as exc:
            print(f"Worker de comandos da malha: {exc}", flush=True)
        _mesh_command_stop.wait(MESH_COMMAND_POLL_SECONDS)

def _automatic_notice_settings():
    raw = _read_json_file(NOTICE_SETTINGS_FILE, {})
    return {
        "inmetEnabled": bool(raw.get("inmetEnabled", True)),
        "meshtasticStableEnabled": bool(raw.get("meshtasticStableEnabled", True)),
        "meshtasticUnstableEnabled": bool(raw.get("meshtasticUnstableEnabled", True)),
        "meshtasticNightlyEnabled": bool(raw.get("meshtasticNightlyEnabled", True)),
        "meshtasticEnabled": bool(raw.get("meshtasticEnabled", True)),
        "meshtasticTemplate": str(raw.get("meshtasticTemplate", "Meshtastic {kind}: {version} — {url}")),
        "pollSeconds": max(300,min(int(raw.get("pollSeconds",NOTICE_POLL_SECONDS)),86400)),
        "channel": 0,
    }


def _save_automatic_notice_settings(payload: dict):
    with _notice_lock:
        data=_automatic_notice_settings()
        allowed={'inmetEnabled','meshtasticEnabled','meshtasticStableEnabled','meshtasticUnstableEnabled',
                 'meshtasticNightlyEnabled','pollSeconds','meshtasticTemplate'}
        if set(payload)-allowed:raise ValueError('Campos de avisos desconhecidos')
        for key in allowed:
            if key not in payload:continue
            value=payload[key]
            if key.endswith('Enabled') and type(value) is not bool:raise ValueError('Ativação deve ser booleana')
            if key=='pollSeconds':
                if type(value) is not int or not 300<=value<=86400:raise ValueError('Intervalo deve ser de 300 a 86400 segundos')
            if key=='meshtasticTemplate':
                firmware_notices.message({'version':'v2.8.0.abcdef0','kind':'nightly','url':'https://nightly.meshtastic.org/'},value)
            data[key]=value
        data.pop('channel',None)
        data['updatedAtMs']=int(time.time()*1000)
        _write_json_file(NOTICE_SETTINGS_FILE,data)
    _notice_wakeup.set()
    return _automatic_notice_settings()


def _automatic_notice_state():
    raw = _read_json_file(NOTICE_STATE_FILE, {})
    raw.setdefault("inmet", {})
    raw.setdefault("meshtasticStableId", None)
    raw.setdefault("meshtasticUnstableId", None)
    raw.setdefault("inmetInitialized", False)
    raw.setdefault("initialized", False)
    return raw


def _truncate_utf8(text: str, max_bytes: int = 600) -> str:
    # Preserva quebras de linha deliberadas. Apenas espaços horizontais são normalizados.
    raw = "\n".join(re.sub(r"[ \t]+", " ", line).strip() for line in str(text or "").replace("\r", "").split("\n"))
    raw = "\n".join(line for line in raw.split("\n") if line).strip()
    if len(raw.encode("utf-8")) <= max_bytes:
        return raw
    suffix = "…"
    limit = max(1, max_bytes - len(suffix.encode("utf-8")))
    out = raw.encode("utf-8")[:limit]
    while out:
        try:
            return out.decode("utf-8") + suffix
        except UnicodeDecodeError:
            out = out[:-1]
    return suffix


def _record_automatic_notice(source: str, external_id: str, kind: str, message: str, success: bool, detail=""):
    now_ms = int(time.time() * 1000)
    try:
        with _archive_connect() as conn:
            conn.execute(
                "INSERT INTO automatic_notices(source,external_id,kind,detected_at,sent_at,success,message,detail) VALUES(?,?,?,?,?,?,?,?)",
                (str(source), str(external_id or ""), str(kind or ""), now_ms, now_ms if success else None,
                 1 if success else 0, str(message or ""), str(detail or "")[:4000]),
            )
            conn.commit()
    except Exception:
        pass


def _notice_send(source: str, external_id: str, kind: str, message: str) -> bool:
    text = _truncate_utf8(message, 1200)
    parts = meshcmd.split_utf8(text, 200)
    if not parts:
        return False
    receipts = []
    try:
        for index, part in enumerate(parts):
            body = _send_primary_message(part)
            if isinstance(body, dict) and body.get("success") is False:
                raise RuntimeError(str(body.get("message") or body.get("error") or body))
            receipts.append(body)
            if index < len(parts) - 1:
                _notice_stop.wait(1.5)
        _record_automatic_notice(source, external_id, kind, "\n---\n".join(parts), True,
                                 json.dumps(receipts, ensure_ascii=False, default=str)[:4000])
        return True
    except Exception as exc:
        _record_automatic_notice(source, external_id, kind, "\n---\n".join(parts), False, str(exc))
        return False


def _notice_brasilia_alert(alert: dict) -> bool:
    hay = " ".join(str(alert.get(k) or "") for k in ("event","headline","description","area","areaDesc","areas")).lower()
    if "brasília" in hay or "brasilia" in hay or "distrito federal" in hay:
        return True
    south, north, west, east = -16.10, -15.40, -48.35, -47.20
    for poly in alert.get("polygons") or []:
        pts=[]
        for p in poly or []:
            try: pts.append((float(p[0]),float(p[1])))
            except Exception: pass
        if not pts: continue
        lats=[p[0] for p in pts]; lons=[p[1] for p in pts]
        if max(lats) >= south and min(lats) <= north and max(lons) >= west and min(lons) <= east:
            return True
    return False


def _notice_alert_id(alert: dict) -> str:
    explicit = alert.get("identifier") or alert.get("id") or alert.get("codigo")
    if explicit:
        return str(explicit)
    basis = "|".join(str(alert.get(k) or "") for k in ("event","headline","expires","description"))
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()[:24]


def _notice_alert_signature(alert: dict) -> str:
    basis = json.dumps(alert, ensure_ascii=False, sort_keys=True, separators=(",",":"))
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()


def _notice_inmet_message(alert: dict, updated=False) -> str:
    prefix = "⚠️ Alerta meteorológico do INMET para Brasília/DF" + (" — atualização" if updated else "")
    event = str(alert.get("event") or "Alerta meteorológico").strip()
    severity = str(alert.get("severity") or "").strip()
    expires = str(alert.get("expires") or "").strip()
    headline = str(alert.get("headline") or alert.get("description") or "").strip()
    lines=[prefix, "Evento: "+event]
    if severity: lines.append("Severidade: "+severity)
    if expires: lines.append("Válido até: "+expires)
    if headline and headline.lower()!=event.lower(): lines.append("Descrição: "+headline)
    lines.append("Fonte: Instituto Nacional de Meteorologia (INMET)")
    return _truncate_utf8("\n".join(lines), 1200)


def _meshtastic_releases():
    req=urllib.request.Request(MESHTASTIC_RELEASES_URL,headers={
        "Accept":"application/vnd.github+json",
        "User-Agent":f"TrafficAnalyzer/{APP_VERSION}",
        "X-GitHub-Api-Version":"2022-11-28",
        "Cache-Control":"no-cache",
    })
    with urllib.request.urlopen(req,timeout=15) as resp:
        data=json.loads(resp.read().decode("utf-8"))
    return [r for r in data if isinstance(r,dict) and not r.get("draft") and r.get("tag_name")] if isinstance(data,list) else []


def _meshtastic_release_kind(release: dict) -> str:
    tag=str(release.get("tag_name") or "").lower()
    unstable=bool(release.get("prerelease")) or bool(re.search(r"(?:alpha|beta|\brc\b|preview|nightly|dev)",tag))
    return "unstable" if unstable else "stable"


def _release_summary(body: str) -> str:
    lines=[]
    for line in str(body or "").replace("\r","").split("\n"):
        s=re.sub(r"^\s*[-*#>]+\s*","",line).strip()
        s=re.sub(r"\[([^\]]+)\]\([^\)]+\)",r"\1",s)
        if s and not s.lower().startswith(("full changelog","what's changed","contributors")):
            lines.append(s)
        if len(" ".join(lines))>220: break
    return _truncate_utf8(" ".join(lines), 220)


def _meshtastic_notice_message(release: dict, kind: str) -> str:
    tag=str(release.get("tag_name") or "").strip()
    label="ESTÁVEL" if kind=="stable" else "INSTÁVEL"
    published=str(release.get("published_at") or release.get("created_at") or "")[:10]
    summary=_release_summary(release.get("body") or "")
    parts=[f"📡 Meshtastic — nova versão {label}: {tag}"]
    if published: parts.append("publicada "+published)
    if summary: parts.append(summary)
    return _truncate_utf8(" · ".join(parts),600)


def _latest_release_of_kind(releases, kind):
    rows=[r for r in releases if _meshtastic_release_kind(r)==kind]
    if not rows: return None
    rows.sort(key=lambda r:str(r.get("published_at") or r.get("created_at") or ""),reverse=True)
    return rows[0]


def _firmware_send(record,text):
    parts=meshcmd.split_utf8(_truncate_utf8(text,1200),200)
    if not parts:
        raise RuntimeError('Anúncio vazio')
    receipts=[]
    try:
        for index,part in enumerate(parts):
            body=_send_primary_message(part)
            if not isinstance(body,dict) or type(body.get('success')) is not bool:
                raise RuntimeError('Backend não confirmou aceitação do anúncio; resultado indeterminado')
            if body['success'] is not True:
                _record_automatic_notice('meshtastic',record['id'],record['kind'],"\n---\n".join(parts),False,str(body)[:400])
                return False
            receipts.append(body)
            if index<len(parts)-1:_notice_stop.wait(1.5)
    except Exception as exc:
        _record_automatic_notice('meshtastic',record['id'],record['kind'],"\n---\n".join(parts),False,str(exc))
        raise # Timeout outcome is ambiguous: do not blindly retransmit.
    _record_automatic_notice('meshtastic',record['id'],record['kind'],"\n---\n".join(parts),True,json.dumps(receipts,ensure_ascii=False,default=str)[:400])
    return True


def _run_firmware_notice_check(state,settings,now):
    records=[];available=[];errors=[]
    sources=state.setdefault('firmwareSources',{})
    for source in ('releases','nightly'):
        info=sources.setdefault(source,{})
        if now<info.get('retryAt',0):
            if info.get('error'):errors.append(info['error'])
            continue
        try:
            if source=='releases':
                rows=firmware_notices.release_records(_meshtastic_releases())
                records.extend(r for r in rows if r['kind']!='nightly')
                available.extend(('stable','unstable'))
            else:
                records.append(firmware_notices.nightly_record(firmware_notices.fetch_json(firmware_notices.NIGHTLY_URL)))
                available.append('nightly')
            info.update(failures=0,error='',retryAt=0,lastCheck=now)
        except Exception as exc:
            failures=min(int(info.get('failures',0))+1,8)
            delay=min(86400,600*2**(failures-1))
            if isinstance(exc,urllib.error.HTTPError):
                try:delay=max(delay,min(86400,int(exc.headers.get('Retry-After','0'))))
                except (ValueError,AttributeError):pass
            error=source+': '+str(exc)[:180]
            info.update(failures=failures,error=error,retryAt=now+delay,lastCheck=now)
            errors.append(error)
    state['firmwareDetected']=records
    keys={'stable':'meshtasticStableEnabled','unstable':'meshtasticUnstableEnabled','nightly':'meshtasticNightlyEnabled'}
    enabled={kind:settings['meshtasticEnabled'] and settings[key] for kind,key in keys.items()}
    sent=firmware_notices.process(state,records,available,enabled,
        lambda value:_write_json_file(NOTICE_STATE_FILE,value),_firmware_send,now,settings['meshtasticTemplate'])
    state['firmwareLastCheck']=now
    state['firmwareLastError']='; '.join(errors)
    _write_json_file(NOTICE_STATE_FILE,state)
    return sent,errors


def _firmware_announce_now(kind,now):
    if kind not in firmware_notices.KINDS:raise ValueError('Categoria inválida')
    settings=_automatic_notice_settings()
    if kind=='nightly':
        records=[firmware_notices.nightly_record(firmware_notices.fetch_json(firmware_notices.NIGHTLY_URL))]
    else:
        records=firmware_notices.release_records(_meshtastic_releases())
    record=firmware_notices.latest(records,kind)
    if not record:raise ValueError('Nenhuma versão '+firmware_notices.LABELS[kind]+' encontrada na fonte oficial')
    with _notice_lock:
        state=_automatic_notice_state()
        result=firmware_notices.announce_now(state,record,lambda value:_write_json_file(NOTICE_STATE_FILE,value),
                                              _firmware_send,now,settings['meshtasticTemplate'])
    result['state']=state
    return result


def _run_automatic_notice_check(force=False):
    with _notice_lock:
        settings=_automatic_notice_settings()
        state=_automatic_notice_state()
        now_ms=int(time.time()*1000)
        errors=[]
        sent_any=False
        try:
            body=_weather_alerts_inmet()
            current={}
            for alert in body.get("alerts") or []:
                if not isinstance(alert,dict) or not _notice_brasilia_alert(alert): continue
                aid=_notice_alert_id(alert); sig=_notice_alert_signature(alert); current[aid]=sig
                old=(state.get("inmet") or {}).get(aid)
                if old is None:
                    if state.get("inmetInitialized") and settings.get("inmetEnabled"):
                        if _notice_send("inmet",aid,"new",_notice_inmet_message(alert,False)): sent_any=True
                        else: current.pop(aid,None)
                elif old != sig and settings.get("inmetEnabled"):
                    if _notice_send("inmet",aid,"update",_notice_inmet_message(alert,True)): sent_any=True
                    else: current[aid]=old
            state["inmet"]=current
            state["inmetInitialized"]=True
        except Exception as exc:
            errors.append("INMET: "+str(exc))
        try:
            sent,firmware_errors=_run_firmware_notice_check(state,settings,now_ms/1000)
            sent_any=sent_any or sent
            errors.extend(firmware_errors)
        except Exception as exc:
            errors.append("Meshtastic: "+str(exc))
        state["initialized"]=True
        state["lastCheckAtMs"]=now_ms
        state["lastError"]="; ".join(errors) if errors else ""
        if sent_any: state["lastSendAtMs"]=int(time.time()*1000)
        _write_json_file(NOTICE_STATE_FILE,state)
        return {"success":not bool(errors),"settings":settings,"state":state,"message":"; ".join(errors) if errors else "Verificação concluída."}


def _automatic_notice_worker():
    if _notice_stop.wait(12): return
    while not _notice_stop.is_set():
        try:
            _run_automatic_notice_check()
        except Exception:
            pass
        _notice_wakeup.clear()
        _notice_wakeup.wait(_automatic_notice_settings()["pollSeconds"])
        if _notice_stop.is_set(): break

def _live_traceroutes(limit: int):
    source = urllib.parse.quote(MM_SOURCE, safe="")
    body = _mm_api_get(f"/api/v1/sources/{source}/traceroutes?limit={limit}")
    rows = body.get("data", []) if isinstance(body, dict) else []
    # Projeção mínima: não devolve token, configuração, PSK nem outros dados da API.
    keep = {
        "id", "packetId", "fromNodeNum", "toNodeNum", "fromNodeId", "toNodeId",
        "route", "routeBack", "snrTowards", "snrBack", "routePositions",
        "channel", "timestamp", "createdAt", "transportMechanism", "viaMqtt",
    }
    return [{k: row.get(k) for k in keep if k in row} for row in rows if isinstance(row, dict)]
NODE_SAFE_FIELDS = {
    "nodeNum", "nodeId", "longName", "shortName", "hwModel", "role", "hopsAway",
    "lastMessageHops", "latitude", "longitude", "altitude", "batteryLevel", "voltage",
    "channelUtilization", "airUtilTx", "lastHeard", "snr", "rssi",
    "lastTracerouteRequest", "firmwareVersion", "channel", "mobile", "rebootCount",
    "hasPKC", "isStoreForwardServer", "nodeStatus", "nodeStatusUpdatedAt",
    "positionChannel", "positionPrecisionBits", "positionGpsAccuracy", "positionHdop",
    "positionTimestamp", "positionLocationSource", "transportLastRf", "transportLastMqtt",
    "transportLastUdp", "createdAt", "updatedAt", "uptimeSeconds",
}
NODE_TELEMETRY_FIELDS = {
    "telemetryType", "timestamp", "value", "unit", "createdAt", "packetTimestamp",
    "packetId", "channel",
}


def _node_num(value):
    try:
        n = int(value)
    except (TypeError, ValueError):
        raise ValueError("nodeNum inválido")
    if n <= 0 or n > 0xFFFFFFFF:
        raise ValueError("nodeNum inválido")
    return n & 0xFFFFFFFF


def _node_hex_id(n: int) -> str:
    return f"!{n & 0xFFFFFFFF:08x}"


def _telemetry_kind(type_name) -> str:
    name = re.sub(r"[^a-z0-9]+", "", str(type_name or "").lower())
    if any(k in name for k in ("pm10", "pm25", "pm2", "co2", "voc", "eco2", "airquality")):
        return "airQuality"
    if any(k in name for k in ("current", "power", "energy", "ch1", "ch2", "ch3")):
        return "power"
    if any(k in name for k in (
        "temperature", "humidity", "pressure", "gas", "iaq", "lux", "wind",
        "weight", "radiation", "distance",
    )):
        return "environment"
    if any(k in name for k in ("battery", "voltage", "channelutil", "airutil", "uptime")):
        return "device"
    return "other"


def _node_details(node_num):
    n = _node_num(node_num)
    source_id = _resolved_mm_source_id()
    source = urllib.parse.quote(source_id, safe="")
    nodes_body = _mm_api_get(f"/api/v1/sources/{source}/nodes")
    rows = nodes_body.get("data", []) if isinstance(nodes_body, dict) else []
    row = None
    for candidate in rows:
        try:
            if isinstance(candidate, dict) and int(candidate.get("nodeNum")) == n:
                row = candidate
                break
        except (TypeError, ValueError):
            continue
    row = row or {}
    node_id = str(row.get("nodeId") or _node_hex_id(n))
    node = {k: row.get(k) for k in NODE_SAFE_FIELDS if k in row}
    node.setdefault("nodeNum", n)
    node.setdefault("nodeId", node_id)
    node["publicKeyAvailable"] = bool(row.get("publicKey"))

    telemetry_rows = []
    try:
        params = urllib.parse.urlencode({"nodeId": node_id, "limit": "160"})
        tel_body = _mm_api_get(f"/api/v1/sources/{source}/telemetry?{params}")
        raw_tel = tel_body.get("data", []) if isinstance(tel_body, dict) else []
        for item in raw_tel:
            if not isinstance(item, dict):
                continue
            projected = {k: item.get(k) for k in NODE_TELEMETRY_FIELDS if k in item}
            projected["kind"] = _telemetry_kind(projected.get("telemetryType"))
            telemetry_rows.append(projected)
        telemetry_rows.sort(key=lambda x: int(x.get("timestamp") or x.get("createdAt") or 0), reverse=True)
        # Popup = estado atual: conserva apenas a amostra mais recente de cada
        # tipo de metadado. O histórico completo continua persistido no MM.
        latest_by_type = []
        seen_types = set()
        for item in telemetry_rows:
            key = str(item.get("telemetryType") or "telemetry")
            if key in seen_types:
                continue
            seen_types.add(key)
            latest_by_type.append(item)
        telemetry_rows = latest_by_type
    except Exception:
        telemetry_rows = []

    # Evidência de resposta real: pacotes RX originados pelo nó após uma
    # solicitação. Isso detecta respostas mesmo quando o conteúdo é idêntico
    # ao que já estava salvo no NodeDB.
    response_packets = []
    try:
        since_ms = int(time.time() * 1000) - 15 * 60 * 1000
        params = urllib.parse.urlencode({
            "limit": "250",
            "from_node": str(n),
            "since": str(since_ms),
        })
        pkt_body = _mm_api_get(f"/api/v1/sources/{source}/packets?{params}")
        pkt_rows = pkt_body.get("data", []) if isinstance(pkt_body, dict) else []
        allowed_ports = {"NODEINFO_APP", "POSITION_APP", "TELEMETRY_APP", "NEIGHBORINFO_APP", "ROUTING_APP"}
        for item in pkt_rows:
            if not isinstance(item, dict):
                continue
            port = str(item.get("portnum_name") or "")
            if port not in allowed_ports:
                continue
            direction = str(item.get("direction") or "").lower()
            if direction and direction != "rx":
                continue
            ts = item.get("timestamp") or item.get("created_at") or item.get("createdAt")
            try:
                ts = int(float(ts))
                if ts < 10_000_000_000:
                    ts *= 1000
            except Exception:
                continue
            metadata = item.get("metadata")
            if isinstance(metadata, str):
                try:
                    metadata = json.loads(metadata)
                except Exception:
                    metadata = {}
            if not isinstance(metadata, dict):
                metadata = {}
            decoded = metadata.get("decoded_payload")
            if not isinstance(decoded, dict):
                decoded = {}
            request_id = (
                metadata.get("requestId") or metadata.get("request_id")
                or decoded.get("requestId") or decoded.get("request_id")
            )
            error_reason = decoded.get("errorReason")
            if error_reason is None:
                error_reason = decoded.get("error_reason")
            response_packets.append({
                "port": port,
                "timestampMs": ts,
                "packetId": item.get("packet_id") or item.get("packetId"),
                "requestId": request_id,
                "routingErrorReason": error_reason if port == "ROUTING_APP" else None,
                "channel": item.get("channel"),
                "rssi": item.get("rssi"),
                "snr": item.get("snr"),
                "hopLimit": item.get("hop_limit") or item.get("hopLimit"),
                "hopStart": item.get("hop_start") or item.get("hopStart"),
                "fromNode": item.get("from_node") or item.get("fromNode"),
                "toNode": item.get("to_node") or item.get("toNode"),
            })
        response_packets.sort(key=lambda x: int(x.get("timestampMs") or 0), reverse=True)
    except Exception:
        response_packets = []

    # Solicitações TX observadas no Packet Monitor. Isso permite acompanhar
    # retries automáticos do MeshMonitor (especialmente Telemetry) sem
    # presumir que a primeira tentativa falhou definitivamente.
    request_packets = []
    try:
        params = urllib.parse.urlencode({
            "limit": "250",
            "to_node": str(n),
            "since": str(since_ms),
        })
        req_body = _mm_api_get(f"/api/v1/sources/{source}/packets?{params}")
        req_rows = req_body.get("data", []) if isinstance(req_body, dict) else []
        allowed_request_ports = {"NODEINFO_APP", "POSITION_APP", "TELEMETRY_APP", "NEIGHBORINFO_APP"}
        for item in req_rows:
            if not isinstance(item, dict):
                continue
            port = str(item.get("portnum_name") or "")
            if port not in allowed_request_ports:
                continue
            direction = str(item.get("direction") or "").lower()
            if direction and direction != "tx":
                continue
            ts = item.get("timestamp") or item.get("created_at") or item.get("createdAt")
            try:
                ts = int(float(ts))
                if ts < 10_000_000_000:
                    ts *= 1000
            except Exception:
                continue
            metadata = item.get("metadata")
            if isinstance(metadata, str):
                try:
                    metadata = json.loads(metadata)
                except Exception:
                    metadata = {}
            if not isinstance(metadata, dict):
                metadata = {}
            request_packets.append({
                "port": port,
                "timestampMs": ts,
                "packetId": metadata.get("packetId") or item.get("packet_id") or item.get("packetId"),
                "requestId": metadata.get("requestId") or metadata.get("request_id"),
                "telemetryType": metadata.get("telemetryType"),
                "channel": item.get("channel"),
                "payloadPreview": item.get("payload_preview"),
            })
        request_packets.sort(key=lambda x: int(x.get("timestampMs") or 0))
    except Exception:
        request_packets = []

    relevant_traces = []
    try:
        for tr in _live_traceroutes(200):
            try:
                if int(tr.get("fromNodeNum") or 0) == n or int(tr.get("toNodeNum") or 0) == n:
                    relevant_traces.append(tr)
                    continue
                route_values = []
                for key in ("route", "routeBack"):
                    value = tr.get(key)
                    if isinstance(value, list):
                        route_values.extend(value)
                    elif isinstance(value, str) and value.strip():
                        try:
                            parsed = json.loads(value)
                            if isinstance(parsed, list):
                                route_values.extend(parsed)
                        except Exception:
                            pass
                if any(int(v) == n for v in route_values):
                    relevant_traces.append(tr)
            except Exception:
                continue
        relevant_traces.sort(key=lambda x: int(x.get("timestamp") or x.get("createdAt") or 0), reverse=True)
    except Exception:
        relevant_traces = []

    neighbors = {"available": True, "data": [], "latestTimestamp": None}
    try:
        q = urllib.parse.urlencode({"sourceId": source_id})
        nb_body = _mm_api_get(f"/api/neighborinfo/{n}?{q}")
        nb_rows = nb_body if isinstance(nb_body, list) else (nb_body.get("data", []) if isinstance(nb_body, dict) else [])
        clean_nb = []
        for item in nb_rows:
            if not isinstance(item, dict):
                continue
            keep = {
                "nodeNum", "neighborNodeNum", "neighborNodeId", "neighborName",
                "snr", "timestamp", "lastRxTime", "nodeId", "nodeName", "bidirectional",
            }
            clean_nb.append({k: item.get(k) for k in keep if k in item})
        neighbors["data"] = clean_nb[:80]
        stamps = []
        for item in clean_nb:
            for key in ("timestamp", "lastRxTime"):
                try:
                    stamps.append(int(item.get(key) or 0))
                except Exception:
                    pass
        neighbors["latestTimestamp"] = max(stamps) if stamps else None
    except Exception as exc:
        msg = str(exc or "").strip()
        low = msg.lower()
        if "<html" in low or "<!doctype" in low or "cannot get /api/neighborinfo" in low or "/api/neighborinfo/" in low and ("404" in low or "cannot get" in low):
            msg = "Neighbor Info indisponível neste MeshMonitor / endpoint não suportado"
        elif len(msg) > 240:
            msg = msg[:237] + "..."
        neighbors = {"available": False, "data": [], "latestTimestamp": None, "error": msg}

    return {
        "success": True,
        "nodeNum": n,
        "node": node,
        "telemetry": {"latest": telemetry_rows[:80]},
        "responses": response_packets[:120],
        "requests": request_packets[:120],
        "traceroute": relevant_traces[0] if relevant_traces else None,
        "neighbors": neighbors,
        "readAtMs": int(time.time() * 1000),
    }


_mm_source_resolution_cache = {"checked_at": 0.0, "configured": None, "resolved": None}


def _resolved_mm_source_id():
    """Return the concrete MeshMonitor source id behind MM_SOURCE/default."""
    configured = str(MM_SOURCE or "default").strip() or "default"
    now = time.time()
    cached = _mm_source_resolution_cache
    if (
        cached.get("configured") == configured
        and cached.get("resolved")
        and now - float(cached.get("checked_at") or 0) < 300
    ):
        return str(cached["resolved"])

    resolved = configured
    if configured == "default":
        try:
            body = _mm_api_get("/api/v1/sources")
            rows = body.get("data", []) if isinstance(body, dict) else []
            primary = next(
                (row for row in rows if isinstance(row, dict) and row.get("isPrimary") and row.get("id")),
                None,
            )
            if primary:
                resolved = str(primary.get("id"))
            elif rows and isinstance(rows[0], dict) and rows[0].get("id"):
                resolved = str(rows[0].get("id"))
        except Exception:
            resolved = configured

    cached.update({"checked_at": now, "configured": configured, "resolved": resolved})
    return resolved


def _mm_response_channel(body):
    """Extract the channel selected by MeshMonitor from structured data/message."""
    if not isinstance(body, dict):
        return None
    data = body.get("data") if isinstance(body.get("data"), dict) else {}
    for value in (body.get("channel"), data.get("channel")):
        try:
            if value is not None:
                channel = int(value)
                if 0 <= channel <= 7:
                    return channel
        except (TypeError, ValueError):
            pass
    for text_value in (body.get("message"), data.get("message")):
        text_value = str(text_value or "")
        match = re.search(r"\bchannel\s+(\d+)\b", text_value, re.IGNORECASE)
        if match:
            try:
                channel = int(match.group(1))
                if 0 <= channel <= 7:
                    return channel
            except (TypeError, ValueError):
                pass
    return None



_virtual_node_probe_cache = {"checked_at": 0.0, "ok": False, "error": ""}


def _node_query_channel(node_num: int, source_id: str) -> int:
    """Resolve the node's last known channel for Virtual Node requests."""
    source = urllib.parse.quote(str(source_id), safe="")
    try:
        body = _mm_api_get(f"/api/v1/sources/{source}/nodes")
        rows = body.get("data", []) if isinstance(body, dict) else []
        for row in rows:
            if not isinstance(row, dict):
                continue
            try:
                if int(row.get("nodeNum")) != int(node_num):
                    continue
            except (TypeError, ValueError):
                continue
            try:
                channel = int(row.get("channel"))
                if 0 <= channel <= 7:
                    return channel
            except (TypeError, ValueError):
                pass
            break
    except Exception:
        pass
    return 0


def _virtual_node_probe(force=False):
    now = time.time()
    cache = _virtual_node_probe_cache
    if not force and now - float(cache.get("checked_at") or 0) < 10:
        return bool(cache.get("ok")), str(cache.get("error") or "")

    error = ""
    ok = True
    if not VIRTUAL_NODE_PYTHON or not Path(VIRTUAL_NODE_PYTHON).is_file():
        ok = False
        error = f"Python do Virtual Node não encontrado: {VIRTUAL_NODE_PYTHON}"
    elif not VIRTUAL_NODE_HELPER.is_file():
        ok = False
        error = f"Helper do Virtual Node não encontrado: {VIRTUAL_NODE_HELPER}"
    else:
        try:
            check = subprocess.run(
                [VIRTUAL_NODE_PYTHON, "-c", "import meshtastic"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=3,
                check=False,
            )
            if check.returncode != 0:
                ok = False
                error = "Cliente Python Meshtastic indisponível no ambiente do Traffic Analyzer"
        except Exception as exc:
            ok = False
            error = f"Falha ao validar cliente Meshtastic: {exc}"
    # Não abrimos uma conexão de sondagem separada: alguns servidores de
    # Virtual Node aceitam apenas uma sessão por vez. A conexão real é feita
    # pelo helper e qualquer falha de TCP volta como diagnóstico explícito.
    cache.update({"checked_at": now, "ok": ok, "error": error})
    return ok, error


def _virtual_query_status_path(query_id: str) -> Path:
    query_id = str(query_id or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{24}", query_id):
        raise ValueError("queryId inválido")
    return VIRTUAL_QUERY_STATE_DIR / f"{query_id}.json"


def _virtual_query_status(query_id: str):
    path = _virtual_query_status_path(query_id)
    try:
        body = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {"success": False, "state": "not_found", "error": "Consulta não encontrada"}
    except Exception as exc:
        return {"success": False, "state": "error", "error": str(exc)}
    return body if isinstance(body, dict) else {"success": False, "state": "error", "error": "Status inválido"}


def _cleanup_virtual_query_statuses():
    try:
        VIRTUAL_QUERY_STATE_DIR.mkdir(parents=True, exist_ok=True)
        cutoff = time.time() - 3600
        for path in VIRTUAL_QUERY_STATE_DIR.glob("*.json"):
            try:
                if path.stat().st_mtime < cutoff:
                    path.unlink(missing_ok=True)
            except Exception:
                pass
    except Exception:
        pass


_virtual_query_execution_lock = threading.Lock()


def _run_virtual_query_job(cmd, status_path: Path, initial: dict):
    # Uma única sessão ativa evita que implementações de Virtual Node que
    # suportam apenas um cliente TCP simultâneo sofram disputa durante "Tudo".
    with _virtual_query_execution_lock:
        try:
            subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                text=False,
                timeout=VIRTUAL_NODE_QUERY_TIMEOUT + VIRTUAL_NODE_CONNECT_TIMEOUT + 20,
                check=False,
            )
        except subprocess.TimeoutExpired:
            payload = {
                **initial,
                "success": False,
                "state": "error",
                "error": "Helper do Virtual Node excedeu o tempo máximo de execução",
                "completedAtMs": int(time.time() * 1000),
            }
            try:
                status_path.write_text(json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
            except Exception:
                pass
        except Exception as exc:
            payload = {
                **initial,
                "success": False,
                "state": "error",
                "error": str(exc),
                "completedAtMs": int(time.time() * 1000),
            }
            try:
                status_path.write_text(json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8")
            except Exception:
                pass


def _virtual_node_send(node_num: int, action: str, channel: int):
    ok, error = _virtual_node_probe()
    if not ok:
        raise RuntimeError(error or "Virtual Node indisponível")

    _cleanup_virtual_query_statuses()
    query_id = secrets.token_hex(12)
    status_path = _virtual_query_status_path(query_id)
    initial = {
        "queryId": query_id,
        "backend": "virtual-node",
        "action": action,
        "destination": _node_hex_id(node_num),
        "channel": channel,
        "host": VIRTUAL_NODE_HOST,
        "port": VIRTUAL_NODE_PORT,
        "success": True,
        "state": "queued",
        "createdAtMs": int(time.time() * 1000),
    }
    status_path.write_text(json.dumps(initial, ensure_ascii=False) + "\n", encoding="utf-8")

    cmd = [
        VIRTUAL_NODE_PYTHON,
        str(VIRTUAL_NODE_HELPER),
        "--host", VIRTUAL_NODE_HOST,
        "--port", str(VIRTUAL_NODE_PORT),
        "--dest", _node_hex_id(node_num),
        "--channel", str(channel),
        "--action", action,
        "--connect-timeout", str(VIRTUAL_NODE_CONNECT_TIMEOUT),
        "--wait-timeout", str(VIRTUAL_NODE_QUERY_TIMEOUT),
        "--query-id", query_id,
        "--status-file", str(status_path),
    ]
    threading.Thread(
        target=_run_virtual_query_job,
        args=(cmd, status_path, initial),
        daemon=True,
        name=f"ta-query-{query_id[:8]}",
    ).start()

    return {
        **initial,
        "statusFile": str(status_path),
        "waitTimeout": VIRTUAL_NODE_QUERY_TIMEOUT,
    }


def _request_node_query(node_num, action):
    n = _node_num(node_num)
    action = str(action or "").strip()
    source_id = _resolved_mm_source_id()
    source = urllib.parse.quote(source_id, safe="")
    destination = _node_hex_id(n)
    requested_at_ms = int(time.time() * 1000)
    endpoint = None
    channel = None
    fallback_reason = ""

    allowed_actions = {
        "nodeinfo", "position", "traceroute", "neighbors",
        "telemetry_device", "telemetry_environment",
        "telemetry_airQuality", "telemetry_power",
    }
    if action not in allowed_actions:
        raise ValueError("Consulta de nó inválida")

    # Traceroute permanece na API do MeshMonitor: esse caminho já foi
    # comprovado na rede real. As demais consultas ativas preferem o Virtual
    # Node e usam o mesmo formato do cliente oficial Meshtastic (wantResponse
    # sem request_id pré-preenchido). A resposta é correlacionada depois pelo
    # packet.id original.
    if action != "traceroute" and NODE_QUERY_BACKEND in {"auto", "virtual"}:
        channel = _node_query_channel(n, source_id)
        try:
            virtual = _virtual_node_send(n, action, channel)
            packet_id = virtual.get("packetId")
            try:
                packet_id = int(packet_id) if packet_id is not None else None
            except (TypeError, ValueError):
                packet_id = None
            query_id = str(virtual.get("queryId") or "")
            accepted_parts = ["Virtual Node iniciado", f"canal {channel}"]
            if packet_id:
                accepted_parts.append(f"packet {packet_id}")
            if query_id:
                accepted_parts.append(f"consulta {query_id[:8]}")
            accepted_message = " · ".join(accepted_parts) + " · aguardando resposta correlacionada"
            return {
                "success": True,
                "action": action,
                "nodeNum": n,
                "requestedAtMs": requested_at_ms,
                "acceptedAtMs": int(time.time() * 1000),
                "acceptedMessage": accepted_message,
                "diagnostic": {
                    "backend": "virtual-node",
                    "sourceId": source_id,
                    "endpoint": f"tcp://{VIRTUAL_NODE_HOST}:{VIRTUAL_NODE_PORT}",
                    "channel": channel,
                    "packetId": packet_id,
                    "requestId": None,
                    "correlationPacketId": packet_id,
                    "queryId": query_id,
                    "virtualNodeHost": VIRTUAL_NODE_HOST,
                    "virtualNodePort": VIRTUAL_NODE_PORT,
                    "queryTimeout": VIRTUAL_NODE_QUERY_TIMEOUT,
                },
                "virtualNode": virtual,
            }
        except Exception as exc:
            if NODE_QUERY_BACKEND == "virtual":
                raise
            fallback_reason = str(exc)

    # Fallback compatível com instalações que ainda não tenham o helper/Virtual
    # Node disponível. O fallback é sempre exposto no diagnóstico; nunca é
    # tratado silenciosamente como se fosse o backend preferencial.
    if action == "nodeinfo":
        endpoint = "/api/nodeinfo/request"
        body = _mm_api_post(endpoint, {
            "destination": destination,
            "sourceId": source_id,
        })
    elif action == "position":
        endpoint = "/api/position/request"
        body = _mm_api_post(endpoint, {
            "destination": destination,
            "sourceId": source_id,
        })
    elif action == "traceroute":
        endpoint = f"/api/v1/sources/{source}/actions/traceroute"
        body = _mm_api_post(endpoint, {"destination": n})
        if isinstance(body, dict):
            data = body.get("data") if isinstance(body.get("data"), dict) else {}
            try:
                channel = int(data.get("channel")) if data.get("channel") is not None else None
            except (TypeError, ValueError):
                channel = None
    elif action == "neighbors":
        endpoint = "/api/neighborinfo/request"
        body = _mm_api_post(endpoint, {
            "destination": destination,
            "sourceId": source_id,
        })
    elif action.startswith("telemetry_"):
        telemetry_type = action.split("_", 1)[1]
        allowed = {"device", "environment", "airQuality", "power"}
        if telemetry_type not in allowed:
            raise ValueError("Tipo de telemetria inválido")
        endpoint = "/api/telemetry/request"
        body = _mm_api_post(endpoint, {
            "destination": destination,
            "telemetryType": telemetry_type,
            "sourceId": source_id,
        })
    else:
        raise ValueError("Consulta de nó inválida")

    if isinstance(body, dict) and body.get("success") is False:
        raise RuntimeError(str(body.get("message") or body.get("error") or "MeshMonitor recusou a consulta"))

    packet_id = None
    request_id = None
    if isinstance(body, dict):
        packet_id = body.get("packetId")
        request_id = body.get("requestId")
        data = body.get("data") if isinstance(body.get("data"), dict) else {}
        if packet_id is None:
            packet_id = data.get("packetId")
        if request_id is None:
            request_id = data.get("requestId")
        if channel is None:
            channel = _mm_response_channel(body)

    accepted_parts = ["MM aceitou"]
    if fallback_reason:
        accepted_parts.insert(0, "Virtual Node indisponível; fallback MM API")
    if channel is not None:
        accepted_parts.append(f"canal {channel}")
    if packet_id is not None:
        accepted_parts.append(f"packet {packet_id}")
    accepted_message = " · ".join(accepted_parts) + " · aguardando RX"
    mm_message = ""
    if isinstance(body, dict):
        mm_message = str(body.get("message") or "")
        if not mm_message and isinstance(body.get("data"), dict):
            mm_message = str(body["data"].get("message") or "")

    return {
        "success": True,
        "action": action,
        "nodeNum": n,
        "requestedAtMs": requested_at_ms,
        "acceptedAtMs": int(time.time() * 1000),
        "acceptedMessage": accepted_message,
        "diagnostic": {
            "backend": "meshmonitor-api",
            "sourceId": source_id,
            "endpoint": endpoint,
            "channel": channel,
            "packetId": packet_id,
            "requestId": request_id,
            "meshMonitorMessage": mm_message,
            "virtualFallbackReason": fallback_reason or None,
        },
        "meshMonitor": body,
    }



PACKET_KEEP_FIELDS = {
    "id", "packet_id", "timestamp", "from_node", "from_node_id", "from_node_longName",
    "to_node", "to_node_id", "to_node_longName", "channel", "portnum", "portnum_name",
    "encrypted", "snr", "rssi", "hop_limit", "hop_start", "relay_node", "payload_size",
    "want_ack", "priority", "payload_preview", "metadata", "direction", "created_at",
    "decrypted_by", "decrypted_channel_id", "transport_mechanism", "spoof_suspected",
    "xeddsa_signed",
}


def _sanitize_packet(row: dict):
    item = {k: row.get(k) for k in PACKET_KEEP_FIELDS if k in row}
    # Privacidade: broadcasts são públicos no canal e podem preservar o payload.
    # Mensagens diretas têm conteúdo/metadata removidos antes de chegar ao navegador
    # OU ao arquivo histórico persistente.
    portnum = item.get("portnum")
    try:
        is_text = item.get("portnum_name") == "TEXT_MESSAGE_APP" or int(portnum) == 1
    except (TypeError, ValueError):
        is_text = item.get("portnum_name") == "TEXT_MESSAGE_APP"
    if is_text:
        to_num = item.get("to_node")
        to_id = str(item.get("to_node_id") or "").lower()
        is_broadcast = to_num in {0xFFFFFFFF, -1} or to_id in {"!ffffffff", "broadcast"}
        if not is_broadcast:
            item["payload_preview"] = "[conteúdo oculto]"
            item["metadata"] = None
    return item


def _mm_packets_raw(limit: int, since=None, offset: int = 0):
    source = urllib.parse.quote(MM_SOURCE, safe="")
    params = {"limit": str(limit), "offset": str(offset)}
    if since is not None:
        params["since"] = str(since)
    body = _mm_api_get(f"/api/v1/sources/{source}/packets?{urllib.parse.urlencode(params)}")
    rows = body.get("data", []) if isinstance(body, dict) else []
    return body if isinstance(body, dict) else {}, [row for row in rows if isinstance(row, dict)]


def _packets(limit: int, since=None, offset: int = 0):
    body, rows = _mm_packets_raw(limit, since=since, offset=offset)
    projected = [_sanitize_packet(row) for row in rows]
    return {
        "success": True,
        "count": len(projected),
        "total": body.get("total", len(projected)),
        "offset": body.get("offset", offset),
        "limit": body.get("limit", limit),
        "data": projected,
    }


def _archive_connect():
    TRAFFIC_ARCHIVE_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(TRAFFIC_ARCHIVE_DB), timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def _archive_init():
    with _archive_connect() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS packets (
          archive_id INTEGER PRIMARY KEY AUTOINCREMENT,
          archive_key TEXT NOT NULL UNIQUE,
          source_id TEXT NOT NULL,
          mm_row_id INTEGER,
          packet_id INTEGER,
          timestamp INTEGER NOT NULL,
          created_at INTEGER,
          direction TEXT,
          from_node INTEGER,
          from_node_id TEXT,
          from_node_long_name TEXT,
          to_node INTEGER,
          to_node_id TEXT,
          to_node_long_name TEXT,
          channel INTEGER,
          portnum INTEGER,
          portnum_name TEXT,
          encrypted INTEGER,
          snr REAL,
          rssi REAL,
          hop_limit INTEGER,
          hop_start INTEGER,
          relay_node INTEGER,
          payload_size INTEGER,
          want_ack INTEGER,
          priority INTEGER,
          payload_preview TEXT,
          metadata TEXT,
          decrypted_by TEXT,
          decrypted_channel_id TEXT,
          transport_mechanism INTEGER,
          spoof_suspected INTEGER,
          xeddsa_signed INTEGER,
          archived_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_packets_timestamp ON packets(timestamp);
        CREATE INDEX IF NOT EXISTS idx_packets_packet_id ON packets(packet_id);
        CREATE INDEX IF NOT EXISTS idx_packets_from_node ON packets(from_node);
        CREATE INDEX IF NOT EXISTS idx_packets_to_node ON packets(to_node);
        CREATE INDEX IF NOT EXISTS idx_packets_portnum_name ON packets(portnum_name);
        CREATE INDEX IF NOT EXISTS idx_packets_direction ON packets(direction);
        CREATE INDEX IF NOT EXISTS idx_packets_relay_node ON packets(relay_node);

        CREATE TABLE IF NOT EXISTS positions (
          position_id INTEGER PRIMARY KEY AUTOINCREMENT,
          position_key TEXT NOT NULL UNIQUE,
          source_id TEXT NOT NULL,
          node_num INTEGER NOT NULL,
          node_id TEXT,
          node_name TEXT,
          timestamp INTEGER NOT NULL,
          latitude REAL NOT NULL,
          longitude REAL NOT NULL,
          altitude REAL,
          snr REAL,
          rssi REAL,
          archived_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_positions_node_time ON positions(source_id,node_num,timestamp);
        CREATE INDEX IF NOT EXISTS idx_positions_time ON positions(timestamp);

        CREATE TABLE IF NOT EXISTS automatic_notices (
          notice_id INTEGER PRIMARY KEY AUTOINCREMENT,
          source TEXT NOT NULL,
          external_id TEXT,
          kind TEXT,
          detected_at INTEGER NOT NULL,
          sent_at INTEGER,
          success INTEGER NOT NULL DEFAULT 0,
          message TEXT,
          detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_auto_notices_time ON automatic_notices(detected_at);
        CREATE INDEX IF NOT EXISTS idx_auto_notices_source ON automatic_notices(source);

        CREATE TABLE IF NOT EXISTS mesh_command_events (
          command_event_id INTEGER PRIMARY KEY AUTOINCREMENT,
          message_key TEXT NOT NULL UNIQUE,
          command TEXT NOT NULL,
          from_node INTEGER,
          from_node_id TEXT,
          received_at INTEGER,
          processed_at INTEGER NOT NULL,
          status TEXT NOT NULL,
          response_text TEXT,
          detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_mesh_command_time ON mesh_command_events(processed_at);
        CREATE INDEX IF NOT EXISTS idx_mesh_command_sender ON mesh_command_events(from_node,command,processed_at);

        CREATE TABLE IF NOT EXISTS deleted_nodes (
          source_id TEXT NOT NULL,
          node_num INTEGER NOT NULL,
          deleted_at_ms INTEGER NOT NULL,
          PRIMARY KEY(source_id,node_num)
        );

        CREATE TABLE IF NOT EXISTS topology_nodes (
          source_id TEXT NOT NULL,
          node_num INTEGER NOT NULL,
          first_seen_ms INTEGER NOT NULL,
          last_seen_ms INTEGER NOT NULL,
          position_seen_ms INTEGER,
          node_json TEXT NOT NULL,
          PRIMARY KEY(source_id,node_num)
        );
        CREATE INDEX IF NOT EXISTS idx_topology_nodes_last_seen ON topology_nodes(source_id,last_seen_ms);

        CREATE TABLE IF NOT EXISTS topology_edge_events (
          event_key TEXT PRIMARY KEY,
          source_id TEXT NOT NULL,
          edge_id TEXT NOT NULL,
          a INTEGER NOT NULL,
          b INTEGER NOT NULL,
          timestamp_ms INTEGER NOT NULL,
          leg TEXT,
          snr REAL,
          transport TEXT NOT NULL,
          trace_id TEXT,
          packet_id TEXT,
          channel INTEGER,
          observation_count INTEGER NOT NULL DEFAULT 1,
          direct_evidence INTEGER NOT NULL DEFAULT 0,
          direct_evidence_kind TEXT,
          archived_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_topology_edge_time ON topology_edge_events(source_id,timestamp_ms);
        CREATE INDEX IF NOT EXISTS idx_topology_edge_pair ON topology_edge_events(source_id,edge_id,timestamp_ms);

        CREATE TABLE IF NOT EXISTS topology_history_meta (
          meta_key TEXT PRIMARY KEY,
          meta_value TEXT
        );
        """)
        edge_cols = {str(row["name"]) for row in conn.execute("PRAGMA table_info(topology_edge_events)").fetchall()}
        if "direct_evidence" not in edge_cols:
            conn.execute("ALTER TABLE topology_edge_events ADD COLUMN direct_evidence INTEGER NOT NULL DEFAULT 0")
        if "direct_evidence_kind" not in edge_cols:
            conn.execute("ALTER TABLE topology_edge_events ADD COLUMN direct_evidence_kind TEXT")
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_topology_edge_direct ON topology_edge_events(source_id,direct_evidence,transport,timestamp_ms)"
        )
    _tracklog_backfill()


def _normalize_archive_retention_days(value) -> int:
    try:
        days = int(value)
    except (TypeError, ValueError):
        days = ARCHIVE_RETENTION_DEFAULT_DAYS
    return days if days in ARCHIVE_RETENTION_ALLOWED_DAYS else ARCHIVE_RETENTION_DEFAULT_DAYS


def _archive_settings():
    raw = _read_json_file(ARCHIVE_SETTINGS_FILE, {})
    return {
        "retentionDays": _normalize_archive_retention_days(raw.get("retentionDays", ARCHIVE_RETENTION_DEFAULT_DAYS)),
        "allowedDays": [0, 1, 7, 30],
        "updatedAtMs": raw.get("updatedAtMs"),
    }


def _save_archive_settings(payload: dict):
    days = _normalize_archive_retention_days(payload.get("retentionDays"))
    if payload.get("retentionDays") not in (None, "", days, str(days)):
        raise ValueError("Retenção inválida. Use 0, 1, 7 ou 30 dias.")
    data = {"retentionDays": days, "updatedAtMs": int(time.time() * 1000)}
    _write_json_file(ARCHIVE_SETTINGS_FILE, data)
    removed = _archive_cleanup(retention_days=days)
    return {**_archive_settings(), "removedPackets": removed}


def _history_ts_ms(value, fallback=0):
    if value in (None, ""):
        return int(fallback or 0)
    try:
        num = float(value)
        if not num:
            return int(fallback or 0)
        return int(num * 1000) if abs(num) < 10_000_000_000 else int(num)
    except (TypeError, ValueError):
        pass
    try:
        raw = str(value).strip().replace("Z", "+00:00")
        return int(datetime.fromisoformat(raw).timestamp() * 1000)
    except Exception:
        return int(fallback or 0)


def _history_valid_position(lat, lon):
    try:
        lat = float(lat); lon = float(lon)
    except (TypeError, ValueError):
        return False
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        return False
    return not (abs(lat) < 0.01 and abs(lon) < 0.01)


def _history_node_seen_ms(node: dict, fallback_ms: int):
    vals = [
        _history_ts_ms(node.get("lastHeard")),
        _history_ts_ms(node.get("updatedAt")),
        _history_ts_ms(node.get("positionTimestamp")),
        _history_ts_ms(node.get("nodeStatusUpdatedAt")),
    ]
    best = max(vals or [0])
    return best or int(fallback_ms or time.time() * 1000)


def _history_node_position_ms(node: dict, fallback_ms: int):
    return (
        _history_ts_ms(node.get("positionTimestamp"))
        or _history_ts_ms(node.get("updatedAt"))
        or _history_ts_ms(node.get("lastHeard"))
        or int(fallback_ms or time.time() * 1000)
    )


def _history_node_id(node_num: int):
    return f"!{int(node_num) & 0xffffffff:08x}"


def _history_merge_node_json(old: dict, new: dict, seen_ms: int, old_position_ms=0):
    merged = dict(old or {})
    new = dict(new or {})
    # Preserve nomes realmente observados em NodeInfo (inclusive os de fábrica
    # anteriores a renomeações), sem inventar aliases. NodeNum é a chave estável.
    alias_fields = ("name", "longName", "shortName", "customName",
                    "originalName", "factoryName", "defaultName")
    aliases = []
    for value in merged.get("nameAliases") or []:
        if isinstance(value, str) and value.strip() and value.strip() not in aliases:
            aliases.append(value.strip()[:80])
    for record in (old or {}, new):
        for name_key in alias_fields:
            value = record.get(name_key)
            if isinstance(value, str):
                candidate = value.strip()[:80]
                if candidate and candidate not in aliases and not candidate.startswith("!"):
                    aliases.append(candidate)
    if aliases:
        merged["nameAliases"] = aliases[-32:]
    state_rank = {"route-only": 0, "stub": 1, "identified": 2}
    old_state = str(merged.get("state") or "route-only")
    new_state = str(new.get("state") or "route-only")
    for key, value in new.items():
        if key in {"latitude", "longitude", "altitude", "positionSource"}:
            continue
        if value is None or value == "":
            continue
        if key == "state":
            if state_rank.get(new_state, 0) >= state_rank.get(old_state, 0):
                merged[key] = new_state
            continue
        if key in {"publicKey", "routeParticipant", "hasPKC", "isStoreForwardServer"}:
            merged[key] = bool(merged.get(key)) or bool(value)
            continue
        if key == "lastHeard":
            previous = _history_ts_ms(merged.get(key))
            current = _history_ts_ms(value)
            merged[key] = max(previous, current) if max(previous, current) else value
            continue
        merged[key] = value
    pos_ms = int(old_position_ms or 0)
    if _history_valid_position(new.get("latitude"), new.get("longitude")):
        candidate_pos_ms = _history_node_position_ms(new, seen_ms)
        if candidate_pos_ms >= pos_ms:
            merged["latitude"] = float(new.get("latitude"))
            merged["longitude"] = float(new.get("longitude"))
            merged["altitude"] = new.get("altitude")
            merged["positionSource"] = new.get("positionSource") or "observed"
            pos_ms = candidate_pos_ms
    return merged, pos_ms


def _topology_store_node(conn, source_id: str, node: dict, seen_ms: int):
    try:
        node_num = int(node.get("nodeNum")) & 0xffffffff
    except Exception:
        return
    if node_num in {0, 1, 2, 3, 255, 65535, 0xffffffff}:
        return
    row = conn.execute(
        "SELECT first_seen_ms,last_seen_ms,position_seen_ms,node_json FROM topology_nodes WHERE source_id=? AND node_num=?",
        (source_id, node_num),
    ).fetchone()
    old = {}
    first_seen = int(seen_ms)
    last_seen = int(seen_ms)
    old_position_ms = 0
    if row:
        try:
            old = json.loads(row["node_json"] or "{}")
        except Exception:
            old = {}
        first_seen = min(int(row["first_seen_ms"] or seen_ms), int(seen_ms))
        last_seen = max(int(row["last_seen_ms"] or 0), int(seen_ms))
        old_position_ms = int(row["position_seen_ms"] or 0)
    merged, position_ms = _history_merge_node_json(old, node, seen_ms, old_position_ms)
    merged["nodeNum"] = node_num
    merged["nodeId"] = merged.get("nodeId") or _history_node_id(node_num)
    merged["name"] = merged.get("name") or merged.get("longName") or merged.get("shortName") or merged["nodeId"]
    merged["firstSeenMs"] = first_seen
    merged["lastSeenMs"] = last_seen
    conn.execute(
        """INSERT INTO topology_nodes(source_id,node_num,first_seen_ms,last_seen_ms,position_seen_ms,node_json)
           VALUES(?,?,?,?,?,?)
           ON CONFLICT(source_id,node_num) DO UPDATE SET
             first_seen_ms=excluded.first_seen_ms,
             last_seen_ms=excluded.last_seen_ms,
             position_seen_ms=excluded.position_seen_ms,
             node_json=excluded.node_json""",
        (source_id, node_num, first_seen, last_seen, position_ms or None, json.dumps(merged, ensure_ascii=False, separators=(",", ":"))),
    )


def _topology_event_key(source_id, edge_id, timestamp_ms, leg, trace_id, snr, transport, occurrence=0):
    raw = "|".join([
        str(source_id), str(edge_id), str(int(timestamp_ms or 0)), str(leg or ""),
        str(trace_id or ""), "" if snr is None else f"{float(snr):.6f}",
        str(transport or ""), str(int(occurrence or 0)),
    ])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _topology_node_evidence(topology: dict):
    """Momento da observação mais recente de cada nó no snapshot (lastHeard, enlaces e traceroutes)."""
    seen = {}

    def note(num, ts):
        try:
            num = int(num) & 0xffffffff
        except Exception:
            return
        if ts:
            seen[num] = max(seen.get(num, 0), int(ts))

    for node in topology.get("nodes", []) or []:
        if isinstance(node, dict):
            note(node.get("nodeNum"), _history_ts_ms(node.get("lastHeard")))
    for edge in topology.get("edges", []) or []:
        if not isinstance(edge, dict):
            continue
        ts = _history_ts_ms(edge.get("lastSeenMs"))
        for ev in edge.get("events", []) or []:
            if isinstance(ev, dict):
                ts = max(ts, _history_ts_ms(ev.get("timestampMs")))
        note(edge.get("a"), ts); note(edge.get("b"), ts)
    for tr in topology.get("traces", []) or []:
        if not isinstance(tr, dict):
            continue
        ts = _history_ts_ms(tr.get("timestampMs") or tr.get("timestamp") or tr.get("createdAt"))
        note(tr.get("fromNodeNum"), ts); note(tr.get("toNodeNum"), ts)
        for key in ("forwardPath", "returnPath"):
            for point in tr.get(key, []) or []:
                if isinstance(point, dict):
                    note(point.get("nodeNum"), ts)
    return seen


def _apply_node_tombstones(topology: dict):
    """Remove do snapshot os nós excluídos pelo administrador.

    O MeshMonitor continua listando o nó após a exclusão local; sem este filtro,
    a próxima leitura do topology.json o reinseria. O nó só volta com evidência
    real posterior à exclusão, e então o registro de exclusão é descartado.
    """
    if not isinstance(topology, dict):
        return topology
    source_id = str(topology.get("sourceId") or MM_SOURCE)
    with _archive_connect() as conn:
        rows = conn.execute("SELECT node_num,deleted_at_ms FROM deleted_nodes WHERE source_id=?", (source_id,)).fetchall()
        if not rows:
            return topology
        evidence = _topology_node_evidence(topology)
        hidden = set()
        for row in rows:
            num = int(row["node_num"])
            if evidence.get(num, 0) > int(row["deleted_at_ms"]):
                conn.execute("DELETE FROM deleted_nodes WHERE source_id=? AND node_num=?", (source_id, num))
                print(f"Nó !{num:08x} reapareceu com evidência posterior à exclusão.", flush=True)
            else:
                hidden.add(num)
        conn.commit()
    if not hidden:
        return topology

    def num_of(value):
        try:
            return int(value) & 0xffffffff
        except Exception:
            return None

    def trace_nodes(tr):
        nums = {num_of(tr.get("fromNodeNum")), num_of(tr.get("toNodeNum"))}
        for key in ("forwardPath", "returnPath"):
            nums.update(num_of(p.get("nodeNum")) for p in tr.get(key, []) or [] if isinstance(p, dict))
        return nums

    filtered = dict(topology)
    filtered["nodes"] = [n for n in topology.get("nodes", []) or []
                         if not (isinstance(n, dict) and num_of(n.get("nodeNum")) in hidden)]
    filtered["edges"] = [e for e in topology.get("edges", []) or []
                         if not (isinstance(e, dict) and {num_of(e.get("a")), num_of(e.get("b"))} & hidden)]
    filtered["traces"] = [t for t in topology.get("traces", []) or []
                          if not (isinstance(t, dict) and trace_nodes(t) & hidden)]
    return filtered


def _topology_history_ingest(topology: dict):
    if not isinstance(topology, dict):
        return {"nodes": 0, "events": 0}
    topology = _apply_node_tombstones(topology)
    source_id = str(topology.get("sourceId") or MM_SOURCE)
    generated_ms = _history_ts_ms(topology.get("generatedAtMs"), int(time.time() * 1000))
    node_count = 0
    event_count = 0
    # Nós que existem apenas por participação em rota não devem parecer
    # "vistos agora" a cada regeneração. Usa a observação real mais recente
    # dos enlaces/traceroutes como fallback do lastSeen histórico.
    route_seen = {}
    for edge in topology.get("edges", []) or []:
        if not isinstance(edge, dict):
            continue
        ts = _history_ts_ms(edge.get("lastSeenMs"))
        if not ts:
            for ev in edge.get("events", []) or []:
                if isinstance(ev, dict):
                    ts = max(ts, _history_ts_ms(ev.get("timestampMs")))
        for key in ("a", "b"):
            try:
                num = int(edge.get(key)) & 0xffffffff
            except Exception:
                continue
            if ts:
                route_seen[num] = max(int(route_seen.get(num) or 0), ts)
    for tr in topology.get("traces", []) or []:
        if not isinstance(tr, dict):
            continue
        ts = _history_ts_ms(tr.get("timestampMs") or tr.get("timestamp") or tr.get("createdAt"))
        for key in ("fromNodeNum", "toNodeNum"):
            try:
                num = int(tr.get(key)) & 0xffffffff
            except Exception:
                continue
            if ts:
                route_seen[num] = max(int(route_seen.get(num) or 0), ts)
        for path_key in ("forwardPath", "returnPath"):
            for point in tr.get(path_key, []) or []:
                if not isinstance(point, dict):
                    continue
                try:
                    num = int(point.get("nodeNum")) & 0xffffffff
                except Exception:
                    continue
                if ts:
                    route_seen[num] = max(int(route_seen.get(num) or 0), ts)
    with _archive_connect() as conn:
        for node in topology.get("nodes", []) or []:
            if not isinstance(node, dict):
                continue
            try:
                node_num = int(node.get("nodeNum")) & 0xffffffff
            except Exception:
                continue
            explicit_seen = max(
                _history_ts_ms(node.get("lastHeard")),
                _history_ts_ms(node.get("updatedAt")),
                _history_ts_ms(node.get("positionTimestamp")),
                _history_ts_ms(node.get("nodeStatusUpdatedAt")),
            )
            seen_ms = explicit_seen or int(route_seen.get(node_num) or 0) or generated_ms
            _topology_store_node(conn, source_id, node, seen_ms)
            node_count += 1
        for edge in topology.get("edges", []) or []:
            if not isinstance(edge, dict):
                continue
            try:
                a = int(edge.get("a")) & 0xffffffff
                b = int(edge.get("b")) & 0xffffffff
            except Exception:
                continue
            lo, hi = sorted((a, b))
            edge_id = f"{lo}:{hi}"
            events = edge.get("events") if isinstance(edge.get("events"), list) else []
            if not events:
                events = [{
                    "timestampMs": edge.get("lastSeenMs") or generated_ms,
                    "leg": edge.get("latestLeg"),
                    "snr": edge.get("avgSnr"),
                    "traceId": edge.get("latestTraceId"),
                    "transport": edge.get("transportClass") or "mqtt",
                    "_count": max(1, int(edge.get("observations") or 1)),
                }]
            occurrences = {}
            for ev in events:
                if not isinstance(ev, dict):
                    continue
                ts = _history_ts_ms(ev.get("timestampMs"), generated_ms)
                leg = str(ev.get("leg") or "")
                snr = ev.get("snr")
                try:
                    snr = float(snr) if snr is not None else None
                except (TypeError, ValueError):
                    snr = None
                transport = "rf" if str(ev.get("transport") or "").lower() == "rf" and snr is not None else "mqtt"
                trace_id = ev.get("traceId")
                raw_direct_kind = str(ev.get("directEvidenceKind") or "").strip() or None
                direct_evidence = 1 if (
                    ev.get("directEvidence") is True
                    and raw_direct_kind == "route-adjacency-api"
                ) else 0
                direct_evidence_kind = "route-adjacency-api" if direct_evidence else None
                sig = (ts, leg, trace_id, snr, transport)
                occurrence = occurrences.get(sig, 0)
                occurrences[sig] = occurrence + 1
                event_key = _topology_event_key(source_id, edge_id, ts, leg, trace_id, snr, transport, occurrence)
                before = conn.total_changes
                conn.execute(
                    """INSERT INTO topology_edge_events(
                         event_key,source_id,edge_id,a,b,timestamp_ms,leg,snr,transport,trace_id,packet_id,channel,
                         observation_count,direct_evidence,direct_evidence_kind,archived_at
                       ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(event_key) DO UPDATE SET
                         direct_evidence=MAX(topology_edge_events.direct_evidence,excluded.direct_evidence),
                         direct_evidence_kind=CASE
                           WHEN topology_edge_events.direct_evidence=1 AND topology_edge_events.direct_evidence_kind IS NOT NULL
                             THEN topology_edge_events.direct_evidence_kind
                           ELSE COALESCE(excluded.direct_evidence_kind,topology_edge_events.direct_evidence_kind)
                         END""",
                    (
                        event_key, source_id, edge_id, lo, hi, ts, leg, snr, transport,
                        None if trace_id is None else str(trace_id),
                        None if edge.get("latestPacketId") is None else str(edge.get("latestPacketId")),
                        edge.get("latestChannel"),
                        max(1, int(ev.get("_count") or ev.get("count") or 1)),
                        direct_evidence, direct_evidence_kind,
                        int(time.time() * 1000),
                    ),
                )
                event_count += conn.total_changes - before
    return {"nodes": node_count, "events": event_count}


def _topology_history_ingest_current():
    try:
        raw = json.loads(TOPOLOGY_FILE.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            return _topology_history_ingest(raw)
    except Exception:
        pass
    return {"nodes": 0, "events": 0}


def _topology_history_drain_queue(limit=200):
    processed = 0
    inserted_events = 0
    try:
        TOPOLOGY_HISTORY_QUEUE_DIR.mkdir(parents=True, exist_ok=True)
        paths = sorted(TOPOLOGY_HISTORY_QUEUE_DIR.glob("topology-*.json"))[:max(1, int(limit))]
    except Exception:
        return {"processed": 0, "events": 0}
    for path in paths:
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            result = _topology_history_ingest(raw if isinstance(raw, dict) else {})
            inserted_events += int(result.get("events") or 0)
            path.unlink(missing_ok=True)
            processed += 1
        except Exception:
            # Mantém o arquivo para uma tentativa futura; não perde observações.
            continue
    return {"processed": processed, "events": inserted_events}


def _history_array(value):
    if isinstance(value, list):
        return value
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, list) else []
        except Exception:
            return []
    return []


def _history_trace_payload(metadata):
    if not isinstance(metadata, dict):
        return None
    if any(k in metadata for k in ("route", "routeBack", "snrTowards", "snrBack", "routePositions")):
        return metadata
    for value in metadata.values():
        if isinstance(value, dict):
            found = _history_trace_payload(value)
            if found:
                return found
    return None


def _history_trace_links(start_num, mids_raw, end_num, snr_raw, leg):
    mids = []
    for value in _history_array(mids_raw):
        try:
            mids.append(int(value) & 0xffffffff)
        except Exception:
            mids.append(0xffffffff)
    snrs = _history_array(snr_raw)
    entries = [(start_num, None)]
    for idx, n in enumerate(mids):
        entries.append((n, snrs[idx] if idx < len(snrs) else None))
    entries.append((end_num, snrs[len(mids)] if len(mids) < len(snrs) else None))
    out = []
    invalid = {0, 1, 2, 3, 255, 65535, 0xffffffff}
    for idx in range(len(entries) - 1):
        a = entries[idx][0]; b, raw_snr = entries[idx + 1]
        if a in invalid or b in invalid:
            continue
        snr = None
        if raw_snr is not None:
            try:
                snr = float(raw_snr) / 4.0
                if abs(snr + 32.0) < 1e-9:
                    snr = None
            except Exception:
                snr = None
        # Pacote bruto arquivado é útil para diagnóstico/histórico, mas sua
        # orientação/estado de conclusão pode ser ambígua. Nunca o usamos para
        # promover um enlace ao Ranking.
        out.append((a, b, leg, snr, idx, False, None))
    return out


def _topology_history_recover_from_archive():
    """Best-effort one-time recovery of old links from archived traceroute packet metadata."""
    meta_key = f"topology-recovery-v1:{MM_SOURCE}"
    with _archive_connect() as conn:
        done = conn.execute("SELECT meta_value FROM topology_history_meta WHERE meta_key=?", (meta_key,)).fetchone()
        if done:
            return {"recovered": 0, "skipped": True}
        oldest = conn.execute(
            "SELECT MIN(timestamp_ms) AS ts FROM topology_edge_events WHERE source_id=?", (MM_SOURCE,)
        ).fetchone()
        oldest_ts = int(oldest["ts"]) if oldest and oldest["ts"] is not None else None
        params = [MM_SOURCE]
        sql = """SELECT packet_id,timestamp,from_node,from_node_id,from_node_long_name,
                        to_node,to_node_id,to_node_long_name,channel,metadata
                 FROM packets
                 WHERE source_id=? AND portnum_name='TRACEROUTE_APP' AND metadata IS NOT NULL"""
        if oldest_ts is not None:
            sql += " AND timestamp < ?"
            params.append(oldest_ts)
        sql += " ORDER BY timestamp ASC"
        rows = conn.execute(sql, params).fetchall()
        recovered = 0
        for row in rows:
            try:
                metadata = json.loads(row["metadata"]) if isinstance(row["metadata"], str) else row["metadata"]
            except Exception:
                continue
            trace = _history_trace_payload(metadata)
            if not trace:
                continue
            try:
                from_num = int(trace.get("fromNodeNum") or row["from_node"]) & 0xffffffff
                to_num = int(trace.get("toNodeNum") or row["to_node"]) & 0xffffffff
            except Exception:
                continue
            ts = _history_ts_ms(trace.get("timestamp") or trace.get("createdAt") or row["timestamp"])
            for num, nid, name in (
                (from_num, row["from_node_id"], row["from_node_long_name"]),
                (to_num, row["to_node_id"], row["to_node_long_name"]),
            ):
                _topology_store_node(conn, MM_SOURCE, {
                    "nodeNum": num,
                    "nodeId": nid or _history_node_id(num),
                    "name": name or nid or _history_node_id(num),
                    "longName": name,
                    "state": "stub" if name else "route-only",
                    "routeParticipant": True,
                }, ts)
            positions = trace.get("routePositions")
            if isinstance(positions, str):
                try:
                    positions = json.loads(positions)
                except Exception:
                    positions = {}
            if isinstance(positions, dict):
                for key, pos in positions.items():
                    if not isinstance(pos, dict):
                        continue
                    try:
                        n = int(key) & 0xffffffff
                    except Exception:
                        continue
                    lat = pos.get("lat"); lon = pos.get("lng", pos.get("lon"))
                    if _history_valid_position(lat, lon):
                        _topology_store_node(conn, MM_SOURCE, {
                            "nodeNum": n, "nodeId": _history_node_id(n), "name": _history_node_id(n),
                            "state": "route-only", "routeParticipant": True,
                            "latitude": float(lat), "longitude": float(lon), "altitude": pos.get("alt"),
                            "positionSource": "archive-traceroute",
                        }, ts)
            legs = []
            if trace.get("route") not in (None, ""):
                legs += _history_trace_links(
                    from_num, trace.get("route"), to_num, trace.get("snrTowards"), "forward",
                )
            if trace.get("routeBack") not in (None, "") or trace.get("snrBack") not in (None, "", "[]", []):
                legs += _history_trace_links(
                    to_num, trace.get("routeBack"), from_num, trace.get("snrBack"), "return",
                )
            occurrences = {}
            trace_id = trace.get("id") or row["packet_id"]
            for a0, b0, leg, snr, hop_idx, direct_evidence, direct_kind in legs:
                lo, hi = sorted((a0, b0)); edge_id = f"{lo}:{hi}"
                transport = "rf" if snr is not None else "mqtt"
                sig = (edge_id, ts, leg, trace_id, snr, transport)
                occurrence = occurrences.get(sig, 0); occurrences[sig] = occurrence + 1
                key = _topology_event_key(MM_SOURCE, edge_id, ts, leg, trace_id, snr, transport, occurrence)
                before = conn.total_changes
                conn.execute(
                    """INSERT INTO topology_edge_events(
                         event_key,source_id,edge_id,a,b,timestamp_ms,leg,snr,transport,trace_id,packet_id,channel,
                         observation_count,direct_evidence,direct_evidence_kind,archived_at
                       ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?,?,?)
                       ON CONFLICT(event_key) DO UPDATE SET
                         direct_evidence=MAX(topology_edge_events.direct_evidence,excluded.direct_evidence),
                         direct_evidence_kind=COALESCE(topology_edge_events.direct_evidence_kind,excluded.direct_evidence_kind)""",
                    (key, MM_SOURCE, edge_id, lo, hi, ts, leg, snr, transport,
                     None if trace_id is None else str(trace_id),
                     None if row["packet_id"] is None else str(row["packet_id"]),
                     row["channel"], 1 if direct_evidence else 0, direct_kind, int(time.time() * 1000)),
                )
                recovered += conn.total_changes - before
        conn.execute(
            "INSERT OR REPLACE INTO topology_history_meta(meta_key,meta_value) VALUES(?,?)",
            (meta_key, json.dumps({"completedAtMs": int(time.time() * 1000), "recovered": recovered}, separators=(",", ":"))),
        )
        return {"recovered": recovered, "skipped": False}


def _topology_direct_evidence_rebuild_v2():
    """Invalida evidência pré-v1.53 e deixa a API /traceroutes reconstruí-la.

    A v1.52 podia promover pacotes brutos (inclusive TX) por TTL. Como não é
    possível provar retroativamente a orientação/conclusão de todos esses
    pacotes, a correção é deliberadamente conservadora: preserva eventos,
    nós, SNR e topologia, mas zera somente a classificação usada no Ranking.
    O coletor v1.53 repõe direct_evidence apenas a partir do endpoint
    /traceroutes, que o MeshMonitor já entrega requester-first.
    """
    meta_key = f"topology-direct-evidence-v2:{MM_SOURCE}"
    with _archive_connect() as conn:
        done = conn.execute(
            "SELECT meta_value FROM topology_history_meta WHERE meta_key=?",
            (meta_key,),
        ).fetchone()
        if done:
            return {"invalidated": 0, "skipped": True}
        row = conn.execute(
            "SELECT COALESCE(SUM(observation_count),0) AS n FROM topology_edge_events "
            "WHERE source_id=? AND direct_evidence=1",
            (MM_SOURCE,),
        ).fetchone()
        invalidated = int(row["n"] or 0) if row else 0
        conn.execute(
            """UPDATE topology_edge_events
               SET direct_evidence=0,direct_evidence_kind=NULL
               WHERE source_id=? AND direct_evidence=1""",
            (MM_SOURCE,),
        )
        conn.execute(
            "INSERT OR REPLACE INTO topology_history_meta(meta_key,meta_value) VALUES(?,?)",
            (meta_key, json.dumps({
                "completedAtMs": int(time.time() * 1000),
                "invalidated": invalidated,
                "policy": "trusted-traceroutes-api-only",
            }, separators=(",", ":"))),
        )
        return {"invalidated": invalidated, "skipped": False}



def _trusted_history_trace_links(start_num, mids_raw, end_num, snr_raw, leg):
    """Adjacências confiáveis de uma linha orientada da API de análise.

    O MeshMonitor define route/routeBack como arrays de intermediários e a
    API /api/analysis/traceroutes entrega cada linha requester-first.
    route=[] é uma resposta válida sem intermediários; route=NULL é pending.
    """
    mids = []
    invalid = {0, 1, 2, 3, 255, 65535, 0xffffffff}
    for value in _history_array(mids_raw):
        try:
            n = int(value) & 0xffffffff
        except Exception:
            n = 0xffffffff
        mids.append(n)
    snrs = _history_array(snr_raw)
    entries = [(int(start_num) & 0xffffffff, None)]
    for pos, n in enumerate(mids):
        entries.append((n, snrs[pos] if pos < len(snrs) else None))
    entries.append((int(end_num) & 0xffffffff, snrs[len(mids)] if len(mids) < len(snrs) else None))
    out = []
    for pos in range(len(entries) - 1):
        a = entries[pos][0]
        b, raw_snr = entries[pos + 1]
        if a in invalid or b in invalid:
            continue
        snr = None
        if raw_snr is not None:
            try:
                snr = float(raw_snr) / 4.0
                if abs(snr + 32.0) < 1e-9:
                    snr = None
            except Exception:
                snr = None
        out.append((a, b, leg, snr, pos))
    return out


def _store_trusted_analysis_traceroute(conn, row):
    """Persiste uma linha histórica orientada sem depender de nós online.

    A API v1 normaliza o alias "default" para o UUID concreto e pode devolver
    esse UUID em row.sourceId. O Traffic Analyzer, porém, indexa o histórico
    pelo MM_SOURCE configurado (frequentemente "default"). Como a chamada HTTP
    já foi source-scoped e autenticada, armazenamos sob a chave lógica local
    em vez de descartar uma linha só porque ela carrega o UUID concreto.
    """
    if not isinstance(row, dict):
        return 0
    try:
        from_num = int(row.get("fromNodeNum")) & 0xffffffff
        to_num = int(row.get("toNodeNum")) & 0xffffffff
    except Exception:
        return 0
    invalid = {0, 1, 2, 3, 255, 65535, 0xffffffff}
    if from_num in invalid or to_num in invalid:
        return 0

    source_id = MM_SOURCE
    ts = _history_ts_ms(row.get("timestamp") or row.get("createdAt"))
    if not ts:
        return 0
    trace_id = row.get("id")
    packet_id = row.get("packetId")

    # Mantém participantes históricos mesmo que já estejam offline. O merge de
    # node_json preserva a última posição válida previamente conhecida.
    for num in (from_num, to_num):
        _topology_store_node(conn, source_id, {
            "nodeNum": num,
            "nodeId": _history_node_id(num),
            "name": _history_node_id(num),
            "state": "route-only",
            "routeParticipant": True,
        }, ts)

    legs = []
    route = row.get("route")
    if route not in (None, "", "null"):
        legs += _trusted_history_trace_links(from_num, route, to_num, row.get("snrTowards"), "forward")

    route_back = row.get("routeBack")
    snr_back = row.get("snrBack")
    has_return = bool(_history_array(route_back))
    if not has_return and snr_back not in (None, "", "null", "[]", []):
        has_return = bool(_history_array(snr_back))
    if has_return:
        legs += _trusted_history_trace_links(to_num, route_back, from_num, snr_back, "return")

    inserted = 0
    occurrences = {}
    for a0, b0, leg, snr, hop_idx in legs:
        lo, hi = sorted((a0, b0))
        edge_id = f"{lo}:{hi}"
        transport = "rf" if snr is not None else "mqtt"
        sig = (edge_id, ts, leg, trace_id, snr, transport)
        occurrence = occurrences.get(sig, 0)
        occurrences[sig] = occurrence + 1
        event_key = _topology_event_key(source_id, edge_id, ts, leg, trace_id, snr, transport, occurrence)
        before = conn.total_changes
        conn.execute(
            """INSERT INTO topology_edge_events(
                 event_key,source_id,edge_id,a,b,timestamp_ms,leg,snr,transport,trace_id,packet_id,channel,
                 observation_count,direct_evidence,direct_evidence_kind,archived_at
               ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,1,'route-adjacency-api',?)
               ON CONFLICT(event_key) DO UPDATE SET
                 direct_evidence=1,
                 direct_evidence_kind='route-adjacency-api'""",
            (
                event_key, source_id, edge_id, lo, hi, ts, leg, snr, transport,
                None if trace_id is None else str(trace_id),
                None if packet_id is None else str(packet_id),
                None,
                int(time.time() * 1000),
            ),
        )
        inserted += conn.total_changes - before
    return inserted


def _topology_direct_history_backfill_v4(force=False):
    """Recupera histórico confiável pela API v1 autenticada por Bearer token.

    A v1.54 usava /api/analysis/traceroutes, cuja optionalAuth não resolve o
    MM_API_TOKEN Bearer. Uma resposta anônima vazia podia ser marcada como
    backfill completo. A v1.55 usa exclusivamente a API v1, que exige e valida
    o token, e aumenta progressivamente o limit até alcançar o início do
    histórico ou o teto de segurança configurado.

    O endpoint v1 retorna os N traceroutes mais recentes. Por isso somente a
    resposta mais ampla bem-sucedida precisa ser processada; event_key mantém
    a operação idempotente.
    """
    meta_key = f"topology-direct-history-v4:{MM_SOURCE}"
    with _archive_connect() as conn:
        previous = conn.execute(
            "SELECT meta_value FROM topology_history_meta WHERE meta_key=?",
            (meta_key,),
        ).fetchone()
        if previous and not force:
            try:
                status = json.loads(previous["meta_value"] or "{}")
            except Exception:
                status = {}
            if status.get("complete") is True:
                return {**status, "skipped": True}

    source = urllib.parse.quote(MM_SOURCE, safe="")
    max_limit = TRACEROUTE_HISTORY_MAX_LIMIT
    if TRACEROUTE_HISTORY_MAX_RECORDS > 0:
        max_limit = min(max_limit, TRACEROUTE_HISTORY_MAX_RECORDS)
    max_limit = max(TRACEROUTE_HISTORY_INITIAL_LIMIT, max_limit)

    limit = min(TRACEROUTE_HISTORY_INITIAL_LIMIT, max_limit)
    attempts = []
    final_rows = None
    final_limit = 0
    complete = False
    truncated = False
    last_error = None

    while True:
        try:
            body = _mm_api_get(f"/api/v1/sources/{source}/traceroutes?limit={limit}")
            if not isinstance(body, dict):
                raise RuntimeError("Resposta inesperada da API v1 de traceroutes")
            if body.get("success") is False:
                raise RuntimeError(str(body.get("message") or body.get("error") or "Falha na API v1 de traceroutes"))
            rows = body.get("data")
            if not isinstance(rows, list):
                raise RuntimeError("API v1 de traceroutes não retornou lista em data")
        except Exception as exc:
            last_error = str(exc)
            attempts.append({"limit": limit, "ok": False, "error": last_error})
            break

        final_rows = rows
        final_limit = limit
        count = len(rows)
        attempts.append({"limit": limit, "ok": True, "count": count})

        # Menos registros que o solicitado prova que chegamos ao início.
        if count < limit:
            complete = True
            break

        # Resposta cheia: ainda pode haver histórico mais antigo.
        if limit >= max_limit:
            truncated = True
            break

        next_limit = min(max_limit, limit * 2)
        if next_limit <= limit:
            truncated = True
            break
        limit = next_limit

    inserted = 0
    processed = 0
    if final_rows is not None:
        processed = len(final_rows)
        with _archive_connect() as conn:
            for row in final_rows:
                inserted += _store_trusted_analysis_traceroute(conn, row)

    result = {
        "completedAtMs": int(time.time() * 1000),
        "processed": processed,
        "inserted": inserted,
        "complete": bool(complete),
        "truncated": bool(truncated),
        "method": "v1-authenticated-progressive-limit",
        "initialLimit": TRACEROUTE_HISTORY_INITIAL_LIMIT,
        "finalLimit": final_limit,
        "maxLimit": max_limit,
        "attempts": attempts[-16:],
        "error": last_error,
        "skipped": False,
    }
    with _archive_connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO topology_history_meta(meta_key,meta_value) VALUES(?,?)",
            (meta_key, json.dumps(result, ensure_ascii=False, separators=(",", ":"))),
        )
    return result


_history_source_cache = None


def _resolve_concrete_history_source_id():
    """Resolve MM_SOURCE para um UUID concreto quando ele é o alias default.

    A rota legada /api/traceroutes/history recebe sourceId via query e NÃO
    passa pelo attachSource da API v1; portanto "default" não é normalizado
    ali. Descobrimos, em ordem de criação, a primeira fonte visível na qual o
    token realmente consegue ler traceroutes — a mesma semântica prática do
    alias default para esse recurso.
    """
    global _history_source_cache
    if _history_source_cache:
        return _history_source_cache
    if MM_SOURCE != "default":
        _history_source_cache = MM_SOURCE
        return _history_source_cache

    body = _mm_api_get("/api/v1/sources")
    rows = body.get("data", []) if isinstance(body, dict) else []
    if not isinstance(rows, list):
        rows = []
    for item in rows:
        source_id = str((item or {}).get("id") or "").strip()
        if not source_id:
            continue
        try:
            source = urllib.parse.quote(source_id, safe="")
            # A leitura abaixo testa especificamente traceroute:read. Uma lista
            # vazia ainda é sucesso e identifica corretamente a fonte.
            _mm_api_get(f"/api/v1/sources/{source}/traceroutes?limit=1")
            _history_source_cache = source_id
            return _history_source_cache
        except Exception:
            continue
    raise RuntimeError("Não foi possível resolver o alias MM_SOURCE=default para uma fonte com traceroute:read")


def _topology_direct_pair_reconcile_v6(force=False):
    """Revalida pares RF históricos individualmente pela API autenticada.

    O backfill global pode não reencontrar um traceroute antigo (retenção,
    volume ou janela da fonte). O mapa, porém, preserva o par RF no traffic.db.
    Para cada par RF sem evidência direta confiável, consultamos o histórico
    específico do par, que o MeshMonitor resolve por colunas indexadas e aceita
    Bearer token via requirePermission. Só pares consecutivos de uma rota
    orientada são promovidos por _store_trusted_analysis_traceroute().
    """
    meta_key = f"topology-direct-pair-reconcile-v6:{MM_SOURCE}"
    with _archive_connect() as conn:
        previous = conn.execute(
            "SELECT meta_value FROM topology_history_meta WHERE meta_key=?",
            (meta_key,),
        ).fetchone()
        if previous and not force:
            try:
                status = json.loads(previous["meta_value"] or "{}")
            except Exception:
                status = {}
            if status.get("complete") is True:
                return {**status, "skipped": True}

        rows = conn.execute(
            """SELECT edge_id,a,b,
                      SUM(CASE WHEN transport='rf' AND snr IS NOT NULL THEN observation_count ELSE 0 END) AS rf_obs,
                      SUM(CASE WHEN direct_evidence=1 AND direct_evidence_kind='route-adjacency-api'
                               THEN observation_count ELSE 0 END) AS direct_obs,
                      MAX(timestamp_ms) AS last_seen
               FROM topology_edge_events
               WHERE source_id=?
               GROUP BY edge_id,a,b
               HAVING rf_obs>0 AND direct_obs=0
               ORDER BY last_seen DESC""",
            (MM_SOURCE,),
        ).fetchall()

    candidates = [dict(row) for row in rows]
    truncated = False
    if TRACEROUTE_PAIR_RECONCILE_MAX_PAIRS > 0 and len(candidates) > TRACEROUTE_PAIR_RECONCILE_MAX_PAIRS:
        candidates = candidates[:TRACEROUTE_PAIR_RECONCILE_MAX_PAIRS]
        truncated = True

    concrete_source_id = _resolve_concrete_history_source_id()
    checked = 0
    recovered_pairs = 0
    inserted = 0
    errors = []
    unresolved = []

    for row in candidates:
        a = int(row["a"]); b = int(row["b"])
        path = (
            f"/api/traceroutes/history/{a}/{b}?"
            + urllib.parse.urlencode({"sourceId": concrete_source_id, "limit": TRACEROUTE_PAIR_HISTORY_LIMIT})
        )
        try:
            body = _mm_api_get(path)
            if not isinstance(body, list):
                raise RuntimeError("Histórico por par não retornou uma lista")
            checked += 1
            with _archive_connect() as conn:
                before = conn.total_changes
                for trace in body:
                    inserted += _store_trusted_analysis_traceroute(conn, trace)
                direct = conn.execute(
                    """SELECT COALESCE(SUM(observation_count),0) AS n
                       FROM topology_edge_events
                       WHERE source_id=? AND edge_id=? AND transport='rf' AND snr IS NOT NULL
                         AND direct_evidence=1 AND direct_evidence_kind='route-adjacency-api'""",
                    (MM_SOURCE, str(row["edge_id"])),
                ).fetchone()
                _ = conn.total_changes - before
            negative_meta_key = f"topology-rf-multihop-v1:{MM_SOURCE}:{row['edge_id']}"
            if direct and int(direct["n"] or 0) > 0:
                recovered_pairs += 1
                # Evidência positiva mais forte invalida uma eventual marca
                # negativa antiga para o mesmo par.
                with _archive_connect() as conn:
                    conn.execute("DELETE FROM topology_history_meta WHERE meta_key=?", (negative_meta_key,))
            else:
                # Só marcamos o par como comprovadamente NÃO direto quando a
                # consulta devolveu traceroutes do próprio par e nenhum deles
                # mostrou A↔B como adjacência. Resposta vazia significa apenas
                # ausência de histórico suficiente e não deve apagar um hop RF
                # confirmado no mapa.
                if body:
                    with _archive_connect() as conn:
                        conn.execute(
                            "INSERT OR REPLACE INTO topology_history_meta(meta_key,meta_value) VALUES(?,?)",
                            (negative_meta_key, json.dumps({
                                "checkedAtMs": int(time.time() * 1000),
                                "edgeId": str(row["edge_id"]),
                                "a": a, "b": b,
                                "traceroutesReturned": len(body),
                                "reason": "pair-history-shows-multihop-only",
                            }, separators=(",", ":"))),
                        )
                unresolved.append({
                    "edgeId": str(row["edge_id"]), "a": a, "b": b,
                    "rfObservations": int(row["rf_obs"] or 0),
                    "lastSeenMs": int(row["last_seen"] or 0),
                    "traceroutesReturned": len(body),
                    "negativeEvidence": bool(body),
                })
        except Exception as exc:
            errors.append({
                "edgeId": str(row["edge_id"]), "a": a, "b": b, "error": str(exc)
            })

    complete = not truncated and not errors
    result = {
        "completedAtMs": int(time.time() * 1000),
        "candidatePairs": len(rows),
        "checkedPairs": checked,
        "recoveredPairs": recovered_pairs,
        "inserted": inserted,
        "unresolvedPairs": len(unresolved),
        "unresolvedSample": unresolved[:50],
        "errors": errors[:50],
        "truncated": truncated,
        "complete": complete,
        "method": "pair-history-authenticated-v6",
        "historySourceId": concrete_source_id,
        "skipped": False,
    }
    with _archive_connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO topology_history_meta(meta_key,meta_value) VALUES(?,?)",
            (meta_key, json.dumps(result, ensure_ascii=False, separators=(",", ":"))),
        )
    return result


def _topology_history_merge(raw: dict):
    if not isinstance(raw, dict):
        return {}
    try:
        raw = _apply_node_tombstones(raw)
        _topology_history_ingest(raw)
        source_id = str(raw.get("sourceId") or MM_SOURCE)
        current_nums = set()
        for n in raw.get("nodes", []) or []:
            try:
                current_nums.add(int(n.get("nodeNum")) & 0xffffffff)
            except Exception:
                pass
        with _archive_connect() as conn:
            node_rows = conn.execute(
                "SELECT node_num,first_seen_ms,last_seen_ms,position_seen_ms,node_json FROM topology_nodes WHERE source_id=?",
                (source_id,),
            ).fetchall()
            nodes = []
            coord = {}
            for row in node_rows:
                try:
                    node = json.loads(row["node_json"] or "{}")
                except Exception:
                    node = {}
                num = int(row["node_num"])
                node["nodeNum"] = num
                node["nodeId"] = node.get("nodeId") or _history_node_id(num)
                node["name"] = node.get("name") or node.get("longName") or node.get("shortName") or node["nodeId"]
                node["firstSeenMs"] = int(row["first_seen_ms"] or 0)
                node["lastSeenMs"] = int(row["last_seen_ms"] or 0)
                node["historical"] = num not in current_nums
                node["currentlyInMeshMonitor"] = num in current_nums
                if node["historical"] and _history_valid_position(node.get("latitude"), node.get("longitude")):
                    node["positionSource"] = "history-last-known"
                if _history_valid_position(node.get("latitude"), node.get("longitude")):
                    coord[num] = (float(node["latitude"]), float(node["longitude"]))
                nodes.append(node)
            # Mantém compatibilidade com entradas correntes que deliberadamente
            # não entram na memória histórica (IDs reservados/diagnósticos).
            stored_nums = {int(n.get("nodeNum")) for n in nodes if n.get("nodeNum") is not None}
            for current in raw.get("nodes", []) or []:
                if not isinstance(current, dict):
                    continue
                try:
                    num = int(current.get("nodeNum")) & 0xffffffff
                except Exception:
                    continue
                if num in stored_nums:
                    continue
                node = dict(current)
                node["historical"] = False
                node["currentlyInMeshMonitor"] = True
                if _history_valid_position(node.get("latitude"), node.get("longitude")):
                    coord[num] = (float(node["latitude"]), float(node["longitude"]))
                nodes.append(node)
                stored_nums.add(num)

            group_rows = conn.execute(
                """SELECT edge_id,a,b,
                          SUM(observation_count) AS observations,
                          SUM(CASE WHEN leg='forward' THEN observation_count ELSE 0 END) AS forward_obs,
                          SUM(CASE WHEN leg='return' THEN observation_count ELSE 0 END) AS return_obs,
                          SUM(CASE WHEN transport='rf' THEN observation_count ELSE 0 END) AS rf_obs,
                          SUM(CASE WHEN direct_evidence=1 THEN observation_count ELSE 0 END) AS direct_obs,
                          SUM(CASE WHEN transport!='rf' THEN observation_count ELSE 0 END) AS nonrf_obs,
                          MIN(timestamp_ms) AS first_seen,
                          MAX(timestamp_ms) AS last_seen,
                          SUM(CASE WHEN snr IS NOT NULL THEN snr*observation_count ELSE 0 END) AS snr_sum,
                          SUM(CASE WHEN snr IS NOT NULL THEN observation_count ELSE 0 END) AS snr_count,
                          MIN(snr) AS min_snr, MAX(snr) AS max_snr
                   FROM topology_edge_events WHERE source_id=? GROUP BY edge_id,a,b""",
                (source_id,),
            ).fetchall()
            latest_rows = conn.execute(
                """SELECT e.* FROM topology_edge_events e
                   JOIN (
                     SELECT edge_id,MAX(timestamp_ms) AS max_ts
                     FROM topology_edge_events WHERE source_id=? GROUP BY edge_id
                   ) m ON e.edge_id=m.edge_id AND e.timestamp_ms=m.max_ts
                   WHERE e.source_id=? ORDER BY e.edge_id,e.event_key""",
                (source_id, source_id),
            ).fetchall()
            latest = {}
            for row in latest_rows:
                latest.setdefault(str(row["edge_id"]), row)
            recent_cutoff = int(time.time() * 1000) - 32 * 86400 * 1000
            recent_rows = conn.execute(
                """SELECT edge_id,timestamp_ms,leg,snr,transport,trace_id,observation_count,direct_evidence,direct_evidence_kind
                   FROM topology_edge_events
                   WHERE source_id=? AND timestamp_ms>=?
                   ORDER BY timestamp_ms ASC,event_key ASC""",
                (source_id, recent_cutoff),
            ).fetchall()
            recent = {}
            for row in recent_rows:
                recent.setdefault(str(row["edge_id"]), []).append({
                    "timestampMs": int(row["timestamp_ms"]),
                    "leg": row["leg"],
                    "snr": row["snr"],
                    "traceId": row["trace_id"],
                    "transport": row["transport"],
                    "directEvidence": bool(row["direct_evidence"]),
                    "directEvidenceKind": row["direct_evidence_kind"],
                    "count": int(row["observation_count"] or 1),
                })
            by_num = {int(n["nodeNum"]): n for n in nodes}
            edges = []
            for row in group_rows:
                a = int(row["a"]); b = int(row["b"]); edge_id = str(row["edge_id"])
                latest_row = latest.get(edge_id)
                obs = int(row["observations"] or 0)
                rf = int(row["rf_obs"] or 0)
                nonrf = int(row["nonrf_obs"] or 0)
                snr_count = int(row["snr_count"] or 0)
                geometry = [[*coord[a]], [*coord[b]]] if a in coord and b in coord else None
                edges.append({
                    "id": edge_id, "a": a, "b": b,
                    "aId": _history_node_id(a), "bId": _history_node_id(b),
                    "aName": (by_num.get(a) or {}).get("name") or _history_node_id(a),
                    "bName": (by_num.get(b) or {}).get("name") or _history_node_id(b),
                    "observations": obs,
                    "forwardObservations": int(row["forward_obs"] or 0),
                    "returnObservations": int(row["return_obs"] or 0),
                    "rfObservations": rf,
                    "directObservations": int(row["direct_obs"] or 0),
                    "mqttObservations": nonrf,
                    "nonRfObservations": nonrf,
                    "transportClass": "rf" if rf > 0 else "mqtt",
                    "firstSeenMs": int(row["first_seen"] or 0),
                    "lastSeenMs": int(row["last_seen"] or 0),
                    "avgSnr": round(float(row["snr_sum"] or 0) / snr_count, 2) if snr_count else None,
                    "minSnr": row["min_snr"], "maxSnr": row["max_snr"],
                    "latestTraceId": latest_row["trace_id"] if latest_row else None,
                    "latestPacketId": latest_row["packet_id"] if latest_row else None,
                    "latestChannel": latest_row["channel"] if latest_row else None,
                    "latestLeg": latest_row["leg"] if latest_row else None,
                    "geometry": geometry,
                    "events": recent.get(edge_id, []),
                    "historyPersistent": True,
                })
            edges.sort(key=lambda e: (int(e.get("lastSeenMs") or 0), int(e.get("observations") or 0)), reverse=True)
            nodes.sort(key=lambda n: (str(n.get("state") or "") != "identified", str(n.get("name") or "").lower()))

        merged = dict(raw)
        summary = dict(raw.get("summary") or {})
        summary["persistentNodes"] = len(nodes)
        summary["historicalNodes"] = sum(1 for n in nodes if n.get("historical"))
        summary["observedEdges"] = len(edges)
        summary["mappableEdges"] = sum(1 for e in edges if e.get("geometry"))
        summary["mappableNodes"] = sum(1 for n in nodes if _history_valid_position(n.get("latitude"), n.get("longitude")))
        merged["summary"] = summary
        merged["nodes"] = nodes
        merged["edges"] = edges
        merged["persistentHistory"] = True
        merged["historyRetention"] = "until-database-reset"
        merged["disclaimer"] = (
            "Nós e enlaces observados são preservados historicamente no traffic.db até o banco ser apagado/resetado. "
            "Os filtros temporais alteram somente a visualização. Linha contínua exige evidência RF válida; "
            "linha tracejada representa MQTT/não-RF."
        )
        return merged
    except Exception:
        return raw


def _access_init():
    ACCESS_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with _archive_connect() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS web_access (
          access_id INTEGER PRIMARY KEY AUTOINCREMENT,
          timestamp INTEGER NOT NULL,
          event TEXT NOT NULL,
          ip TEXT NOT NULL,
          country TEXT,
          city TEXT,
          user_agent TEXT,
          referer TEXT,
          accept_language TEXT,
          authenticated INTEGER NOT NULL DEFAULT 0,
          username TEXT,
          path TEXT,
          method TEXT,
          status INTEGER,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_web_access_time ON web_access(timestamp);
        CREATE INDEX IF NOT EXISTS idx_web_access_ip ON web_access(ip);
        CREATE INDEX IF NOT EXISTS idx_web_access_event ON web_access(event);
        CREATE INDEX IF NOT EXISTS idx_web_access_country ON web_access(country);
        CREATE INDEX IF NOT EXISTS idx_web_access_city ON web_access(city);
        """)
        if ACCESS_RETENTION_DAYS > 0:
            cutoff = int(time.time() * 1000) - ACCESS_RETENTION_DAYS * 86400 * 1000
            conn.execute("DELETE FROM web_access WHERE timestamp < ?", (cutoff,))
            conn.commit()


def _access_peer_ip(handler) -> str:
    try:
        return str(handler.client_address[0] or "unknown")
    except Exception:
        return "unknown"


def _access_is_trusted_proxy_peer(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(str(ip))
        return addr.is_loopback or addr.is_private
    except Exception:
        return False


def _access_client_ip(handler) -> str:
    peer = _access_peer_ip(handler)
    if _access_is_trusted_proxy_peer(peer):
        forwarded = str(handler.headers.get("X-Forwarded-For") or "").split(",", 1)[0].strip()
        if forwarded:
            try:
                ipaddress.ip_address(forwarded)
                return forwarded
            except Exception:
                pass
        real_ip = str(handler.headers.get("X-Real-IP") or "").strip()
        if real_ip:
            try:
                ipaddress.ip_address(real_ip)
                return real_ip
            except Exception:
                pass
    return peer


def _access_geo_from_headers(handler, client_ip: str):
    peer = _access_peer_ip(handler)
    if not _access_is_trusted_proxy_peer(peer):
        return None, None
    country = (
        handler.headers.get("CF-IPCountry")
        or handler.headers.get("X-Vercel-IP-Country")
        or handler.headers.get("X-Country-Code")
        or handler.headers.get("X-Geo-Country")
    )
    city = (
        handler.headers.get("CF-IPCity")
        or handler.headers.get("X-Vercel-IP-City")
        or handler.headers.get("X-City")
        or handler.headers.get("X-Geo-City")
    )
    try:
        if city:
            city = urllib.parse.unquote(str(city))
    except Exception:
        city = str(city or "")
    return (str(country).strip() if country else None, str(city).strip() if city else None)


def _access_geo(client_ip: str, handler=None):
    country = city = None
    if handler is not None:
        country, city = _access_geo_from_headers(handler, client_ip)
        if country or city:
            return country, city
    try:
        addr = ipaddress.ip_address(client_ip)
        if addr.is_private or addr.is_loopback:
            return "Local", "Rede local"
    except Exception:
        return country, city
    if not ACCESS_GEOIP_URL:
        return country, city

    now = time.time()
    with _access_geo_lock:
        cached = _access_geo_cache.get(client_ip)
        if cached and now - float(cached.get("ts") or 0) < 86400:
            return cached.get("country"), cached.get("city")
    try:
        url = ACCESS_GEOIP_URL.replace("{ip}", urllib.parse.quote(client_ip, safe=""))
        req = urllib.request.Request(url, headers={"User-Agent": f"TrafficAnalyzer/{APP_VERSION}"})
        with urllib.request.urlopen(req, timeout=2.5) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        if isinstance(payload, dict):
            country = payload.get("country") or payload.get("country_name") or payload.get("countryCode") or payload.get("country_code")
            city = payload.get("city") or payload.get("town")
    except Exception:
        pass
    with _access_geo_lock:
        _access_geo_cache[client_ip] = {"ts": now, "country": country, "city": city}
        if len(_access_geo_cache) > 2048:
            oldest = sorted(_access_geo_cache.items(), key=lambda kv: float(kv[1].get("ts") or 0))[:256]
            for key, _ in oldest:
                _access_geo_cache.pop(key, None)
    return country, city


def _access_safe_referer(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        parts = urllib.parse.urlsplit(raw)
        return urllib.parse.urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))[:500]
    except Exception:
        return raw.split("?", 1)[0][:500]


def _access_rotate_log_if_needed():
    try:
        if ACCESS_LOG_FILE.exists() and ACCESS_LOG_FILE.stat().st_size >= ACCESS_LOG_MAX_BYTES:
            rotated = ACCESS_LOG_FILE.with_suffix(ACCESS_LOG_FILE.suffix + ".1")
            try:
                rotated.unlink(missing_ok=True)
            except TypeError:
                if rotated.exists():
                    rotated.unlink()
            ACCESS_LOG_FILE.replace(rotated)
    except Exception:
        pass


def _record_access_event(handler, event="pageview", status=200, path=None, username=None):
    now_ms = int(time.time() * 1000)
    client_ip = _access_client_ip(handler)
    country, city = _access_geo(client_ip, handler)
    session = _auth_session(handler)
    authenticated = bool(session)
    if username is None and session:
        username = session.get("user")
    record = {
        "timestamp": now_ms,
        "event": str(event or "pageview"),
        "ip": client_ip,
        "country": country,
        "city": city,
        "userAgent": str(handler.headers.get("User-Agent") or "")[:600],
        "referer": _access_safe_referer(handler.headers.get("Referer") or ""),
        "acceptLanguage": str(handler.headers.get("Accept-Language") or "")[:200],
        "authenticated": authenticated,
        "username": str(username or "")[:120] or None,
        "path": str(path or handler.path.split("?", 1)[0])[:300],
        "method": str(getattr(handler, "command", "GET") or "GET")[:16],
        "status": int(status),
        "createdAt": now_ms,
    }
    try:
        with _archive_connect() as conn:
            conn.execute(
                """INSERT INTO web_access (
                     timestamp,event,ip,country,city,user_agent,referer,accept_language,
                     authenticated,username,path,method,status,created_at
                   ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    record["timestamp"], record["event"], record["ip"], record["country"], record["city"],
                    record["userAgent"], record["referer"], record["acceptLanguage"],
                    1 if record["authenticated"] else 0, record["username"], record["path"],
                    record["method"], record["status"], record["createdAt"],
                ),
            )
            conn.commit()
    except Exception as exc:
        print(f"AVISO: falha ao registrar acesso no banco: {exc}", flush=True)
    try:
        ACCESS_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with _access_log_lock:
            _access_rotate_log_if_needed()
            with ACCESS_LOG_FILE.open("a", encoding="utf-8") as logf:
                logf.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception as exc:
        print(f"AVISO: falha ao escrever access.log: {exc}", flush=True)


def _access_browser(user_agent: str) -> str:
    ua = str(user_agent or "")
    if "Edg/" in ua:
        return "Edge"
    if "OPR/" in ua or "Opera" in ua:
        return "Opera"
    if "Chrome/" in ua and "Chromium/" not in ua:
        return "Chrome"
    if "Firefox/" in ua:
        return "Firefox"
    if "Safari/" in ua and "Chrome/" not in ua:
        return "Safari"
    return "Outro"


def _access_os(user_agent: str) -> str:
    ua = str(user_agent or "")
    if "Windows" in ua:
        return "Windows"
    if "Android" in ua:
        return "Android"
    if "iPhone" in ua or "iPad" in ua:
        return "iOS/iPadOS"
    if "Mac OS X" in ua or "Macintosh" in ua:
        return "macOS"
    if "Linux" in ua:
        return "Linux"
    return "Outro"


def _access_stats(days=30):
    days = max(1, min(int(days or 30), 3650))
    now_ms = int(time.time() * 1000)
    cutoff = now_ms - days * 86400 * 1000
    cutoff7 = now_ms - 7 * 86400 * 1000
    cutoff30 = now_ms - 30 * 86400 * 1000
    today = datetime.now().strftime("%Y-%m-%d")
    with _archive_connect() as conn:
        total = int(conn.execute("SELECT COUNT(*) n FROM web_access WHERE event='pageview'").fetchone()["n"] or 0)
        today_count = int(conn.execute(
            "SELECT COUNT(*) n FROM web_access WHERE event='pageview' AND date(timestamp/1000,'unixepoch','localtime')=?",
            (today,),
        ).fetchone()["n"] or 0)
        count7 = int(conn.execute("SELECT COUNT(*) n FROM web_access WHERE event='pageview' AND timestamp>=?", (cutoff7,)).fetchone()["n"] or 0)
        count30 = int(conn.execute("SELECT COUNT(*) n FROM web_access WHERE event='pageview' AND timestamp>=?", (cutoff30,)).fetchone()["n"] or 0)
        unique30 = int(conn.execute("SELECT COUNT(DISTINCT ip) n FROM web_access WHERE event='pageview' AND timestamp>=?", (cutoff30,)).fetchone()["n"] or 0)
        login_failed30 = int(conn.execute("SELECT COUNT(*) n FROM web_access WHERE event='login_failed' AND timestamp>=?", (cutoff30,)).fetchone()["n"] or 0)
        login_success30 = int(conn.execute("SELECT COUNT(*) n FROM web_access WHERE event='login_success' AND timestamp>=?", (cutoff30,)).fetchone()["n"] or 0)
        daily_rows = conn.execute(
            """SELECT date(timestamp/1000,'unixepoch','localtime') day,
                      COUNT(*) accesses, COUNT(DISTINCT ip) unique_ips
               FROM web_access
               WHERE event='pageview' AND timestamp>=?
               GROUP BY day ORDER BY day""",
            (cutoff,),
        ).fetchall()
        country_rows = conn.execute(
            """SELECT COALESCE(NULLIF(country,''),'Não informado') country,
                      COUNT(*) accesses, COUNT(DISTINCT ip) unique_ips
               FROM web_access
               WHERE event='pageview' AND timestamp>=?
               GROUP BY COALESCE(NULLIF(country,''),'Não informado')
               ORDER BY accesses DESC LIMIT 30""",
            (cutoff,),
        ).fetchall()
        city_rows = conn.execute(
            """SELECT COALESCE(NULLIF(city,''),'Não informado') city,
                      COALESCE(NULLIF(country,''),'Não informado') country,
                      COUNT(*) accesses, COUNT(DISTINCT ip) unique_ips
               FROM web_access
               WHERE event='pageview' AND timestamp>=?
               GROUP BY COALESCE(NULLIF(city,''),'Não informado'), COALESCE(NULLIF(country,''),'Não informado')
               ORDER BY accesses DESC LIMIT 40""",
            (cutoff,),
        ).fetchall()
        ip_rows = conn.execute(
            """SELECT ip, MAX(country) country, MAX(city) city, COUNT(*) accesses,
                      MIN(timestamp) first_seen, MAX(timestamp) last_seen,
                      MAX(user_agent) user_agent
               FROM web_access
               WHERE event='pageview' AND timestamp>=?
               GROUP BY ip ORDER BY accesses DESC, last_seen DESC LIMIT 100""",
            (cutoff,),
        ).fetchall()
        ua_rows = conn.execute(
            """SELECT user_agent, COUNT(*) accesses
               FROM web_access
               WHERE event='pageview' AND timestamp>=?
               GROUP BY user_agent""",
            (cutoff,),
        ).fetchall()

    browser_counts = {}
    os_counts = {}
    for row in ua_rows:
        count = int(row["accesses"] or 0)
        browser = _access_browser(row["user_agent"])
        os_name = _access_os(row["user_agent"])
        browser_counts[browser] = browser_counts.get(browser, 0) + count
        os_counts[os_name] = os_counts.get(os_name, 0) + count

    return {
        "success": True,
        "generatedAtMs": now_ms,
        "days": days,
        "logFile": str(ACCESS_LOG_FILE),
        "retentionDays": ACCESS_RETENTION_DAYS,
        "geoipConfigured": bool(ACCESS_GEOIP_URL),
        "summary": {
            "today": today_count,
            "last7d": count7,
            "last30d": count30,
            "uniqueIps30d": unique30,
            "total": total,
            "loginSuccess30d": login_success30,
            "loginFailed30d": login_failed30,
        },
        "daily": [dict(r) for r in daily_rows],
        "countries": [dict(r) for r in country_rows],
        "cities": [dict(r) for r in city_rows],
        "ips": [dict(r) for r in ip_rows],
        "browsers": [{"name": k, "accesses": v} for k, v in sorted(browser_counts.items(), key=lambda kv: kv[1], reverse=True)],
        "operatingSystems": [{"name": k, "accesses": v} for k, v in sorted(os_counts.items(), key=lambda kv: kv[1], reverse=True)],
    }


def _archive_key(item: dict):
    rid = item.get("id")
    if rid is not None:
        return f"{MM_SOURCE}:row:{rid}:{item.get('timestamp') or item.get('created_at') or ''}"
    return ":".join([
        MM_SOURCE,
        "fallback",
        str(item.get("packet_id") or ""),
        str(item.get("timestamp") or ""),
        str(item.get("direction") or ""),
        str(item.get("from_node") or ""),
        str(item.get("to_node") or ""),
        str(item.get("relay_node") or ""),
        str(item.get("portnum") or item.get("portnum_name") or ""),
    ])


def _archive_metadata(value):
    if value is None:
        return None
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    except Exception:
        return str(value)


def _position_payload(metadata):
    if metadata is None:
        return None
    obj = metadata
    if isinstance(obj, str):
        try:
            obj = json.loads(obj)
        except Exception:
            return None
    if not isinstance(obj, dict):
        return None
    candidates = [obj]
    for key in ("decoded_payload", "decoded", "position", "payload"):
        val = obj.get(key)
        if isinstance(val, dict):
            candidates.insert(0, val)
    for d in candidates:
        lat = d.get("latitude")
        lon = d.get("longitude")
        if lat is None:
            lat = d.get("latitudeI")
        if lon is None:
            lon = d.get("longitudeI")
        try:
            lat = float(lat); lon = float(lon)
        except Exception:
            continue
        if abs(lat) > 90:
            lat /= 1e7
        if abs(lon) > 180:
            lon /= 1e7
        if not (-90 <= lat <= 90 and -180 <= lon <= 180) or (abs(lat) < 1e-9 and abs(lon) < 1e-9):
            continue
        alt = d.get("altitude", d.get("altitudeHae"))
        try:
            alt = float(alt) if alt is not None else None
        except Exception:
            alt = None
        return lat, lon, alt
    return None


def _tracklog_position_tuple(item, ts, now_ms):
    try:
        portnum = int(item.get("portnum")) if item.get("portnum") is not None else None
    except Exception:
        portnum = None
    if item.get("portnum_name") != "POSITION_APP" and portnum != 3:
        return None
    try:
        node_num = int(item.get("from_node"))
    except Exception:
        return None
    pos = _position_payload(item.get("metadata"))
    if not pos:
        return None
    lat, lon, alt = pos
    key = _archive_key(item)
    name = item.get("from_node_longName") or item.get("from_node_id")
    return (key, MM_SOURCE, node_num, item.get("from_node_id"), name, ts, lat, lon, alt, item.get("snr"), item.get("rssi"), now_ms)


def _tracklog_insert_values(conn, values):
    if not values:
        return 0
    before = conn.total_changes
    conn.executemany("""
      INSERT OR IGNORE INTO positions (
        position_key,source_id,node_num,node_id,node_name,timestamp,latitude,longitude,altitude,snr,rssi,archived_at
      ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    """, values)
    return conn.total_changes - before


def _tracklog_backfill():
    try:
        now_ms = int(time.time() * 1000)
        with _archive_connect() as conn:
            rows = conn.execute("""
              SELECT archive_key,source_id,mm_row_id AS id,packet_id,timestamp,created_at,direction,
                     from_node,from_node_id,from_node_long_name AS from_node_longName,
                     to_node,to_node_id,to_node_long_name AS to_node_longName,channel,portnum,portnum_name,
                     snr,rssi,relay_node,metadata
              FROM packets
              WHERE source_id=? AND (portnum_name='POSITION_APP' OR portnum=3)
              ORDER BY timestamp ASC
            """, (MM_SOURCE,)).fetchall()
            vals=[]
            for row in rows:
                item=dict(row)
                item["id"]=item.get("id")
                v=_tracklog_position_tuple(item,int(item.get("timestamp") or now_ms),now_ms)
                if v:
                    # preserve the original packet archive key exactly
                    v=(str(item.get("archive_key")),)+v[1:]
                    vals.append(v)
                if len(vals)>=1000:
                    _tracklog_insert_values(conn,vals); vals=[]
            _tracklog_insert_values(conn,vals)
    except Exception as exc:
        print(f"AVISO: não foi possível reconstruir tracklog histórico: {exc}", flush=True)


def _archive_insert_rows(rows):
    if not rows:
        return 0
    now_ms = int(time.time() * 1000)
    sql = """
      INSERT OR IGNORE INTO packets (
        archive_key, source_id, mm_row_id, packet_id, timestamp, created_at, direction,
        from_node, from_node_id, from_node_long_name, to_node, to_node_id, to_node_long_name,
        channel, portnum, portnum_name, encrypted, snr, rssi, hop_limit, hop_start, relay_node,
        payload_size, want_ack, priority, payload_preview, metadata, decrypted_by,
        decrypted_channel_id, transport_mechanism, spoof_suspected, xeddsa_signed, archived_at
      ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """
    values = []
    position_values = []
    for raw in rows:
        item = _sanitize_packet(raw)
        ts = item.get("timestamp") or item.get("created_at") or now_ms
        try:
            ts = int(ts)
        except Exception:
            ts = now_ms
        if ts < 10_000_000_000:
            ts *= 1000
        archive_key = _archive_key(item)
        values.append((
            archive_key, MM_SOURCE, item.get("id"), item.get("packet_id"), ts,
            item.get("created_at"), item.get("direction"), item.get("from_node"),
            item.get("from_node_id"), item.get("from_node_longName"), item.get("to_node"),
            item.get("to_node_id"), item.get("to_node_longName"), item.get("channel"),
            item.get("portnum"), item.get("portnum_name"), int(bool(item.get("encrypted"))) if item.get("encrypted") is not None else None,
            item.get("snr"), item.get("rssi"), item.get("hop_limit"), item.get("hop_start"),
            item.get("relay_node"), item.get("payload_size"), int(bool(item.get("want_ack"))) if item.get("want_ack") is not None else None,
            item.get("priority"), item.get("payload_preview"), _archive_metadata(item.get("metadata")),
            item.get("decrypted_by"), item.get("decrypted_channel_id"), item.get("transport_mechanism"),
            int(bool(item.get("spoof_suspected"))) if item.get("spoof_suspected") is not None else None,
            int(bool(item.get("xeddsa_signed"))) if item.get("xeddsa_signed") is not None else None,
            now_ms,
        ))
        posv = _tracklog_position_tuple(item, ts, now_ms)
        if posv:
            position_values.append((archive_key,)+posv[1:])
    with _archive_connect() as conn:
        before = conn.total_changes
        conn.executemany(sql, values)
        inserted_packets = conn.total_changes - before
        _tracklog_insert_values(conn, position_values)
        return inserted_packets


def _archive_last_timestamp():
    with _archive_connect() as conn:
        row = conn.execute("SELECT MAX(timestamp) AS ts FROM packets WHERE source_id=?", (MM_SOURCE,)).fetchone()
        return int(row["ts"]) if row and row["ts"] is not None else None


def _archive_cleanup(retention_days=None):
    days = _normalize_archive_retention_days(
        _archive_settings().get("retentionDays") if retention_days is None else retention_days
    )
    if days <= 0:
        return 0
    cutoff = int(time.time() * 1000) - days * 86400 * 1000
    with _archive_connect() as conn:
        cur = conn.execute("DELETE FROM packets WHERE timestamp < ?", (cutoff,))
        removed_packets = max(0, cur.rowcount or 0)
        conn.execute("DELETE FROM positions WHERE timestamp < ?", (cutoff,))
    if removed_packets:
        print(
            f"Retenção do tráfego: removidos {removed_packets} pacote(s) com mais de {days} dia(s). "
            "Nós e enlaces históricos foram preservados.",
            flush=True,
        )
    return removed_packets


def _archive_sync_pass(since):
    offset = 0
    inserted = 0
    pages = 0
    while pages < 10000:
        body, rows = _mm_packets_raw(ARCHIVE_PAGE_SIZE, since=since, offset=offset)
        if not rows:
            break
        inserted += _archive_insert_rows(rows)
        pages += 1
        got = len(rows)
        offset += got
        try:
            total = int(body.get("total"))
        except Exception:
            total = None
        if total is not None and offset >= total:
            break
        if total is None and got < ARCHIVE_PAGE_SIZE:
            break
    return inserted


def _archive_sync_once(full=False):
    last_ts = None if full else _archive_last_timestamp()
    since = None if last_ts is None else max(0, last_ts - ARCHIVE_OVERLAP_MS)
    # O endpoint por fonte usa paginação por offset. Como novos pacotes podem
    # chegar enquanto as páginas são percorridas, fazemos duas passagens sobre
    # a mesma janela. INSERT OR IGNORE torna a segunda passagem barata e reduz
    # o risco de lacunas causadas por deslocamento das páginas.
    inserted = _archive_sync_pass(since)
    inserted += _archive_sync_pass(since)
    _archive_cleanup()
    return inserted


def _archive_worker():
    with _archive_status_lock:
        _archive_status["running"] = True
    first_success = False
    while not _archive_stop.is_set():
        try:
            # Na primeira sincronização, pagina tudo o que ainda está retido no
            # Packet Monitor. Depois trabalha apenas sobre uma janela sobreposta.
            was_first = not first_success
            inserted = _archive_sync_once(full=was_first)
            if was_first:
                recovery = _topology_history_recover_from_archive()
                if recovery.get("recovered"):
                    print(f"Topologia histórica: {recovery['recovered']} observação(ões) recuperada(s) do arquivo de tráfego sem promover Ranking.", flush=True)
                correction = _topology_direct_evidence_rebuild_v2()
                if not correction.get("skipped"):
                    print(
                        "Ranking RF v1.53: "
                        f"{int(correction.get('invalidated') or 0)} observação(ões) de evidência legada "
                        "foram invalidadas; somente /traceroutes pode revalidá-las.",
                        flush=True,
                    )
                history = _topology_direct_history_backfill_v4()
                if not history.get("skipped"):
                    state = "completo" if history.get("complete") else "parcial"
                    print(
                        "Ranking RF v1.55: backfill histórico autenticado "
                        f"{state}; {int(history.get('processed') or 0)} traceroute(s) processado(s), "
                        f"{int(history.get('inserted') or 0)} evidência(s) inserida(s), "
                        f"limit final={int(history.get('finalLimit') or 0)}, "
                        f"método={history.get('method')}.",
                        flush=True,
                    )
            # Evidências históricas confiáveis e snapshots atuais coexistem.
            # Uma vez gravadas no traffic.db, não dependem de o nó estar online.
            _topology_history_drain_queue()
            _topology_history_ingest_current()
            if was_first:
                # Reconciliar depois de drenar snapshots antigos garante que
                # todo par RF já conhecido esteja disponível para a busca por par.
                pairs = _topology_direct_pair_reconcile_v6()
                if not pairs.get("skipped"):
                    state = "completo" if pairs.get("complete") else "parcial"
                    print(
                        "Ranking RF v1.57.1: reconciliação histórica por par "
                        f"{state}; {int(pairs.get('checkedPairs') or 0)} par(es) consultado(s), "
                        f"{int(pairs.get('recoveredPairs') or 0)} recuperado(s), "
                        f"{int(pairs.get('unresolvedPairs') or 0)} sem prova direta.",
                        flush=True,
                    )
            first_success = True
            with _archive_status_lock:
                _archive_status.update({
                    "last_sync_ms": int(time.time() * 1000),
                    "last_error": None,
                    "inserted_last_sync": inserted,
                })
        except Exception as exc:
            with _archive_status_lock:
                _archive_status.update({
                    "last_sync_ms": int(time.time() * 1000),
                    "last_error": str(exc),
                    "inserted_last_sync": 0,
                })
        _archive_stop.wait(ARCHIVE_POLL_SECONDS)
    with _archive_status_lock:
        _archive_status["running"] = False


def _archive_status_snapshot():
    try:
        with _archive_connect() as conn:
            row = conn.execute("SELECT COUNT(*) AS n, MIN(timestamp) AS first_ts, MAX(timestamp) AS last_ts FROM packets").fetchone()
            topo_nodes = conn.execute("SELECT COUNT(*) AS n FROM topology_nodes WHERE source_id=?", (MM_SOURCE,)).fetchone()
            topo_edges = conn.execute("SELECT COUNT(DISTINCT edge_id) AS n FROM topology_edge_events WHERE source_id=?", (MM_SOURCE,)).fetchone()
            count = int(row["n"] or 0)
            first_ts = row["first_ts"]
            last_ts = row["last_ts"]
            persistent_nodes = int(topo_nodes["n"] or 0)
            persistent_edges = int(topo_edges["n"] or 0)
    except Exception:
        count, first_ts, last_ts, persistent_nodes, persistent_edges = 0, None, None, 0, 0
    db_bytes = 0
    for p in (TRAFFIC_ARCHIVE_DB, Path(str(TRAFFIC_ARCHIVE_DB) + "-wal"), Path(str(TRAFFIC_ARCHIVE_DB) + "-shm")):
        try:
            db_bytes += p.stat().st_size
        except Exception:
            pass
    with _archive_status_lock:
        status = dict(_archive_status)
    return {
        "db": str(TRAFFIC_ARCHIVE_DB),
        "packets": count,
        "firstTimestamp": first_ts,
        "lastTimestamp": last_ts,
        "retentionDays": _archive_settings().get("retentionDays", ARCHIVE_RETENTION_DEFAULT_DAYS),
        "persistentNodes": persistent_nodes,
        "persistentEdges": persistent_edges,
        "dbBytes": db_bytes,
        "schemaVersion": 2,
        **status,
    }


def _archive_where(query):
    clauses = []
    params = []
    def add_num(name, op):
        raw = (query.get(name) or [None])[0]
        if raw not in (None, ""):
            clauses.append(f"timestamp {op} ?")
            params.append(int(raw))
    add_num("since", ">=")
    add_num("until", "<=")
    direction = (query.get("direction") or [None])[0]
    if direction in {"rx", "tx"}:
        clauses.append("direction = ?")
        params.append(direction)
    ptype = (query.get("type") or [None])[0]
    if ptype:
        clauses.append("portnum_name = ?")
        params.append(ptype)
    node = (query.get("node") or [None])[0]
    if node not in (None, ""):
        try:
            n = int(node, 0)
            clauses.append("(from_node = ? OR to_node = ?)")
            params.extend([n, n])
        except ValueError:
            clauses.append("(from_node_id = ? OR to_node_id = ? OR from_node_long_name LIKE ? OR to_node_long_name LIKE ?)")
            params.extend([node, node, f"%{node}%", f"%{node}%"])
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", params


def _archive_row_to_dict(row):
    d = dict(row)
    meta = d.get("metadata")
    if meta:
        try:
            d["metadata"] = json.loads(meta)
        except Exception:
            pass
    for key in ("encrypted", "want_ack", "spoof_suspected", "xeddsa_signed"):
        if d.get(key) is not None:
            d[key] = bool(d[key])
    # Mantém aliases compatíveis com os nomes expostos pelo Packet Monitor.
    d["id"] = d.pop("mm_row_id", None)
    d["from_node_longName"] = d.pop("from_node_long_name", None)
    d["to_node_longName"] = d.pop("to_node_long_name", None)
    return d


def _archive_packets_query(query):
    limit = max(1, min(int((query.get("limit") or ["1000"])[0]), 5000))
    offset = max(0, int((query.get("offset") or ["0"])[0]))
    where, params = _archive_where(query)
    with _archive_connect() as conn:
        total = int(conn.execute(f"SELECT COUNT(*) AS n FROM packets{where}", params).fetchone()["n"])
        rows = conn.execute(
            f"SELECT * FROM packets{where} ORDER BY timestamp DESC, archive_id DESC LIMIT ? OFFSET ?",
            [*params, limit, offset],
        ).fetchall()
    data = [_archive_row_to_dict(r) for r in rows]
    return {"success": True, "count": len(data), "total": total, "offset": offset, "limit": limit, "data": data}


def _archive_stats_query(query):
    where, params = _archive_where(query)
    with _archive_connect() as conn:
        row = conn.execute(
            f"SELECT COUNT(*) AS total, SUM(direction='rx') AS rx, SUM(direction='tx') AS tx, MIN(timestamp) AS first_ts, MAX(timestamp) AS last_ts, COUNT(DISTINCT from_node) AS origin_nodes FROM packets{where}",
            params,
        ).fetchone()
        types = conn.execute(
            f"SELECT COALESCE(portnum_name, CAST(portnum AS TEXT), 'UNKNOWN') AS type, COUNT(*) AS count FROM packets{where} GROUP BY COALESCE(portnum_name, CAST(portnum AS TEXT), 'UNKNOWN') ORDER BY count DESC",
            params,
        ).fetchall()
    return {
        "success": True,
        "total": int(row["total"] or 0),
        "rx": int(row["rx"] or 0),
        "tx": int(row["tx"] or 0),
        "firstTimestamp": row["first_ts"],
        "lastTimestamp": row["last_ts"],
        "originNodes": int(row["origin_nodes"] or 0),
        "byType": [{"type": r["type"], "count": int(r["count"])} for r in types],
    }


def _archive_nodes_query(query):
    where, params = _archive_where(query)
    with _archive_connect() as conn:
        rows = conn.execute(
            f"""SELECT from_node AS nodeNum, MAX(from_node_id) AS nodeId,
                       MAX(from_node_long_name) AS longName, COUNT(*) AS packets,
                       AVG(snr) AS avgSnr, AVG(rssi) AS avgRssi, MAX(timestamp) AS lastSeen
                FROM packets{where}
                WHERE_APPEND
                GROUP BY from_node ORDER BY packets DESC""".replace(
                    "WHERE_APPEND",
                    (" AND from_node IS NOT NULL" if where else " WHERE from_node IS NOT NULL")
                ),
            params,
        ).fetchall()
    return {"success": True, "count": len(rows), "data": [dict(r) for r in rows]}


def _archive_links_query(query):
    where, params = _archive_where(query)
    suffix = " AND from_node IS NOT NULL AND to_node IS NOT NULL" if where else " WHERE from_node IS NOT NULL AND to_node IS NOT NULL"
    with _archive_connect() as conn:
        rows = conn.execute(
            f"""SELECT from_node AS fromNode, MAX(from_node_id) AS fromNodeId,
                       to_node AS toNode, MAX(to_node_id) AS toNodeId,
                       COUNT(*) AS packets, AVG(snr) AS avgSnr, AVG(rssi) AS avgRssi,
                       MAX(timestamp) AS lastSeen
                FROM packets{where}{suffix}
                GROUP BY from_node, to_node ORDER BY packets DESC""",
            params,
        ).fetchall()
    return {"success": True, "count": len(rows), "data": [dict(r) for r in rows]}


def _archive_rf_longest_links_query(query):
    """Top 10 por distância usando a mesma classificação RF do mapa.

    topology_edge_events já representa adjacências (hops) da topologia.
    Portanto, uma observação com transport='rf' e SNR válido é evidência do
    hop RF A↔B. Quando a API de traceroutes ainda está disponível, mantemos a
    marca route-adjacency-api para auditoria, mas ela não é requisito para o
    ranking. Isso preserva enlaces históricos legítimos cujo traceroute já
    caducou no MeshMonitor, como acontece com nós offline/antigos.
    """
    clauses = [
        "e.source_id = ?",
        "e.transport = 'rf'",
        "e.snr IS NOT NULL",
    ]
    params = [MM_SOURCE]
    raw_since = (query.get("since") or [None])[0]
    raw_until = (query.get("until") or [None])[0]
    if raw_since not in (None, ""):
        clauses.append("e.timestamp_ms >= ?")
        params.append(int(raw_since))
    if raw_until not in (None, ""):
        clauses.append("e.timestamp_ms <= ?")
        params.append(int(raw_until))

    node_filter = (query.get("node") or [None])[0]
    node_nums = None
    with _archive_connect() as conn:
        if node_filter not in (None, ""):
            try:
                node_nums = [int(str(node_filter), 0) & 0xffffffff]
            except ValueError:
                matches = []
                for row in conn.execute(
                    "SELECT node_num,node_json FROM topology_nodes WHERE source_id=?",
                    (MM_SOURCE,),
                ).fetchall():
                    try:
                        node = json.loads(row["node_json"] or "{}")
                    except Exception:
                        node = {}
                    needle = str(node_filter).strip().lower()
                    hay = " ".join(str(node.get(k) or "") for k in ("nodeId","name","longName","shortName")).lower()
                    if needle and needle in hay:
                        matches.append(int(row["node_num"]))
                node_nums = matches
            if not node_nums:
                return {"success": True, "count": 0, "data": []}
            placeholders = ",".join("?" for _ in node_nums)
            clauses.append(f"(e.a IN ({placeholders}) OR e.b IN ({placeholders}))")
            params.extend(node_nums)
            params.extend(node_nums)

        rows = conn.execute(
            f"""SELECT e.edge_id,e.a,e.b,
                       SUM(e.observation_count) AS rfObservations,
                       SUM(CASE WHEN e.direct_evidence=1 AND e.direct_evidence_kind='route-adjacency-api'
                                THEN e.observation_count ELSE 0 END) AS trustedDirectObservations,
                       SUM(e.snr*e.observation_count)/NULLIF(SUM(e.observation_count),0) AS avgSnr,
                       MAX(e.timestamp_ms) AS lastRfSeenMs,
                       GROUP_CONCAT(DISTINCT CASE WHEN e.direct_evidence=1 THEN e.direct_evidence_kind END) AS directEvidenceKinds,
                       GROUP_CONCAT(DISTINCT e.trace_id) AS evidenceTraceIds,
                       GROUP_CONCAT(DISTINCT e.packet_id) AS evidencePacketIds
                FROM topology_edge_events e
                WHERE {' AND '.join(clauses)}
                GROUP BY e.edge_id,e.a,e.b""",
            params,
        ).fetchall()

        node_rows = conn.execute(
            "SELECT node_num,node_json FROM topology_nodes WHERE source_id=?",
            (MM_SOURCE,),
        ).fetchall()

        negative_prefix = f"topology-rf-multihop-v1:{MM_SOURCE}:"
        negative_rows = conn.execute(
            "SELECT meta_key FROM topology_history_meta WHERE meta_key LIKE ?",
            (negative_prefix + "%",),
        ).fetchall()
        negative_edges = {str(r["meta_key"])[len(negative_prefix):] for r in negative_rows}

    node_map = {}
    for row in node_rows:
        try:
            node = json.loads(row["node_json"] or "{}")
        except Exception:
            node = {}
        node["nodeNum"] = int(row["node_num"])
        node_map[int(row["node_num"])] = node

    data = []
    for row in rows:
        if str(row["edge_id"]) in negative_edges:
            continue
        a = int(row["a"]); b = int(row["b"])
        na = node_map.get(a, {}); nb = node_map.get(b, {})
        if not (_history_valid_position(na.get("latitude"), na.get("longitude")) and
                _history_valid_position(nb.get("latitude"), nb.get("longitude"))):
            continue
        distance_km = _haversine_m(
            float(na["latitude"]), float(na["longitude"]),
            float(nb["latitude"]), float(nb["longitude"]),
        ) / 1000.0
        rf_observations = int(row["rfObservations"] or 0)
        trusted_observations = int(row["trustedDirectObservations"] or 0)
        kinds = [x for x in str(row["directEvidenceKinds"] or "").split(",") if x]
        if trusted_observations < rf_observations:
            kinds.append("rf-hop-observed")
        if trusted_observations and trusted_observations < rf_observations:
            evidence_source = "mixed"
        elif trusted_observations:
            evidence_source = "api-traceroute"
        else:
            evidence_source = "topology-rf-hop"
        data.append({
            "edgeId": str(row["edge_id"]),
            "a": a,
            "b": b,
            "aId": na.get("nodeId") or _history_node_id(a),
            "bId": nb.get("nodeId") or _history_node_id(b),
            "aName": na.get("name") or na.get("longName") or na.get("shortName") or na.get("nodeId") or _history_node_id(a),
            "bName": nb.get("name") or nb.get("longName") or nb.get("shortName") or nb.get("nodeId") or _history_node_id(b),
            "distanceKm": round(distance_km, 3),
            "rfObservations": rf_observations,
            "trustedDirectObservations": trusted_observations,
            "avgSnr": round(float(row["avgSnr"]), 2) if row["avgSnr"] is not None else None,
            "lastRfSeenMs": int(row["lastRfSeenMs"] or 0),
            "directEvidence": True,
            "directEvidenceKinds": list(dict.fromkeys(kinds)),
            "evidenceSource": evidence_source,
            "evidenceTraceIds": [x for x in str(row["evidenceTraceIds"] or "").split(",") if x][:12],
            "evidencePacketIds": [x for x in str(row["evidencePacketIds"] or "").split(",") if x][:12],
        })
    data.sort(key=lambda x: (-float(x["distanceKm"]), -int(x["rfObservations"]), -int(x["lastRfSeenMs"])))
    return {"success": True, "count": min(10, len(data)), "data": data[:10]}


def _archive_rf_ranking_audit_query(query):
    """Explica a elegibilidade usando exatamente o mesmo critério RF do mapa."""
    clauses = ["e.source_id = ?", "e.transport = 'rf'", "e.snr IS NOT NULL"]
    params = [MM_SOURCE]
    raw_since = (query.get("since") or [None])[0]
    raw_until = (query.get("until") or [None])[0]
    if raw_since not in (None, ""):
        clauses.append("e.timestamp_ms >= ?")
        params.append(int(raw_since))
    if raw_until not in (None, ""):
        clauses.append("e.timestamp_ms <= ?")
        params.append(int(raw_until))

    with _archive_connect() as conn:
        rows = conn.execute(
            f"""SELECT e.edge_id,e.a,e.b,
                       SUM(e.observation_count) AS rfObservations,
                       SUM(CASE WHEN e.direct_evidence=1 AND e.direct_evidence_kind='route-adjacency-api'
                                THEN e.observation_count ELSE 0 END) AS trustedDirectObservations,
                       SUM(e.snr*e.observation_count)/NULLIF(SUM(e.observation_count),0) AS avgSnr,
                       MAX(e.timestamp_ms) AS lastRfSeenMs,
                       GROUP_CONCAT(DISTINCT CASE WHEN e.direct_evidence=1 THEN e.trace_id END) AS directTraceIds
                FROM topology_edge_events e
                WHERE {' AND '.join(clauses)}
                GROUP BY e.edge_id,e.a,e.b""",
            params,
        ).fetchall()
        node_rows = conn.execute(
            "SELECT node_num,node_json FROM topology_nodes WHERE source_id=?",
            (MM_SOURCE,),
        ).fetchall()

        negative_prefix = f"topology-rf-multihop-v1:{MM_SOURCE}:"
        negative_rows = conn.execute(
            "SELECT meta_key FROM topology_history_meta WHERE meta_key LIKE ?",
            (negative_prefix + "%",),
        ).fetchall()
        negative_edges = {str(r["meta_key"])[len(negative_prefix):] for r in negative_rows}

    node_map = {}
    for row in node_rows:
        try:
            node = json.loads(row["node_json"] or "{}")
        except Exception:
            node = {}
        node["nodeNum"] = int(row["node_num"])
        node_map[int(row["node_num"])] = node

    data = []
    eligible = []
    for row in rows:
        a = int(row["a"]); b = int(row["b"])
        na = node_map.get(a, {}); nb = node_map.get(b, {})
        has_pos = (
            _history_valid_position(na.get("latitude"), na.get("longitude"))
            and _history_valid_position(nb.get("latitude"), nb.get("longitude"))
        )
        distance_km = None
        if has_pos:
            distance_km = round(_haversine_m(
                float(na["latitude"]), float(na["longitude"]),
                float(nb["latitude"]), float(nb["longitude"]),
            ) / 1000.0, 3)
        rf_obs = int(row["rfObservations"] or 0)
        trusted_obs = int(row["trustedDirectObservations"] or 0)
        item = {
            "edgeId": str(row["edge_id"]), "a": a, "b": b,
            "aName": na.get("name") or na.get("longName") or na.get("shortName") or na.get("nodeId") or _history_node_id(a),
            "bName": nb.get("name") or nb.get("longName") or nb.get("shortName") or nb.get("nodeId") or _history_node_id(b),
            "distanceKm": distance_km,
            "rfObservations": rf_obs,
            "directObservations": rf_obs,
            "trustedDirectObservations": trusted_obs,
            "avgSnr": round(float(row["avgSnr"]), 2) if row["avgSnr"] is not None else None,
            "lastRfSeenMs": int(row["lastRfSeenMs"] or 0),
            "directTraceIds": [x for x in str(row["directTraceIds"] or "").split(",") if x][:12],
            "evidenceSource": "api-traceroute" if trusted_obs >= rf_obs else ("mixed" if trusted_obs else "topology-rf-hop"),
        }
        if str(row["edge_id"]) in negative_edges:
            item["eligible"] = False
            item["reason"] = "multihop_confirmado"
        elif not has_pos:
            item["eligible"] = False
            item["reason"] = "sem_posicao"
        else:
            item["eligible"] = True
            item["reason"] = "elegivel"
            eligible.append(item)
        data.append(item)

    eligible.sort(key=lambda x: (-float(x["distanceKm"]), -int(x["rfObservations"]), -int(x["lastRfSeenMs"])))
    top_ids = {x["edgeId"] for x in eligible[:10]}
    for item in data:
        if item.get("eligible") and item["edgeId"] not in top_ids:
            item["reason"] = "fora_top10"
    data.sort(key=lambda x: (
        0 if x["reason"] not in ("elegivel", "fora_top10") else 1,
        -(float(x["distanceKm"]) if x["distanceKm"] is not None else -1),
        -int(x["lastRfSeenMs"]),
    ))
    summary = {
        "rfEdges": len(data),
        "eligible": sum(1 for x in data if x.get("eligible")),
        "inTop10": sum(1 for x in data if x["edgeId"] in top_ids),
        "withoutDirectEvidence": 0,
        "withoutTrustedTrace": sum(1 for x in data if int(x.get("trustedDirectObservations") or 0) <= 0),
        "confirmedMultihop": sum(1 for x in data if x["reason"] == "multihop_confirmado"),
        "withoutPosition": sum(1 for x in data if x["reason"] == "sem_posicao"),
    }
    return {"success": True, "summary": summary, "count": len(data), "data": data[:200]}


def _archive_export(query, fmt="jsonl"):
    export_query = dict(query)
    export_query["limit"] = [str(max(1, min(int((query.get("limit") or ["100000"])[0]), 100000)))]
    export_query["offset"] = ["0"]
    data = _archive_packets_query(export_query)["data"]
    if fmt == "csv":
        out = io.StringIO()
        fields = [
            "archive_id", "source_id", "id", "packet_id", "timestamp", "created_at", "direction",
            "from_node", "from_node_id", "from_node_longName", "to_node", "to_node_id", "to_node_longName",
            "channel", "portnum", "portnum_name", "encrypted", "snr", "rssi", "hop_limit", "hop_start",
            "relay_node", "payload_size", "want_ack", "priority", "payload_preview", "metadata",
            "decrypted_by", "decrypted_channel_id", "transport_mechanism", "spoof_suspected", "xeddsa_signed", "archived_at",
        ]
        w = csv.DictWriter(out, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for row in data:
            r = dict(row)
            if isinstance(r.get("metadata"), (dict, list)):
                r["metadata"] = json.dumps(r["metadata"], ensure_ascii=False)
            w.writerow(r)
        return "text/csv; charset=utf-8", out.getvalue().encode("utf-8")
    body = "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in data)
    return "application/x-ndjson; charset=utf-8", body.encode("utf-8")



def _load_topology_safe():
    try:
        _topology_history_drain_queue()
        raw = json.loads(TOPOLOGY_FILE.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return {}
        return _topology_history_merge(raw)
    except Exception:
        return {}


def _node_last_seen_map(topology):
    result = {}
    for n in topology.get("nodes", []) or []:
        try:
            num = int(n.get("nodeNum"))
        except Exception:
            continue
        heard = n.get("lastHeard")
        try:
            heard_ms = int(float(heard) * 1000) if float(heard or 0) < 10_000_000_000 else int(float(heard))
        except Exception:
            heard_ms = 0
        result[num] = {"lastSeen": heard_ms, "name": n.get("name") or n.get("longName") or n.get("nodeId"), "nodeId": n.get("nodeId")}
    with _archive_connect() as conn:
        rows = conn.execute("""SELECT from_node AS nodeNum, MAX(timestamp) AS lastSeen, MAX(from_node_long_name) AS longName, MAX(from_node_id) AS nodeId FROM packets WHERE from_node IS NOT NULL GROUP BY from_node""").fetchall()
    for r in rows:
        num = int(r["nodeNum"])
        cur = result.setdefault(num, {"lastSeen": 0, "name": None, "nodeId": None})
        cur["lastSeen"] = max(int(cur.get("lastSeen") or 0), int(r["lastSeen"] or 0))
        cur["name"] = cur.get("name") or r["longName"] or r["nodeId"] or f"!{num & 0xffffffff:08x}"
        cur["nodeId"] = cur.get("nodeId") or r["nodeId"] or f"!{num & 0xffffffff:08x}"
    return result


def _trace_leg_hops(path):
    if not isinstance(path, list) or len(path) < 2:
        return None
    return max(0, len(path) - 1)


def _network_health():
    now = int(time.time() * 1000)
    topology = _load_topology_safe()
    nodes = _node_last_seen_map(topology)
    cutoff2 = now - 2 * 3600 * 1000
    cutoff24 = now - 24 * 3600 * 1000
    cutoff7 = now - 7 * 86400 * 1000
    seen = [int(x.get("lastSeen") or 0) for x in nodes.values()]
    active2 = sum(1 for ts in seen if ts >= cutoff2)
    active24 = sum(1 for ts in seen if ts >= cutoff24)
    active7 = sum(1 for ts in seen if ts >= cutoff7)
    no_traffic = sum(1 for ts in seen if ts <= 0)
    silent24 = sum(1 for ts in seen if 0 < ts < cutoff24)

    with _archive_connect() as conn:
        r24 = conn.execute("""SELECT COUNT(*) AS total, SUM(direction='rx') AS rx, SUM(direction='tx') AS tx FROM packets WHERE timestamp>=?""", (cutoff24,)).fetchone()
        daily_rows = conn.execute("""SELECT strftime('%Y-%m-%d', timestamp/1000, 'unixepoch', 'localtime') AS day, COUNT(*) AS packets, COUNT(DISTINCT from_node) AS nodes FROM packets WHERE timestamp>=? GROUP BY day ORDER BY day""", (cutoff7,)).fetchall()
        node7 = conn.execute("""SELECT from_node AS nodeNum, COUNT(*) AS packets, AVG(snr) AS avgSnr, MAX(timestamp) AS lastSeen, MAX(from_node_long_name) AS longName, MAX(from_node_id) AS nodeId FROM packets WHERE timestamp>=? AND from_node IS NOT NULL GROUP BY from_node""", (cutoff7,)).fetchall()
        chat_rows = conn.execute("""
            SELECT
              from_node AS nodeNum,
              COUNT(DISTINCT (CAST(from_node AS TEXT) || ':' || COALESCE(CAST(packet_id AS TEXT), archive_key))) AS interactions,
              MAX(from_node_long_name) AS longName,
              MAX(from_node_id) AS nodeId
            FROM packets
            WHERE from_node IS NOT NULL
              AND channel = 0
              AND portnum_name = 'TEXT_MESSAGE_APP'
              AND (
                to_node IN (4294967295, -1)
                OR lower(COALESCE(to_node_id,'')) IN ('!ffffffff','broadcast')
              )
            GROUP BY from_node
            ORDER BY interactions DESC, longName COLLATE NOCASE
        """).fetchall()
    by_node7 = {int(r['nodeNum']): dict(r) for r in node7}
    chat_interactions = []
    for r in chat_rows:
        num = int(r["nodeNum"])
        info = nodes.get(num, {})
        node_id = info.get("nodeId") or r["nodeId"] or f"!{num & 0xffffffff:08x}"
        name = info.get("name") or r["longName"] or node_id
        chat_interactions.append({
            "nodeNum": num,
            "nodeId": node_id,
            "name": name,
            "interactions": int(r["interactions"] or 0),
        })
    daily_map = {r['day']: dict(r) for r in daily_rows}
    daily=[]
    for i in range(6,-1,-1):
        ts = now - i*86400*1000
        day = datetime.fromtimestamp(ts/1000).strftime('%Y-%m-%d')
        row=daily_map.get(day,{})
        daily.append({"day":day,"label":datetime.fromtimestamp(ts/1000).strftime('%d/%m'),"packets":int(row.get('packets') or 0),"nodes":int(row.get('nodes') or 0)})

    traces = topology.get("traces", []) or []
    forward=ret=roundtrip=incomplete=0; hop_samples=[]
    for tr in traces:
        fh=_trace_leg_hops(tr.get('forwardPath')); rh=_trace_leg_hops(tr.get('returnPath'))
        if fh is not None: forward += 1; hop_samples.append(fh)
        if rh is not None: ret += 1; hop_samples.append(rh)
        if fh is not None and rh is not None: roundtrip += 1
        if fh is None or rh is None: incomplete += 1
    avg_hops = round(sum(hop_samples)/len(hop_samples),2) if hop_samples else None
    med_hops = round(float(statistics.median(hop_samples)),2) if hop_samples else None

    edges=topology.get('edges',[]) or []
    recent_edges=sum(1 for e in edges if int(e.get('lastSeenMs') or 0)>=cutoff24)
    attention=[]
    for num, info in nodes.items():
        ts=int(info.get('lastSeen') or 0)
        if ts and ts>=cutoff24: continue
        seven=by_node7.get(num,{})
        attention.append({"nodeNum":num,"nodeId":info.get('nodeId'),"name":info.get('name'),"lastSeen":ts or None,"packets7d":int(seven.get('packets') or 0),"avgSnr7d":round(float(seven['avgSnr']),2) if seven.get('avgSnr') is not None else None})
    attention.sort(key=lambda x: (x['lastSeen'] is None, x['lastSeen'] or 0))
    attention=attention[:25]
    total_tr=len(traces)
    return {"success":True,"generatedAtMs":now,"nodes":{"total":len(nodes),"active2h":active2,"active24h":active24,"active7d":active7,"silent24h":silent24,"noTraffic":no_traffic},"traffic":{"packets24h":int(r24['total'] or 0),"rx24h":int(r24['rx'] or 0),"tx24h":int(r24['tx'] or 0)},"links":{"observed":len(edges),"recent24h":recent_edges},"traceroutes":{"total":total_tr,"forward":forward,"return":ret,"roundTrip":roundtrip,"incomplete":incomplete,"roundTripRate":round(100*roundtrip/total_tr,2) if total_tr else 0,"avgHops":avg_hops,"medianHops":med_hops},"daily":daily,"chatInteractions":chat_interactions,"attentionNodes":attention}


def _path_signature(path):
    if not isinstance(path,list) or len(path)<2: return None
    vals=[]
    for p in path:
        if isinstance(p,dict): vals.append(str(p.get('nodeNum') or p.get('nodeId') or p.get('name') or '?'))
        else: vals.append(str(p))
    return ' > '.join(vals)


def _anomalies():
    now=int(time.time()*1000); topology=_load_topology_safe(); nodes=_node_last_seen_map(topology); data=[]
    cutoff24=now-24*3600*1000
    for num,info in nodes.items():
        ts=int(info.get('lastSeen') or 0)
        if ts<=0: continue
        age=now-ts
        if age>7*86400*1000:
            data.append({"severity":"critical","type":"node_silent","title":"Nó silencioso há mais de 7 dias","subject":info.get('name') or info.get('nodeId'),"message":"Não há tráfego recente deste nó no histórico disponível.","evidence":f"Última observação: {datetime.fromtimestamp(ts/1000).strftime('%d/%m/%Y %H:%M')}","timestampMs":ts})
        elif age>24*3600*1000:
            data.append({"severity":"warning","type":"node_silent","title":"Nó silencioso há mais de 24 h","subject":info.get('name') or info.get('nodeId'),"message":"O nó ultrapassou a janela de 24 horas sem tráfego observado.","evidence":f"Última observação: {datetime.fromtimestamp(ts/1000).strftime('%d/%m/%Y %H:%M')}","timestampMs":ts})

    for e in topology.get('edges',[]) or []:
        recent=[]; prev=[]
        for ev in e.get('events',[]) or []:
            sn=ev.get('snr'); ts=int(ev.get('timestampMs') or 0)
            if sn is None: continue
            try: sn=float(sn)
            except Exception: continue
            if ts>=cutoff24: recent.append(sn)
            elif ts>=now-48*3600*1000: prev.append(sn)
        if len(recent)>=2 and len(prev)>=2:
            a=sum(recent)/len(recent); b=sum(prev)/len(prev); delta=a-b
            if delta<=-4.0:
                data.append({"severity":"warning" if delta>-8 else "critical","type":"snr_degradation","title":"Queda de SNR no enlace","subject":f"{e.get('aName') or e.get('aId')} ↔ {e.get('bName') or e.get('bId')}","message":f"SNR médio caiu {abs(delta):.1f} dB entre as duas janelas de 24 h.","evidence":f"Anterior: {b:.1f} dB · Atual: {a:.1f} dB · amostras {len(prev)}/{len(recent)}","timestampMs":int(e.get('lastSeenMs') or now)})

    groups={}
    for tr in topology.get('traces',[]) or []:
        a=tr.get('fromNodeNum'); b=tr.get('toNodeNum')
        if a is None or b is None: continue
        key=(int(a),int(b)); groups.setdefault(key,[]).append(tr)
    for key,arr in groups.items():
        arr=sorted(arr,key=lambda x:int(x.get('timestampMs') or 0))
        latest=arr[-1]; fh=_trace_leg_hops(latest.get('forwardPath')); rh=_trace_leg_hops(latest.get('returnPath'))
        subj=f"{latest.get('fromName')} → {latest.get('toName')}"
        if (fh is None) != (rh is None):
            data.append({"severity":"info","type":"asymmetric_trace","title":"Traceroute assimétrico","subject":subj,"message":"A observação mais recente contém apenas um dos sentidos do traceroute.","evidence":f"Ida: {'sem rota' if fh is None else str(fh)+' hops'} · Volta: {'sem rota' if rh is None else str(rh)+' hops'}","timestampMs":int(latest.get('timestampMs') or now)})
        current=fh if fh is not None else rh
        historical=[]
        for tr in arr[:-1][-12:]:
            h=_trace_leg_hops(tr.get('forwardPath'))
            if h is None: h=_trace_leg_hops(tr.get('returnPath'))
            if h is not None: historical.append(h)
        if current is not None and len(historical)>=2:
            base=float(statistics.median(historical)); diff=current-base
            if abs(diff)>=2:
                data.append({"severity":"warning","type":"route_hops_change","title":"Mudança relevante de hops","subject":subj,"message":f"O traceroute mais recente mudou {diff:+.0f} hops em relação à mediana recente.","evidence":f"Atual: {current} hops · mediana anterior: {base:.1f} · {_path_signature(latest.get('forwardPath') or latest.get('returnPath')) or ''}","timestampMs":int(latest.get('timestampMs') or now)})

    rank={'critical':0,'warning':1,'info':2}
    data.sort(key=lambda x:(rank.get(x['severity'],9),-int(x.get('timestampMs') or 0)))
    summary={"total":len(data),"critical":sum(1 for x in data if x['severity']=='critical'),"warning":sum(1 for x in data if x['severity']=='warning'),"info":sum(1 for x in data if x['severity']=='info')}
    return {"success":True,"generatedAtMs":now,"summary":summary,"data":data[:100],"method":"Heurísticas sobre silêncio, SNR e traceroutes; resultados devem ser interpretados com contexto RF."}


def _archive_dump_zip():
    """Build a ZIP containing one valid JSON document with every archived packet.

    JSON is written directly into the compressed member in SQLite batches, so
    the complete archive is never materialized in RAM. Direct text messages are
    already redacted by _sanitize_packet before persistence.
    """
    generated = datetime.now().astimezone()
    stamp = generated.strftime("%Y-%m-%d_%H%M%S")
    download_name = f"traffic-analyzer-dump-{stamp}.zip"
    fd, tmp_name = tempfile.mkstemp(prefix="traffic-analyzer-dump-", suffix=".zip")
    os.close(fd)
    tmp_path = Path(tmp_name)
    try:
        with _archive_connect() as conn:
            stats = conn.execute(
                "SELECT COUNT(*) AS n, MIN(timestamp) AS first_ts, MAX(timestamp) AS last_ts FROM packets"
            ).fetchone()
            metadata = {
                "traffic_analyzer_version": APP_VERSION,
                "generated_at": generated.isoformat(timespec="seconds"),
                "source_id": MM_SOURCE,
                "packet_count": int(stats["n"] or 0),
                "first_packet_timestamp": stats["first_ts"],
                "last_packet_timestamp": stats["last_ts"],
                "archive_schema_version": 1,
                "privacy": "Direct TEXT_MESSAGE_APP payloads are redacted before archival.",
            }
            cursor = conn.execute("SELECT * FROM packets ORDER BY timestamp ASC, archive_id ASC")
            with zipfile.ZipFile(tmp_path, "w", compression=zipfile.ZIP_DEFLATED,
                                 compresslevel=6, allowZip64=True) as zf:
                with zf.open("traffic.json", "w", force_zip64=True) as member:
                    member.write(b'{"export":')
                    member.write(json.dumps(metadata, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
                    member.write(b',"packets":[')
                    first = True
                    while True:
                        rows = cursor.fetchmany(1000)
                        if not rows:
                            break
                        for row in rows:
                            if not first:
                                member.write(b',')
                            first = False
                            packet = _archive_row_to_dict(row)
                            member.write(json.dumps(packet, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
                    member.write(b']}')
        return tmp_path, download_name
    except Exception:
        try:
            tmp_path.unlink(missing_ok=True)
        except Exception:
            pass
        raise


def _haversine_m(lat1, lon1, lat2, lon2):
    import math
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2-lat1); dl = math.radians(lon2-lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*r*math.atan2(math.sqrt(a), math.sqrt(max(0.0,1-a)))


def _tracklog_query(hours: int = 24):
    hours = max(1, min(int(hours or 24), 24*30))
    cutoff = int(time.time()*1000) - hours*3600*1000
    with _archive_connect() as conn:
        rows = conn.execute("""
          SELECT node_num,node_id,node_name,timestamp,latitude,longitude,altitude,snr,rssi
          FROM positions WHERE source_id=? AND timestamp>=?
          ORDER BY node_num,timestamp ASC
        """, (MM_SOURCE, cutoff)).fetchall()
    by_node = {}
    for row in rows:
        n = int(row["node_num"])
        by_node.setdefault(n, []).append(row)
    tracks=[]
    try:
        top=json.loads(TOPOLOGY_FILE.read_text(encoding="utf-8"))
    except Exception:
        top={}
    node_meta={int(n.get("nodeNum")):n for n in (top.get("nodes") or []) if n.get("nodeNum") is not None}
    total_points=0
    for node_num, pts in by_node.items():
        cleaned=[]; distance=0.0; last=None
        for row in pts:
            lat=float(row["latitude"]); lon=float(row["longitude"]); ts=int(row["timestamp"])
            if last:
                d=_haversine_m(last["lat"],last["lon"],lat,lon)
                dt=max(1,(ts-last["timestampMs"])/1000.0)
                speed_kmh=(d/dt)*3.6
                # elimina jitter submétrico e saltos manifestamente incompatíveis com deslocamento terrestre
                if d < 3.0:
                    continue
                if speed_kmh > 300.0 and d > 5000.0:
                    continue
                distance += d
            point={"timestampMs":ts,"lat":lat,"lon":lon,"altitude":row["altitude"],"snr":row["snr"],"rssi":row["rssi"]}
            cleaned.append(point); last=point
        if len(cleaned)<2 or distance<100.0:
            continue
        meta=node_meta.get(node_num) or {}
        name=meta.get("name") or meta.get("longName") or (pts[-1]["node_name"] if pts else None) or meta.get("nodeId") or f"!{node_num & 0xffffffff:08x}"
        short=meta.get("shortName") or ""
        node_id=meta.get("nodeId") or (pts[-1]["node_id"] if pts else None) or f"!{node_num & 0xffffffff:08x}"
        # proteção de resposta: amostra no máximo ~2500 pontos por nó
        if len(cleaned)>2500:
            step=max(1,len(cleaned)//2500)
            sampled=cleaned[::step]
            if sampled[-1] is not cleaned[-1]: sampled.append(cleaned[-1])
            cleaned=sampled
        total_points += len(cleaned)
        tracks.append({"nodeNum":node_num,"nodeId":node_id,"name":name,"shortName":short,"pointCount":len(cleaned),"distanceMeters":round(distance,1),"firstTimestampMs":cleaned[0]["timestampMs"],"lastTimestampMs":cleaned[-1]["timestampMs"],"points":cleaned})
    tracks.sort(key=lambda t:(-t["distanceMeters"],str(t["name"])))
    return {"success":True,"hours":hours,"generatedAtMs":int(time.time()*1000),"trackCount":len(tracks),"pointCount":total_points,"tracks":tracks}


def _coverage_rf_query(hours: int = 24):
    hours = max(1, min(int(hours or 24), 24 * 30))
    cutoff = int(time.time() * 1000) - hours * 3600 * 1000
    with _archive_connect() as conn:
        rows = conn.execute("""
          SELECT node_num,node_id,node_name,timestamp,latitude,longitude,snr,rssi
          FROM positions
          WHERE source_id=? AND timestamp>=? AND (snr IS NOT NULL OR rssi IS NOT NULL)
          ORDER BY timestamp DESC
          LIMIT 12000
        """, (MM_SOURCE, cutoff)).fetchall()
    points=[]
    for row in rows:
        try:
            lat=float(row["latitude"]); lon=float(row["longitude"])
        except Exception:
            continue
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            continue
        points.append({
            "nodeNum": int(row["node_num"]), "nodeId": row["node_id"], "name": row["node_name"],
            "timestampMs": int(row["timestamp"]), "lat": lat, "lon": lon,
            "snr": row["snr"], "rssi": row["rssi"],
        })
    # Amostragem espacial/temporal simples para manter o navegador leve.
    if len(points) > 5000:
        step=max(1, len(points)//5000); points=points[::step][:5000]
    return {"success": True, "hours": hours, "count": len(points), "points": points}


def _http_json(url: str, headers=None, timeout=15):
    req=urllib.request.Request(url, headers={"Accept":"application/json", "User-Agent":f"TrafficAnalyzer/{APP_VERSION}", **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _clouds_meta():
    if not RAINBOW_API_TOKEN:
        raise RuntimeError("TA_RAINBOW_API_TOKEN não configurado")
    token=urllib.parse.quote(RAINBOW_API_TOKEN, safe="")
    body=_http_json(f"https://api.rainbow.ai/tiles/v1/snapshot?layer=clouds&token={token}")
    snapshot=int(body.get("snapshot") or 0)
    if snapshot <= 0:
        raise RuntimeError("snapshot de nuvens indisponível")
    return {"success": True, "snapshot": snapshot}


def _cloud_tile(snapshot: int, z: int, x: int, y: int):
    if not RAINBOW_API_TOKEN:
        raise RuntimeError("TA_RAINBOW_API_TOKEN não configurado")
    token=urllib.parse.quote(RAINBOW_API_TOKEN, safe="")
    url=f"https://api.rainbow.ai/tiles/v1/clouds/{int(snapshot)}/{int(z)}/{int(x)}/{int(y)}?token={token}"
    req=urllib.request.Request(url, headers={"Accept":"image/png","User-Agent":f"TrafficAnalyzer/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return resp.read()


def _elevation_tile(z: int, x: int, y: int):
    z=int(z);x=int(x);y=int(y)
    if z < 0 or z > 15:
        raise ValueError("zoom de elevação fora do intervalo suportado")
    limit=1 << z
    x=x % limit
    if y < 0 or y >= limit:
        raise ValueError("tile de elevação fora dos limites")
    url=f"{ELEVATION_TILE_BASE_URL}/{z}/{x}/{y}.png"
    req=urllib.request.Request(url, headers={"Accept":"image/png","User-Agent":f"TrafficAnalyzer/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw=resp.read(2_000_000)
        ctype=str(resp.headers.get("Content-Type") or "").lower()
    if len(raw) < 8 or raw[:8] != b"\x89PNG\r\n\x1a\n":
        raise RuntimeError(f"tile DEM inválido ({ctype or 'sem Content-Type'})")
    return raw


def _lightning_query(south, west, north, east, minutes=60):
    if not LIGHTNING_API_KEY:
        raise RuntimeError("TA_LIGHTNING_API_KEY não configurado")
    params=urllib.parse.urlencode({
        "since_minutes": max(5,min(int(minutes or 60),120)),
        "min_lat": float(south), "max_lat": float(north),
        "min_lon": float(west), "max_lon": float(east),
    })
    body=_http_json("https://api.lightningapi.dev/v1/flashes?"+params, headers={"X-API-Key": LIGHTNING_API_KEY})
    rows=body.get("flashes") if isinstance(body,dict) else body
    rows=rows if isinstance(rows,list) else []
    now=time.time(); out=[]
    for row in rows[:3000]:
        if not isinstance(row,dict): continue
        lat=row.get("latitude",row.get("lat")); lon=row.get("longitude",row.get("lon"))
        try: lat=float(lat); lon=float(lon)
        except Exception: continue
        ts=row.get("timestamp",row.get("time",row.get("timestamp_ms")))
        try:
            t=float(ts or 0); t=t/1000.0 if t>10_000_000_000 else t
        except Exception: t=now
        out.append({"lat":lat,"lon":lon,"ageMinutes":max(0,(now-t)/60.0),"timestampMs":int(t*1000)})
    return {"success":True,"count":len(out),"flashes":out}


def _cap_text(el, tag):
    for child in el.iter():
        if str(child.tag).split("}")[-1] == tag:
            return (child.text or "").strip()
    return ""


def _weather_alerts_inmet():
    if not INMET_ALERTS_URL:
        raise RuntimeError("TA_INMET_ALERTS_URL não configurado")
    req=urllib.request.Request(INMET_ALERTS_URL, headers={"Accept":"application/xml, text/xml, application/json","User-Agent":f"TrafficAnalyzer/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        raw=resp.read()
        ctype=str(resp.headers.get("Content-Type") or "").lower()
    alerts=[]
    if "json" in ctype or raw.lstrip().startswith((b"{",b"[")):
        data=json.loads(raw.decode("utf-8"))
        rows=data.get("avisos",data.get("alerts",data)) if isinstance(data,dict) else data
        for row in (rows if isinstance(rows,list) else []):
            if not isinstance(row,dict): continue
            polygons=[]
            poly=row.get("polygon") or row.get("poligono")
            if isinstance(poly,str):
                pts=[]
                for pair in re.split(r"\s+",poly.strip()):
                    try:
                        lat,lon=pair.split(",",1); pts.append([float(lat),float(lon)])
                    except Exception: pass
                if len(pts)>=3: polygons.append(pts)
            alerts.append({"identifier":row.get("identifier") or row.get("id") or row.get("codigo"),"event":row.get("evento") or row.get("event"),"severity":row.get("severidade") or row.get("severity"),"headline":row.get("headline") or row.get("titulo"),"description":row.get("descricao") or row.get("description"),"areaDesc":row.get("areaDesc") or row.get("area") or row.get("areas") or row.get("municipios"),"expires":row.get("fim") or row.get("expires"),"polygons":polygons})
    else:
        import xml.etree.ElementTree as ET
        root=ET.fromstring(raw)
        candidates=[x for x in root.iter() if str(x.tag).split("}")[-1]=="alert"]
        if not candidates and str(root.tag).split("}")[-1]=="alert": candidates=[root]
        for alert in candidates:
            info=next((x for x in alert.iter() if str(x.tag).split("}")[-1]=="info"), alert)
            polygons=[]
            area_desc=[]
            for area in [x for x in info.iter() if str(x.tag).split("}")[-1]=="area"]:
                desc=_cap_text(area,"areaDesc")
                if desc: area_desc.append(desc)
                for pol in [x for x in area.iter() if str(x.tag).split("}")[-1]=="polygon"]:
                    pts=[]
                    for pair in re.split(r"\s+",(pol.text or "").strip()):
                        try:
                            lat,lon=pair.split(",",1); pts.append([float(lat),float(lon)])
                        except Exception: pass
                    if len(pts)>=3: polygons.append(pts)
            alerts.append({"identifier":_cap_text(alert,"identifier"),"event":_cap_text(info,"event"),"severity":_cap_text(info,"severity"),"headline":_cap_text(info,"headline"),"description":_cap_text(info,"description"),"areaDesc":"; ".join(area_desc),"expires":_cap_text(info,"expires"),"polygons":polygons})
    return {"success":True,"source":"INMET","count":len(alerts),"alerts":alerts}


def _read_json_file(path: Path, default):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else dict(default)
    except Exception:
        return dict(default)


def _write_json_file(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
    with tmp.open("w",encoding="utf-8") as output:
        output.write(json.dumps(data,ensure_ascii=False,indent=2)+"\n")
        output.flush();os.fsync(output.fileno())
    os.replace(tmp, path)


UI_DEFAULT_BOOLEAN_KEYS = {
    "onlyIdentified", "showShortNames", "showLines", "showNodes", "showHeatmap",
    "soundEnabled", "soundRoutingEnabled", "soundMessagesEnabled", "soundAlertsEnabled",
    "soundStereoEnabled", "activityAnimationEnabled", "activityOriginEnabled",
    "activityRelayEnabled", "autoZoomTraceroute", "nodeInfoFlowEnabled",
    "messageBold", "messageItalic", "messageUnderline", "weatherRadarEnabled",
    "rfCoverageEnabled", "hillshadeEnabled", "elevationEnabled", "lightningEnabled", "alertsEnabled", "cloudsEnabled",
}


def _sanitize_ui_defaults(raw: dict) -> dict:
    if not isinstance(raw, dict):
        return {}
    out = {}
    if str(raw.get("ageHours")) in {"all", "1", "6", "12", "24", "168", "720"}:
        out["ageHours"] = str(raw.get("ageHours"))
    try:
        v = int(raw.get("minObs"))
        if 1 <= v <= 100000:
            out["minObs"] = v
    except (TypeError, ValueError):
        pass
    for key in UI_DEFAULT_BOOLEAN_KEYS:
        if isinstance(raw.get(key), bool):
            out[key] = raw[key]
    if raw.get("mapType") in {"osm", "topo", "light", "dark", "satellite"}:
        out["mapType"] = raw["mapType"]
    try:
        v = int(raw.get("brightness"))
        if 30 <= v <= 150:
            out["brightness"] = v
    except (TypeError, ValueError):
        pass
    try:
        v = int(raw.get("elevationThreshold"))
        if 0 <= v <= 9000:
            out["elevationThreshold"] = v
    except (TypeError, ValueError):
        pass
    try:
        v = int(raw.get("elevationSliderMax"))
        if 100 <= v <= 9000:
            out["elevationSliderMax"] = v
    except (TypeError, ValueError):
        pass
    try:
        v = int(raw.get("elevationOpacity"))
        if 10 <= v <= 100:
            out["elevationOpacity"] = v
    except (TypeError, ValueError):
        pass
    for key in ("rfLineColor", "mqttLineColor", "lineColor"):
        color = str(raw.get(key) or "")
        if re.fullmatch(r"#[0-9a-fA-F]{6}", color):
            out[key] = color.lower()
    for key, lo, hi in [("rfLineWidth", 1, 8), ("mqttLineWidth", 1, 8), ("lineWidth", 1, 8), ("soundVolume", 0, 100), ("soundMinInterval", 40, 800), ("soundMaxVoices", 1, 8), ("messageFontSize", 10, 20), ("messageRowGap", 1, 14)]:
        try:
            v = int(raw.get(key))
            if lo <= v <= hi:
                out[key] = v
        except (TypeError, ValueError):
            pass
    if raw.get("animSpeed") in {80, 150, 280, 500}:
        out["animSpeed"] = int(raw["animSpeed"])
    if raw.get("soundTheme") in {"pinball70", "formal", "radio", "silent"}:
        out["soundTheme"] = raw["soundTheme"]
    if raw.get("soundDensity") in {"low", "normal", "high"}:
        out["soundDensity"] = raw["soundDensity"]
    if raw.get("activityDuration") in {650, 1000, 1500, 2000}:
        out["activityDuration"] = int(raw["activityDuration"])
    if raw.get("messageFontFamily") in {"system", "arial", "verdana", "tahoma", "georgia", "mono"}:
        out["messageFontFamily"] = raw["messageFontFamily"]
    try:
        v = float(raw.get("messageLineHeight"))
        if 1.10 <= v <= 2.00:
            out["messageLineHeight"] = round(v, 2)
    except (TypeError, ValueError):
        pass
    if raw.get("uiTheme") in {"dark", "light"}:
        out["uiTheme"] = raw["uiTheme"]
    out["defaultsVersion"] = 420
    return out


def _ui_defaults_record() -> dict:
    raw = _read_json_file(UI_DEFAULTS_FILE, {})
    prefs = raw.get("prefs") if isinstance(raw.get("prefs"), dict) else raw
    return {
        "defaults": _sanitize_ui_defaults(prefs),
        "updatedAtMs": raw.get("updatedAtMs") if isinstance(raw, dict) else None,
    }


def _save_ui_defaults(payload: dict) -> dict:
    prefs_raw = payload.get("prefs") if isinstance(payload, dict) else None
    prefs = _sanitize_ui_defaults(prefs_raw if isinstance(prefs_raw, dict) else {})
    if not prefs:
        raise ValueError("Nenhuma preferência visual válida foi informada.")
    data = {"prefs": prefs, "updatedAtMs": int(time.time() * 1000)}
    _write_json_file(UI_DEFAULTS_FILE, data)
    return {"defaults": prefs, "updatedAtMs": data["updatedAtMs"]}


def _normalize_version_check_interval_minutes(value):
    try:
        minutes = int(round(float(value)))
    except (TypeError, ValueError):
        minutes = VERSION_CHECK_DEFAULT_MINUTES
    return max(VERSION_CHECK_MIN_MINUTES, min(VERSION_CHECK_MAX_MINUTES, minutes))


def _update_settings():
    raw = _read_json_file(UPDATE_SETTINGS_FILE, {
        "enabled": True,
        "rollbackEnabled": True,
        "checkIntervalMinutes": VERSION_CHECK_DEFAULT_MINUTES,
    })
    return {
        # A partir da v1.48.0, updates estáveis oficiais são sempre automáticos.
        "enabled": True,
        "rollbackEnabled": bool(raw.get("rollbackEnabled", True)),
        "checkIntervalMinutes": _normalize_version_check_interval_minutes(raw.get("checkIntervalMinutes")),
    }


def _save_update_settings(payload: dict):
    current = _update_settings()
    data = {
        "enabled": True,
        "rollbackEnabled": bool(payload.get("rollbackEnabled", True)),
        "checkIntervalMinutes": _normalize_version_check_interval_minutes(payload.get("checkIntervalMinutes", current["checkIntervalMinutes"])),
        "updatedAtMs": int(time.time() * 1000),
    }
    _write_json_file(UPDATE_SETTINGS_FILE, data)
    return data


def _local_release_notes(version: str = APP_VERSION):
    path = Path(__file__).with_name("CHANGELOG.md")
    notes = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
        active = False
        prefix = f"## {version}"
        prefix_v = f"## v{version}"
        for line in lines:
            stripped = line.strip()
            if not active and (stripped.startswith(prefix) or stripped.startswith(prefix_v)):
                active = True
                continue
            if active and stripped.startswith("## "):
                break
            if active and stripped.startswith("- "):
                notes.append(stripped[2:].strip())
    except Exception:
        pass
    return notes


def _current_release_info():
    return {
        "success": True,
        "version": APP_VERSION,
        "notes": _local_release_notes(APP_VERSION),
        "releaseUrl": f"https://github.com/alexpmr/traffic-analyzer/releases/tag/v{APP_VERSION}",
        "lastInstall": _read_json_file(LAST_INSTALL_FILE, {}),
    }


def _update_runtime_status():
    settings = _update_settings()
    status = _read_json_file(UPDATE_STATUS_FILE, {"state": "idle"})
    status["settings"] = settings
    status["localVersion"] = APP_VERSION
    status["lastInstall"] = _read_json_file(LAST_INSTALL_FILE, {})
    return status


def _request_update(version_data=None, reason: str = "manual"):
    data = version_data or _version_status(force=True)
    if not data.get("success") or data.get("status") == "unavailable":
        raise RuntimeError(data.get("message") or "Não foi possível consultar a Latest Release")
    if not data.get("stable", True):
        raise RuntimeError("A Latest Release consultada não é estável")
    if not data.get("updateAvailable"):
        return {"success": True, "requested": False, "message": "Nenhuma atualização disponível.", "status": _update_runtime_status()}
    settings = _update_settings()
    now_ms = int(time.time() * 1000)
    request = {
        "requestedAtMs": now_ms,
        "requestedBy": reason,
        "targetVersion": data.get("latestVersion"),
        "rollbackEnabled": bool(settings.get("rollbackEnabled", True)),
    }
    _write_json_file(UPDATE_REQUEST_FILE, request)
    _write_json_file(UPDATE_STATUS_FILE, {
        "state": "pending",
        "targetVersion": data.get("latestVersion"),
        "previousVersion": APP_VERSION,
        "requestedAtMs": now_ms,
        "requestedBy": reason,
        "message": "Solicitação de atualização enviada.",
    })
    return {"success": True, "requested": True, "message": "Solicitação de atualização enviada.", "targetVersion": data.get("latestVersion"), "status": _update_runtime_status()}


def _maybe_request_auto_update(version_data: dict):
    settings = _update_settings()
    if not version_data.get("updateAvailable") or not version_data.get("stable", True):
        return
    target = str(version_data.get("latestVersion") or "")
    status = _read_json_file(UPDATE_STATUS_FILE, {})
    state = str(status.get("state") or "")
    if str(status.get("targetVersion") or "") == target:
        if state in {"pending", "running"}:
            started = float(status.get("startedAtMs") or status.get("requestedAtMs") or 0) / 1000.0
            limit = AUTO_UPDATE_PENDING_STALE_SECONDS if state == "pending" else AUTO_UPDATE_RUNNING_STALE_SECONDS
            if started and time.time() - started < limit:
                return
        if state in {"failed", "rolled_back"}:
            completed = float(status.get("completedAtMs") or 0) / 1000.0
            if completed and time.time() - completed < AUTO_UPDATE_RETRY_BACKOFF_SECONDS:
                return
    try:
        _request_update(version_data=version_data, reason="automatic")
    except Exception as exc:
        _write_json_file(UPDATE_STATUS_FILE, {
            "state": "failed",
            "targetVersion": target,
            "previousVersion": APP_VERSION,
            "completedAtMs": int(time.time() * 1000),
            "requestedBy": "automatic",
            "message": str(exc),
        })


def _automatic_update_watch_worker():
    """Detecta releases estáveis em background, sem depender de navegador/login."""
    if _update_watch_stop.wait(15):
        return
    while not _update_watch_stop.is_set():
        try:
            version_data = _version_status(force=False)
            _maybe_request_auto_update(version_data)
        except Exception as exc:
            print(f"Monitor de atualização automática: {exc}", flush=True)
        minutes = _update_settings().get("checkIntervalMinutes", VERSION_CHECK_DEFAULT_MINUTES)
        wait_seconds = max(60, _normalize_version_check_interval_minutes(minutes) * 60)
        if _update_watch_stop.wait(wait_seconds):
            break


def _version_tuple(value: str):
    raw = str(value or "").strip().lower()
    if raw.startswith("v"):
        raw = raw[1:]
    out = []
    for part in raw.split(".")[:4]:
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits or 0))
    while len(out) < 4:
        out.append(0)
    return tuple(out)


def _version_status(force: bool = False):
    now = time.time()
    cache_ttl_seconds = _update_settings()["checkIntervalMinutes"] * 60
    with _version_status_lock:
        cached = _version_status_cache.get("data")
        checked_at = float(_version_status_cache.get("checked_at") or 0)
        if cached and not force and now - checked_at < cache_ttl_seconds:
            return dict(cached)

        req = urllib.request.Request(
            GITHUB_RELEASES_LATEST_URL,
            headers={
                "Accept": "application/vnd.github+json",
                "User-Agent": f"Traffic-Analyzer/{APP_VERSION}",
                "X-GitHub-Api-Version": "2022-11-28",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=8) as resp:
                release = json.loads(resp.read().decode("utf-8"))
            tag = str(release.get("tag_name") or "").strip()
            latest = tag[1:] if tag.lower().startswith("v") else tag
            if not latest:
                raise RuntimeError("Release Latest sem tag de versão")
            wanted = f"traffic-analyzer-v{latest}.zip"
            assets = release.get("assets") if isinstance(release.get("assets"), list) else []
            asset = next((a for a in assets if isinstance(a, dict) and a.get("name") == wanted), None)
            if not asset:
                asset = next((a for a in assets if isinstance(a, dict) and a.get("name") == "traffic-analyzer-latest.zip"), None)
            download_url = str(asset.get("browser_download_url") or "") if isinstance(asset, dict) else ""
            data = {
                "success": True,
                "status": "ok",
                "localVersion": APP_VERSION,
                "latestVersion": latest,
                "updateAvailable": _version_tuple(latest) > _version_tuple(APP_VERSION),
                "releaseUrl": release.get("html_url"),
                "downloadUrl": download_url,
                "downloadName": asset.get("name") if isinstance(asset, dict) else None,
                "publishedAt": release.get("published_at"),
                "notes": str(release.get("body") or "").strip(),
                "stable": not bool(release.get("draft")) and not bool(release.get("prerelease")),
                "checkedAtMs": int(now * 1000),
            }
            _version_status_cache["checked_at"] = now
            _version_status_cache["data"] = dict(data)
            return data
        except Exception as exc:
            if cached:
                stale = dict(cached)
                stale["status"] = "stale"
                stale["message"] = f"Falha na consulta atual; exibindo último resultado conhecido: {exc}"
                return stale
            return {
                "success": False,
                "status": "unavailable",
                "localVersion": APP_VERSION,
                "latestVersion": None,
                "updateAvailable": False,
                "releaseUrl": "https://github.com/alexpmr/traffic-analyzer/releases/latest",
                "downloadUrl": "",
                "downloadName": None,
                "publishedAt": None,
                "notes": "",
                "message": str(exc),
                "checkedAtMs": int(now * 1000),
            }


def _refresh_topology_now():
    if not _topology_refresh_lock.acquire(blocking=False):
        return {"success": False, "busy": True, "message": "Atualização de topologia já está em andamento."}
    try:
        script = Path(__file__).with_name("traffic_analyzer.py")
        proc = subprocess.run([sys.executable, str(script), "--topology-only"], capture_output=True, text=True, timeout=90, env=os.environ.copy())
        if proc.returncode != 0:
            detail = (proc.stderr or proc.stdout or "falha sem detalhes").strip()
            raise RuntimeError(detail[-1800:])
        updated_ms = int(TOPOLOGY_FILE.stat().st_mtime * 1000) if TOPOLOGY_FILE.exists() else int(time.time()*1000)
        _topology_history_drain_queue()
        _topology_history_ingest_current()
        return {"success": True, "updatedAtMs": updated_ms, "message": "Topologia atualizada e memória histórica preservada."}
    finally:
        _topology_refresh_lock.release()


class Handler(BaseHTTPRequestHandler):
    server_version = f"TrafficAnalyzer/{APP_VERSION}"

    def _send(self, status, content_type, body: bytes, extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header("Permissions-Policy", "geolocation=(), camera=(), microphone=()")
        for key, value in (extra_headers or {}).items():
            self.send_header(str(key), str(value))
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path, content_type: str, download_name: str):
        size = path.stat().st_size
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(size))
        self.send_header("Content-Disposition", f'attachment; filename="{download_name}"')
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        with path.open("rb") as src:
            while True:
                chunk = src.read(1024 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        spa_roots = {"/", "/index.html", "/mapa", "/nos", "/trafego", "/mensagens", "/estatisticas", "/automacoes", "/configuracoes", "/ajuda"}
        spa_prefixes = ("/mapa/", "/nos/", "/mensagens/", "/estatisticas/", "/automacoes/")
        if path in spa_roots or path.startswith(spa_prefixes):
            _record_access_event(self, event="pageview", status=200, path=path)
            self._send(200, "text/html; charset=utf-8", HTML.encode("utf-8"))
            return
        if path == "/api/automations":
            if AUTH_ENABLED and not _auth_session(self):
                self._send(401, "application/json; charset=utf-8",
                           json.dumps({"success": False, "message": "Faça login para revisar as automações."}).encode("utf-8"))
                return
            try:
                body = {"success": True, "settings": _automation_settings(),
                        "globalEnabled": MESH_COMMANDS_ENABLED,
                        "liveStatus": _mesh_command_live_status(),
                        "items": [{"id": "ping", "name": "PING"}, {"id": "clima", "name": "CLIMA"}],
                        "events": _automation_events(60),
                        "firmwareNotices":{"settings":_automatic_notice_settings(),"state":_automatic_notice_state()},
                        "homeAssistant":_home_assistant_public()}
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/automations/events":
            if AUTH_ENABLED and not _auth_session(self):
                self._send(401, "application/json; charset=utf-8",
                           json.dumps({"success": False, "message": "Faça login para consultar o histórico."}).encode("utf-8"))
                return
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                bot = (query.get("bot") or [""])[0]
                limit = int((query.get("limit") or ["80"])[0])
                body = {"success": True, "events": _automation_events(limit, bot)}
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/automations_ui.js":
            try:
                self._send(200, "application/javascript; charset=utf-8",
                           Path(__file__).with_name("automations_ui.js").read_bytes())
            except OSError:
                self._send(503, "text/plain; charset=utf-8", b"Frontend de automacoes indisponivel")
            return
        if path == "/api/auth/status":
            self._send(200, "application/json; charset=utf-8", json.dumps(_auth_status(self), ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/layers/rf-coverage":
            try:
                query=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                hours=int((query.get("hours") or ["24"])[0])
                body=_coverage_rf_query(hours)
                self._send(200,"application/json; charset=utf-8",json.dumps(body,ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/layers/clouds/meta":
            try:
                body=_clouds_meta()
                self._send(200,"application/json; charset=utf-8",json.dumps(body,ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(503,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path.startswith("/api/layers/clouds/tile/"):
            try:
                parts=path.strip("/").split("/")
                snapshot,z,x,y=map(int,parts[-4:])
                raw=_cloud_tile(snapshot,z,x,y)
                self._send(200,"image/png",raw)
            except Exception as e:
                self._send(502,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path.startswith("/api/layers/elevation/tile/"):
            try:
                parts=path.strip("/").split("/")
                z,x,y=map(int,parts[-3:])
                raw=_elevation_tile(z,x,y)
                self._send(200,"image/png",raw)
            except Exception as e:
                self._send(502,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/layers/lightning":
            try:
                query=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                vals={k:float((query.get(k) or ["0"])[0]) for k in ("south","west","north","east")}
                minutes=int((query.get("minutes") or ["60"])[0])
                body=_lightning_query(vals["south"],vals["west"],vals["north"],vals["east"],minutes)
                self._send(200,"application/json; charset=utf-8",json.dumps(body,ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(503,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/layers/weather-alerts":
            try:
                body=_weather_alerts_inmet()
                self._send(200,"application/json; charset=utf-8",json.dumps(body,ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(503,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/automatic-notices":
            try:
                body={"success":True,"settings":_automatic_notice_settings(),"state":_automatic_notice_state()}
                self._send(200,"application/json; charset=utf-8",json.dumps(body,ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/ui-defaults":
            try:
                body = {"success": True, **_ui_defaults_record()}
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/version-status":
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                force = (query.get("force") or ["0"])[0] in {"1", "true", "yes"}
                body = _version_status(force=force)
                _maybe_request_auto_update(body)
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "status": "unavailable", "localVersion": APP_VERSION, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/update/status":
            try:
                self._send(200, "application/json; charset=utf-8", json.dumps({"success": True, **_update_runtime_status()}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/current-release-notes":
            self._send(200, "application/json; charset=utf-8", json.dumps(_current_release_info(), ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/access-stats":
            if AUTH_ENABLED and not _auth_session(self):
                self._send(401, "application/json; charset=utf-8", json.dumps({"success": False, "error": "authentication_required", "message": "Autenticação administrativa necessária."}, ensure_ascii=False).encode("utf-8"))
                return
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                days = int((query.get("days") or ["30"])[0])
                body = _access_stats(days)
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/access-log":
            if AUTH_ENABLED and not _auth_session(self):
                self._send(401, "application/json; charset=utf-8", json.dumps({"success": False, "error": "authentication_required", "message": "Autenticação administrativa necessária."}, ensure_ascii=False).encode("utf-8"))
                return
            try:
                if not ACCESS_LOG_FILE.exists():
                    ACCESS_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
                    ACCESS_LOG_FILE.touch()
                self._send_file(ACCESS_LOG_FILE, "application/x-ndjson; charset=utf-8", "traffic-analyzer-access.log")
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path in ("/api/topology", "/topology.json"):
            try:
                if not TOPOLOGY_FILE.exists():
                    raise FileNotFoundError(str(TOPOLOGY_FILE))
                body = _load_topology_safe()
                if not body:
                    raise RuntimeError("topology.json inválido ou memória histórica indisponível")
                raw = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                self._send(200, "application/json; charset=utf-8", raw)
            except FileNotFoundError:
                self._send(503, "application/json; charset=utf-8", json.dumps({
                    "error": "topology_not_ready",
                    "message": "topology.json ainda não foi gerado",
                }).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({
                    "error": "topology_invalid",
                    "message": str(e),
                }).encode("utf-8"))
            return
        if path == "/api/live-traceroutes":
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                limit = int((query.get("limit") or ["100"])[0])
                limit = max(1, min(limit, 200))
                rows = _live_traceroutes(limit)
                self._send(200, "application/json; charset=utf-8", json.dumps({
                    "success": True, "count": len(rows), "data": rows,
                }, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(502, "application/json; charset=utf-8", json.dumps({
                    "success": False, "error": "live_unavailable", "message": str(e),
                }, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/node-details":
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                node_num = (query.get("nodeNum") or [None])[0]
                body = _node_details(node_num)
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "error": "bad_node", "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(502, "application/json; charset=utf-8", json.dumps({"success": False, "error": "node_details_unavailable", "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/node-query-status":
            if AUTH_ENABLED and not _auth_session(self):
                self._send(401, "application/json; charset=utf-8", json.dumps({
                    "success": False,
                    "error": "authentication_required",
                    "message": "Autenticação administrativa necessária.",
                }, ensure_ascii=False).encode("utf-8"))
                return
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                query_id = (query.get("queryId") or [None])[0]
                body = _virtual_query_status(query_id)
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({
                    "success": False,
                    "state": "error",
                    "error": "bad_query",
                    "message": str(e),
                }, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({
                    "success": False,
                    "state": "error",
                    "message": str(e),
                }, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/packets":
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                limit = max(1, min(int((query.get("limit") or ["250"])[0]), 1000))
                offset = max(0, int((query.get("offset") or ["0"])[0]))
                since_raw = (query.get("since") or [None])[0]
                since = int(since_raw) if since_raw not in (None, "") else None
                body = _packets(limit, since=since, offset=offset)
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(502, "application/json; charset=utf-8", json.dumps({
                    "success": False, "error": "packet_monitor_unavailable", "message": str(e),
                }, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/messages":
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                limit = max(1, min(int((query.get("limit") or ["250"])[0]), 1500))
                body = _primary_messages(limit)
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(502, "application/json; charset=utf-8", json.dumps({"success": False, "error": "messages_unavailable", "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/network-health":
            try:
                self._send(200, "application/json; charset=utf-8", json.dumps(_network_health(), ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "error": "health_error", "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/anomalies":
            try:
                self._send(200, "application/json; charset=utf-8", json.dumps(_anomalies(), ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "error": "anomaly_error", "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/archive/dump":
            tmp_path = None
            try:
                tmp_path, download_name = _archive_dump_zip()
                self._send_file(tmp_path, "application/zip", download_name)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as e:
                try:
                    self._send(500, "application/json; charset=utf-8", json.dumps({
                        "success": False, "error": "archive_dump_error", "message": str(e),
                    }, ensure_ascii=False).encode("utf-8"))
                except Exception:
                    pass
            finally:
                if tmp_path is not None:
                    try:
                        tmp_path.unlink(missing_ok=True)
                    except Exception:
                        pass
            return
        if path.startswith("/api/archive/"):
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                if path == "/api/archive/settings":
                    body = {"success": True, "settings": _archive_settings(), "status": _archive_status_snapshot()}
                    self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
                    return
                if path == "/api/archive/status":
                    body = {"success": True, **_archive_status_snapshot()}
                    self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
                    return
                if path == "/api/archive/packets":
                    body = _archive_packets_query(query)
                    self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
                    return
                if path == "/api/archive/stats":
                    body = _archive_stats_query(query)
                    self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
                    return
                if path == "/api/archive/nodes":
                    body = _archive_nodes_query(query)
                    self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
                    return
                if path == "/api/archive/links":
                    body = _archive_links_query(query)
                    self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
                    return
                if path == "/api/archive/rf-longest-links":
                    body = _archive_rf_longest_links_query(query)
                    self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
                    return
                if path == "/api/archive/rf-ranking-audit":
                    body = _archive_rf_ranking_audit_query(query)
                    self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
                    return
                if path == "/api/archive/export":
                    fmt = (query.get("format") or ["jsonl"])[0].lower()
                    if fmt not in {"jsonl", "csv"}:
                        raise ValueError("format deve ser jsonl ou csv")
                    ctype, raw = _archive_export(query, fmt=fmt)
                    self._send(200, ctype, raw)
                    return
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({
                    "success": False, "error": "archive_error", "message": str(e),
                }, ensure_ascii=False).encode("utf-8"))
                return
        if path == "/health":
            ok = TOPOLOGY_FILE.exists()
            self._send(200 if ok else 503, "application/json; charset=utf-8", json.dumps({
                "ok": ok,
                "topologyFile": str(TOPOLOGY_FILE),
                "archive": _archive_status_snapshot(),
            }, ensure_ascii=False).encode("utf-8"))
            return
        self._send(404, "text/plain; charset=utf-8", b"Not found\n")

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        if path == "/api/auth/login":
            try:
                if not AUTH_ENABLED:
                    self._send(409, "application/json; charset=utf-8", json.dumps({"success": False, "error": "auth_disabled", "message": "A autenticação está desativada nesta instalação."}, ensure_ascii=False).encode("utf-8"))
                    return
                if not AUTH_PASSWORD_HASH:
                    self._send(503, "application/json; charset=utf-8", json.dumps({"success": False, "error": "auth_not_configured", "message": "A autenticação está ativada, mas ainda não há senha administrativa configurada."}, ensure_ascii=False).encode("utf-8"))
                    return
                ip = _auth_client_ip(self)
                remaining = _auth_login_remaining(ip)
                if remaining:
                    self._send(429, "application/json; charset=utf-8", json.dumps({"success": False, "error": "login_rate_limited", "message": f"Muitas tentativas de login. Aguarde {remaining} segundos."}, ensure_ascii=False).encode("utf-8"))
                    return
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 4096:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Corpo da requisição inválido")
                username = str(payload.get("username") or "").strip()
                password = str(payload.get("password") or "")
                user_ok = hmac.compare_digest(username.encode("utf-8"), AUTH_USER.encode("utf-8"))
                password_ok = _auth_verify_password(password)
                if not (user_ok and password_ok):
                    _auth_register_failure(ip)
                    _record_access_event(self, event="login_failed", status=401, path="/api/auth/login", username=username)
                    time.sleep(0.18)
                    self._send(401, "application/json; charset=utf-8", json.dumps({"success": False, "error": "invalid_credentials", "message": "Usuário ou senha inválidos."}, ensure_ascii=False).encode("utf-8"))
                    return
                _auth_clear_failures(ip)
                sid, csrf, expires = _auth_new_session()
                body = {"success": True, "authenticated": True, "user": AUTH_USER, "csrfToken": csrf, "expiresAtMs": int(expires * 1000)}
                _record_access_event(self, event="login_success", status=200, path="/api/auth/login", username=AUTH_USER)
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"), {"Set-Cookie": _auth_set_cookie_header(self, sid, AUTH_SESSION_SECONDS)})
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/auth/logout":
            session = _auth_session(self)
            if AUTH_ENABLED and session:
                supplied = str(self.headers.get("X-CSRF-Token") or "")
                expected = str(session.get("csrf") or "")
                if not supplied or not hmac.compare_digest(supplied, expected):
                    self._send(403, "application/json; charset=utf-8", json.dumps({"success": False, "error": "csrf_failed", "message": "Proteção CSRF inválida."}, ensure_ascii=False).encode("utf-8"))
                    return
            _auth_drop_session(self)
            self._send(200, "application/json; charset=utf-8", json.dumps({"success": True, "authenticated": False}, ensure_ascii=False).encode("utf-8"), {"Set-Cookie": _auth_set_cookie_header(self, "", 0)})
            return
        if not _auth_require_write(self):
            return
        if path in ("/api/automations", "/api/automations/preview", "/api/automations/test-send"):
            try:
                if "application/json" not in str(self.headers.get("Content-Type") or "").lower():
                    raise ValueError("Content-Type application/json obrigatório")
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 8192:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Corpo da requisição inválido")
                bot = str(payload.get("bot") or "").lower()
                if bot not in automgr.AUTOMATION_IDS:
                    raise ValueError("Automação desconhecida")
                if path == "/api/automations":
                    patch = payload.get("settings")
                    if not isinstance(patch, dict):
                        raise ValueError("Configurações inválidas")
                    result = automgr.save(AUTOMATION_SETTINGS_FILE, _automation_defaults(),
                                          bot, patch, username=AUTH_USER)
                    body = {"success": True, "settings": result}
                elif path == "/api/automations/preview":
                    patch = payload.get("settings")
                    config = _automation_settings()
                    if patch is not None:
                        config[bot] = automgr.validate_bot(bot, patch, config)
                    body = {"success": True, **_automation_preview(bot, config[bot])}
                else:
                    if payload.get("confirm") is not True:
                        raise ValueError("Confirmação explícita obrigatória antes do envio")
                    body = _automation_test_send(bot)
                self._send(200, "application/json; charset=utf-8",
                           json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8",
                           json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8",
                           json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/ui-defaults":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 16384:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Corpo da requisição inválido")
                body = _save_ui_defaults(payload)
                self._send(200, "application/json; charset=utf-8", json.dumps({"success": True, **body}, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/archive/settings":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 4096:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Corpo da requisição inválido")
                settings = _save_archive_settings(payload)
                body = {"success": True, "settings": settings, "status": _archive_status_snapshot()}
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/nodeinfo/traceroute":
            try:
                if "application/json" not in str(self.headers.get("Content-Type") or "").lower():
                    raise ValueError("Content-Type application/json obrigatório")
                size = int(self.headers.get("Content-Length", "0") or 0)
                if not 1 <= size <= 1024:
                    raise ValueError("Corpo inválido")
                payload = json.loads(self.rfile.read(size).decode("utf-8"))
                body = _nodeinfo_trace_request(payload)
                self._send(202, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except (ValueError, KeyError) as exc:
                message = str(exc)
                status = 429 if message.startswith("Limite de RF") else 400
                self._send(status, "application/json; charset=utf-8", json.dumps({"success": False, "message": message}, ensure_ascii=False).encode("utf-8"))
            except Exception as exc:
                self._send(502, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(exc)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/node-query":
            try:
                if "application/json" not in str(self.headers.get("Content-Type") or "").lower():
                    raise ValueError("Content-Type application/json obrigatório")
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 4096:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Corpo da requisição inválido")
                body = _request_node_query(payload.get("nodeNum"), payload.get("action"))
                self._send(202, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "error": "bad_request", "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                message = str(e)
                status = 429 if "HTTP 429" in message else (403 if "HTTP 403" in message else 502)
                self._send(status, "application/json; charset=utf-8", json.dumps({"success": False, "error": "node_query_failed", "message": message}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/topology/refresh":
            try:
                body = _refresh_topology_now()
                self._send(200 if body.get("success") else 409, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except subprocess.TimeoutExpired:
                self._send(504, "application/json; charset=utf-8", json.dumps({"success": False, "error": "refresh_timeout", "message": "A atualização excedeu 90 segundos."}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "error": "refresh_failed", "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/automatic-notices":
            try:
                length=int(self.headers.get("Content-Length","0") or 0)
                if length<=0 or length>4096: raise ValueError("Corpo da requisição inválido")
                payload=json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload,dict): raise ValueError("Corpo da requisição inválido")
                settings=_save_automatic_notice_settings(payload)
                body={"success":True,"settings":settings,"state":_automatic_notice_state()}
                self._send(200,"application/json; charset=utf-8",json.dumps(body,ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/automatic-notices/firmware-check":
            try:
                with _notice_lock:
                    state=_automatic_notice_state()
                    sent,errors=_run_firmware_notice_check(state,_automatic_notice_settings(),time.time())
                body={"success":True,"sent":sent,"errors":errors,"state":state}
                self._send(200,"application/json; charset=utf-8",json.dumps(body,ensure_ascii=False).encode('utf-8'))
            except Exception as exc:
                self._send(500,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(exc)}).encode('utf-8'))
            return
        if path in ("/api/home-assistant", "/api/home-assistant/test"):
            try:
                length=int(self.headers.get("Content-Length","0") or 0)
                if length<=0 or length>4096: raise ValueError("Corpo da requisição inválido")
                payload=json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload,dict): raise ValueError("Corpo da requisição inválido")
                if path == "/api/home-assistant":
                    body={"success":True,"homeAssistant":_save_home_assistant(payload)}
                else:
                    body=_test_home_assistant()
                self._send(200,"application/json; charset=utf-8",json.dumps(body,ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/automatic-notices/firmware-announce":
            try:
                length=int(self.headers.get("Content-Length","0") or 0)
                if length<=0 or length>1024: raise ValueError("Corpo da requisição inválido")
                payload=json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload,dict): raise ValueError("Corpo da requisição inválido")
                result=_firmware_announce_now(str(payload.get("kind") or ""),time.time())
                ok=result["status"]=="sent"
                result.update(success=ok,message="Anúncio aceito pelo backend." if ok else result.get("error") or "Envio não confirmado")
                self._send(200 if ok else 502,"application/json; charset=utf-8",json.dumps(result,ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(502,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/automatic-notices/check":
            try:
                body=_run_automatic_notice_check(force=True)
                self._send(200 if body.get("success") else 207,"application/json; charset=utf-8",json.dumps(body,ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500,"application/json; charset=utf-8",json.dumps({"success":False,"message":str(e)},ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/update/settings":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 4096:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Corpo da requisição inválido")
                settings = _save_update_settings(payload)
                if settings.get("enabled"):
                    _maybe_request_auto_update(_version_status(force=True))
                self._send(200, "application/json; charset=utf-8", json.dumps({"success": True, "settings": settings, "status": _update_runtime_status()}, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/update/trigger":
            try:
                if "application/json" not in str(self.headers.get("Content-Type") or "").lower():
                    raise ValueError("Content-Type application/json obrigatório")
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 1024:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict) or payload.get("action") != "update":
                    raise ValueError("Ação de atualização inválida")
                body = _request_update(reason="manual")
                self._send(202 if body.get("requested") else 200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/messages/private":
            try:
                if "application/json" not in str(self.headers.get("Content-Type") or "").lower():
                    raise ValueError("Content-Type application/json obrigatório")
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 4096:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                body = _send_private_node_message(payload.get("nodeNum"), payload.get("text"))
                self._send(201, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(502, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/node-ping":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 1024:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                body = _ping_node(payload.get("nodeNum"))
                self._send(202, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(502, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/node-favorite":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 1024:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                body = _set_device_node_favorite(payload.get("nodeNum"), payload.get("favorite"))
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(502, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/nodes-bulk-delete":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 8192:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Corpo da requisição inválido")
                body = _bulk_delete_nodes(payload.get("nodeNums"), str(payload.get("scope") or ""))
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/node-delete-everywhere":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 1024:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                body = _delete_node_everywhere(payload.get("nodeNum"))
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/node-local-delete":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 1024:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                body = _delete_local_node(payload.get("nodeNum"))
                self._send(200, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(500, "application/json; charset=utf-8", json.dumps({"success": False, "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        if path == "/api/messages/send":
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                if length <= 0 or length > 8192:
                    raise ValueError("Corpo da requisição inválido")
                payload = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Corpo da requisição inválido")
                body = _send_primary_message(
                    payload.get("text"),
                    reply_id=payload.get("replyId"),
                    emoji=bool(payload.get("emoji")),
                )
                status = 201 if body.get("success") else 502
                self._send(status, "application/json; charset=utf-8", json.dumps(body, ensure_ascii=False).encode("utf-8"))
            except ValueError as e:
                self._send(400, "application/json; charset=utf-8", json.dumps({"success": False, "error": "bad_request", "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            except Exception as e:
                self._send(502, "application/json; charset=utf-8", json.dumps({"success": False, "error": "send_failed", "message": str(e)}, ensure_ascii=False).encode("utf-8"))
            return
        self._send(404, "text/plain; charset=utf-8", b"Not found\n")

    def log_message(self, fmt, *args):
        print(f"{self.address_string()} - {fmt % args}", flush=True)


def main():
    _archive_init()
    _access_init()
    archive_thread = threading.Thread(target=_archive_worker, name="traffic-archive", daemon=True)
    archive_thread.start()
    notice_thread = threading.Thread(target=_automatic_notice_worker, name="automatic-notices", daemon=True)
    notice_thread.start()
    command_thread = threading.Thread(target=_mesh_command_live_worker, name="mesh-commands-live", daemon=True)
    command_thread.start()
    update_thread = threading.Thread(target=_automatic_update_watch_worker, name="automatic-update-watch", daemon=True)
    update_thread.start()
    httpd = ThreadingHTTPServer((BIND, PORT), Handler)
    print(f"Traffic Analyzer v{APP_VERSION} ouvindo em http://{BIND}:{PORT}/", flush=True)
    print(f"Topologia: {TOPOLOGY_FILE}", flush=True)
    print(f"Arquivo histórico de tráfego: {TRAFFIC_ARCHIVE_DB}", flush=True)
    print(f"Log de acessos web: {ACCESS_LOG_FILE}", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        _archive_stop.set()
        _notice_stop.set()
        _notice_wakeup.set()
        _mesh_command_stop.set()
        _update_watch_stop.set()
        httpd.server_close()


if __name__ == "__main__":
    main()
