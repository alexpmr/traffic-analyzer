# Changelog

## 1.47.1 - 2026-10-08

- Corrige `Invalid LatLng object: (undefined, undefined)` introduzido pela memória histórica da v1.47.0.
- O mapa agora valida latitude/longitude antes de criar marcadores e pontos de heatmap.
- Nós históricos sem posição permanecem no inventário da aba Nós, mas não são enviados ao Leaflet.
- Coordenadas válidas em formato numérico ou string numérica continuam aceitas.
- Rejeita coordenadas ausentes, NaN/infinito, fora das faixas geográficas e Null Island.
- Adiciona smoke test específico reproduzindo um nó histórico sem coordenadas e verificando que os demais nós continuam visíveis.
- Mantém sem alterações a persistência permanente de nós/enlaces e a retenção configurável do tráfego bruto.

## 1.47.0 - 2026-10-08

- Cria memória histórica permanente de **nós** e **enlaces** dentro do `traffic.db`.
- Nós observados permanecem no inventário mesmo depois de saírem do NodeDB/API do MeshMonitor.
- Preserva a última posição válida conhecida para nós históricos quando disponível.
- Enlaces observados deixam de depender da retenção e do limite de traceroutes do MeshMonitor.
- Mantém eventos recentes suficientes para os filtros temporais e agregados completos para **Janela = Todos**.
- Filtros de 1 h, 6 h, 12 h, 24 h, 7 dias e 30 dias passam a ocultar apenas a visualização, sem excluir a memória histórica.
- Mantém a regra de confirmação RF somente com evidência física válida (SNR); demais observações permanecem MQTT/não-RF.
- Adiciona fila durável `topology-history-queue` para preservar snapshots gerados enquanto o serviço web estiver parado.
- Implementa recuperação best-effort de enlaces antigos a partir de metadata de `TRACEROUTE_APP` já arquivado.
- Adiciona **Configurações → Banco de tráfego** com retenção de **1 dia, 1 semana, 1 mês ou Nunca apagar**.
- Define **Nunca apagar** como padrão.
- A limpeza automática remove apenas pacotes e posições brutas; tabelas históricas de nós/enlaces não são removidas.
- Mostra na interface quantidade de pacotes, nós/enlaces históricos, registro mais antigo e tamanho aproximado do banco.
- Atualiza instalador, documentação, testes automatizados e smoke tests.

## 1.46.0 - 2026-10-06

- Corrige o seletor de idiomas para exibir **bandeiras reais em SVG embutido** no botão ativo e nas opções Português/English.
- Remove a dependência dos emojis Unicode de bandeira, evitando a renderização como **BR/US** em Windows + Chrome.
- Mantém as bandeiras locais, sem CDN, Twemoji, fonte externa ou recurso remoto.
- Torna o zoom do mapa mais gradual com passo de **0,20**, snap fracionário de **0,05** e sensibilidade da roda ajustada para **120 px por nível de zoom**.
- Reduz o debounce da roda para **30 ms**, deixando mouse e touchpad mais suaves e previsíveis.
- Mantém os botões +/− usando a mesma granularidade fracionária e preserva o ponto sob o cursor pelo comportamento nativo do Leaflet.
- Altera **Estatísticas → Período** para iniciar em **Todo** por padrão.
- Garante que o fallback interno de Estatísticas também considere todo o histórico quando nenhum valor estiver disponível.
- Preserva os demais períodos (1 h, 6 h, 24 h, 7 dias e 30 dias), filtro por nó e todos os recursos da v1.45.0.

## 1.45.0 - 2026-10-03

- Substitui os círculos isolados da camada **Cobertura RF** por um **mapa de calor real** usando Leaflet.heat.
- Cada recepção arquivada contribui para o heatmap; regiões com observações sobrepostas ganham maior intensidade visual.
- A intensidade individual considera SNR quando disponível e usa RSSI como fallback, preservando os dados reais observados.
- Mantém o popup técnico de cada recepção por meio de áreas de interação transparentes, sem voltar a desenhar os antigos círculos visíveis.
- A Cobertura RF continua usando apenas o histórico já coletado pelo Traffic Analyzer e não transmite pacotes adicionais na malha.
- Altera a verificação automática de nova versão para **15 minutos por padrão**.
- Adiciona em **Configurações → Atualizações** o campo para definir o intervalo de verificação entre **5 e 1.440 minutos**.
- Persiste o intervalo no servidor e aplica a alteração imediatamente, sem reiniciar o Traffic Analyzer.
- O clique manual no indicador de versão continua forçando uma consulta nova ao GitHub.
- Preserva o seletor de idiomas com bandeiras e todos os recursos da v1.44.0.

## 1.44.0 - 2026-10-02

- Adiciona worker de avisos automáticos no canal primário.
- Monitora alertas oficiais do INMET aplicáveis a Brasília/DF e envia apenas novos alertas ou atualizações relevantes.
- Usa texto/área do aviso e fallback geométrico por polígono para identificar avisos que atingem o Distrito Federal.
- Evita flood na primeira execução, registrando como conhecidos os alertas já ativos e as versões Meshtastic já publicadas.
- Monitora Releases oficiais do firmware Meshtastic e diferencia versões estáveis de prereleases/alpha/beta/RC/preview/nightly/dev.
- Permite habilitar/desabilitar separadamente avisos do INMET, versões estáveis e versões instáveis.
- Adiciona ação administrativa Verificar agora.
- Registra tentativas de envio na tabela automatic_notices do traffic.db.
- Limita o texto automático a aproximadamente 600 bytes antes do envio.
- Intervalo padrão de verificação de 600 segundos, configurável por variável de ambiente.
- Preserva todos os recursos da v1.43.0.

## 1.43.0 - 2026-09-30

- Publica uma versão completa consolidando todos os recursos atuais do Traffic Analyzer.
- Renomeia a camada analítica de elevação para **Relevo com corte**, deixando explícita sua função no menu Camadas.
- Mantém o **slider vertical de corte** diretamente sobre o mapa para filtrar, em tempo real, somente o terreno igual ou acima da cota selecionada.
- Renomeia o título do controle para **Corte do relevo** e mantém a cota atual visível no topo.
- Mantém o limite máximo padrão do slider em **3.000 m**, configurável entre **100 e 9.000 m** pelo campo inferior ou em Configurações.
- Mantém o slider com **390 px** de altura em telas normais e **255 px** em telas menores.
- Mantém o ajuste de opacidade da camada, persistência local e padrão global do administrador.
- Preserva **Relevo sombreado** como camada independente, além de radar, cobertura RF, raios, alertas, nuvens, topologia, animações, mensagens, estatísticas e consultas aos nós.
- Preserva compatibilidade das preferências existentes: os identificadores internos da antiga Elevação mínima não mudam.
- Preserva todos os recursos da v1.42.1.

## 1.42.1 - 2026-10-01

- Faz o campo numérico inferior do controle de Elevação mínima definir o limite máximo do slider.
- Mantém o limite máximo padrão em 3.000 m e faixa configurável de 100 a 9.000 m.
- Sincroniza o campo inferior com a configuração de limite superior existente.
- Mantém o valor da cota mínima controlado pelo slider e exibido no topo.
- Ajusta automaticamente a cota quando o novo máximo for inferior ao valor atual.
- Aumenta a altura do slider vertical em 50%, de 260 px para 390 px.
- Em telas de menor altura, aumenta de 170 px para 255 px.
- Preserva todos os recursos da v1.42.0.

## 1.42.0 - 2026-09-30

- Adiciona configuração do limite superior do slider da camada Elevação mínima.
- Define 3.000 m como limite superior padrão.
- Permite configurar o limite entre 100 e 9.000 m.
- Faz o slider, o campo numérico e a marcação superior da escala acompanharem dinamicamente o limite configurado.
- Ajusta automaticamente a cota mínima quando ela estiver acima do novo limite.
- Aumenta a altura do slider vertical para 260 px e para 170 px em telas de baixa altura.
- Persiste o novo limite nas preferências locais e no padrão global do administrador.
- Corrige a restauração de preferências antigas para respeitar a nova faixa dinâmica.
- Preserva todos os recursos da v1.41.1.

## 1.41.1 - 2026-09-30

- Limita o slider vertical da camada Elevação mínima à faixa de 0 a 4.000 m.
- Atualiza as marcações visuais da escala para 4.000 m no topo e 0 m na base.
- Aplica o mesmo limite ao campo numérico de ajuste da cota.
- Reposiciona o controle para o lado direito, centralizado verticalmente no mapa.
- Garante que o controle apareça somente com Elevação mínima ligada.
- Mantém Relevo sombreado independente do controle de cota.
- Persiste a cota selecionada para restauração ao reativar a camada.
- Preserva todos os recursos da v1.41.0.

## 1.41.0 - 2026-09-30

- Adiciona a camada analítica **Elevação mínima**, independente do Relevo sombreado.
- Usa Terrain Tiles globais em formato Terrarium, disponibilizados pelo Registry of Open Data on AWS, como DEM real de elevação.
- Adiciona controle deslizante **vertical** diretamente no mapa para ajustar a cota mínima em tempo real.
- Mostra somente o terreno com altitude **maior ou igual** à cota selecionada; áreas abaixo do limite ficam transparentes.
- Usa faixa de -500 m a 9.000 m, passo de 50 m no slider e campo numérico para ajuste fino.
- Adiciona controle de opacidade da camada e mantém nós, enlaces, animações e demais overlays acima da elevação.
- Persiste ativação, cota mínima e opacidade no navegador e no padrão global dos visitantes.
- Faz o backend atuar como proxy dos tiles DEM, evitando dependência de CORS e mantendo a fonte externa desacoplada da interface.
- Preserva todos os recursos da v1.40.0.

## 1.40.0 - 2026-09-30

- Adiciona camada Cobertura RF baseada nas posições arquivadas que possuem evidência de SNR/RSSI, sem tráfego adicional na malha.
- Faz a Cobertura RF acompanhar o período selecionado no mapa e exibir detalhes da recepção no clique.
- Adiciona overlay de Relevo sombreado usando Esri World Hillshade.
- Adiciona camada de Alertas meteorológicos com leitura do feed público CAP/RSS/JSON do INMET e desenho dos polígonos informados.
- Adiciona camada de Raios por integração opcional com Lightning API, consultada apenas para o viewport visível e últimos 60 minutos.
- Adiciona camada de Nuvens por integração opcional com Rainbow Weather Tiles, com proxy no backend para proteger o token.
- Persiste o estado das novas camadas no navegador e no padrão global do administrador.
- Mantém o Radar meteorológico ligado por padrão; novas camadas iniciam desligadas.
- Isola falhas dos provedores externos e mostra status individual no menu Camadas.
- Preserva todos os recursos da v1.39.0.

## 1.39.0 - 2026-09-30

- Adiciona seletor de mapa-base à barra principal do mapa, junto de Enquadrar e Atualizar.
- Oferece OSM/Ruas, Topográfico, Claro, Escuro e Satélite com troca imediata.
- Mantém sincronização bidirecional entre o seletor rápido e Configurações.
- Adiciona menu Camadas preparado para novas sobreposições.
- Adiciona Radar meteorológico como primeira camada, ligado por padrão.
- Usa o quadro de precipitação mais recente do RainViewer e atualiza a camada a cada 5 minutos.
- Persiste mapa-base e estado da camada de radar nas preferências locais e no padrão global do administrador.
- Trata indisponibilidade do radar sem afetar a topologia ou o mapa-base.
- Preserva todos os recursos da v1.38.0.

## 1.38.0 - 2026-09-30

- Confirma enlaces RF somente quando o hop possui evidência física válida de sinal, atualmente SNR válido.
- Classifica como MQTT/não-RF as observações sem SNR válido, mesmo quando o registro de traceroute chegou ao MeshMonitor por RF.
- Mantém contadores independentes de observações RF e MQTT/não-RF para enlaces mistos.
- Adiciona distância em linha reta, em quilômetros, ao popup de cada enlace quando ambas as estações possuem posição válida.
- Faz a aba Nós abrir uma visualização ampla das informações e consultas do nó, reutilizando a mesma estrutura de dados do mapa.
- Torna o nome do remetente na aba Mensagens clicável para abrir as informações do nó.
- Amplia o modal de detalhes do nó.
- Atualiza testes automatizados de classificação RF/MQTT para cobrir hop sem evidência de sinal.
- Preserva todos os recursos da v1.37.1.

## 1.37.1 - 2026-09-29

- Corrige falso status ATUALIZADO causado pelo cache de versão de 1 hora.
- Força uma consulta nova ao abrir a interface.
- Reduz o TTL interno da versão publicada para 5 minutos.
- Altera a verificação periódica para 5 minutos.
- Envia Cache-Control no-cache e Pragma no-cache ao consultar a Latest Release.
- Preserva todos os recursos da v1.37.0.

## 1.37.0 - 2026-09-29

- Reorganiza a navegação superior e cria a aba principal Estatísticas.
- Move Saúde da Rede, Anomalias e Acessos para dentro de Estatísticas, preservando seus recursos.
- Adiciona Visão Geral com KPIs e resumo textual automático do estado da rede.
- Adiciona filtros por período e por nó para análises derivadas do histórico persistente.
- Adiciona painéis de RF, Routing, Tráfego, Consultas, Chat e Energia.
- Exibe relações observadas, médias de SNR/RSSI, distribuição por hops, relays mais observados e participação dos tipos de pacote.
- Consolida TX/RX observados das consultas NodeInfo, Position, Telemetry, Traceroute e Routing.
- Consolida bateria, tensão e alertas de bateria baixa quando esses dados existirem na topologia.
- Mantém a distinção entre evidência lógica de tráfego e enlace RF físico.
- Não altera o esquema do traffic.db e reutiliza as APIs de arquivo, topologia, saúde, anomalias e acessos.
- Atualiza os testes automatizados de navegação para a nova arquitetura de Estatísticas.
- Preserva todos os recursos da v1.36.5.

## 1.36.5 - 2026-09-29

- Usa o Virtual Node do MeshMonitor como backend preferencial das consultas ativas, preservando Traceroute na API do MM.
- Envia requests com o formato do cliente oficial Meshtastic, sem request_id pré-preenchido e sem wantAck forçado.
- Correlaciona respostas por `RX decoded.request_id == TX packet.id`.
- Deixa de tratar telemetria periódica não correlacionada como resposta da consulta.
- Interpreta `ROUTING_APP` correlacionado e mostra `NO_RESPONSE`, `NO_ROUTE`, `NO_CHANNEL`, `NOT_AUTHORIZED` e demais códigos reais.
- Define 30 s de timeout para consultas enviadas pelo Virtual Node.
- Adiciona `meshtastic_query.py` e venv dedicado com `meshtastic[cli] 2.7.11`.
- Adiciona configuração de backend/host/porta do Virtual Node e fallback explícito no modo auto.
- Preserva todos os recursos da v1.36.4.

## 1.36.4 - 2026-09-29

- Eleva o timeout efetivo de Telemetry para 90 s, preservando 20 s nas demais consultas.
- Mostra fases intermediárias de recuperação em vez de classificar Telemetry como falha aos 20 s.
- Coleta os TX destinados ao nó no Packet Monitor e conta retries reais por tipo de Telemetry.
- Mantém o botão Tudo acompanhando as consultas até o encerramento individual de cada janela.
- Continua observando timeouts por até 3 minutos e converte respostas tardias para respondido automaticamente.
- Inclui ROUTING_APP nas evidências e só associa ACK/NAK quando existe requestId correlacionável ao packetId do TX.
- Preserva portnum, canal, SNR e RSSI nas respostas confirmadas.
- Usa o source concreto para detalhes, telemetria, pacotes e Neighbor Info.
- Preserva todos os recursos da v1.36.3.

## 1.36.3 - 2026-09-28

- Substitui o seletor nativo de idioma por menu visual com bandeira, nome do idioma e seta.
- Destaca o idioma ativo no menu e mantém Português e English como idiomas suportados nesta versão.
- Mantém a escolha salva no navegador e aplica a tradução imediatamente sem recarregar a página.
- Adiciona navegação por teclado e atributos de acessibilidade ao seletor.
- Ajusta o componente aos temas claro e escuro.
- Atualiza os testes de interface para validar o novo seletor e a troca Português ↔ English.
- Preserva todas as funcionalidades da v1.36.2.

## 1.36.2 - 2026-09-27

- Remove o canal 0 fixo das consultas NodeInfo e Position; o MeshMonitor volta a resolver o canal correto do nó.
- Resolve o ID concreto da fonte primária quando MM_SOURCE está configurado como default.
- Usa o source concreto nas consultas NodeInfo, Position, Neighbor Info e Telemetry.
- Extrai e exibe o canal efetivamente selecionado pelo MeshMonitor.
- Aumenta o espaçamento do botão Tudo de 700 ms para 2 s para reduzir rajadas/collisions entre requests e respostas.
- Aumenta o timeout individual de 15 s para 20 s.
- Enriquece a evidência de RX com portnum, canal, SNR e RSSI quando disponíveis no Packet Monitor.
- Mantém a conversão de timeout para respondido quando uma resposta tardia é detectada.
- Preserva o diagnóstico separado entre TX aceito pelo MeshMonitor e ausência de RX.
- Preserva expansão em tela cheia e demais recursos da v1.36.1.

## 1.36.1 - 2026-09-27

- Corrige o envio de NodeInfo, Position, Neighbor Info e Telemetry usando os endpoints source-aware do MeshMonitor 4.16.x.
- NodeInfo e Position passam a usar explicitamente o canal primário 0 e o source configurado.
- Telemetry e Neighbor Info passam a enviar sourceId explicitamente.
- O timestamp da solicitação é capturado antes da chamada ao MeshMonitor, evitando perder respostas que chegam durante o próprio request HTTP.
- O status individual informa quando o MeshMonitor aceitou a consulta e inclui canal/packet ID quando disponíveis.
- Em timeout, diferencia consulta aceita de ausência de resposta RX.
- O botão Expandir da janela do nó passa a usar praticamente toda a viewport do navegador, inclusive sobre as barras superiores.
- Restaurar devolve a janela à geometria anterior.
- Preserva consultas assíncronas, barras de progresso e demais recursos da v1.36.0.

## 1.36.0 - 2026-09-27

- Substitui o popup de informações do nó baseado em Leaflet por uma janela flutuante independente sobre o mapa.
- Permite arrastar a janela livremente pelo cabeçalho.
- Adiciona redimensionamento real pelo canto inferior direito para ampliar e reduzir a janela.
- Adiciona botões Reposicionar, Expandir/Restaurar e Fechar no cabeçalho da janela.
- Mantém posição e dimensões durante refreshes da topologia e atualizações assíncronas das consultas.
- Faz o conteúdo usar rolagem interna da própria janela, sem depender das limitações de tamanho/posição do popup Leaflet.
- Reutiliza a mesma janela ao selecionar outro nó no mapa.
- Sanitiza erros de Neighbor Info para não exibir HTML bruto/404 do MeshMonitor.
- Atualiza os smoke tests para validar abertura, arraste, redução de tamanho, persistência após render e expansão/restauração.
- Preserva consultas assíncronas, barras de progresso, checagem horária de versão e demais recursos da v1.35.1.

## 1.35.1 - 2026-09-27

- Torna o botão Tudo das consultas ao nó não bloqueante: todas as perguntas são disparadas na mesma rodada, com espaçamento de 700 ms entre transmissões, sem aguardar timeout da anterior.
- Reduz o timeout interativo das consultas para 15 s e acompanha cada tarefa de forma independente.
- Adiciona barra de progresso individual para NodeInfo, Position, Power, Traceroute, Device, Environment, Air Quality e Neighbor Info.
- Exibe os resultados assim que cada resposta é detectada e mostra o tempo de resposta de cada consulta concluída.
- Corrige a detecção de Telemetry para exigir o subtipo correspondente à consulta em vez de aceitar qualquer pacote TELEMETRY_APP.
- Reordena as consultas para Informações do nó, Posição, Energia, Traceroute, Dispositivo, Ambiente, Qualidade do ar, Vizinhos e Tudo.
- Torna o popup de informações do nó redimensionável e adiciona Expandir/Restaurar, preservando o comportamento de arraste.
- Ao clicar no indicador de versão, força uma nova consulta ao GitHub e abre o popup com o estado atual ou com as novidades da versão disponível.
- Abre o popup de versão imediatamente ao clique e atualiza seu conteúdo assim que a verificação for concluída.
- Mantém no popup de versão o link direto para a Release e adiciona botão Fechar.
- Altera a verificação automática de novas versões para uma vez por hora.
- Preserva todos os recursos da v1.34.0.

## 1.34.0 - 2026-09-26

- Detecta respostas reais de NodeInfo, Position e Telemetry pelo tráfego RX observado no MeshMonitor.
- Torna o botão Tudo sequencial, com timeout por pergunta, guarda entre transmissões, progresso e Traceroute por último.
- Evita Neighbor Info em nós não locais/0-hop.
- Deduplica metadados do popup pelo tipo, mantendo apenas a amostra mais recente.
- Completa a tradução dinâmica do popup e mantém percentuais com uma casa decimal.
- Aumenta a largura útil do popup, acrescenta Fechar/Reposicionar e preserva a posição arrastada por coordenada de tela durante refreshes.
- Corrige a referência de distância da aba Nós para VHF3.
- Colore o percentual da bateria em verde/amarelo/vermelho.
- Adiciona filtro instantâneo caractere por caractere à aba Nós.
- Ao clicar em um nó na lista, focaliza e aproxima o mapa sem abrir o popup automaticamente.
- Adiciona a aba Acessos com estatísticas por dia, país, cidade, IP, navegador, sistema operacional e eventos de login.
- Persiste o log bruto em access.log ao lado do traffic.db e indexa os eventos na tabela web_access.
- Protege as estatísticas de acesso por autenticação administrativa quando habilitada.
- Mantém GeoIP externo desabilitado por padrão; aceita cabeçalhos de proxy/CDN ou endpoint configurado explicitamente.
- Adiciona testes de navegação da aba Acessos, autorização da API e persistência visual do popup após renderização.
- Preserva todos os recursos da v1.33.0.

## 1.33.0 - 2026-09-26

- Torna o popup de informações de nó arrastável pelo cabeçalho em mouse e touch.
- Mantém o arraste independente da rolagem vertical do conteúdo do popup.
- Limita o deslocamento do popup aos limites visíveis do mapa.
- Eleva o popup acima da legenda e dos controles do Leaflet enquanto estiver aberto.
- Oculta a ponta do popup quando a janela é deslocada do marcador.
- Preserva o deslocamento e a rolagem durante atualizações automáticas da topologia do mesmo nó.
- Reinicia a posição flutuante ao fechar o popup ou selecionar outro nó.
- Mantém estático o modal de detalhes aberto pela aba Nós para nós sem marcador.
- Adiciona smoke test de navegador para verificar o arraste real do popup.
- Preserva os recursos da v1.32.0.
## 1.32.0 - 2026-09-26

- Adiciona a nova aba Nós com inventário ordenável dos nós conhecidos.
- Exibe por padrão Nome longo, Nome curto, Role, Hardware, Saltos, Bateria, Tensão, Distância, SNR, Última interação e Última posição.
- Adiciona colunas opcionais RSSI, Utilização do canal, Air Util TX, Node ID, PKC e Estado.
- Permite ordenar qualquer coluna em ordem crescente ou decrescente clicando no título.
- Colore a idade da última interação: verde até 1 h, amarelo entre 1 h e 12 h e vermelho acima de 12 h.
- Atualiza automaticamente o texto de idade enquanto a aba Nós estiver aberta.
- Consulta o endpoint de status da fonte do MeshMonitor para identificar o nó local e calcular a distância geográfica de cada nó com posição conhecida.
- Permite abrir os detalhes do nó a partir da tabela, reutilizando o popup do mapa quando possível.
- Converte hwModel numérico para nomes amigáveis de hardware e Role numérica para nomes legíveis.
- Preserva o popup aberto e sua rolagem durante a regeneração periódica da topologia.
- Mantém checks verdes somente após detectar respostas novas às consultas do nó.
- Padroniza percentuais com uma casa decimal em popup, telemetria e inventário de nós.
- Preserva os recursos e o fluxo de atualização da v1.31.0.

## 1.31.0 - 2026-09-26

- Torna o popup dos nós mais largo e orientado para paisagem em telas de desktop.
- Organiza metadados em duas duplas campo/valor por linha e distribui checklist/metadados recebidos em colunas quando houver espaço.
- Adiciona rolagem vertical interna ao popup com altura máxima relativa à viewport.
- Mantém comportamento responsivo em telas médias e pequenas, voltando para disposição vertical quando necessário.
- Transforma a troca de idioma do cabeçalho em um menu pull-down compacto, preservando Português e English e a preferência local.
- Faz o indicador superior de nova versão iniciar diretamente o download do ZIP da Latest Release estável.
- Inclui na API de status da versão o asset ZIP exato da Release mais recente, com fallback para traffic-analyzer-latest.zip.
- Mantém o modal de versão quando não existir atualização para baixar.
- Altera o instalador para parar a instância web, o timer e uma execução agendada anterior antes de substituir os arquivos.
- Reinicia os serviços normalmente ao final e mantém configurações, credenciais e dados persistentes.
- Preserva consultas de nós, mapa, RF/MQTT-não-RF, mensagens e demais recursos da v1.30.0.

## 1.30.0 - 2026-09-26

- Expande o popup de nós para exibir um inventário completo dos metadados esperados, marcando com ✓ os dados disponíveis e com ☐ os ausentes.
- Adiciona latitude, longitude, coordenadas combinadas, altitude e data/hora da última posição ao popup.
- Exibe metadados seguros do NodeDB do MeshMonitor, incluindo identidade, hardware/role, firmware, posição, RF, bateria, tensão, utilização de canal, Air Util TX, uptime, reboots, Store & Forward e PKC quando disponíveis.
- Adiciona consultas individuais de Node Info, Position, Device Metrics, Environment Metrics, Air Quality, Power Metrics, Neighbor Info e Traceroute.
- Adiciona botão Tudo, que dispara as consultas sequencialmente com intervalo entre transmissões e deixa o Traceroute por último.
- Mostra no próprio popup o estado de cada consulta e marca ✓ à medida que uma resposta nova é detectada no MeshMonitor.
- Atualiza os metadados do popup em tempo real enquanto houver respostas pendentes.
- Encaminha as solicitações pelos endpoints do próprio MeshMonitor, preservando o MM como fonte de verdade e permitindo que as respostas fiquem disponíveis também na interface/banco do MM.
- Mantém Neighbor Info sujeito às restrições de nó local/0-hop e aos limites do firmware/MeshMonitor.
- Protege todas as consultas ativas com a autenticação administrativa e CSRF já usados nas demais operações de escrita.
- Amplia o topology.json com metadados seguros para que o popup abra imediatamente com o máximo de informação já conhecida.
- Preserva o mapa e os recursos RF/MQTT-não-RF da v1.29.0.

## 1.29.0 - 2026-09-26

- Classifica cada observação de enlace como RF ou MQTT/não-RF usando evidência por hop dos traceroutes.
- Segue a regra do MeshMonitor em que o sentinel de SNR desconhecido do hop prevalece sobre o transporte do registro para identificar um trecho não confirmado por RF.
- Mantém linha contínua quando existe ao menos uma observação RF do enlace no período selecionado.
- Exibe linha tracejada quando todas as observações do enlace no período são MQTT/não-RF.
- Adiciona ao popup do enlace contadores separados de observações RF e MQTT/não-RF e indicação explícita de enlaces mistos.
- Adiciona legenda de tipos de enlace ao mapa, além da legenda existente de idade do tráfego.
- Adiciona cor e espessura independentes para enlaces RF e MQTT/não-RF em Configurações.
- Migra automaticamente a antiga cor/espessura única para o estilo RF e cria padrão separado para MQTT/não-RF.
- Inclui as novas preferências no padrão global do administrador e no localStorage dos visitantes.
- Adiciona testes automatizados para o cenário A-B MQTT/não-RF e B-VHF3 RF, além de smoke test do tracejado no navegador.

## 1.28.0 - 2026-09-25

- Libera para visitantes sem login as configurações exclusivamente visuais e locais: tema, mapa-base, filtros de exibição, brilho, linhas, nós, heatmap, animações, sons e aparência das mensagens.
- Mantém essas preferências no `localStorage` do navegador do visitante; elas não alteram o servidor, a malha nem a experiência de outros usuários.
- Mantém bloqueadas sem login todas as ações administrativas e de escrita: envio/reply/reações de mensagens, refresh administrativo da topologia, auto-update, disparo de atualização e alteração do padrão global.
- Adiciona padrão visual global persistente no servidor. O administrador pode salvar a configuração visual atual como apresentação inicial de novos visitantes.
- Novos navegadores recebem primeiro o padrão global do administrador; preferências locais do visitante passam a sobrescrevê-lo somente naquele navegador.
- Adiciona botão `Restaurar padrão do administrador`, que remove o override local e volta à apresentação global na próxima carga.
- Adiciona API pública somente leitura `GET /api/ui-defaults` e API administrativa protegida `POST /api/ui-defaults` com sessão e CSRF.
- Valida e normaliza no backend todos os campos aceitos como padrão visual, impedindo gravação arbitrária no arquivo de configuração.
- Atualiza testes, Ajuda, README, instalador e manual PDF para refletir a separação entre personalização local e administração.

## 1.27.1 - 2026-09-25

- Corrige tiles 403 "Access blocked" no mapa Ruas (OSM).
- Substitui o endereço legado com subdomínios por `https://tile.openstreetmap.org/{z}/{x}/{y}.png`, conforme a política atual do OSM.
- Troca `Referrer-Policy: same-origin` por `strict-origin-when-cross-origin` para que requisições web de tiles enviem Referer válido sem expor o caminho completo.
- Adiciona fallback automático temporário para Claro (CARTO) após falhas repetidas dos tiles OSM.
- Mantém todos os controles de segurança e autenticação adicionados na v1.27.0.

## 1.27.0 - 2026-09-25

- Remove a aba Tracklog, o mapa, os controles e o JavaScript específico da interface.
- Mantém a coleta histórica de posições no banco para uso interno, relatórios e análises, sem endpoint público de Tracklog.
- Adiciona autenticação administrativa opcional no servidor, ativada por padrão pelo instalador da v1.27.0.
- Mantém acesso público não autenticado em modo somente leitura.
- Bloqueia alterações de Configurações para usuários não autenticados.
- Mantém Mensagens legível sem login, mas bloqueia envio, reply, reações e demais ações de escrita.
- Protege todos os endpoints POST com sessão administrativa e token CSRF.
- Adiciona sessão com cookie HttpOnly, SameSite=Strict, expiração configurável e Secure automático atrás de HTTPS com X-Forwarded-Proto.
- Adiciona rate limit de login após tentativas repetidas.
- Armazena a senha administrativa somente como PBKDF2-SHA256 com salt e 600.000 iterações.
- Adiciona utilitário `traffic-analyzer-set-password` para definir/trocar credenciais.
- Altera `/etc/traffic-analyzer-map.env` para permissão 0600.
- Impede que acesso público não autenticado dispare o auto-update por consulta de versão.
- Documenta uso de reverse proxy HTTPS para exposição na internet.

## 1.26.0 - 2026-09-25

- Corrige o auto-scroll da aba Mensagens para preservar a posição quando o usuário está lendo mensagens antigas.
- Adiciona botão ↓ Novas mensagens quando chegam mensagens abaixo da posição atual.
- Preserva o ponto de leitura ao usar Carregar anteriores.
- Aumenta o tamanho dos emojis no seletor, no botão do compositor, no menu de reação e nos chips de reação.
- Corrige reação com HTTP 403 adicionando fallback automático: tenta tapback Meshtastic nativo e, quando somente o endpoint legado é recusado por permissão, envia resposta emoji compatível pela API v1 com replyId.
- Exibe no status quando a reação foi enviada em modo compatível.
- Separa a notificação sonora de mensagens do limitador dos sons de roteamento para torná-la audível mesmo com tráfego intenso.
- Torna a assinatura sonora de nova mensagem mais distinta nos temas Fliperama anos 70, Formal e Rádio / Telecom.
- Reações/tapbacks recebidos não geram notificação sonora de nova mensagem.

## 1.25.1 - 2026-09-25

- Mantém os recursos de replies, emojis, reações e animações simultâneas da v1.25.0.
- Corrige o manual PDF para evitar glifos quebrados em emojis não suportados pela fonte.
- Atualiza a seção de instalação do manual para usar Configurações > Atualizações em vez de exibir o comando do atualizador.

## 1.25.0 - 2026-09-25

- Adiciona reply estruturado de mensagens pelo `replyId` nativo do Meshtastic/MeshMonitor.
- Adiciona referência visual à mensagem original e opção para cancelar a resposta antes do envio.
- Adiciona seletor de emojis no compositor.
- Adiciona reações/tapbacks Meshtastic com `emoji=1` e `replyId`, incluindo 👍 👎 ❤️ 😂 😮 😢.
- Agrupa reações sob a mensagem original e oculta os pacotes de reação como linhas independentes.
- Ajusta a seleção de menção para usar `@` somente como gatilho de busca; o texto final contém apenas o nome do nó.
- Adiciona reprodução histórica concorrente, permitindo vários traceroutes em trânsito ao mesmo tempo.
- Mantém animações ao vivo concorrentes e remove limites artificiais das filas de traceroutes e de eventos pausados.
- Torna a velocidade dinâmica para animações já em execução.
- Adiciona contador de pacotes em trânsito/congelados no status do mapa.
- Preserva intervalos históricos curtos e comprime proporcionalmente janelas extensas para uma reprodução prática.
- Mantém a exigência de caminhos observados: nenhum hop intermediário é fabricado para animação.

## 1.24.1 - 2026-09-25

- Mantém todos os recursos funcionais da v1.24.0.
- Corrige o tema Silencioso para permanecer realmente sem áudio inclusive no teste.
- Permite sonorizar um relay observado logo após o lançamento quando a primeira observação da viagem já traz esse relay.
- Corrige o manual PDF para evitar glifos quadrados de bandeiras em fontes sem suporte a emoji.

## 1.24.0 - 2026-09-25

- Adiciona temas sonoros Fliperama anos 70, Formal, Rádio / Telecom e Silencioso.
- No tema Fliperama, diferencia lançamento do pacote, ricochete em relay observado, chegada/ACK, mensagem e falha.
- Sonoriza traceroutes hop a hop somente a partir dos caminhos efetivamente observados.
- Adiciona densidade sonora, intervalo mínimo, limite de sons simultâneos, filtros por tipo de evento e estéreo espacial opcional.
- Adiciona teste de tema com sequência demonstrativa.
- Adiciona som para novas mensagens e alerta para falha de envio.
- Remove o comando de atualização em linha do popup de informações da versão.
- Substitui Verificar agora por Continuar no popup de versão; o botão apenas fecha a janela.
- Mantém Ver Release no GitHub e Fechar no popup de novidades.
- Remove do popup o Markdown bruto da seção de screenshots das notas da Release.
- Garante seletor principal com 🇧🇷 Português e 🇺🇸 English, sem abreviações BR/US/ENG.

## 1.23.1 - 2026-09-25

- Corrige falha crítica de inicialização da interface da v1.23.0.
- Corrige a tabela de internacionalização, que continha uma entrada inválida por ausência de vírgula e interrompia o JavaScript antes da configuração das abas.
- Mantém smoke test em Chromium para validar a abertura e a navegação entre as principais abas antes de novas publicações.

## 1.23.0 - 2026-09-25

- Adiciona bandeiras do Brasil e dos Estados Unidos ao seletor de idioma.
- Remove o caractere @ das menções antes de transmitir a mensagem, preservando apenas o nome do nó.
- Adiciona controles visuais de fonte, negrito, itálico, sublinhado, altura de linha e espaçamento entre mensagens.
- Adiciona filtro de severidade na aba Anomalias: Todas, Críticas, Atenção e Informativas.
- Adiciona ajuste de espessura das linhas do mapa e restauração de cor/espessura ao padrão.
- Adiciona auto-update opcional por Latest Release estável, executado por serviço systemd dedicado.
- Adiciona verificação de saúde, lock contra atualizações simultâneas e rollback automático em caso de falha.
- Adiciona status de atualização, botão Atualizar agora e persistência das preferências de auto-update no servidor.
- Adiciona popup de novidades exibido uma única vez ao iniciar após uma atualização.
- O atualizador manual `traffic-analyzer-update` passa a usar a mesma cadeia segura de Latest Release estável do auto-update.

## 1.22.0 - 2026-09-24

- Adiciona internacionalização completa da interface em Português (PT-BR) e English (EN), mantendo PT-BR como padrão.
- Adiciona seletor de idioma no cabeçalho com persistência no navegador e troca imediata.
- Traduz navegação, configurações, abas, controles, filtros, status, legendas, tooltips, popups e painéis analíticos.
- Datas e números da interface passam a usar locale compatível com o idioma selecionado.
- Preserva nomes de nós, mensagens dos usuários, IDs, valores brutos de protocolo e notas de Release sem tradução artificial.
- Adiciona nova aba Ajuda/Help com instruções completas de uso do Traffic Analyzer.
- A Ajuda/Help cobre mapa, reprodução, pausa e backlog, Tracklog, Tráfego, Mensagens/@menções, Saúde da Rede, Anomalias, Configurações, idioma, atualização e limites de interpretação.
- Adiciona uma camada central de tradução com MutationObserver para também traduzir elementos criados dinamicamente.

## 1.21.0 - 2026-09-24

- Adiciona aba Tracklog com mapa histórico de deslocamento por estação.
- Cria tabela persistente `positions` em `traffic.db`, alimentada por pacotes POSITION_APP decodificados.
- Reconstrói posições antigas a partir do histórico de pacotes existente quando possível.
- Detecta mobilidade por deslocamento observado, ignora jitter submétrico e filtra saltos incompatíveis com deslocamento terrestre.
- Adiciona filtros de período, seleção de nó, enquadramento, distância acumulada e detalhes por ponto.
- Adiciona autocomplete de menções no chat ao digitar `@`, pesquisando short name, nome completo e node ID.
- Ao selecionar uma menção, substitui o atalho pelo nome completo do nó antes do envio.
- Destaca menções reconhecidas nos balões do chat.
- Mantém as correções de pausa/represamento, indicador de versão e tema claro/escuro da v1.20.0.

## 1.20.0 - 2026-09-24

- Corrige o represamento no modo Ao vivo: traceroutes incompletos não são mais marcados como vistos antes de se tornarem animáveis.
- Mantém polling, coleta e processamento durante a pausa; traceroutes completos ficam em fila e animações ativas permanecem congeladas.
- Amplia a fila de traceroutes ao vivo para 5.000 eventos e passa a informar descartes se o limite for atingido.
- Represa também pulsos de atividade visual recebidos durante a pausa e os libera ao retomar.
- Adiciona indicador de versão no topo com comparação contra a Latest Release do GitHub.
- Adiciona janela com notas da Release, link para o GitHub e comando de atualização.
- Adiciona tema Claro, mantendo Escuro como padrão, com persistência no navegador.
- Remove do resumo do mapa o aviso "Linhas = adjacências observadas, não enlaces permanentes".
- Mantém screenshots anonimizados no README e nas notas da Release.

## 1.19.0 - 2026-09-24

- Unifica os controles de reprodução e pausa em um único botão alternável ▶/⏸.
- No modo Ao vivo, a pausa continua afetando somente a animação, preservando coleta e processamento em segundo plano.
- Ao retomar o Ao vivo, traceroutes acumulados durante a pausa são iniciados simultaneamente.
- No Histórico, a pausa passa a congelar e retomar a animação exatamente do ponto atual.
- Ativa zoom fracionário no Leaflet com `zoomSnap=0.05` e `zoomDelta=0.25`.
- Refaz o comando Enquadrar para maximizar a ocupação da tela com margem aproximada de 6 px.
- O ajuste fino do enquadramento verifica os círculos dos nós e rótulos permanentes antes de aceitar um nível maior de zoom.
- Mantém screenshots anonimizados nas notas da Release e no README.


## 1.18.0 - 2026-09-23

- Pausa no modo Ao vivo congela somente a animação; coleta e processamento continuam ativos.
- Traceroutes represados iniciam simultaneamente ao retomar; animações em andamento continuam do ponto congelado.
- Auto Zoom desligado passa a bloquear enquadramentos automáticos de NodeInfo.
- Enquadrar usa margem fixa mínima de 22 px.
- Atualizar passa a regenerar a topologia imediatamente, com feedback visual.
- Removida a coluna Canal da tabela principal de Tráfego.
- Mensagens usam melhor a tela e ganham controle de tamanho de fonte em Configurações.
- Adicionados screenshots públicos anonimizados.
- Adicionado workflow de ZIP e Release formal marcada como Latest.


## v1.17.0 - 2026-09-23

- **Mensagens:** texto branco no campo de composição.
- **Mensagens:** pop-up de nova mensagem removido; permanecem somente contador e destaque piscante na aba superior enquanto houver não lidas.
- **Mensagens:** adicionada ação explícita **Carregar anteriores**, com preservação da posição de leitura.
- **Mensagens:** botão **Atualizar** passa a forçar consulta imediata com feedback visual.
- **Saúde da Rede:** ranking acumulado de interações por chat no canal primário, ordenado em ordem decrescente.
- **Distribuição:** atualização Git sem prompt de autenticação e documentação de download/instalação via ZIP.


## 1.16.0 - 2026-09-23

- Adicionada aba Mensagens para o canal primário (0), com interface de chat.
- Adicionados GET `/api/messages` e POST `/api/messages/send` no backend local do Traffic Analyzer.
- Envio é feito server-side para `/api/v1/sources/{sourceId}/messages`; o token MeshMonitor não é exposto ao navegador.
- Adicionados pop-up de nova mensagem, contador de não lidas e animação da aba Mensagens.
- Estados de entrega respeitam semântica real do MeshMonitor: `delivered` = transmitida à malha e `confirmed` = ACK do protocolo; não há recibo de leitura humana em broadcast.
- Mantidas as abas Saúde da Rede e Anomalias e o tempo amigável de última audição no popup dos nós.
- Manual PDF teve tabelas reconstruídas para evitar textos sobrepostos.

## 1.15.0 - 2026-09-23

- Adicionadas as abas superiores **Saúde da Rede** e **Anomalias**.
- Saúde da Rede consolida atividade de nós, tráfego 24 h, enlaces, traceroutes, hops, série dos últimos 7 dias e nós silenciosos.
- Detecção de Anomalias adiciona heurísticas de silêncio >24 h/>7 dias, degradação de SNR, mudança de hops e traceroute assimétrico.
- Adicionados `/api/network-health` e `/api/anomalies` para consumo pela interface e pelo futuro relatório.
- Popup de nó agora informa há quanto tempo ocorreu o último tráfego observado.
- Adicionado `update.sh` e o comando instalado `traffic-analyzer-update` para atualização direta pelo GitHub.
- Mantido OSM como mapa padrão e preservadas todas as funções de tráfego, arquivo histórico e traceroute da v1.14.0.

## 1.14.0

- Remove completamente do Traffic Analyzer o recurso **Remover nó**, incluindo botão do popup, endpoint local de exclusão e proxy destrutivo para o MeshMonitor. A exclusão volta a ser responsabilidade exclusiva do próprio MeshMonitor.
- Define **Ruas (OpenStreetMap / OSM)** como mapa-base padrão. A migração da v1.14.0 troca o antigo padrão Satélite por OSM uma única vez; escolhas manuais posteriores continuam persistidas.
- Simplifica o cabeçalho e remove a linha `gerado em ... · fonte ...`.
- Atualiza o título padrão para **Traffic Analyzer v1.14.0 - MeshMonitor - por Alex, PT2VHF**.
- Mantém o painel de traceroute com origem/destino e distâncias de ida, volta e total, sem estimar segmentos sem coordenadas.
- Mantém o diretório de instalação/extração fixo `traffic-analyzer/`, embora o arquivo ZIP continue versionado.
- Atualiza documentação, exemplos de configuração e instalador para a nova versão.

## 1.13.0

- Corrige o botão **Remover nó** para usar a rota real do MeshMonitor 4.16.x: `DELETE /api/messages/nodes/:nodeNum?sourceId=<fonte>`.
- Mantém a exclusão restrita ao banco local do MeshMonitor da fonte configurada e preserva o histórico já arquivado em `traffic.db`.
- Converte erros `401`, `403` e `404` de remoção em mensagens amigáveis; respostas HTML do MeshMonitor não são mais despejadas na interface.
- Informa especificamente quando o token não possui `messages:write`, quando o nó já não existe e quando o endpoint de remoção não é suportado.
- Após exclusão confirmada, poda imediatamente nó, adjacências e traceroutes correspondentes do `topology.json` e recarrega a interface.
- Padroniza o pacote para extrair sempre no diretório **`traffic-analyzer/`**, mantendo o ZIP versionado sem acumular uma pasta de trabalho diferente para cada release.
- Mantém cores de atividade: verde até 2 h, laranja entre 2 e 24 h, vermelho acima de 24 h e cinza sem timestamp confiável.
- Mantém firmware removido, Dados técnicos amigáveis, dump JSON, arquivo SQLite, traceroutes concorrentes, Auto Zoom, pulsos e sons por viagem.
- Adiciona um painel discreto durante traceroutes animados, exibindo origem e destino, distância direta, distância total da IDA, distância total da VOLTA e o total combinado ida + volta quando ambas as pernas são conhecidas.
- Em traceroutes simultâneos, mantém uma entrada independente por animação ativa; distâncias são calculadas apenas a partir dos hops com coordenadas conhecidas, sem estimar lacunas.

## 1.12.0

- Colore os nós do mapa pela recência de atividade observada: **verde** para tráfego nas últimas 2 horas, **laranja** entre 2 e 24 horas e **vermelho** para atividade mais antiga que 24 horas; nós sem timestamp confiável ficam cinza.
- A recência usa o maior timestamp disponível entre o arquivo histórico do Traffic Analyzer (`/api/archive/nodes`) e `lastHeard` do MeshMonitor, evitando depender apenas dos pacotes carregados no navegador.
- Atualiza a legenda do mapa para explicar as faixas de atividade por tempo.
- Adiciona **Remover nó** ao popup de cada nó. A ação pede confirmação e remove o nó do banco local do MeshMonitor para a fonte configurada, preservando o histórico já arquivado em `traffic.db`.
- Após remoção bem-sucedida, o nó e as adjacências correspondentes são retirados imediatamente da topologia local; se o nó voltar a ser ouvido pelo MeshMonitor, ele poderá reaparecer.
- A remoção depende de o token configurado no Traffic Analyzer possuir a permissão de escrita exigida pelo MeshMonitor; falhas de autorização são apresentadas na interface.
- Remove totalmente a informação de **firmware** dos dados gerados e do popup dos nós, pois essa informação não é obtida de forma confiável para os nós remotos.
- Mantém Dados técnicos em formato amigável, dump JSON, histórico SQLite, Ao vivo por padrão, traceroutes concorrentes, Auto Zoom, pulsos e sons por viagem.

## 1.11.0

- Reformula a seção **Dados técnicos** do detalhe de pacote para apresentar os metadados em formato amigável, com pares rótulo/valor em vez de JSON bruto como visualização principal.
- Adiciona nomes legíveis para campos comuns, incluindo ID do pacote, tipo de telemetria, destino, direção, canal, relay, transporte, horário de recepção e indicadores MQTT.
- Destinos numéricos passam a ser exibidos como Node ID hexadecimal e, quando o nó está presente na topologia, com o nome conhecido do nó.
- Valores técnicos reconhecidos reutilizam a formatação amigável de unidades, datas, booleanos, SNR/RSSI, tensão, bateria, temperatura, umidade e pressão.
- `decoded_payload` não é duplicado em Dados técnicos, pois já aparece na seção Payload em formato amigável.
- Mantém **Ver JSON bruto** somente como diagnóstico secundário e recolhido, para troubleshooting avançado.
- Preserva integralmente os recursos da v1.10.0: dump JSON completo em ZIP, histórico SQLite, Ao vivo por padrão, traceroutes concorrentes, Auto Zoom e realce de atividade.

## 1.10.0

- Exibe a versão instalada ao lado do nome **Traffic Analyzer** no cabeçalho superior e também no título da página do navegador; o servidor lê o arquivo `VERSION` instalado para reduzir risco de divergência entre interface e pacote.
- Adiciona o botão **Baixar dump JSON (.zip)** na aba Tráfego.
- O dump contém todo o histórico persistente em um único `traffic.json`, compactado em ZIP, sem o limite de 100.000 linhas do endpoint de exportação tabular.
- O JSON inclui metadados da exportação: versão, horário de geração, fonte, quantidade de pacotes, primeiro/último timestamp, versão do esquema e aviso de privacidade.
- A geração do dump é feita por streaming para o ZIP e por lotes de SQLite, evitando carregar todo o histórico em memória.
- Adiciona `GET /api/archive/dump` com `Content-Disposition` para integração com outras ferramentas.
- Mantém a política de privacidade: mensagens diretas `TEXT_MESSAGE_APP` já chegam ao arquivo com conteúdo e metadata sensível removidos; o dump não reintroduz esses dados.
- Corrige o procedimento genérico de instalação/atualização: o bloco passa a localizar o ZIP em diretórios pessoais comuns (`$PWD`, `$HOME`, `/home` e `/root`) e funciona também quando o administrador está logado diretamente como `root`.
- O instalador passa a copiar o arquivo `VERSION` para `/opt/traffic-analyzer`, usado pelo cabeçalho da aplicação.
- Preserva os recursos da v1.9.0: Ao vivo por padrão, traceroutes concorrentes, Auto Zoom, pulsos de atividade e arquivo histórico SQLite.

## 1.9.0

- Define **Ao vivo** como modo padrão de reprodução do mapa e inicia o polling de novos traceroutes automaticamente ao abrir a interface.
- Permite **múltiplas animações de traceroute simultâneas**: um novo traceroute começa imediatamente mesmo que outro ainda esteja em curso; nenhuma animação ao vivo entra em fila aguardando a anterior terminar.
- Adiciona **Auto Zoom opcional para traceroutes**: ao iniciar uma animação, enquadra os nós envolvidos; com traceroutes simultâneos usa a área combinada e, 5 segundos após a última animação terminar, retorna ao enquadramento anterior.
- Mantém a animação ao longo das linhas de traceroute e acrescenta pulso visual nos nós conhecidos à medida que o marcador alcança origem, relays e destino/resposta.
- Amplia o realce de atividade para tráfego comum: cada pacote observado pode realçar o nó transmissor/resposta e o `relay_node` quando ele puder ser resolvido sem ambiguidade.
- Mantém a regra de não inventar hops ou relays intermediários quando o Packet Monitor não fornece evidência suficiente.
- Mantém sons separados da animação visual: o som toca somente na primeira observação de uma **nova viagem de pacote**, e cópias/retransmissões do mesmo `packet_id` não geram novos sons.
- Adiciona arquivo histórico persistente SQLite em `/var/lib/traffic-analyzer/traffic.db`, preservado entre reinicializações e atualizações.
- Na primeira execução, importa todo o tráfego ainda retido no Packet Monitor; depois sincroniza continuamente novos registros com sobreposição temporal, duas passagens por janela e deduplicação.
- Preserva a privacidade no arquivo: conteúdo e metadata de `TEXT_MESSAGE_APP` direto são removidos antes da persistência; broadcast continua disponível quando decodificado.
- Adiciona API para integração com geradores de relatório: `/api/archive/status`, `/api/archive/packets`, `/api/archive/stats`, `/api/archive/nodes`, `/api/archive/links` e `/api/archive/export` (JSONL ou CSV).
- O endpoint `/health` passa a incluir o estado do arquivo histórico.
- O serviço web passa a usar o usuário de sistema dedicado `traffic-analyzer`, com escrita restrita ao diretório persistente necessário.
- O instalador preserva `traffic.db`, acrescenta automaticamente as novas variáveis de arquivo histórico em instalações existentes e não depende de `/home/painel` nem de outro nome de usuário específico.
- Padroniza os exemplos para começar em `cd ~` e funcionar a partir do home corrente.
- Ao final da instalação, o próprio `install.sh` executa `systemctl status traffic-analyzer.timer --no-pager` e `systemctl status traffic-analyzer-map.service --no-pager`.
- Mantém o ajuste da v1.8.0 para colunas compactas na aba Tráfego e painel de detalhes usando o restante da largura disponível.

## 1.8.0

- Ajusta a aba **Tráfego** para usar colunas compactas e de largura previsível; o painel de detalhes passa a ocupar o restante da largura disponível.
- Mantém rolagem horizontal em telas menores e oculta o painel lateral quando a largura não comporta as duas áreas com legibilidade.
- Adiciona animação de **atividade em tempo real** no mapa, independente dos traceroutes.
- Realça a origem/resposta de uma nova viagem com pulso e ícone de rádio.
- Realça o `relay_node` observado com pulso amarelo quando ele pode ser resolvido sem ambiguidade para um nó posicionado.
- Não inventa relays intermediários quando o byte de relay é ambíguo ou não há posição.
- Adiciona controles em Configurações para ligar/desligar a animação, origem/resposta, retransmissor e duração do pulso.
- Altera as notificações sonoras: o áudio toca apenas no **início de uma nova viagem de pacote**, não para cada cópia/retransmissão observada.
- Usa `packet_id` (ou ID no metadata) para deduplicar a mesma viagem sonora; TX interno sem ID continua sendo tratado como nova viagem individual.
- Mantém os cinco timbres, volume e botão de teste.
- Atualiza documentação e manual com a distinção entre **som por viagem** e **animação por atividade observável**.

## 1.7.0

- Move os controles de visualização do mapa para a aba **Configurações**: janela temporal, mínimo de observações, mapa-base, brilho, cor das linhas, linhas, nós, mapa de calor, nomes curtos e somente identificados.
- Mantém no mapa apenas os comandos operacionais **Enquadrar** e **Atualizar**, junto da barra de reprodução.
- Remove a mensagem **"aguardando novo traceroute"** do modo Ao vivo; o estado ocioso passa a mostrar somente **AO VIVO**.
- Adiciona cinco perfis de som de notificação sintetizados localmente: **Plim, Campainha, Click, Duplo e Suave**.
- Mantém volume, filtro RX/TX, botão de teste e proteção anti-spam sonora.
- Mensagens `TEXT_MESSAGE_APP` em **broadcast** passam a exibir o payload no detalhe do pacote.
- Mensagens diretas continuam com o conteúdo oculto por padrão no proxy web.
- Payloads decodificados dos demais tipos passam a ser exibidos em formato amigável, com rótulos e unidades quando reconhecidos, em vez de JSON como visualização principal.
- O JSON bruto continua disponível de forma secundária, recolhido em **Dados técnicos**.
- Preferências de mapa antes posicionadas no cabeçalho passam a ser persistidas junto das demais preferências locais.
- Manual revisado para evitar extrapolação de textos em diagramas/caixas.
- O PDF agora termina com uma seção **Changelog** detalhada, sincronizada com este arquivo.

## 1.6.0

- Adiciona visualização automática de fluxo para NodeInfo dirigido.
- Pedidos NodeInfo TX registrados pelo MeshMonitor são reconhecidos imediatamente.
- NodeInfo RX remoto usa correlação ida/volta para evitar chamar toda mensagem dirigida de pedido.
- Procura traceroute completo entre os mesmos endpoints dentro de uma janela temporal de 180 s.
- Quando existe evidência, anima o fluxo pelos hops observados no traceroute.
- Quando não existe, desenha apenas linha lógica tracejada e não inventa relays.
- Adiciona botão **Mostrar fluxo** ao detalhe de NodeInfo.
- Adiciona preferência para ligar/desligar fluxo NodeInfo no mapa.
- Corrige a diagramação inicial do manual, ampliando caixas e aplicando quebra de linha controlada.

## 1.5.0

- Renomeia a aplicação para **Traffic Analyzer**.
- Adiciona aba **Tráfego** com Packet Monitor RX/TX em tempo quase real.
- Adiciona filtros, detalhes de pacote, contadores e som "plim" configurável.
- Mantém mapa/topologia/traceroutes da série anterior e migração automática.

## 1.4.0

- Adiciona reprodução cronológica de traceroutes em modo Histórico e Ao vivo.
- Anima ida e volta com velocidade visual constante e sem pausa nos nós.
- Adiciona janela **Todos** e aumenta o limite padrão de traceroutes carregados.
- Passa a preservar lacunas quando um hop é desconhecido, evitando criar adjacências RF falsas.
- Adiciona eventos por enlace para estatísticas filtradas pela janela temporal.

## 1.3.0

- Adiciona mapa de calor de atividade de roteamento.
- Adiciona controles independentes de linhas e círculos dos nós.
- Consolida manual técnico dentro do ZIP.

## 1.2.0 - 1.2.2

- Adiciona escolha de mapa-base, brilho, cor de linhas e nomes curtos.
- Define Satélite como mapa padrão e amarelo como cor padrão dos enlaces.

## 1.1.0 - 1.1.1

- Adiciona `topology.json` e interface web separada na porta 8788.
- Corrige carregamento do Leaflet e redimensionamento inicial do mapa.

## 1.0.0

- Primeira versão do serviço de descoberta por traceroutes.
- Descobre hops intermediários e classifica nós identificados, stubs e route-only.
- Implementa solicitação controlada de NodeInfo com cooldown e limite de tentativas.
